package com.isimpo.tech.framework.applet.service.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraEvaluate;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraStaCommon;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraStaffEvaluate;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip.TraEvaluateMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TraEvaluService extends BaseService<TraEvaluateMapper, TraEvaluate> {

    /**
     * 增加
     * @param traStaCommon
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse add(TraStaCommon traStaCommon){
        EntityUtils.setCreatAndUpdatInfo(traStaCommon.getTraEvaluate());
        List<TraStaffEvaluate> list = traStaCommon.getTraStaffEvaluateList();
        list.stream().forEach(s -> EntityUtils.setCreatAndUpdatInfo(s));
        int num = mapper.insertTraEval(traStaCommon.getTraEvaluate());
        int result = mapper.insertTraStaffEval(list);
        if  (num > 0 && result > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    public TraStaCommon getTraEvalu(TraEvaluate entity){
        TraStaCommon traStaCommon = new TraStaCommon();
        TraEvaluate traEvaluate= mapper.getTraEvalu(entity);
        List<TraStaffEvaluate> traStaffEvaluate = mapper.findTraStaff(entity);
        traStaCommon.setTraStaffEvaluateList(traStaffEvaluate);
        traStaCommon.setTraEvaluate(traEvaluate);
        return traStaCommon;
    }
}
