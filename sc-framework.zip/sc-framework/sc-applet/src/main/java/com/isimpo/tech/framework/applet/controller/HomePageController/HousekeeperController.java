/*
* Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
* SIMPO Technology. CONFIDENTIAL
*/
package com.isimpo.tech.framework.applet.controller.HomePageController;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Housekeeper;
import com.isimpo.tech.framework.applet.auto.entity.homePage.IndexPic;
import com.isimpo.tech.framework.applet.service.homePage.HousekeeperService;
import com.isimpo.tech.framework.applet.service.homePage.IndexPicService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zx
 * @version 1.0
 * @since 2018/4/24
 */
@RestController
@RequestMapping("/homePage/housekeeper")
public class HousekeeperController extends BaseController<HousekeeperService, Housekeeper> {
}
