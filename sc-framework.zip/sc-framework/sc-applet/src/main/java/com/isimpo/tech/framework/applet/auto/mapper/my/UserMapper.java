package com.isimpo.tech.framework.applet.auto.mapper.my;

import com.isimpo.tech.framework.applet.auto.entity.my.CardVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;

import tk.mybatis.mapper.common.Mapper;

/**
 * 用户信息
 * @author Tank
 * @version V1.0
 * @since 2019/2/26
 *
 */
public interface UserMapper extends Mapper<UserInfoVo> {

    /**
     * 查询可乐名片消息
     * @param user
     * @return int
     */
    int updateUserInfo(UserInfoVo user);
}
