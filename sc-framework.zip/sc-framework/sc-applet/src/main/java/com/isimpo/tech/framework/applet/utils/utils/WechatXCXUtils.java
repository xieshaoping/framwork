/*
 * Copyright (c) 2018, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.isimpo.tech.framework.applet.utils.WechatConstants;
import com.isimpo.tech.framework.applet.utils.wxQrcode.QrCodeInfo;
import com.isimpo.tech.framework.applet.utils.wxQrcode.Token;
import com.isimpo.tech.framework.common.util.CacheUtils;
import com.xiaoleilu.hutool.util.RandomUtil;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Chen.XinBang
 * @version 1.0
 * @since 2018年09月28日
 */
public class WechatXCXUtils {

    /**
     * 创建二维码
     */
    public final static String wechat_qrcode_create_url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=#ACCESS_TOKEN#";
    /**
     * 获取微信API全局凭证 url
     */
    public static final String WECHAT_TOKEN_URL =
            "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=#APPID#&secret=#APPSECRET#";
    /**
     * 登录凭证校验
     */
    public static final String GETUSER_URL="https://api.weixin.qq.com/sns/jscode2session";
    private static final String ALL_MEDIA_URL =
            "https://api.weixin.qq.com/cgi-bin/material/batchget_material?access_token=#ACCESS_TOKEN#";

    /**
     * 上传图片接口
     */
    public static final String UPLOAD_URL="https://xcx.isimpo.cn/rc/upload/getProgramCode";

    public static final String ROOT="/home/project/klgl/files";
    public static final String PATH="qrcode/";
    public static final String HEAD_PATH="/head/";

    public static final String APPID = "#APPID#";
    public static final String APPSECRET = "#APPSECRET#";

    //小程序  //体验 wx2e8565b61b79ab2b   //生产 wx3176b3183271cf6f
    public static final String APPID_VAL = "wx3176b3183271cf6f";
    //public static final String APPID_VAL = "wx2e8565b61b79ab2b";
    //体验 6b825b169e80c777e73bbc3ae179c480 //生产 56abd3bdadee6901ba7c35820244b9c4
    public static final String APPSECRET_VAL = "56abd3bdadee6901ba7c35820244b9c4";
    //public static final String APPSECRET_VAL = "6b825b169e80c777e73bbc3ae179c480";

    //微信公众号
    //多磨川测试
//    public static final String WX_APPID_VAL = "wx389de081fded42f0";
//    public static final String WX_APPSECRET_VAL = "ca83f6a50dbbe6d081bda1cf0030110d";
    //日程共享
    public static final String WX_APPID_VAL = "wx3176b3183271cf6f";
    public static final String WX_APPSECRET_VAL = "56abd3bdadee6901ba7c35820244b9c4";

    public static final String UTF_8 = "UTF-8";


    protected static final Logger log = LoggerFactory.getLogger(WechatXCXUtils.class);


    /**
     * 动态生成二维码
     * @param uui 参数
     * @param page 跳转地址
     * @return
     */
    public static String getQrCode(String uui,String page) {
        // 生成二维码
        QrCodeInfo imgInfo = new QrCodeInfo();
        //参数
        imgInfo.setScene(uui);
        imgInfo.setPage(page);
        imgInfo.setWidth(430);
        return saveQrCode(imgInfo);

    }

    /**
     * 生成带参的二维码并保存到服务器
     *
     * @param qc 二维码vo
     */
    public static String saveQrCode(QrCodeInfo qc) {
        // TODO: 2018/9/29  参数要改
        String json = JSON.toJSONString(qc);
         json = json.replace("hyaline", "is_hyaline");
        //获取token
        String access_token = getToken().getAccess_token();
        String js = "{\"is_hyaline\":false,\"auto_color\":false,\"line_color\":null,\"scene\":\"1212111\",\"width\":430}";
        //获取二维码
        Map<String, Object> map = createQrCode(access_token, json,qc.getScene());
        return (String) map.get("imgPath");
    }


    /**
     * 生成带参的小程序码并保存到服务器
     *@param uui 参数
     * @param page 跳转地址
     */
    public static String saveCodePic(String uui,String page) {
        // 生成二维码
        QrCodeInfo imgInfo = new QrCodeInfo();
        //参数
        imgInfo.setScene(uui);
        imgInfo.setPage(page);
        imgInfo.setWidth(430);

        String json = JSON.toJSONString(imgInfo);
        json = json.replace("hyaline", "is_hyaline");
        //获取token
        String access_token = getToken().getAccess_token();
        //获取二维码
        Map<String, Object> resultMap = new HashMap<String, Object>();
        String requestUrl = wechat_qrcode_create_url.replace("#ACCESS_TOKEN", access_token);
        Map<String,String> map=new HashedMap<>();
        map.put("url",requestUrl);
        map.put("json",json);
        String result = HttpClientUtils.sendPostRequest(UPLOAD_URL, map, UTF_8, UTF_8);

        return result;
    }

    /**
     * 获取token
     *
     * @return
     */
    public static Token getToken() {
        //Token token =CacheUtils.get(WechatConstants.ACCESS_TOKEN, Token.class);
        //if (token == null) {
        Token token = makeToken();
            CacheUtils.set(WechatConstants.ACCESS_TOKEN, token, 6000);
        //}
        return token;
    }

    public static Token makeToken() {
        Token token;
        String requestUrl = WECHAT_TOKEN_URL.replace(APPID, APPID_VAL).replace(APPSECRET, APPSECRET_VAL);
        // 发起GET请求获取凭证
        String re = HttpClientUtils.sendGetRequest(requestUrl, UTF_8);
        if (re == null || re.length() == 0) {
            log.error("微信token获取失败，请求无响应");
            return null;
        }
        token = JSON.parseObject(re, Token.class);
        if (StringUtils.isEmpty(token.getAccess_token())) {
            log.error("微信token获取失败，errorCode：{}, errorMsg：{}", token.getErrcode(), token.getErrmsg());
            return null;
        }
        return token;
    }

    /**
     * 获取token
     *
     * @return
     */
    public static Token getWXToken() {
        Token token = CacheUtils.get(WechatConstants.WX_ACCESS_TOKEN, Token.class);
        if (token == null) {
            token = makeWXToken();
        } else {
            log.info("当前凭证是:{}", token.getAccess_token());
            long var72 = Long.parseLong(CacheUtils.getString(WechatConstants.WX_ALL_ACCESS_TOKEN_CREATE_TIME));
            log.info("上一次获取凭证的时间是" + new Date(var72) + ",毫秒数是" + var72);
            if ((long) (token.getExpires_in() * 1000) - ((new Date()).getTime() - var72) <= 1800000L) {
                token = makeWXToken();
            }
        }
        return token;
    }

    public static Token makeWXToken() {
        Token token;
        String requestUrl = WECHAT_TOKEN_URL.replace(APPID, WX_APPID_VAL).replace(APPSECRET, WX_APPSECRET_VAL);
        // 发起GET请求获取凭证
        String re = HttpClientUtils.sendGetRequest(requestUrl, UTF_8);
        if (re == null || re.length() == 0) {
            log.error("微信token获取失败，请求无响应");
            return null;
        }
        token = JSON.parseObject(re, Token.class);
        if (StringUtils.isEmpty(token.getAccess_token())) {
            log.error("微信token获取失败，errorCode：{}, errorMsg：{}", token.getErrcode(), token.getErrmsg());
            return null;
        }
        log.error("获取token成功》》》》》》:{}",token);
        try {
            CacheUtils.set(WechatConstants.WX_ACCESS_TOKEN, token, WechatConstants.ACCESS_TOKEN_EXPIRED_TIME);
            CacheUtils.set(WechatConstants.WX_ALL_ACCESS_TOKEN_CREATE_TIME, Long.valueOf((new Date()).getTime()), WechatConstants.ACCESS_TOKEN_EXPIRED_TIME);
            log.info("当前凭证是:{}", token.getAccess_token());
        } catch (Exception var71) {
            log.error("获取token失败 return:{}",token);
        }
        return token;
    }

    /**
     * 创建二维码ticket
     *
     * @param accessToken
     * @param jsonMsg
     * @return
     */
    public static Map<String, Object> createQrCode(String accessToken, String jsonMsg,String id) {

        Map<String, Object> resultMap = new HashMap<String, Object>();
        String requestUrl = wechat_qrcode_create_url.replace("#ACCESS_TOKEN", accessToken);
        try {
            CreateImgUtil.httpPostWithJSON(requestUrl, jsonMsg, id+".png",ROOT+PATH);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        resultMap.put("imgPath", PATH+id+".png");
        return resultMap;

    }

    /**
     * 获取用户信息
     * @param code
     * @return
     */
    public static Map decodeUserInfo(String code) {
        Map map = new HashMap();
        //登录凭证不能为空
        if (code == null || code.length() == 0) {
            map.put("status", 0);
            map.put("msg", "code 不能为空");
            return map;
        }
        //授权（必填）
        String grant_type = "authorization_code";
        // 1、向微信服务器 使用登录凭证 code 获取 session_key 和 openid    //请求参数
        String params = "?appid=" + APPID_VAL + "&secret=" + APPSECRET_VAL + "&js_code=" + code + "&grant_type=" + grant_type;
        //发送请求
        String sr = HttpClientUtils.sendGetRequest(GETUSER_URL+params,UTF_8);
        //解析相应内容（转换成json对象）
        JSONObject json = JSONObject.parseObject(sr);
        //获取会话密钥（session_key）
        //用户的唯一标识（openid）
        String openid = (String) json.get("openid");
        String unionId=(String)json.get("unionId");
        if(StringUtils.isEmpty(openid)){
            map.put("status", 0);
            map.put("msg", "请求失败！");
        }else {
            map.put("status",1);
            map.put("openId", openid);
            map.put("unionId",unionId);
        }

        return map;
    }

    /**
     * 保存头像
     * @param headImgUrl
     * @return
     */
    public static String saveHeadStream(String headImgUrl,String path){
        //保存到本地的图片
        try (InputStream stream = HttpClientUtils.getUrlInputStream(headImgUrl)) {
            //保存用户头像
            String pngName = RandomUtil.simpleUUID();
            int nu = CreateImgUtil.saveToImgByInputStream(stream, path + HEAD_PATH, pngName + ".png");
            if(nu>0){
                return HEAD_PATH + pngName + ".png";
            }
        } catch (Exception ex) {
        }
        return null;
    }

    /**
     *
     * @param type 素材的类型，图片（image）、视频（video）、语音 （voice）、图文（news）
     * @param offset 从全部素材的该偏移位置开始返回，0表示从第一个素材 返回
     * @param count 返回素材的数量，取值在1到20之间
     * @return
     */
    public static String getAllMedia(String type, String offset, String count) {
        String accessToken=getWXToken().getAccess_token();
        String result = "";
        String getAllMediaUrl = ALL_MEDIA_URL.replace(WechatConstants.ACCESS_TOKEN, accessToken);
        //String mediaJson = "{\"type\":\"" + type + "\",\"offset\":" + offset + ",\"count\":" + count + "}";
       Map<String,String> map=new HashedMap<>();
        map.put("type",type);
        map.put("offset",offset);
        map.put("count",count);
        result = HttpClientUtils.sendPostRequest(getAllMediaUrl, map, UTF_8, UTF_8);
        return result;
    }
    /**
     2      * 获取素材列表并存入集合中
     3      * @param accessToken 获取接口凭证的唯一标识
     4      * @param type 素材的类型，图片（image）、视频（video）、语音 （voice）、图文（news）
     5      * @param offset 从全部素材的该偏移位置开始返回，0表示从第一个素材 返回
     6      * @param count 返回素材的数量，取值在1到20之间
     7      * @return
     8      */
    /*public static Map<String,Object> getMaterial(String type, String offset, String count) {
        Map<String,String> map=new HashedMap<>();
        Map<String,Object> reMap=new HashedMap<>();
        List<Material> lists = new ArrayList<Material>();//定义图文素材实体类集合
        String accessToken=getWXToken().getAccess_token();
        String result = "";
        String getAllMediaUrl = ALL_MEDIA_URL.replace(WechatConstants.ACCESS_TOKEN, accessToken);
        String mediaJson = "{\"type\":\"" + type + "\",\"offset\":" + offset + ",\"count\":" + count + "}";
        map.put("type",type);
        map.put("offset",offset);
        map.put("count",count);
        result = HttpClientUtils.sendPostRequest(getAllMediaUrl, mediaJson, UTF_8, UTF_8);
        JSONObject jsonObject=JSON.parseObject(result);
        // 如果请求成功
        if (null != jsonObject) {
            try {
                reMap.put("total_count",jsonObject.get("total_count"));
                reMap.put("item_count",jsonObject.get("item_count"));
                Material material;
                JSONArray jsonArray = jsonObject.getJSONArray("item");
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject json = (JSONObject) jsonArray.get(i);
                    //String updateTime = json.getString("update_time");
                    json = json.getJSONObject("content");
                    String updateTime = json.getString("create_time");
                    //格式化
                    if(StringUtils.isNotEmpty(updateTime)){
                        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.DATE_FORMAT_DAY);
                        updateTime=sdf.format(new Date(Long.valueOf(updateTime+"000")));
                    }
                    JSONArray arr = json.getJSONArray("news_item");
                    json = (JSONObject) arr.get(0);
                    material = new Material();
                    String title = json.getString("title");
                    String author = json.getString("author");
                    String digest = json.getString("digest");
                    String thumb_media_id = json.getString("thumb_media_id");
                    //System.out.println(thumb_media_id);
                    String url = json.getString("url");
                    String content = json.getString("content");
                    //去除html标签
                    content = removeHtml(content);
                    material.setTitle(title);
                    material.setAuthor(author);
                    material.setDigest(digest);
                    material.setThumbMediaId(thumb_media_id);
                    material.setUrl(url);
                    material.setContent(content);
                    material.setUpdateTime(updateTime);
                    lists.add(material);
                }
            } catch (Exception e) {

                // 获取Material失败
                log.error("获取Material失败 errcode:{} errmsg:{}", jsonObject.get("errcode"), jsonObject.getString("errmsg"));
            }
        }
        reMap.put("list",lists);
        return reMap;
    }*/

    //从html中提取纯文本
    public static String removeHtml(String inputString) {
        String htmlStr = inputString; // 含html标签的字符串
        String textStr = "";
        Pattern p_script;
        Matcher m_script;
        Pattern p_style;
        Matcher m_style;
        Pattern p_html;
        Matcher m_html;
        try {
            String regEx_script = "<[\\s]*?script[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?script[\\s]*?>"; // 定义script的正则表达式{或<script[^>]*?>[\\s\\S]*?<\\/script>
            String regEx_style = "<[\\s]*?style[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?style[\\s]*?>"; // 定义style的正则表达式{或<style[^>]*?>[\\s\\S]*?<\\/style>
            String regEx_html = "<[^>]+>"; // 定义HTML标签的正则表达式
            p_script = Pattern.compile(regEx_script, Pattern.CASE_INSENSITIVE);
            m_script = p_script.matcher(htmlStr);
            htmlStr = m_script.replaceAll(""); // 过滤script标签
            p_style = Pattern.compile(regEx_style, Pattern.CASE_INSENSITIVE);
            m_style = p_style.matcher(htmlStr);
            htmlStr = m_style.replaceAll(""); // 过滤style标签
            p_html = Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE);
            m_html = p_html.matcher(htmlStr);
            htmlStr = m_html.replaceAll(""); // 过滤html标签
            htmlStr = htmlStr.replaceAll("&nbsp;", "");
            textStr = htmlStr;
        } catch (Exception e) {
            System.err.println("removeHtml: " + e.getMessage());
        }
        //剔除空格行
        textStr = textStr.replaceAll("[ ]+", " ");
        textStr = textStr.replaceAll("(?m)^\\s*$(\\n|\\r\\n)", "");
        return textStr;// 返回文本字符串
    }





}
