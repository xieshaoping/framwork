package com.isimpo.tech.framework.applet.auto.mapper.resound;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.strategy.StrategyVo;
import com.isimpo.tech.framework.common.util.Query;

import tk.mybatis.mapper.common.Mapper;

/**
 * 旅咖说
 * @author Tank
 * @version V1.0
 * @since 2019/2/18
 *
 */
public interface StrategyMapper extends Mapper<StrategyVo> {
    /**
     * 查询攻略列表
     * @param query
     * @return
     */
    List<StrategyVo> getStrategyList(Query query);

    /**
     * 根据id查询攻略详情
     * @param id
     */
    StrategyVo getStrategyDetailById(String id);


    /**
     * 根据攻略id查询点赞记录列表
     * @param mainId
     * @return
     */
    List<PraiseRecordVo> listPraiseRecordById(String mainId);


    /**
     * 根据攻略id查询评论列表
     * @param mainId
     * @return
     */
    List<CommentVo> listCommentById(String mainId);

    /**
     * 添加点赞记录
     * @param praiseRecord
     * @return
     */
    int addPraiseRecord(PraiseRecordVo praiseRecord);

    /**
     * 删除点赞记录
     * @param praiseRecord
     * @return
     */
    int delPraiseRecord(PraiseRecordVo praiseRecord);

    /**
     * 添加攻略
     * @param strategy
     * @return
     */
    int addStrategy(StrategyVo strategy);

    /**
     * 根据id删除攻略
     * @param strategy
     * @return int
     */
    int delStrategy(StrategyVo strategy);

    /**
     * 查询当前用户是否已点赞
     * @param mainId-旅咖说的id
     * @param memId -当前用户di
     * @return
     */
    int checkPraise(@Param("mainId") String mainId,@Param("memId") String memId);

    /**
     * 添加评论
     * @param comment
     * @return
     */
    int addComment(CommentVo comment);

    /**
     * 删除评论
     * @param comment
     * @return
     */
    int delComment(CommentVo comment);

    /**
     * 检查是否存在攻略
     * @param memId
     * @return int
     */
    int checkExist(String memId);
}
