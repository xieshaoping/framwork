/*
 * @(#) EAlbumsMapper.java 2019年02月14日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.mapper.ealbums;

import com.isimpo.tech.framework.applet.auto.entity.ealbums.AlbumPicVo;
import com.isimpo.tech.framework.applet.auto.entity.ealbums.AlbumVo;
import com.isimpo.tech.framework.applet.auto.entity.ealbums.TravelInfoVo;
import com.isimpo.tech.framework.applet.auto.entity.ealbums.TravelsVo;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月14日
 */
public interface EAlbumsMapper extends Mapper<AlbumVo> {

    /**
     * 电子相册列表
     */
    List<AlbumVo> albumList(Query query);

    /**
     * 电子相册删除
     */
    Integer albumDel(AlbumVo albumVo);

    /**
     * 行程列表
     */
    List<TravelInfoVo> travelList(AlbumVo albumVo);

    /**
     * 根据行程查询游记列表
     */
    List<TravelsVo> travelsList(AlbumVo albumVo);

    /**
     * 保存电子相册
     */
    Integer albumSave(AlbumVo albumVo);

    /**
     * 保存电子相册图片
     */
    Integer albumPicSave(@Param("albumPicList") List<AlbumPicVo> albumPicList);

    /**
     * 通过电子相册id获取详情信息
     */
    AlbumVo getAlbumDetail(AlbumVo albumVo);

    /**
     * 通过电子相册id获取动态图中所有图片
     */
    List<AlbumPicVo> getAlbumPic(AlbumVo albumVo);
}
