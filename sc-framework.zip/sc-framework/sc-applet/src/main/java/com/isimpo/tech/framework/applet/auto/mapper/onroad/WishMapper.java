package com.isimpo.tech.framework.applet.auto.mapper.onroad;

import java.util.List;

import com.isimpo.tech.framework.applet.auto.entity.onroad.wish.WishVo;
import com.isimpo.tech.framework.common.util.Query;

import tk.mybatis.mapper.common.Mapper;

/**
 * 会员祝福
 * @author Tank
 * @version V1.0
 * @since 2019/2/23
 *
 */
public interface WishMapper extends Mapper<WishVo> {

    /**
     * 查询会员祝福列表
     * @param query
     * @return
     */
    List<WishVo> listWishesByTraId(Query query);
    


    /**
     * 删除会员祝福
     * @param wish
     * @return
     */
    int delWish(WishVo wish);

    

    /**
     * 添加会员祝福
     * @param wish
     * @return
     */
    int addWish(WishVo wish);
    
}
