package com.isimpo.tech.framework.applet.controller.my;

import com.isimpo.tech.framework.applet.auto.entity.my.CsrOrder;
import com.isimpo.tech.framework.applet.service.my.CsrOrderService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * 订单管理
 * @author wangxinhai
 * @since 2019/4/18
 */
@RestController
@RequestMapping("/csrOrder")
public class CsrOrderController extends BaseController<CsrOrderService, CsrOrder> {

    @GetMapping("/getOrderById")
    @ResponseBody
    public AjaxResponse getOrderById(String id){
        return AjaxResponse.of(baseService.selectById(id));
    }

    @PostMapping("/addOrder")
    @ResponseBody
    public AjaxResponse addOrder(@RequestBody CsrOrder csrOrder, HttpServletRequest request){
        return baseService.addOrder(csrOrder, request);
    }

    /**
     * 获取订单类型个数 个人中心
     * @return
     */
    @GetMapping("/getOrderTypeNum")
    @ResponseBody
    public AjaxResponse getOrderTypeNum() {
        return AjaxResponse.of(baseService.getOrderTypeNum());
    }

}
