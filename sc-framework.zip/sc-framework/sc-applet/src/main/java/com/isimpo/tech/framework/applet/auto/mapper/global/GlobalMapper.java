package com.isimpo.tech.framework.applet.auto.mapper.global;

import com.isimpo.tech.framework.applet.auto.entity.sysBase.SysConfigure;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author zhuyilong
 * @since 2019/3/1
 */
public interface GlobalMapper extends Mapper<SysConfigure> {
    /**
     * 查询系统配置信息
     * @return
     */
    SysConfigure getSysConfig();
}
