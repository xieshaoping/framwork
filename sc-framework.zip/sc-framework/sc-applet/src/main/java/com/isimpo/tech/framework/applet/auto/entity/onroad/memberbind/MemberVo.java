package com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind;

import java.util.Date;
import java.util.List;

import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/14
 *
 */

public class MemberVo extends BaseVo {

    // 会员id
    private String id;

    // 微信用户id
    private String openId;

    // 消息id
    private String newsId;

    // 行程id
    private String traId;

    // 会员昵称
    private String nickName;

    //会员头像
    private String photo;

    // 会员手机号
    private String phone;

    // 微信用户表里对应的id
    private String wecharId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getWecharId() {
        return wecharId;
    }

    public void setWecharId(String wecharId) {
        this.wecharId = wecharId;
    }
}
