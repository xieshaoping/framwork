package com.isimpo.tech.framework.applet.controller.global;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.isimpo.tech.framework.applet.service.global.GlobalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.applet.auto.entity.onroad.wish.WishVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.service.onroad.WishService;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 获取用户信息
 * @author Tank
 * @version V1.0
 * @since 2019/2/25
 *
 */
@RestController
@RequestMapping("/global")
public class GlobalController {
    private GlobalService globalService;

    @Autowired
    public GlobalController(GlobalService globalService) {
        this.globalService = globalService;
    }

    /**
     * 查询用户信息
     * @param request
     * @return
     */
    @GetMapping("/getUserInfo")
    public AjaxResponse getNewsList(HttpServletRequest request) {
        // 从缓存中获取用户信息传递到前台
        UserInfoVo user = UserInfoUtils.getUserInfo(request);
        return AjaxResponse.of(user);
    }

    /**
     * 查询系统配置信息
     * @return
     */
    @GetMapping("/sysConfig")
    public AjaxResponse getSysConfig() {
        return globalService.getSysConfig();
    }

}
