/*
 * @(#) TripDetailService.java 2019年02月23日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraSupp;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TripItemVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TripPlaceVo;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip.TripDetailMapper;
import com.isimpo.tech.framework.common.service.BaseService;
import org.springframework.stereotype.Service;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月23日
 */
@Service
public class TripDetailService extends BaseService<TripDetailMapper, TripPlaceVo> {

    /**
     * 地点详情
     */
    public TripPlaceVo tripPlaceDetail(TripPlaceVo tripPlaceVo) {
        return mapper.tripPlaceDetail(tripPlaceVo);
    }

    /**
     * 事项详情
     */
    public TripItemVo tripItemDetail(TripItemVo tripItemVo) {
        return mapper.tripItemDetail(tripItemVo);
    }

    /**
     * 补充事项详情
     * @param id
     * @return
     */
    public TraSupp tripSuppDetail(String id){
        return mapper.tripSuppDetail(id);
    }
}
