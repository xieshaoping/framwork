package com.isimpo.tech.framework.applet.controller;

import com.isimpo.tech.framework.applet.service.schedule.TraScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
/**
 * 行程定时任务
 * @author wangxinhai
 * @version 1.0
 * @since 2019年5月23日
 */
@Component
public class TraScheduler {

    @Autowired
    private TraScheduleService traScheduleService;

    /**
     * 6分钟执行一次
     * 第一次提醒 早中晚提醒 总结提醒 评价提醒
     */
    @Scheduled(fixedRate = 600 * 1000L)
    public void sendMessage() throws Exception {
        traScheduleService.sendMessage();
    }


    /**
     * 每天9点执行一次
     * 前一天、三天提醒
     */
    @Scheduled(cron = "0 0 9 9 * ? ")
    public void sendMbMessage() throws Exception{
        traScheduleService.sendMbMessage();
    }


}
