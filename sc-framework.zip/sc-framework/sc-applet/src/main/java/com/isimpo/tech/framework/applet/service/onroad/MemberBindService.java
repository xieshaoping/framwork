package com.isimpo.tech.framework.applet.service.onroad;

import javax.servlet.http.HttpServletRequest;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.service.homePage.IndexPicService;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberWeChatVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.MemberBindMapper;
import com.isimpo.tech.framework.applet.auto.mapper.wechat.WechatUserMapper;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;

/**
 * 会员绑定
 * @author Tank
 * @version V1.0
 * @since 2019/2/20
 *
 */
@Service
public class MemberBindService extends BaseService<MemberBindMapper, MemberVo> {

    private Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired HttpServletRequest request;

    @Autowired
    private WechatUserMapper wechatUserMapper;

    @Autowired
    private IndexPicService indexPicService;

    /**
     * 查询会员是否绑定
     * @return
     */
    public AjaxResponse findMember() {
        UserInfoVo loginUser = UserInfoUtils.getUserInfo(request);
        if(loginUser == null || loginUser.getOpenId().trim().isEmpty()){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        String openId = loginUser.getOpenId().trim();
        MemberVo vo = mapper.findMemberByOpenId(openId);
        return AjaxResponse.of(vo);
    }

    /**
     * 绑定会员
     * @param phone
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse saveRelation(String phone) {
        if(phone == null || phone.trim().isEmpty()){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        UserInfoVo loginUser = UserInfoUtils.getUserInfo(request);
        logger.info("userinfo-openid======="+loginUser.getOpenId());
        logger.info("userinfo-wecharid======="+loginUser.getWecharId());
        if(loginUser == null || loginUser.getOpenId().trim().isEmpty()){
            return AjaxResponse.of(ResponseCode.FAIL,"该用户尚未登录");
        }
        //检查该手机号的会员是否已经绑定- 可以两个微信号绑定同一个会员，以后再做
        int already = mapper.checkBind(phone);
        if (already > 0 ){
            return AjaxResponse.of(ResponseCode.FAIL,"该手机号已经被绑定,如有疑问请联系我们！<br>联系电话：<a style='color:red;'href=\"tel:"+indexPicService.getPhone()+"\">"+indexPicService.getPhone()+"</a>");
        }

        // 在csr_member里查看该手机号对应的用户id
        String memId = mapper.getMemberIdByPhone(phone);
//        String wecharId = loginUser.getWecharId();
        String wecharId = mapper.getWecharIdByOpenId(loginUser.getOpenId());

        if(StringUtils.isEmpty(memId)){
            /*return AjaxResponse.of(ResponseCode.FAIL,"无会员信息，如有疑问请联系我们！<br>联系电话：<a style='color:red;'href=\"tel:"+indexPicService.getPhone()+"\">"+indexPicService.getPhone()+"</a>");*/
            return AjaxResponse.of(20001,"无会员信息");
        }
        if(StringUtils.isEmpty(wecharId)){
            return AjaxResponse.of(ResponseCode.FAIL,"未查到该用户的微信信息");
        }
        //该用户是存在的，需要往关系表里插入关系
        MemberWeChatVo vo = new MemberWeChatVo();

        EntityUtils.setCreatAndUpdatInfo(vo);
        vo.setAddUserId(memId);
        vo.setUpdUserId(memId);
        vo.setMemId(memId);
        vo.setWecharId(wecharId);
        // 拿到 memId与 wecharId之后到数据中再次查询是否已经存在该用户关系
        int exist = mapper.checkExist(vo);
        if (exist>0) {
            return AjaxResponse.of(ResponseCode.FAIL,"您已绑定，请重新登录");
        }
        int num = mapper.insertRelation(vo);
        if(num>0){
            // 如果关系插入成功，更新缓存信息
            UserInfoUtils.freshUserInfo(request,wechatUserMapper.userInfo(loginUser.getOpenId()));
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);

    }


    /**
     * 无会员信息时 创建会员
     * @param phone
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addMember(String phone) {
        if(phone == null || phone.trim().isEmpty()){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        UserInfoVo loginUser = UserInfoUtils.getUserInfo(request);
        if(loginUser == null || loginUser.getOpenId().trim().isEmpty()){
            return AjaxResponse.of(ResponseCode.FAIL,"该用户尚未登录");
        }
        Member member = new Member();
        EntityUtils.setCreatAndUpdatInfo(member);
        member.setName(loginUser.getNickName());
        member.setPhone(phone);
        member.setType("1");
        member.setTalentFlag("0");
        member.setAddUserId(member.getId());
        member.setUpdUserId(member.getId());
        int result = mapper.insertMember(member);
        if(result > 0){
            String wecharId = mapper.getWecharIdByOpenId(loginUser.getOpenId());
            //该用户是存在的，需要往关系表里插入关系
            MemberWeChatVo vo = new MemberWeChatVo();

            EntityUtils.setCreatAndUpdatInfo(vo);
            vo.setAddUserId(member.getId());
            vo.setUpdUserId(member.getId());
            vo.setMemId(member.getId());
            vo.setWecharId(wecharId);
            // 拿到 memId与 wecharId之后到数据中再次查询是否已经存在该用户关系
            int exist = mapper.checkExist(vo);
            if (exist>0) {
                return AjaxResponse.of(ResponseCode.FAIL,"您已绑定，请重新登录");
            }
            int num = mapper.insertRelation(vo);
            if(num>0){
                // 如果关系插入成功，更新缓存信息
                UserInfoUtils.freshUserInfo(request,wechatUserMapper.userInfo(loginUser.getOpenId()));
                return AjaxResponse.of(ResponseCode.SUCCESS);
            }
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

}
