/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.homePage;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Housekeeper;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Reserve;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.HousekeeperMapper;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.ReserveMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author zx
 * @version 1.0
 * @since 2018/4/24
 */
@Service
public class HousekeeperService extends BaseService<HousekeeperMapper, Housekeeper> {
}
