/*
 * @(#) SceneInfo.java 2015年4月9日
 *
 * Copyright (c) 2010, HMI Technology. All Rights Reserved.
 * HMI Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils.wxQrcode;

/**
 * 场景信息Vo
 * 
 * @author zhengjiudong
 * @version 1.0
 * @since 2015年4月9日
 */
public class SceneInfo {
	
	private String scene_id;         //场景值ID，临时二维码时为32位非0整型，永久二维码时最大值为1000
	
	public String getScene_id() {
		return scene_id;
	}

	public void setScene_id(String scene_id) {
		this.scene_id = scene_id;
	}
}
