/*
 * @(#) TripPlaceVo.java 2019年02月23日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月23日
 */
@Table(name = "tra_place")
public class TripPlaceVo extends BaseVo {

    @Id
    private String id;
    /**行程id*/
    private String traId;
    /**行程日期id*/
    private String calendarId;
    /**主题图片*/
    private String cover;
    /**中文名称*/
    private String name;
    /**英文名称*/
    private String enName;
    /**基本介绍*/
    private String overView;
    /**温馨提示*/
    private String tips;
    /**排序*/
    private String sort;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    public String getCalendarId() {
        return calendarId;
    }

    public void setCalendarId(String calendarId) {
        this.calendarId = calendarId;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public String getOverView() {
        return overView;
    }

    public void setOverView(String overView) {
        this.overView = overView;
    }

    public String getTips() {
        return tips;
    }

    public void setTips(String tips) {
        this.tips = tips;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }
}
