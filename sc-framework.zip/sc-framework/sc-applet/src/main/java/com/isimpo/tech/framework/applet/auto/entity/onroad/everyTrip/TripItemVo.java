/*
 * @(#) TripItemVo.java 2019年02月25日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月25日
 */
@Table(name = "tra_item")
public class TripItemVo extends BaseVo {

    @Id
    private String id;
    /**地点id*/
    private String placeId;
    /**类型*/
    private String type;
    /**主题图片*/
    private String cover;
    /**中文名称*/
    private String name;
    /**英文名称*/
    private String enName;
    /**基本介绍*/
    private String overview;
    /**温馨提示*/
    private String tips;
    /**地点经度*/
    private String longitude;
    /**地点维度*/
    private String latitude;
    /**起始时间*/
    private String startTime;
    /**结束时间*/
    private String endTime;
    /**是否预订(0：无预订，1：已预订）*/
    private String reserve;
    /**详细信息*/
    private String content;
    /**附件(多个附件地址逗号隔开)*/
    private String files;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPlaceId() {
        return placeId;
    }

    public void setPlaceId(String placeId) {
        this.placeId = placeId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getTips() {
        return tips;
    }

    public void setTips(String tips) {
        this.tips = tips;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getReserve() {
        return reserve;
    }

    public void setReserve(String reserve) {
        this.reserve = reserve;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFiles() {
        return files;
    }

    public void setFiles(String files) {
        this.files = files;
    }
}
