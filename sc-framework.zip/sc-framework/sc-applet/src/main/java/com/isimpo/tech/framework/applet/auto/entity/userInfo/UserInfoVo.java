/*
 * @(#) UserInfoVo.java 2019年02月21日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.userInfo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月21日
 */
public class UserInfoVo {

    /**微信用户主键*/
    private String wecharId;
    /**微信用户开放id*/
    private String openId;
    /**微信昵称*/
    private String nickName;
    /**头像*/
    private String photo;
    /**会员id*/
    private String memId;
    /**姓名*/
    private String name;
    /**性别（0：女，1：男）*/
    private String gender;
    /**生日*/
    private Date birthday;
    /**手机*/
    private String phone;
    /**证件类型（关联字典表信息）*/
    private String idType;
    /**证件号码*/
    private String idNum;
    /**联系地址*/
    private String source;
    /**备注*/
    private String note;
    /**类型（1：会员，2：管家,3:领队）*/
    private String type;
    /**达人标识（0：否，1是）*/
    private String talentFlag;

    public String getWecharId() {
        return wecharId;
    }

    public void setWecharId(String wecharId) {
        this.wecharId = wecharId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonFormat(pattern = "yyyy-MM-dd")
    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTalentFlag() {
        return talentFlag;
    }

    public void setTalentFlag(String talentFlag) {
        this.talentFlag = talentFlag;
    }
}
