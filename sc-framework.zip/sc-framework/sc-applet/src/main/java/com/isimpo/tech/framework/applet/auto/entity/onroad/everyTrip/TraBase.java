/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;

/**
 * 行程管理
 * @author Tank
 * @version V1.0
 * @since 2019/1/29
 *
 */
@Table(name = "tra_base")
public class TraBase extends BaseVo {
    /** id*/
    private String id;
    /** 名称*/
    private String name;
    /** 客户id*/
    @Column(name = "customer_id")
    private String customerId;
    /** 客户姓名*/
    private String customerName;
    /** 联系人*/
    private String contact;
    /** 手机号码*/
    private String phone;
    /** 开始日期*/
    private Date startDate;
    /** 结束日期*/
    private Date endDate;
    /** 管家id*/
    @Column(name = "housekeeper_id")
    private String housekeeperId;
    /** 管家名称*/
    private String housekeeperName;
    /** 领队id*/
    @Column(name = "guide_id")
    private String guiderId;
    /** 领队名称*/
    private String guiderName;
    /** 行程状态*/
    private String state;
    /** 行程状态*/
    private String cover;
    /** 备注*/
    private String note;
    /** 紧急联系电话*/
    private String urgentPhone;
    /** 修改人姓名*/
    private String updUser;

    private String overview;

    private String traRemind;

    /**
     * 行程时差
     */
    @Column(name = "time_diff")
    private Integer timeDiff;

    /**
     * 第一次提醒
     */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @Column(name = "first_remind")
    private Date firstRemind;

    /**
     * 总结提醒
     */
    @Column(name = "sum_remind")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date sumRemind;

    /**
     * 早上提醒
     */
    @Column(name = "morn_remind")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date mornRemind;

    /**
     * 中午提醒
     */
    @Column(name = "noon_remind")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date noonRemind;

    /**
     * 晚上提醒
     */
    @Column(name = "night_remind")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date nightRemind;

    /**
     * 评价提醒
     */
    @Column(name = "eval_remind")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date evalRemind;

    @Column(name = "overview_photo")
    private String overviewPhoto;

    //用户名称
    @Transient
    private String userName;

    //性别
    @Transient
    private String gender;

    //公开标识
    private String publicFlag;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonFormat(pattern="yyyy-MM-dd")
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    @JsonFormat(pattern="yyyy-MM-dd")
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getHousekeeperName() {
        return housekeeperName;
    }

    public void setHousekeeperName(String housekeeperName) {
        this.housekeeperName = housekeeperName;
    }

    public String getGuiderName() {
        return guiderName;
    }

    public void setGuideName(String guiderName) {
        this.guiderName = guiderName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getUpdUser() {
        return updUser;
    }

    public void setUpdUser(String updUser) {
        this.updUser = updUser;
    }

    public String getHousekeeperId() {
        return housekeeperId;
    }

    public void setHousekeeperId(String housekeeperId) {
        this.housekeeperId = housekeeperId;
    }

    public String getGuiderId() {
        return guiderId;
    }

    public void setGuiderId(String guiderId) {
        this.guiderId = guiderId;
    }

    public void setGuiderName(String guiderName) {
        this.guiderName = guiderName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getUrgentPhone() {
        return urgentPhone;
    }

    public void setUrgentPhone(String urgentPhone) {
        this.urgentPhone = urgentPhone;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getOverviewPhoto() {
        return overviewPhoto;
    }

    public void setOverviewPhoto(String overviewPhoto) {
        this.overviewPhoto = overviewPhoto;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPublicFlag() {
        return publicFlag;
    }

    public void setPublicFlag(String publicFlag) {
        this.publicFlag = publicFlag;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTraRemind() {
        return traRemind;
    }

    public void setTraRemind(String traRemind) {
        this.traRemind = traRemind;
    }

    public Integer getTimeDiff() {
        return timeDiff;
    }

    public void setTimeDiff(Integer timeDiff) {
        this.timeDiff = timeDiff;
    }

    public Date getFirstRemind() {
        return firstRemind;
    }

    public void setFirstRemind(Date firstRemind) {
        this.firstRemind = firstRemind;
    }

    public Date getSumRemind() {
        return sumRemind;
    }

    public void setSumRemind(Date sumRemind) {
        this.sumRemind = sumRemind;
    }

    public Date getMornRemind() {
        return mornRemind;
    }

    public void setMornRemind(Date mornRemind) {
        this.mornRemind = mornRemind;
    }

    public Date getNoonRemind() {
        return noonRemind;
    }

    public void setNoonRemind(Date noonRemind) {
        this.noonRemind = noonRemind;
    }

    public Date getNightRemind() {
        return nightRemind;
    }

    public void setNightRemind(Date nightRemind) {
        this.nightRemind = nightRemind;
    }

    public Date getEvalRemind() {
        return evalRemind;
    }

    public void setEvalRemind(Date evalRemind) {
        this.evalRemind = evalRemind;
    }

    @Override
    public String toString() {
        return "TraManageVo{" + "id='" + id + '\'' + ", name='" + name + '\'' + ", contact='" + contact + '\''
                + ", phone='" + phone + '\'' + '}';
    }
}
