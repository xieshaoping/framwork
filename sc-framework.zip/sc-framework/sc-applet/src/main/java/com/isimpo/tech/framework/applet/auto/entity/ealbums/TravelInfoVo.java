/*
 * @(#) TravelInfoVo.java 2019年02月15日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.ealbums;

import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月15日
 */
@Table(name = "tra_base")
public class TravelInfoVo {

    @Id
    private String id;
    /**行程名称*/
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
