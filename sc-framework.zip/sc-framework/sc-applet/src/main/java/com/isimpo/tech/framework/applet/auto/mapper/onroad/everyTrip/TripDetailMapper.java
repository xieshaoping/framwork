/*
 * @(#) TripDetailMapper.java 2019年02月23日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraSupp;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TripItemVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TripPlaceVo;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月23日
 */
public interface TripDetailMapper extends Mapper<TripPlaceVo> {

    /**
     * 地点详情
     */
    TripPlaceVo tripPlaceDetail(TripPlaceVo tripPlaceVo);

    /**
     * 事项详情
     */
    TripItemVo tripItemDetail(TripItemVo tripItemVo);


    TraSupp tripSuppDetail(String id);
}
