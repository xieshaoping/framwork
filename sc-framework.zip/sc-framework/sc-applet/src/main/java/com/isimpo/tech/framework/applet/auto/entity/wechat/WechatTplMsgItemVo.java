/*
 * Copyright (c) 2018, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.wechat;

import java.io.Serializable;

/**
 * 模版消息字段
 *
 * @author Fei
 * @version 1.0
 * @since 2018年10月10日
 */
public class WechatTplMsgItemVo implements Serializable {

    /**
     * 字段值
     */
    private String value;

    /**
     * 字段颜色
     */
    private String color = "#173177";

    public WechatTplMsgItemVo(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
