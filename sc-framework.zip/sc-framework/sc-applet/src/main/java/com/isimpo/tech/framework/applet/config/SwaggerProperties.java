package com.isimpo.tech.framework.applet.config;

import javax.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

/**
 * Swagger2 配置文件
 *
 * @author abator
 * @version 1.0
 * @since 2017年12月28日
 */
@ConfigurationProperties(prefix = "swagger")
@Validated
public class SwaggerProperties {

    private final SwaggerService service = new SwaggerService();

    @NotNull
    private String basePackage;

    public SwaggerService getService() {
        return service;
    }

    public String getBasePackage() {
        return basePackage;
    }

    public void setBasePackage(String basePackage) {
        this.basePackage = basePackage;
    }

    public static class SwaggerService {

        private String name;

        private String developer;

        private String email;

        private String url;

        private String description;

        private String version;

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getDeveloper() {
            return developer;
        }

        public void setDeveloper(String developer) {
            this.developer = developer;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }
    }
}
