package com.isimpo.tech.framework.applet.controller.onroad;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberVo;
import com.isimpo.tech.framework.applet.service.onroad.MemberBindService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;

/**
 * 
 * @author Tank
 * @version V1.0
 * @since 2019/2/13
 *
 */
@RestController
@RequestMapping("/memberBind")
public class MemberBindController extends BaseController<MemberBindService, MemberVo> {

    /**
      * 根据Request对象查找是否已经绑定会员
      * @return
      */
    @GetMapping("/find")
    public AjaxResponse findMember() {
        return baseService.findMember();
    }

    /**
     * 根据手机号进行操作
     * @param phone 消息id
     * @return
     */
    @GetMapping("/save")
    public AjaxResponse saveRelation(String phone) {
        return baseService.saveRelation(phone);
    }

    /**
     * 无会员信息时 创建会员
     * @param phone
     * @return
     */
    @GetMapping("/addMember")
    public AjaxResponse addMember(String phone){
        return baseService.addMember(phone);
    }


}
