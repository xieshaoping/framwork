package com.isimpo.tech.framework.applet.controller.resound;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.TravelRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.TraTravelerTalk;
import com.isimpo.tech.framework.applet.service.onroad.timememory.TimeMemoryService;
import com.isimpo.tech.framework.applet.service.resound.TraTravelerTalkService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 旅咖说控制器
 * @author Tank
 * @version V1.0
 * @since 2019/2/18
 *
 */
@RestController
@RequestMapping("/travelerTalk")
public class TraTravelerTalkController extends BaseController<TraTravelerTalkService,TraTravelerTalk>{

    /**
     * 查询我的旅咖说列表
     * @param params
     * @return
     */
    @GetMapping("/list")
    public AjaxResponse getTraTalkList(@RequestParam Map<String, Object> params) {
        return baseService.getTraTalkList(new Query(params));
    }

    /**
     * 查询旅咖说详情-根据旅咖说id
     * @param mainId
     * @return
     */
    @GetMapping("/detail")
    public AjaxResponse getTraTalkDetail(String mainId) {
        return baseService.getTraTalkDetail(mainId);
    }

    /**
     * 根据旅咖说id删除旅咖说
     * @param mainId
     * @return
     */
    @GetMapping("/del")
    public AjaxResponse delTalk(String mainId) {
        return baseService.delTraTalk(mainId);
    }
    /**
     * 添加旅咖说
     * @param talk
     * @return
     */
    @PostMapping("/add")
    public AjaxResponse addTraTalk(@RequestBody TraTravelerTalk talk) {
        return baseService.addTraTalk(talk);
    }

    /**
     * 点赞
     * @param praiseRecord
     * @return
     */
    @GetMapping("/praise")
    public AjaxResponse praise(PraiseRecordVo praiseRecord) {
        return baseService.praise(praiseRecord);
    }

    /**
     * 取消赞
     * @param praiseRecord
     * @return
     */
    @GetMapping("/unPraise")
    public AjaxResponse unPraise(PraiseRecordVo praiseRecord) {
        return baseService.unPraise(praiseRecord);
    }

    /**
     * 增加评论
     * @param comment
     * @return
     */
    @PostMapping("/addComment")
    public AjaxResponse addComment(@RequestBody CommentVo comment) {
        return baseService.addComment(comment);
    }

    /**
     * 删除评论
     * @param commentVo
     * @return
     */
    @GetMapping("/delComment")
    public AjaxResponse delComment(CommentVo commentVo) {
        return baseService.delComment(commentVo);
    }

}
