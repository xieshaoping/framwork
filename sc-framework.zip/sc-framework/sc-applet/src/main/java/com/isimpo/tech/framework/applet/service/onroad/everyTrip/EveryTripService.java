package com.isimpo.tech.framework.applet.service.onroad.everyTrip;

import com.alibaba.fastjson.JSONObject;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.auto.entity.homePage.SysDict;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.*;
import com.isimpo.tech.framework.applet.auto.entity.sysBase.SysConfigure;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatTplMsgItemVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatTplMsgVo;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.ReserveMapper;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip.TraItemMapper;
import com.isimpo.tech.framework.applet.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.applet.utils.WeinXinUtil;
import com.isimpo.tech.framework.applet.utils.utils.HttpClientUtils;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.wechat.WeChatConfigUtil;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.WechatConstants;
import com.isimpo.tech.wechat.pojo.WechatConfig;
import com.xiaoleilu.hutool.extra.mail.MailAccount;
import com.xiaoleilu.hutool.extra.mail.MailUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 每日行程
 * @author wangxinhai
 * @version V1.0
 * @since 2019/2/23
 */
@Service
public class EveryTripService extends BaseService<TraItemMapper, TraItem> {

    @Autowired
    private ReserveMapper reserveMapper;

    @Autowired
    private TraItemMapper traItemMapper;

    @NotNull
    @Value("${templateId}")
    private String templateId;

    @NotNull
    @Value("${h5Url}")
    private String h5Url;



    private Logger logger = LoggerFactory.getLogger(EveryTripService.class);
    /**
     * 校验当前用户有没有绑定会员
     * @param request
     * @return
     */
    public AjaxResponse checkMemberBind(HttpServletRequest request){
        UserInfoVo userInfoVo = UserInfoUtils.getUserInfo(request);
        return AjaxResponse.of(userInfoVo.getMemId() != null ? ResponseCode.SUCCESS : ResponseCode.FAIL);
    }

    /**
     * 根据当前会员id查询行程列表
     * @param memId
     * @return
     */
    public List<TraBase> getTraItemById(String memId, String type){
        Member member = mapper.getMemberById(memId);
        if("2".equals(type)){//管家
            if("1".equals(member.getAllFlag())){ // 查看全部
                return mapper.getTraItemHouseKeep(memId,member.getAllFlag());
            }
            return mapper.getListAll(memId);
        }else if("3".equals(type)){ //领队
            return mapper.getListAll(memId);
        }
        return mapper.getTraItemById(memId);
    }

    /**
     * 根据行程id查询会员列表
     * @param traId
     * @return
     */
    public List<Member> getMemberListByTraId(String traId){
        return mapper.getMemberListByTraId(traId);
    }

    /**
     * 根据行程id获取日历
     * @param traId
     * @return
     */
    public List<TraCalendar> getCalendarByTraId(String traId){
        List<TraCalendar> list = mapper.getCalendarByTraId(traId);
        if(list.size()>0){
            list.get(0).setSelectFlag("1");
        }
        return list;
    }

    /**
     * 根据行程 日历获取行程列表
     * @param traPlace
     * @return
     */
    public List<TraPlaceTraItem> getTraPlaceItemList(TraPlace traPlace){
        return  mapper.getPlaceTraItemList(traPlace);
    }

    /**
     * 根据行程id获取紧急联系电话
     * @param traId
     * @return
     */
    public String getPhoneByTraId(String traId){
        return mapper.getPhoneByTraId(traId);
    }

    /**
     * 保存祝福内容
     * @param traWish
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse saveTraWish(TraWish traWish){
        EntityUtils.setCreatAndUpdatInfo(traWish);
        traWish.setAddUserId(traWish.getMemId());
        traWish.setUpdUserId(traWish.getMemId());
        int num = mapper.saveTraWish(traWish);
        if(num > 0){
            setTemplantDate("",traWish.getContent(),traWish.getTraId(),traWish.getMemId(),traWish.getId());
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 保存投诉内容
     * @param traComplain
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse saveTraComplaint(TraComplain traComplain){
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY/MM/dd");
        traComplain.setContent(SensitiveWordUtils.filterStr(traComplain.getContent().toString()));
        EntityUtils.setCreatAndUpdatInfo(traComplain);
        traComplain.setAddUserId(traComplain.getMemId());
        traComplain.setUpdUserId(traComplain.getMemId());
        int num = mapper.saveTraComplaint(traComplain);
        if(num > 0){
            //  从基础设置sys_base里获取提醒邮箱List
            String emails = reserveMapper.getEmailList();
            String[] emailList = emails.split(",");
            List<String> list = new ArrayList<>();
            for (String email : emailList) {
                list.add(email);
            }
            // 从数据库获取系统发件人邮箱地址、密码
            SysConfigure sysConfigure = reserveMapper.getSysConfigure();
            // 开始发送邮件
            MailAccount account = new MailAccount();
            Member member = mapper.getMemberById(traComplain.getMemId());
            TraBase traBase = mapper.getTramById(traComplain.getRangeId());
            String title = "【会员投诉】" + traBase.getName() + '-' + member.getName();
            account.setHost("smtp.qq.com");
            account.setAuth(true);
            account.setPort(465);
            account.setFrom(sysConfigure.getSendEmail());
            account.setUser(sysConfigure.getSendEmail());// 发件人邮箱
            account.setPass(sysConfigure.getEmailPwd());// 发件人密码
            account.setStartttlsEnable(true);
            StringBuilder html = new StringBuilder();
            // 邮件内容
            html.append("投诉内容：<br>");
            html.append("&nbsp;&nbsp;&nbsp;&nbsp;" + traComplain.getContent());
            html.append("<br><br><br>");
            html.append("&nbsp;&nbsp;&nbsp;&nbsp;行程：" + traBase.getName() + "<br>");
            html.append("&nbsp;&nbsp;&nbsp;&nbsp;姓名：" + member.getName() + "<br>");
            html.append("&nbsp;&nbsp;&nbsp;&nbsp;手机：" + member.getPhone() + "<br>");
            html.append("&nbsp;&nbsp;&nbsp;&nbsp;时间：" + sdf.format(traComplain.getAddTime()));
            //  循环邮箱list
            for (String email : list) {
                try {
                    MailUtil.send(account, email, title, html.toString(), true);
                } catch (Exception e) {
                    logger.error(email + "：该邮件地址不存在！");
                }
            }
            // 发送邮件结束
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 根据id获取行程
     * @param traId
     * @return
     */
    public TraBase getTraById(String traId){
        return mapper.getTramById(traId);
    }

    /**
     * 根据id获取日历
     * @param id
     */
    public TraCalendar getCalendarById(String id){
        return mapper.getCalendarById(id);
    }

    /**
     * 获取系统配置
     * @return
     */
    public CocoCard getSysBase(){
        return mapper.getCocoCard();
    }

    public AjaxResponse checkMemberTram(String memId, String traId){
        int num = mapper.checkMemberTram(memId,traId);
        int result = mapper.checkTraBase(memId,traId);
        if(num > 0 || result > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 根据行程id获取管家信息
     * @param traId
     * @return
     */
    public Member getHouseKeppInfo(String traId){
        return mapper.getHouseKeppInfo(traId);
    }

    /**
     * 根据行程id获取领队信息
     * @param traId
     * @return
     */
    public List<Member> getGuideInfo(String traId){
        return mapper.getGuideInfo(traId);
    }

    /**
     * 发送模板消息
     *
     * @param name
     * @param content
     * @param traId
     */
    public void setTemplantDate(String name, String content,String traId,String memId,String traWishId) {
        //查询该行程所在的成员  openId
        //List<String> authPeoples = traItemMapper.getMemberListByTraId(traId).stream().map(Member::getOpenId).collect(Collectors.toList());
        List<Member> list = traItemMapper.getMemberListByTraId(traId);
        List<Member> memberList = traItemMapper.findAllFlagMember();
        Member member = traItemMapper.getMemberOpenId(memId);
        list.addAll(memberList);
        list.add(member);
        TraBase traBase = traItemMapper.getTramById(traId);
        List<String> openIds = new ArrayList<>();
        openIds.add("1");
        for (int i = 0;i<list.size();i++) {
            //发送模板消息
            WechatTplMsgVo tplMsgVo = new WechatTplMsgVo();
            tplMsgVo.setTemplate_id(templateId);
            tplMsgVo.setUrl(h5Url + "static/page/onroad/everyTrip/everyTrip.html?traWishId=" + traWishId + "&xcId=" + traId + "&xcState=" + traBase.getState());
            Map<String, WechatTplMsgItemVo> map = new HashMap<>();
            map.put("first",new WechatTplMsgItemVo("尊敬的"+list.get(i).getName()+"，您好，可乐国旅温馨提醒。"));
            map.put("keyword1",new WechatTplMsgItemVo(traBase.getName()));
            map.put("keyword2",new WechatTplMsgItemVo("祝福墙"));
            map.put("keyword3",new WechatTplMsgItemVo(content));
            map.put("remark", new WechatTplMsgItemVo(""));
            tplMsgVo.setData(map);
            if(openIds.contains(list.get(i).getOpenId())){
                continue;
            }
            if(list.get(i).getOpenId() != null){
                openIds.add(list.get(i).getOpenId());
                sendTplMsg(tplMsgVo, list.get(i).getOpenId());
            }else{
                logger.error("发送模版消息失败：token:{} 或 没有审核人员");
            }
        }
    }

    public boolean sendTplMsg(WechatTplMsgVo tplMsgVo, String openId){
        WechatConfig wechatConfig = WeChatConfigUtil.getWechatConfig();
        String accessToken = WechatApi.getToken();//WeinXinUtil.getAccessToken(wechatConfig.getAppId(),wechatConfig.getSecret());//WechatApi.getToken();
        Boolean success = false;
        if (StringUtils.isNotEmpty(openId) && StringUtils.isNotEmpty(accessToken)) {
            String requestUrl = WechatConstants.WECHAT_SEND_WECHAT_URL.replace("#ACCESS_TOKEN#", accessToken);
            tplMsgVo.setTouser(openId);
            String params = JSONObject.toJSONString(tplMsgVo);
            params = stringUncode(params);
            try {
                String result = HttpClientUtils.sendPostSSLRequest(requestUrl, params);
                if (StringUtils.isNotBlank(result)) {
                    JSONObject jsonObject = JSONObject.parseObject(result);
                    if (jsonObject.containsKey("errcode") && jsonObject.getIntValue("errcode") == 0) {
                        success = true;
                        logger.info("发送模版消息成功：token:{}：{}：{}", accessToken, params, result);
                    } else {
                        logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                    }
                } else {
                    logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                }
            } catch (Exception ex) {
                logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, ex);
            }
        } else {
            logger.error("发送模版消息失败：token:{} 或 没有审核人员", accessToken);
        }
        return success;
    }

    /**
     * 特殊字符转码
     *
     * @param param
     * @return
     */
    public static String stringUncode(String param) {
        if (param != null && !param.trim().equals("")) {
            try {
                param = URLEncoder.encode(param, "utf-8");//转码
                param = URLDecoder.decode(param, "UTF-8");//解码
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return param;
    }

    /**
     * 行程日历添加
     * @author wangxinhai
     * @param traCalendar
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse addTraCalendar(TraCalendar traCalendar){
        List<TraCalendar> traCalendarList = mapper.getTraCalendarByTraIdAndDate(traCalendar.getTraId(),traCalendar.getTraDate());
        if(traCalendarList.size() > 0){
            return AjaxResponse.of(20001, "该行程日期已存在");
        }
        EntityUtils.setCreatAndUpdatInfo(traCalendar);
        int num = mapper.addTraCalendar(traCalendar);
        if(num > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 行程地点添加
     * @author wangxinhai
     * @param traPlace
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse addTraPlace(TraPlace traPlace){
        int num = mapper.getTraPlaceMaxSort(traPlace);
        traPlace.setSort(++num);
        EntityUtils.setCreatAndUpdatInfo(traPlace);
        // 敏感词过滤
        traPlace.setName(SensitiveWordUtils.filterStr(traPlace.getName()));
        traPlace.setEnName(SensitiveWordUtils.filterStr(traPlace.getEnName()));
        traPlace.setOverview(SensitiveWordUtils.filterStr(traPlace.getOverview()));
        traPlace.setTips(SensitiveWordUtils.filterStr(traPlace.getTips()));
        int result = mapper.insertTraPlace(traPlace);
        if(result > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    public List<SysDict> getItemType() {
        return mapper.getItemType();
    }
}
