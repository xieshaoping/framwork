package com.isimpo.tech.framework.applet.sequence;

/**
 * 编码类型
 * （生成编码的默认格式：前缀名+yyyyMMdd+固定长度序号）
 *
 * @author wgq
 * @version 1.0
 * @since 2018-01-07
 */
public enum SeqType {

    /**
     * 前台会员userNo
     */
    USER_NO("M", 9, false),

    CLASS_NO("C",8,true),
    /**
     * 订单No
     */
    ORDER_NO("J", 9, true),
    /**
     * 平台商家会员编号
     */
    M_USER_NO("U", 9, false);




    /**
     * 前缀名
     */
    private String prefix;

    /**
     * 序号长度
     */
    private int serialLen;

    /**
     * 是否带有yyyyMMdd格式
     */
    private boolean hasYMD;

    /**
     * 构造函数 （生成编码的格式，根据 {@code hasYMD}值决定，true：前缀名+yyyyMMdd+固定长度序号；false：前缀+固定长度序号）
     *
     * @param prefix 前缀
     * @param serialLen 序号长度
     * @param hasYMD 是否带有yyyyMMdd格式，true:带有，false：前缀+固定长度序号
     */
    SeqType(String prefix, int serialLen, boolean hasYMD) {
        this.prefix = prefix;
        this.serialLen = serialLen;
        this.hasYMD = hasYMD;
    }

    /**
     * 构造函数 （生成默认编码的格式，{@code hasYMD}值为true：前缀名+yyyyMMdd+固定长度序号）
     *
     * @param prefix 前缀
     * @param serialLen 序号长度
     */
    SeqType(String prefix, int serialLen) {
        this(prefix, serialLen, true);
    }

    public boolean isHasYMD() {
        return hasYMD;
    }

    public String getPrefix() {
        return prefix;
    }

    public int getSerialLen() {
        return serialLen;
    }

}
