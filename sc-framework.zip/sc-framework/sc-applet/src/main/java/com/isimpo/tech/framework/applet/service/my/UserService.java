package com.isimpo.tech.framework.applet.service.my;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isimpo.tech.framework.applet.auto.entity.my.CardVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.mapper.my.UserMapper;
import com.isimpo.tech.framework.applet.auto.mapper.wechat.WechatUserMapper;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;

/**
 * 用户信息
 * @author Tank
 * @version V1.0
 * @since 2019/2/26
 *
 */
@Service
public class UserService extends BaseService<UserMapper, UserInfoVo> {

    @Autowired
    HttpServletRequest request;

    @Autowired
    private WechatUserMapper wechatUserMapper;

    /**
     * 修改用户信息
     *
     * @param
     * @return AjaxResponse
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse updateUserInfo(UserInfoVo user) {
        if(user == null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        EntityUtils.setUpdatedInfo(user);
        int num = mapper.updateUserInfo(user);
        if(num >0){
            UserInfoUtils.freshUserInfo(request,wechatUserMapper.userInfo(user.getOpenId()));
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 实时获取用户信息
     * @param openId
     * @return userInfoVo
     */
    public AjaxResponse getCurrentUserByOpenId(String openId) {
        if(openId == null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        UserInfoVo user = wechatUserMapper.userInfo(openId);
        if(user == null){
            return AjaxResponse.of(ResponseCode.FAIL,"未查到该用户信息！");
        }
        return AjaxResponse.of(user);
    }

}
