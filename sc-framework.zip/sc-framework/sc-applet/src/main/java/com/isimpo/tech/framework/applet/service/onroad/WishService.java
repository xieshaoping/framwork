package com.isimpo.tech.framework.applet.service.onroad;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.onroad.wish.WishVo;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.WishMapper;
import com.isimpo.tech.framework.applet.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 会员祝福
 * @author Tank
 * @version V1.0
 * @since 2019/2/23
 *
 */
@Service
public class WishService extends BaseService<WishMapper, WishVo> {

    /**
     * 分页查询会员祝福列表
     * @param query
     * @return
     */
    public AjaxResponse getWishes(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<WishVo> list = mapper.listWishesByTraId(query);       
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }

    public List<WishVo> getWishesAll(Query query) {
        List<WishVo> list = mapper.listWishesByTraId(query);
        return list;
    }

    

    /**
     * 删除会员祝福
     * @param wish
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delWish(WishVo wish) {
        EntityUtils.setUpdatedInfo(wish);
        int count = mapper.delWish(wish);
        if (count > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    

    /**
     * 添加会员祝福
     * @param wish
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addWish(WishVo wish) {
        if(wish == null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        wish.setContent(SensitiveWordUtils.filterStr(wish.getContent().toString()));
        EntityUtils.setCreatAndUpdatInfo(wish);
//        wish.setAddUserId("11");
//        wish.setUpdUserId("11");
        if (mapper.addWish(wish) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    


}
