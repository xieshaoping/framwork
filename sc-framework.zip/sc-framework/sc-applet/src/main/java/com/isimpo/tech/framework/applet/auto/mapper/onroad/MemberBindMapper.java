package com.isimpo.tech.framework.applet.auto.mapper.onroad;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberWeChatVo;

import tk.mybatis.mapper.common.Mapper;

/**
 * 会员绑定
 * @author Tank
 * @version V1.0
 * @since 2019/2/20
 *
 */
public interface MemberBindMapper extends Mapper<MemberVo> {

    /**
     * 根据openId检查是否已经绑定会员
     * @param openId
     * @return MemberVo
     */
    MemberVo findMemberByOpenId(String openId);

    /**
     * 查询手机号是否已经绑定
     * @param phone
     * @return string
     */
    String getMemberIdByPhone(String phone);

    /**
     * 查询openId对应的wechar_id
     * @param openId
     * @return string
     */
    String getWecharIdByOpenId(String openId);

    /**
     * 向会员微信关系表里插入数据
     * @param vo
     * @return string
     */
    int insertRelation(MemberWeChatVo vo);

    /**
     * 检查数据库中是否已经存在该条数据
     * @param vo
     * @return string
     */
    int checkExist(MemberWeChatVo vo);

    /**
     * 检查微信用户关系表中是否存在该手机号的相关信息
     * @param phone
     * @return string
     */
    int checkBind(String phone);

    int insertMember(Member member);

}
