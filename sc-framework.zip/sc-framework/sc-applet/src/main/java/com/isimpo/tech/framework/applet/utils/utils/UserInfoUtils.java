/*
 * @(#) UserInfoUtils.java 2019年02月21日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils.utils;

import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.util.CacheUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月21日
 */
public class UserInfoUtils {

    public static UserInfoVo getUserInfo(HttpServletRequest request){
        String currentUserToken = request.getHeader(CommonConstants.CONTEXT_KEY_USER_TOKEN);
        return CacheUtils.get(currentUserToken, UserInfoVo.class);
    }

    /**
     * 更新缓存
     */
    public static void freshUserInfo(HttpServletRequest request, UserInfoVo userInfoVo) {
        String currentUserToken = request.getHeader(CommonConstants.CONTEXT_KEY_USER_TOKEN);
        CacheUtils.set(currentUserToken, userInfoVo,1800);//半小时过期
    }
}
