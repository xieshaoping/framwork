/*
 * Copyright (c) 2018, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils.wxQrcode;

/**
 * key
 *
 * @author Chen.XinBang
 * @version 1.0
 * @since 2018年11月07日
 */
public class CacheConstants {
    //班级ids缓存Key
    public static final String CLASSID_KEY = "CLASSID_KEY_";
    //班级ids缓存Key
    public static final String CLASSID_TEACHER_KEY = "CLASSID_TEACHER_KEY_";
    //班级id缓存时间
    public static final int CLASSID_TIME = 5 * 60 * 60;
    //校区ids缓存Key
    public static final String SCHOOLID_KEY = "SCHOOLID_KEY_";
    //班级ids缓存时间
    public static final int SCHOOLID_TIME = 5 * 60 * 60;
}
