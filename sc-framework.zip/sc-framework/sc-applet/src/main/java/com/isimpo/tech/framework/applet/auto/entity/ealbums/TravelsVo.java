/*
 * @(#) TravelsVo.java 2019年02月15日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.ealbums;

import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月15日
 */
@Table(name = "tra_travels")
public class TravelsVo {

    @Id
    private String id;
    /**内容*/
    private String content;
    /**文件地址(多个图片地址用英文逗号隔开)*/
    private String filePath;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
