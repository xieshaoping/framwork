package com.isimpo.tech.framework.applet.auto.mapper.my;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Route;
import com.isimpo.tech.framework.applet.auto.entity.my.CsrOrder;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface CsrOrderMapper extends Mapper<CsrOrder> {
    List<CsrOrder> findList(Query query);
    CsrOrder selectById(Object id);
    Route getRouteById(String id);
    int updateRoute(Route route);
    List<CsrOrder> findAllList(String userId);
}