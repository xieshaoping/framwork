/*
 * @(#) EAlbumsController.java 2019年02月14日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller.ealbums;

import com.isimpo.tech.framework.applet.auto.entity.ealbums.AlbumVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.service.ealbums.EAlbumsService;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.CacheUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月14日
 */
@RestController
@RequestMapping("album")
public class EAlbumsController
                extends BaseController<EAlbumsService, AlbumVo> {

    /**
     * 电子相册列表
     */
    @GetMapping("albumList")
    public AjaxResponse albumList(HttpServletRequest request,
                    @RequestParam Map<String, Object> params) {
        UserInfoVo userInfoVo = UserInfoUtils.getUserInfo(request);
        params.put("memId",userInfoVo.getMemId());
        return AjaxResponse.of(baseService.albumList(params));
    }

    /**
     * 电子相册删除
     */
    @GetMapping("albumDel") public AjaxResponse albumDel(AlbumVo albumVo) {
        try {
            return AjaxResponse.of(baseService.albumDel(albumVo));
        } catch (Exception e) {
            return AjaxResponse.of(ResponseCode.FAIL);
        }
    }

    /**
     * 行程列表
     */
    @GetMapping("travelList")
    public AjaxResponse travelList(HttpServletRequest request, AlbumVo albumVo) {
        UserInfoVo userInfoVo = UserInfoUtils.getUserInfo(request);
        albumVo.setMemId(userInfoVo.getMemId());
        return AjaxResponse.of(baseService.travelList(albumVo));
    }

    /**
     * 根据行程查询游记列表
     */
    @RequestMapping("travelsList") public AjaxResponse travelsList(AlbumVo albumVo) {
        UserInfoVo userInfoVo = UserInfoUtils.getUserInfo(request);
        albumVo.setMemId(userInfoVo.getMemId());
        return AjaxResponse.of(baseService.travelsList(albumVo));
    }

    /**
     * 电子相册保存
     */
    @RequestMapping("albumSave") public AjaxResponse albumSave(
                    @RequestParam Map<String, Object> params) throws Exception {
        UserInfoVo userInfoVo = UserInfoUtils.getUserInfo(request);
        params.put("memId",userInfoVo.getMemId());
        return AjaxResponse.of(baseService.albumSave(params));
    }

    /**
     * 动态电子相册详情
     */
    @RequestMapping("albumDetail")
    public AjaxResponse albumDetail(HttpServletRequest request, AlbumVo albumVo) {
        return AjaxResponse.of(baseService.albumDetail(albumVo));
    }
}
