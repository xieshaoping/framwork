/*
 * Copyright (c) 2018, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.wechat;

import java.io.Serializable;
import java.util.Map;

/**
 * 微信模版消息
 *
 * @author Fei
 * @version 1.0
 * @since 2018年10月10日
 */
public class WechatTplMsgVo implements Serializable {

    /**
     * 模版ID
     */
    private String template_id;

    /**
     * 接收用户openID
     */
    private String touser;

    /**
     * 连接地址
     */
    private String url;

    /**
     * 标题颜色
     */
    private String topcolor = "#FF0000";

    /**
     * 数据
     */
    private Map<String, WechatTplMsgItemVo> data;

    public String getTemplate_id() {
        return template_id;
    }

    public void setTemplate_id(String template_id) {
        this.template_id = template_id;
    }

    public String getTouser() {
        return touser;
    }

    public void setTouser(String touser) {
        this.touser = touser;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTopcolor() {
        return topcolor;
    }

    public void setTopcolor(String topcolor) {
        this.topcolor = topcolor;
    }

    public Map<String, WechatTplMsgItemVo> getData() {
        return data;
    }

    public void setData(Map<String, WechatTplMsgItemVo> data) {
        this.data = data;
    }
}
