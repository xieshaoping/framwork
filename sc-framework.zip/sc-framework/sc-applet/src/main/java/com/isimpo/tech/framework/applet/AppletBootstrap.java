package com.isimpo.tech.framework.applet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.ace.cache.EnableAceCache;

@EnableEurekaClient
@EnableCircuitBreaker
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class,scanBasePackages = "com.isimpo.tech.framework")
@EnableScheduling
@EnableAceCache
@EnableTransactionManagement
public class AppletBootstrap {

	public static void main(String[] args) {
		SpringApplication.run(AppletBootstrap.class, args);
	}
}
