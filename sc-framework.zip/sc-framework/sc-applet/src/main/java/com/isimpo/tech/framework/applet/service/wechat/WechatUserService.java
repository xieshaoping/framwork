/*
 * @(#) WechatUserService.java 2019年02月13日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.wechat;

import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatUserVo;
import com.isimpo.tech.framework.applet.auto.mapper.wechat.WechatUserMapper;
import com.isimpo.tech.framework.applet.utils.WeinXinUtil;
import com.isimpo.tech.framework.applet.utils.utils.WechatXCXUtils;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.wechat.WeChatConfigUtil;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.pojo.ReceiveMsg;
import com.isimpo.tech.wechat.pojo.WechatConfig;
import com.isimpo.tech.wechat.pojo.WeixinOauthToken;
import com.isimpo.tech.wechat.pojo.user.WechatUserInfo;
import com.xiaoleilu.hutool.util.RandomUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;


/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月13日
 */
@Service
public class WechatUserService {

    @Value("${imagePath.path}")
    String path;

    @Autowired
    private WechatUserMapper wechatUserMapper;

    /**
     *微信用户关注的处理
     */
    public String updateTxWechatSubscribe(ReceiveMsg receiveMsgVo) {
        WechatConfig configVo = WeChatConfigUtil.getWechatConfig();
        // 根据openId获取微信用户基本信息
        String token = WeinXinUtil.getToken(configVo.getAppId(), configVo.getSecret());
        WechatUserInfo userInfo = WechatApi.getWechatUserInfo(token, receiveMsgVo.getFromUserName());
        userInfo.setNickname(userInfo.getNickname().replaceAll("[\\ud800\\udc00-\\udbff\\udfff\\ud800-\\udfff]", "□"));
        //获取头像
        String headImgUrl = userInfo.getHeadimgurl();
        //头像不为空，则保存
        if (!StringUtils.isEmpty(headImgUrl)) {
            headImgUrl = WechatXCXUtils.saveHeadStream(headImgUrl,path);
        }
        userInfo.setHeadimgurl(headImgUrl);
        //封装需要保存的数据
        WechatUserVo userVo = new WechatUserVo();
        userVo.setId(RandomUtil.simpleUUID());
        userVo.setNickName(userInfo.getNickname());
        userVo.setOpenId(userInfo.getOpenid());
        userVo.setPhoto(userInfo.getHeadimgurl());
        //用户关注时，数据库不存在信息则新增，存在则更新
        Integer result = wechatUserMapper.wechatUserSave(userVo);
        if(result == 0){
            // 已存在用户
            UserInfoVo existUser = wechatUserMapper.userInfo(userVo.getOpenId());
            String nickName = existUser.getNickName();
            String photo = existUser.getPhoto();
            // 昵称与头像已存在则保留原来的昵称与头像
            if (nickName != null && !"".equals(nickName)) {
                userVo.setNickName(nickName);
            }
            if (photo != null && !"".equals(photo)) {
                userVo.setPhoto(photo);
            }
            wechatUserMapper.wechatUserUpd(userVo);
        }
        return "";
    }

    /**
     * 微信授权，用户信息存缓存
     */
    public UserInfoVo oauthCallback(HttpServletRequest request, HttpServletResponse response,
                    String code){
        String appId = WeChatConfigUtil.getWechatConfig().getAppId();
        String appsecret = WeChatConfigUtil.getWechatConfig().getSecret();
        WeixinOauthToken weixinOauth2Token = WechatApi.getOauth2AccessToken(appId, appsecret, code);
        String openId = weixinOauth2Token.getOpenid();
        UserInfoVo loginUser = wechatUserMapper.userInfo(openId);
        //用户未关注时先保存openid
        if(null == loginUser) {
            WechatUserVo wechatUserVo = new WechatUserVo();
            wechatUserVo.setId(RandomUtil.simpleUUID());
            wechatUserVo.setOpenId(openId);
            EntityUtils.setCreatAndUpdatInfoTwo(wechatUserVo,wechatUserVo.getId());
            wechatUserMapper.wechatUserSave(wechatUserVo);

            loginUser = new UserInfoVo();
            loginUser.setOpenId(openId);
            loginUser.setWecharId(wechatUserVo.getId());
        }
        return loginUser;
    }

    /**
     * 获取微信分享签名参数
     */
    public Map<String, String> getWxConfig(String linkUrl) {
        WechatConfig configVo = WeChatConfigUtil.getWechatConfig();
        // 获取token
        //String token = WeinXinUtil.getToken(configVo.getAppId(), configVo.getSecret());
        String token = WechatApi.getToken();
        //String ticket = WeinXinUtil.getConfigTicKet(token);
        String ticket = WechatApi.getTicket();
        Map<String, String> ret = WeinXinUtil.sign(ticket,linkUrl);
        ret.put("appId",configVo.getAppId());
        return ret;
    }
}
