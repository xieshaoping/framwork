package com.isimpo.tech.framework.applet.auto.mapper.onroad.timememory;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraBase;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.TimeMemoryVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.TravelRecordVo;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;
import java.util.Map;

/**
 * @author zhuyilong
 * @since 2019/2/13
 */
public interface TimeMemoryMapper extends Mapper<PraiseRecordVo> {
    /**
     * 查询时光留影详情
     * @param id
     * @return
     */
    TimeMemoryVo getTimeMemory(@Param("id") String id, @Param("uid") String uid, @Param("wid") String wid);

    /**
     * 查询时光留影列表
     * @param params
     * @return
     */
    List<TimeMemoryVo> listTimeMemory(Map<String, Object> params);

    /**
     * 查询指定时光留影下的评论列表
     * @param travelRecord
     * @return
     */
//    List<CommentVo> listComment(TravelRecordVo travelRecord);

    /**
     * 查询指定时光留影下的点赞列表
     * @param travelRecord
     * @return
     */
//    List<PraiseRecordVo> listPraiseRecord(TravelRecordVo travelRecord);

    /**
     * 逻辑删除时光留影
     * @param travelRecord
     * @return
     */
    int delTimeMemory(TravelRecordVo travelRecord);

    /**
     * 获取行程的行程事项信息
     * @param travelRecordVo
     * @return
     */
    TravelRecordVo getItemInfo(TravelRecordVo travelRecordVo);

    /**
     * 查询指定游记点赞记录列表
     * @param praiseRecord
     * @return
     */
    List<PraiseRecordVo> listPraiseRecord(PraiseRecordVo praiseRecord);

    /**
     * 添加点赞记录
     * @param praiseRecord
     * @return
     */
    int addPraiseRecord(PraiseRecordVo praiseRecord);

    /**
     * 删除点赞记录
     * @param praiseRecord
     * @return
     */
    int delPraiseRecord(PraiseRecordVo praiseRecord);

    /**
     * 添加行程游记
     * @param travelRecord
     * @return
     */
    int addTravelRecord(TravelRecordVo travelRecord);

    /**
     * 添加评论
     * @param comment
     * @return
     */
    int addComment(CommentVo comment);

    /**
     * 删除评论
     * @param comment
     * @return
     */
    int delComment(CommentVo comment);
}
