package com.isimpo.tech.framework.applet.auto.mapper.onroad;

import java.util.List;

import com.isimpo.tech.framework.applet.auto.entity.onroad.news.ConfirmVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.news.NewsVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.news.TraManageVo;
import com.isimpo.tech.framework.common.util.Query;

import tk.mybatis.mapper.common.Mapper;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/13
 *
 */
public interface NewsMapper extends Mapper<NewsVo> {

    /**
     * 查询可乐消息列表
     * @param query
     * @return
     */
    List<NewsVo> listNews(Query query);

    /**
     * 查询可乐消息确认列表
     * @param list 消息列表
     * @return
     */
    List<MemberVo> getConfirmList(List<NewsVo> list);

    /**
     * 获取可乐消息详情
     * @param newsId
     * @return
     */
    NewsVo getNewsDetail(String newsId);

    /**
     * 删除可乐消息
     * @param news
     * @return
     */
    int delNews(NewsVo news);

    /**
     * 确认可乐消息
     * @param conf
     * @return
     */
    int confirmNews(ConfirmVo conf);

    /**
     * 检查可乐消息是否已经被确认
     * @param conf
     * @return
     */
    int checkConfirm(ConfirmVo conf);

    /**
     * 添加可乐消息
     * @param news
     * @return
     */
    int addNews(NewsVo news);

    /**
     * 查询行程列表
     * @return
     */
    List<TraManageVo> listTravel();

    /**
     * 查询行程下的成员列表
     * @param traId
     * @return
     */
    List<MemberVo> listMember(String traId);
}
