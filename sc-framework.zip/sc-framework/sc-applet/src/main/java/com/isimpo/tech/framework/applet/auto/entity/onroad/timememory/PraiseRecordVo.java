package com.isimpo.tech.framework.applet.auto.entity.onroad.timememory;

import com.isimpo.tech.framework.common.entity.BaseVo;

import java.util.Date;
import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Table(name = "tra_laud_record")
public class PraiseRecordVo extends BaseVo {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 主体id（被评论的游记、旅咖说的id）
     */
    @Column(name = "main_id")
    private String mainId;

    /**
     * 会员id
     */
    @Column(name = "mem_id")
    private String memId;

    /**
     * 类型（1：游记，2：旅咖说）
     */
    private String type;

    /**
     * 点赞人昵称
     */
    private String nickName;

    /**
     * 点赞人头像
     */
    private String photo;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取主体id（被评论的游记、旅咖说的id）
     *
     * @return main_id - 主体id（被评论的游记、旅咖说的id）
     */
    public String getMainId() {
        return mainId;
    }

    /**
     * 设置主体id（被评论的游记、旅咖说的id）
     *
     * @param mainId 主体id（被评论的游记、旅咖说的id）
     */
    public void setMainId(String mainId) {
        this.mainId = mainId;
    }

    /**
     * 获取会员id
     *
     * @return mem_id - 会员id
     */
    public String getMemId() {
        return memId;
    }

    /**
     * 设置会员id
     *
     * @param memId 会员id
     */
    public void setMemId(String memId) {
        this.memId = memId;
    }

    /**
     * 获取类型（1：游记，2：旅咖说）
     *
     * @return type - 类型（1：游记，2：旅咖说）
     */
    public String getType() {
        return type;
    }

    /**
     * 设置类型（1：游记，2：旅咖说）
     *
     * @param type 类型（1：游记，2：旅咖说）
     */
    public void setType(String type) {
        this.type = type;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    @Override
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    public Date getAddTime() {
        return super.getAddTime();
    }
}