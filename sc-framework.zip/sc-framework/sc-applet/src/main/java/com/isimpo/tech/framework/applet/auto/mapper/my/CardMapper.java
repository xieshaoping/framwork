package com.isimpo.tech.framework.applet.auto.mapper.my;

import java.util.List;

import com.isimpo.tech.framework.applet.auto.entity.my.CardVo;

import tk.mybatis.mapper.common.Mapper;

/**
 * 可乐名片
 * @author Tank
 * @version V1.0
 * @since 2019/2/26
 *
 */
public interface CardMapper extends Mapper<CardVo> {

    /**
     * 查询可乐名片消息
     * @param
     * @return CardVo
     */
    CardVo getCardMess();
}
