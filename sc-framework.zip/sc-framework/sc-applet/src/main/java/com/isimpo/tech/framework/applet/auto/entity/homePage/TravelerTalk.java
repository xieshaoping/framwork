package com.isimpo.tech.framework.applet.auto.entity.homePage;

import java.util.Date;
import javax.persistence.*;

@Table(name = "tra_traveler_talk")
public class TravelerTalk {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 会员id
     */
    @Column(name = "mem_id")
    private String memId;

    /**
     * 标题
     */
    private String title;

    /**
     * 摘要
     */
    private String digest;

    /**
     * 封面
     */
    private String cover;

    /**
     * 显示状态（0：隐藏，1：显示）
     */
    private String state;

    /**
     * 视频地址
     */
    @Column(name = "video_path")
    private String videoPath;
    /**视频截图地址*/
    private String screenshot;

    /**
     * 备注
     */
    private String note;

    /**
     * 类型（1：平台，2：会员）
     */
    private String type;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取会员id
     *
     * @return mem_id - 会员id
     */
    public String getMemId() {
        return memId;
    }

    /**
     * 设置会员id
     *
     * @param memId 会员id
     */
    public void setMemId(String memId) {
        this.memId = memId;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取摘要
     *
     * @return digest - 摘要
     */
    public String getDigest() {
        return digest;
    }

    /**
     * 设置摘要
     *
     * @param digest 摘要
     */
    public void setDigest(String digest) {
        this.digest = digest;
    }

    /**
     * 获取封面
     *
     * @return cover - 封面
     */
    public String getCover() {
        return cover;
    }

    /**
     * 设置封面
     *
     * @param cover 封面
     */
    public void setCover(String cover) {
        this.cover = cover;
    }

    /**
     * 获取显示状态（0：隐藏，1：显示）
     *
     * @return state - 显示状态（0：隐藏，1：显示）
     */
    public String getState() {
        return state;
    }

    /**
     * 设置显示状态（0：隐藏，1：显示）
     *
     * @param state 显示状态（0：隐藏，1：显示）
     */
    public void setState(String state) {
        this.state = state;
    }

    public String getScreenshot() {
        return screenshot;
    }

    public void setScreenshot(String screenshot) {
        this.screenshot = screenshot;
    }

    /**
     * 获取视频地址
     *
     * @return video_path - 视频地址
     */
    public String getVideoPath() {
        return videoPath;
    }

    /**
     * 设置视频地址
     *
     * @param videoPath 视频地址
     */
    public void setVideoPath(String videoPath) {
        this.videoPath = videoPath;
    }

    /**
     * 获取备注
     *
     * @return note - 备注
     */
    public String getNote() {
        return note;
    }

    /**
     * 设置备注
     *
     * @param note 备注
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * 获取类型（1：平台，2：会员）
     *
     * @return type - 类型（1：平台，2：会员）
     */
    public String getType() {
        return type;
    }

    /**
     * 设置类型（1：平台，2：会员）
     *
     * @param type 类型（1：平台，2：会员）
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 获取删除标识(1:已删除,0:正常)
     *
     * @return del_flag - 删除标识(1:已删除,0:正常)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:已删除,0:正常)
     *
     * @param delFlag 删除标识(1:已删除,0:正常)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建备注
     *
     * @return add_mark - 创建备注
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建备注
     *
     * @param addMark 创建备注
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新备注
     *
     * @return upd_mark - 更新备注
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新备注
     *
     * @param updMark 更新备注
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }
}
