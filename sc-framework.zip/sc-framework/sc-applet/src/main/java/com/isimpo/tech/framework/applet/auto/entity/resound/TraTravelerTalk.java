package com.isimpo.tech.framework.applet.auto.entity.resound;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 *
 * @author Tank
 * @version V1.0
 * @description 旅咖说 according xyh
 * @since 2019/2/18
 *
 */
@Table(name = "tra_traveler_talk")
public class TraTravelerTalk extends BaseVo {
    //旅咖说id
    @Id
    private String id;

    //会员id
    @Column(name = "mem_id")
    private String memId;

    // 会员头像
    private String photo;

    // 会员昵称
    private String nickName;

    //标题
    @Column(name = "title")
    private String title;

    //摘要
    @Column(name = "digest")
    private String digest;

    //封面
    @Column(name = "cover")
    private String cover;

    //显示状态（0：隐藏，1：显示）
    @Column(name = "state")
    private String state;

    //视频地址
    @Column(name = "video_path")
    private String videoPath;

    // 视频截图
    @Column(name = "screenshot")
    private String screenshot;

    //备注
    @Column(name = "note")
    private String note;

    //类型（1：平台，2：会员）
    @Column(name = "type")
    private String type;

    // 点赞标识 praiseFlag 0-未点赞 1-已点赞
    private String praiseFlag = "0";

    // 点赞列表
    @Transient
    private List<PraiseRecordVo> praiseUsers;

    // 评论列表
    @Transient
    private List<CommentVo> comments;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDigest() {
        return digest;
    }

    public void setDigest(String digest) {
        this.digest = digest;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getVideoPath() {
        return videoPath;
    }

    public void setVideoPath(String videoPath) {
        this.videoPath = videoPath;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<PraiseRecordVo> getPraiseUsers() {
        return praiseUsers;
    }

    public void setPraiseUsers(List<PraiseRecordVo> praiseUsers) {
        this.praiseUsers = praiseUsers;
    }

    public List<CommentVo> getComments() {
        return comments;
    }

    public void setComments(List<CommentVo> comments) {
        this.comments = comments;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getAddTime() {
        return super.getAddTime();
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getUpdTime() {
        return super.getUpdTime();
    }

    public String getPraiseFlag() {
        return praiseFlag;
    }

    public void setPraiseFlag(String praiseFlag) {
        this.praiseFlag = praiseFlag;
    }

    public String getScreenshot() {
        return screenshot;
    }

    public void setScreenshot(String screenshot) {
        this.screenshot = screenshot;
    }
}
