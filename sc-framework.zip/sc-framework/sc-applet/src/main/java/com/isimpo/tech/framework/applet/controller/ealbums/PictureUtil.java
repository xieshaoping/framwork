/*
 * @(#) sss.java 2019年02月18日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller.ealbums;

import org.springframework.beans.factory.annotation.Value;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月18日
 */
public class PictureUtil {

    @Value("${imagePath.path}")
    static String imagePath;

    /**
     * 纵向合图的x坐标像素
     */
    private final static int y_width = 540;

    /**
     * 纵向合成图片
     * @param first 放上面的图片路径
     * @param second 放下面的图片路径
     * @param out 文件输出目录
     * @param border 图片预留边框
     */
    public static boolean yPic(String first, String second, String out,
                    int border) {
        boolean isOk = true;
        try {
            /* 1 读取第一张图片 */
            File fileOne = new File(first);
            BufferedImage imageFirst = ImageIO.read(fileOne);
            int width1 = imageFirst.getWidth();// 图片宽度
            int height1 = imageFirst.getHeight();// 图片高度
            int height = (int)((y_width/(double)width1)*height1);
            int width = y_width;
            // 等比缩放
            imageFirst = resize(imageFirst, width, height);
            width = imageFirst.getWidth();
            height = imageFirst.getHeight();// 图片高度
            int[] imageArrayFirst = new int[(width-border) * height];// 从图片中读取RGB
            imageArrayFirst = imageFirst.getRGB(0, 0, (width-border), height,
                            imageArrayFirst, 0, (width-border));

            /* 2对第二张图片做相同的处理 */
            File fileTwo = new File(second);
            BufferedImage imageSecond = ImageIO.read(fileTwo);
            int widthTwo1 = imageSecond.getWidth();// 图片宽度
            int heightTwo1 = imageSecond.getHeight();// 图片高度
            //第二张图片管理
            int heightTwo = (int)((y_width/(double)widthTwo1)*heightTwo1);
            int widthTwo = y_width;
            // 等比缩放
            imageSecond = resize(imageSecond, widthTwo, heightTwo);
            // 缩放后图片的大小
            widthTwo = imageSecond.getWidth();// 图片宽度
            heightTwo = imageSecond.getHeight();// 图片高度
            /* 2对第二张图片做相同的处理begin */
            int[] imageArraySecond = new int[(widthTwo - border) * heightTwo];
            imageArraySecond = imageSecond.getRGB(border, 0,
                            (widthTwo - border), heightTwo, imageArraySecond, 0,
                            (widthTwo - border));
            int w = y_width;
            // 图片高度
            int h = height + heightTwo + border*2 + 20;
            // 生成新图片
            BufferedImage imageResult = new BufferedImage(w, h,
                            BufferedImage.TYPE_INT_RGB);
            // 解决黑色背景,默认的TYPE_INT_RGB都是0，都是黑色的
            Graphics2D g = (Graphics2D) imageResult.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, w, h);// 填充整个屏幕
            g.dispose();
            //计算图片居中时x位置
            int firstx = (y_width-width)/2+border;
            int secondx = (y_width-widthTwo)/2+border;
            // 留边框
            imageResult.setRGB(firstx, border, (width-border*2), height, imageArrayFirst, 0, (width-border));// 设置上半部分的RGB
            imageResult.setRGB(secondx, (height+border+20), (widthTwo - border * 2),
                            heightTwo, imageArraySecond, 0, (widthTwo - border));// 设置下半部分的RGB
            File outFile = new File(out);
            ImageIO.write(imageResult, "jpg", outFile);// 写图片

        } catch (Exception e) {
            System.out.println("纵向合成图片失败....");
            isOk = false;
        }
        return isOk;
    }

    /**
     * 实现图像的等比缩放
     * @param source 待处理的图片流
     * @param targetW 宽度
     * @param targetH 高度
     * @return
     */
    public static BufferedImage resize(BufferedImage source, int targetW,
                    int targetH) {
        int width = source.getWidth();// 图片宽度
        int height = source.getHeight();// 图片高度
        return zoomInImage(source, targetW, targetH);
    }

    /**
     * 对图片进行强制放大或缩小
     * @param originalImage 原始图片
     * @return
     */
    public static BufferedImage zoomInImage(BufferedImage originalImage,
                    int width, int height) {
        BufferedImage newImage = new BufferedImage(width, height,
                        originalImage.getType());
        Graphics g = newImage.getGraphics();
        g.drawImage(originalImage, 0, 0, width, height, null);
        g.dispose();
        return newImage;
    }

    /**
     *  文字图片合成
     * @param content 文字
     * @param newPicUrl 合成图片地址
     */
    public static void pictureMix(String content,  String newPicUrl) throws Exception {
        int width = 540;// 图片宽度
        int height = getHeight(content,newPicUrl);// 图片高度
        String s = content;
        File file = new File(newPicUrl);
        Font font = new Font("宋体", Font.BOLD, 22);
        BufferedImage bi = new BufferedImage(width, height,
                        BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = (Graphics2D) bi.getGraphics();
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
        g2.setFont(font);
        g2.setBackground(Color.WHITE);
        g2.clearRect(0, 0, width, height);
        g2.setPaint(Color.black);
        FontRenderContext context = g2.getFontRenderContext();
        Rectangle2D bounds = font.getStringBounds(s, context);
        int x = 1;
        int y = 1;
//        double ascent = -bounds.getY();
//        double baseY = y + ascent;
        String tempStr = "";
        int tempy = 0;
        int charLength = 0;
        StringBuilder sb = new StringBuilder();
        for(int i=0; i<content.length(); i++) {
            int oneCharLength = getCharLen(content.charAt(i),g2);
            charLength += oneCharLength;
            if(charLength >= (width)) {
                y = y+25;
                //长度已经满一行,进行文字叠加
                g2.drawString(sb.toString(), 0, y);
                sb.delete(0, sb.length());//清空内容,重新追加
                height += 30;
                charLength = oneCharLength;
            }
            sb.append(content.charAt(i));
        }
        g2.drawString(sb.toString(),0,y+25);

        ImageIO.write(bi, "jpg", file);
    }

    public static int getHeight(String content,String newPicUrl){
        int width = 540;// 图片宽度
        int height = 30;// 图片高度
        String s = content;
        File file = new File(newPicUrl);
        Font font = new Font("宋体", Font.BOLD, 22);
        BufferedImage bi = new BufferedImage(width, height,
                BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = (Graphics2D) bi.getGraphics();
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
        g2.setFont(font);
        int length = getWatermarkLength(s,g2);
        height = ((length/width) + 1)*30;
        return height;
    }

    public static int getCharLen(char c, Graphics2D g) {
        return g.getFontMetrics(g.getFont()).charWidth(c);
    }

    /**
     * 获取水印文字总长度
     *@paramwaterMarkContent水印的文字
     *@paramg
     *@return水印文字总长度
     */
    public static int getWatermarkLength(String waterMarkContent, Graphics2D g) {
        return g.getFontMetrics(g.getFont()).charsWidth(waterMarkContent.toCharArray(),0, waterMarkContent.length());
    }

    /**
     * 图片copy
     * @param oldPicUrl 图片地址
     * @param newPicUrl 复制后新地址
     * @throws Exception
     */
    public static void copyPicture(String oldPicUrl, String newPicUrl) throws Exception{
        File fileOne = new File(oldPicUrl);
        BufferedImage imageFirst = ImageIO.read(fileOne);
        File file = new File(newPicUrl);
        ImageIO.write(imageFirst, "jpg", file);
    }

    public static void main(String[] args) throws Exception {

        String first = "D:/upload/d/2.jpg";
        String second = "D:/upload/d/1.jpg";
        String out = "D:/upload/d/tu48.jpg";
        pictureMix("风景很美风景很美风景很美风景很美风景很美风景很美风景很美风景很美风景很美风景很美风景很美风景很美风景很美风景很美风景很美",out);
//        yPic(out,first,out,0);
//        yPic(out,second,out,20);
    }
}
