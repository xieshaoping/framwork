package com.isimpo.tech.framework.applet.controller.meet.route;

/**
 * @author zhuyilong
 * @since 2019/2/27
 */

import com.isimpo.tech.framework.applet.auto.entity.meet.route.RouteVo;
import com.isimpo.tech.framework.applet.service.meet.route.RouteService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 路线管理
 */
@RestController("routeManageController")
@RequestMapping("/meet/route")
public class RouteController extends BaseController<RouteService, RouteVo> {
    /**
     * 分页获取路线列表
     * @param params
     * @return
     */
    @RequestMapping("/list")
    public AjaxResponse getRouteList(@RequestParam Map<String, Object> params) {
        return baseService.getRouteList(new Query(params));
    }
}
