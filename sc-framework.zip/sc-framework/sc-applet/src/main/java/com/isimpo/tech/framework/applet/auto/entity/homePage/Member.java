package com.isimpo.tech.framework.applet.auto.entity.homePage;

import java.util.Date;
import javax.persistence.*;

@Table(name = "csr_member")
public class Member {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 姓名
     */
    private String name;

    /**
     * 性别（0：女，1：男）
     */
    private String gender;

    /**
     * 生日
     */
    private Date birthday;

    /**
     * 手机
     */
    private String phone;

    /**
     * 证件类型（关联字典表信息）
     */
    @Column(name = "id_type")
    private String idType;

    /**
     * 证件号码
     */
    @Column(name = "id_num")
    private String idNum;

    /**
     * 联系地址
     */
    private String source;

    /**
     * 备注
     */
    private String note;

    /**
     * 类型（1：会员，2：管家）
     */
    private String type;

    /**
     * 达人标识（0：否，1是）
     */
    @Column(name = "talent_flag")
    private String talentFlag;

    /**
     * 查看全部行程（0：否，1是）
     */
    @Column(name = "all_flag")
    private String allFlag;

    //团长标识
    @Transient
    private String leaderFlag;

    //管家标识
    @Transient
    private String housekeeperFlag;

    //领队标识
    @Transient
    private String guideFlag;

    //头像
    @Transient
    private String photo;

    // -- 1:管家，2：领队，3：团长，4：普通会员
    @Transient
    private String role;

    //openId
    @Transient
    private String openId;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取姓名
     *
     * @return name - 姓名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置姓名
     *
     * @param name 姓名
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取性别（0：女，1：男）
     *
     * @return gender - 性别（0：女，1：男）
     */
    public String getGender() {
        return gender;
    }

    /**
     * 设置性别（0：女，1：男）
     *
     * @param gender 性别（0：女，1：男）
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * 获取生日
     *
     * @return birthday - 生日
     */
    public Date getBirthday() {
        return birthday;
    }

    /**
     * 设置生日
     *
     * @param birthday 生日
     */
    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    /**
     * 获取手机
     *
     * @return phone - 手机
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 设置手机
     *
     * @param phone 手机
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * 获取证件类型（关联字典表信息）
     *
     * @return id_type - 证件类型（关联字典表信息）
     */
    public String getIdType() {
        return idType;
    }

    /**
     * 设置证件类型（关联字典表信息）
     *
     * @param idType 证件类型（关联字典表信息）
     */
    public void setIdType(String idType) {
        this.idType = idType;
    }

    /**
     * 获取证件号码
     *
     * @return id_num - 证件号码
     */
    public String getIdNum() {
        return idNum;
    }

    /**
     * 设置证件号码
     *
     * @param idNum 证件号码
     */
    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    /**
     * 获取联系地址
     *
     * @return source - 联系地址
     */
    public String getSource() {
        return source;
    }

    /**
     * 设置联系地址
     *
     * @param source 联系地址
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * 获取备注
     *
     * @return note - 备注
     */
    public String getNote() {
        return note;
    }

    /**
     * 设置备注
     *
     * @param note 备注
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * 获取类型（1：会员，2：管家）
     *
     * @return type - 类型（1：会员，2：管家）
     */
    public String getType() {
        return type;
    }

    /**
     * 设置类型（1：会员，2：管家）
     *
     * @param type 类型（1：会员，2：管家）
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 获取达人标识（0：否，1是）
     *
     * @return talent_flag - 达人标识（0：否，1是）
     */
    public String getTalentFlag() {
        return talentFlag;
    }

    /**
     * 设置达人标识（0：否，1是）
     *
     * @param talentFlag 达人标识（0：否，1是）
     */
    public void setTalentFlag(String talentFlag) {
        this.talentFlag = talentFlag;
    }

    /**
     * 获取删除标识(1:已删除,0:正常)
     *
     * @return del_flag - 删除标识(1:已删除,0:正常)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:已删除,0:正常)
     *
     * @param delFlag 删除标识(1:已删除,0:正常)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建备注
     *
     * @return add_mark - 创建备注
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建备注
     *
     * @param addMark 创建备注
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新备注
     *
     * @return upd_mark - 更新备注
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新备注
     *
     * @param updMark 更新备注
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    public String getLeaderFlag() {
        return leaderFlag;
    }

    public void setLeaderFlag(String leaderFlag) {
        this.leaderFlag = leaderFlag;
    }

    public String getHousekeeperFlag() {
        return housekeeperFlag;
    }

    public void setHousekeeperFlag(String housekeeperFlag) {
        this.housekeeperFlag = housekeeperFlag;
    }

    public String getGuideFlag() {
        return guideFlag;
    }

    public void setGuideFlag(String guideFlag) {
        this.guideFlag = guideFlag;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getAllFlag() {
        return allFlag;
    }

    public void setAllFlag(String allFlag) {
        this.allFlag = allFlag;
    }
}