package com.isimpo.tech.framework.applet.controller.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraEvaluate;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraStaCommon;
import com.isimpo.tech.framework.applet.service.onroad.everyTrip.TraEvaluService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

/**
 * 行程评价
 * @author wangxinhai
 * @version V1.0
 * @since 2019/5/22
 */
@RestController
@RequestMapping("/onroad/traEvaluate")
public class TraEvaluController extends BaseController<TraEvaluService, TraEvaluate> {
    /**
     * 增加
     * @param traStaCommon
     * @return
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResponse add(@RequestBody TraStaCommon traStaCommon){
        return AjaxResponse.of(baseService.add(traStaCommon));
    }

    @GetMapping("/getTraEvalu")
    public AjaxResponse getTraEvalu(TraEvaluate traEvaluate){
        return AjaxResponse.of(baseService.getTraEvalu(traEvaluate));
    }
}
