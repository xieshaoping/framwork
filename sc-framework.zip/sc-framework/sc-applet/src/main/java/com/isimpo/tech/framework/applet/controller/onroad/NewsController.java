package com.isimpo.tech.framework.applet.controller.onroad;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.applet.auto.entity.onroad.news.NewsVo;
import com.isimpo.tech.framework.applet.service.onroad.NewsService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 
 * @author Tank
 * @version V1.0
 * @since 2019/2/13
 *
 */
@RestController
@RequestMapping("/news")
public class NewsController extends BaseController<NewsService, NewsVo> {

    /**
     * 查询可乐消息列表
     * @param params
     * @return
     */
    @GetMapping("/list")
    public AjaxResponse getNewsList(@RequestParam Map<String, Object> params) {
        Query query = new Query(params);
        return baseService.getNews(query);
    }

    /**
     * 删除可乐消息
     * @param news
     * @return
     */
    @GetMapping("/del")
    public AjaxResponse delNews(NewsVo news) {
        return baseService.delNews(news);
    }

    /**
     * 确认可乐消息
     * @param newsId memId
     * @return
     */
    @GetMapping("/confirm")
    public AjaxResponse delNews(String newsId,String memId) {
        return baseService.confirmNews(newsId,memId);
    }

    /**
     * 查询消息详情
     * @param newsId 消息id
     * @return
     */
    @GetMapping("/detail")
    public AjaxResponse getNewsDetail(String newsId) {
        return baseService.getNewsDetail(newsId);
    }
    /**
     * 添加可乐消息
     * @param news
     * @return
     */
    @PostMapping("/add")
    public AjaxResponse addNews(@RequestBody NewsVo news) {
        return baseService.addNews(news);
    }

    /**
     * 查询行程列表
     * @return
     */
    @GetMapping("/listTra")
    public AjaxResponse getTravelList() {
        return baseService.getTravelList();
    }

    /**
     * 查询行程列表-昵称、头像
     * @param traId
     * @return
     */
    @GetMapping("/listMember")
    public AjaxResponse getMemberList(String traId) {
        return baseService.getMemberList(traId);
    }


}
