package com.isimpo.tech.framework.applet.auto.entity.resound.strategy;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.TraTravelerTalk;
import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 * 旅游攻略
 * @author Tank
 * @version V1.0
 * @since 2019/2/21
 *
 */
@Table(name = "cont_strategy")
public class StrategyVo extends BaseVo {
    // id
    private String id;

    // 标题
    private String title;

    // 封面
    private String cover;

    // 显示状态 0-隐藏 1-显示
    private String state;

    // 出发时间
    private String setOut;

    // 行程天数
    private Integer days;

    // 人均花费
    private String cost;

    // 出行伙伴
    private String companion;

    // 摘要
    private String summary;

    // 详细介绍
    private String content;

    // 来源 1-平台 2-达人
    private String source;

    // 作者 会员id
    private String author;

    // 作者头像
    private String photo;

    // 作者昵称
    private String nickName;

    // 作者是否是达人
    private String talentFlag = "0";

    // 点赞数量
    private int praiseNum = 0;

    // 是否已点赞
    private String praiseFlag = "0";

    // 是否置顶 0-不置顶  1-置顶
    private String topFlag = "0";

    // 点赞列表
    @Transient
    private List<PraiseRecordVo> praiseUsers;

    // 评论列表
    @Transient
    private List<CommentVo> comments;
    /**名字*/
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getSetOut() {
        return setOut;
    }

    public void setSetOut(String setOut) {
        this.setOut = setOut;
    }

    public Integer getDays() {
        return days;
    }

    public void setDays(Integer days) {
        this.days = days;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getCompanion() {
        return companion;
    }

    public void setCompanion(String companion) {
        this.companion = companion;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPraiseNum() {
        return praiseNum;
    }

    public void setPraiseNum(int praiseNum) {
        this.praiseNum = praiseNum;
    }

    public List<PraiseRecordVo> getPraiseUsers() {
        return praiseUsers;
    }

    public void setPraiseUsers(List<PraiseRecordVo> praiseUsers) {
        this.praiseUsers = praiseUsers;
    }

    public List<CommentVo> getComments() {
        return comments;
    }

    public void setComments(List<CommentVo> comments) {
        this.comments = comments;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getAddTime() {
        return super.getAddTime();
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getUpdTime() {
        return super.getUpdTime();
    }

    public String getPraiseFlag() {
        return praiseFlag;
    }

    public void setPraiseFlag(String praiseFlag) {
        this.praiseFlag = praiseFlag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTalentFlag() {
        return talentFlag;
    }

    public void setTalentFlag(String talentFlag) {
        this.talentFlag = talentFlag;
    }

    public String getTopFlag() {
        return topFlag;
    }

    public void setTopFlag(String topFlag) {
        this.topFlag = topFlag;
    }
}
