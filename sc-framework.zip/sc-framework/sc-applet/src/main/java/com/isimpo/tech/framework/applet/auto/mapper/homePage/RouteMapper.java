package com.isimpo.tech.framework.applet.auto.mapper.homePage;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Route;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface RouteMapper extends Mapper<Route> {

    List<Route> findList(Query query);
}
