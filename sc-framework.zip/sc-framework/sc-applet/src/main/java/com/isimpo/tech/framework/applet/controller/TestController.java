/*
 * Copyright (c) 2018, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller;

import org.springframework.web.bind.annotation.*;

import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.Map;

/**
 * testController
 */
@RestController
@Api(tags = "测试controller")
@RequestMapping("/test")
public class TestController {

    /**
     * 测试
     *
     * @return 10000成功
     */
    @GetMapping("/test")
    @ApiOperation(value = "测试方法", notes = "方法测试")
    public AjaxResponse test() {
        return AjaxResponse.of(ResponseCode.SUCCESS,"get请求成功");
    }


    @PostMapping("/testSubmit")
    @ResponseBody
    public AjaxResponse testSubmit(@RequestParam Map<String,Object> params){
        System.out.println(params);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }
}
