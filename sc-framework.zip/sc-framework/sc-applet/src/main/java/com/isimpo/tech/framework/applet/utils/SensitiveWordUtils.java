package com.isimpo.tech.framework.applet.utils;

/**
 * @author zhuyilong
 * @since 2019/3/8
 */

/**
 * 敏感词过滤工具类
 */
public class SensitiveWordUtils {
    // 敏感词过滤器单例
    private static SensitiveWord sensitiveWord = new SensitiveWord();
    // 工具类，不允许构造实例
    private SensitiveWordUtils() {}

    /**
     * 获取敏感词过滤类单例（线程安全）
     * @return
     */
    public static synchronized SensitiveWord getSensitiveWord() {
        if (sensitiveWord == null) {
            sensitiveWord = new SensitiveWord();
        }
        return sensitiveWord;
    }

    /**
     * 将SensitiveWord单例置为null，触发下次重新加载该实例
     */
    public static synchronized void reloadSensitiveWord() {
        if (sensitiveWord != null) {
            sensitiveWord = null;
        }
    }

    /**
     * 敏感词过滤
     * @param str   要过滤的字符串
     * @return  过滤后的字符串
     */
    public static String filterStr(String str) {
        return getSensitiveWord().filterInfo(str);
    }
}
