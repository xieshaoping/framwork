package com.isimpo.tech.framework.applet.controller.resound;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.TraTravelerTalk;
import com.isimpo.tech.framework.applet.auto.entity.resound.strategy.StrategyVo;
import com.isimpo.tech.framework.applet.service.resound.StrategyService;
import com.isimpo.tech.framework.applet.service.resound.TraTravelerTalkService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 攻略控制器
 * @author Tank
 * @version V1.0
 * @since 2019/2/21
 *
 */
@RestController
@RequestMapping("/strategy")
public class StrategyController extends BaseController<StrategyService,StrategyVo>{

    /**
     * 查询我的攻略列表
     * @param param-如果传会员则是会员攻略列表,如果是空字符串则是全部列表
     * @return
     */
    @GetMapping("/list")
    public AjaxResponse getTraTalkList(@RequestParam Map<String,Object> param) {
        Query query = new Query(param);
        return baseService.getStrategyList(query);
    }

    /**
     * 查询攻略表里是否存在某会员的攻略
     * @param memId
     * @return boolean
     */
    @GetMapping("/checkExist")
    public AjaxResponse check(String memId) {
        return baseService.checkExist(memId);
    }

    /**
     * 查询攻略详情-根据攻略id
     * @param id
     * @return
     */
    @GetMapping("/detail")
    public AjaxResponse getDetail(String id) {
        return baseService.getDetail(id);
    }

    /**
     * 添加攻略
     * @param vo
     * @return
     */
    @PostMapping("/add")
    public AjaxResponse addTraTalk(@RequestBody StrategyVo vo) {
        return baseService.addStrategy(vo);
    }

    /**
     * 点赞
     * @param praiseRecord
     * @return
     */
    @GetMapping("/praise")
    public AjaxResponse praise(PraiseRecordVo praiseRecord) {
        return baseService.praise(praiseRecord);
    }

    /**
     * 取消赞
     * @param praiseRecord
     * @return
     */
    @GetMapping("/unPraise")
    public AjaxResponse unPraise(PraiseRecordVo praiseRecord) {
        return baseService.unPraise(praiseRecord);
    }

    /**
     * 增加评论
     * @param comment
     * @return
     */
    @PostMapping("/addComment")
    public AjaxResponse addComment(@RequestBody CommentVo comment) {
        return baseService.addComment(comment);
    }

    /**
     * 删除评论
     * @param commentVo
     * @return
     */
    @GetMapping("/delComment")
    public AjaxResponse delComment(CommentVo commentVo) {
        return baseService.delComment(commentVo);
    }

}
