package com.isimpo.tech.framework.applet.controller.reverberation;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Article;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.strategy.StrategyVo;
import com.isimpo.tech.framework.applet.service.resound.StrategyService;
import com.isimpo.tech.framework.applet.service.reverberation.ArticleService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 攻略控制器
 * @author Tank
 * @version V1.0
 * @since 2019/2/21
 *
 */
@RestController
@RequestMapping("/reverberation/article")
public class ArticleController extends BaseController<ArticleService, Article>{

//    /**
//     * 查询
//     * @param
//     * @return
//     */
//    @GetMapping("/list")
//    public AjaxResponse getArticleList() {
//        return baseService.getArticleList();
//    }

    @GetMapping("/list")
    @ResponseBody
    public AjaxResponse getArticleList(@RequestParam Map<String, Object> params) {
        Query query = new Query(params);
        return AjaxResponse.of(baseService.getArticleList(query));
    }

    /**
     * 查询我的旅咖说列表
     * @param id
     * @return
     */
    @GetMapping("/getOne")
    public AjaxResponse getOne(String id) {
        return baseService.getOne(id);
    }

}
