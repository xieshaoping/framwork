package com.isimpo.tech.framework.applet.controller.my;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.applet.auto.entity.my.CardVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.wish.WishVo;
import com.isimpo.tech.framework.applet.service.my.CardService;
import com.isimpo.tech.framework.applet.service.onroad.WishService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 可乐名片
 * @author Tank
 * @version V1.0
 * @since 2019/2/26
 *
 */
@RestController
@RequestMapping("/card")
public class CardController extends BaseController<CardService, CardVo> {

    /**
     * 查询可乐名片
     * @param
     * @return
     */
    @GetMapping("/message")
    public AjaxResponse getCard() {
        return baseService.getCardMess();
    }

}
