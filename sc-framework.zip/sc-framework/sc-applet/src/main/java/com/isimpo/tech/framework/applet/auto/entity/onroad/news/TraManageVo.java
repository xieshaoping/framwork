/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.onroad.news;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 * 行程管理
 * @author Tank
 * @version V1.0
 * @since 2019/1/29
 *
 */
public class TraManageVo extends BaseVo {
    /** id*/
    private String id;
    /** 名称*/
    private String name;
    /** 客户id*/
    private String customerId;
    /** 客户姓名*/
    private String customerName;
    /** 联系人*/
    private String contact;
    /** 手机号码*/
    private String phone;
    /** 开始日期*/
    private Date startDate;
    /** 结束日期*/
    private Date endDate;
    /** 管家id*/
    private String housekeeperId;
    /** 管家名称*/
    private String housekeeperName;
    /** 领队id*/
    private String guiderId;
    /** 领队名称*/
    private String guiderName;
    /** 行程状态*/
    private String state;
    /** 行程状态*/
    private String cover;
    /** 备注*/
    private String note;
    /** 紧急联系电话*/
    private String urgentPhone;
    /** 修改人姓名*/
    private String updUser;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonFormat(pattern="yyyy-MM-dd")
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    @JsonFormat(pattern="yyyy-MM-dd")
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getHousekeeperName() {
        return housekeeperName;
    }

    public void setHousekeeperName(String housekeeperName) {
        this.housekeeperName = housekeeperName;
    }

    public String getGuiderName() {
        return guiderName;
    }

    public void setGuideName(String guiderName) {
        this.guiderName = guiderName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getUpdUser() {
        return updUser;
    }

    public void setUpdUser(String updUser) {
        this.updUser = updUser;
    }

    public String getHousekeeperId() {
        return housekeeperId;
    }

    public void setHousekeeperId(String housekeeperId) {
        this.housekeeperId = housekeeperId;
    }

    public String getGuiderId() {
        return guiderId;
    }

    public void setGuiderId(String guiderId) {
        this.guiderId = guiderId;
    }

    public void setGuiderName(String guiderName) {
        this.guiderName = guiderName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getUrgentPhone() {
        return urgentPhone;
    }

    public void setUrgentPhone(String urgentPhone) {
        this.urgentPhone = urgentPhone;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    @Override
    public String toString() {
        return "TraManageVo{" + "id='" + id + '\'' + ", name='" + name + '\'' + ", contact='" + contact + '\''
                + ", phone='" + phone + '\'' + '}';
    }
}
