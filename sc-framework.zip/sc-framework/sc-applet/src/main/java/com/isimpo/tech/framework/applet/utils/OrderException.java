/*
 * @(#) DineOrderException.java 2018年06月09日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils;


public class OrderException extends RuntimeException {
    public OrderException(){
        super();
    }

    public OrderException(String message){
        super(message);
    }
}
