package com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip;

import java.util.List;

public class TraPlaceTraItem {
    private String id;
    private String enName; //地点名称
    List<TraItem> traItemList; //行程列表
    List<TraSupp> traSuppList; //补充列表

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public List<TraItem> getTraItemList() {
        return traItemList;
    }

    public void setTraItemList(List<TraItem> traItemList) {
        this.traItemList = traItemList;
    }

    public List<TraSupp> getTraSuppList() {
        return traSuppList;
    }

    public void setTraSuppList(List<TraSupp> traSuppList) {
        this.traSuppList = traSuppList;
    }
}
