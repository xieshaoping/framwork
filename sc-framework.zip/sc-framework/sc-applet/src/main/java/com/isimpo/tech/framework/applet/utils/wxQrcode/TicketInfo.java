/*
 * @(#) TicketInfo.java 2015年4月9日
 *
 * Copyright (c) 2010, HMI Technology. All Rights Reserved.
 * HMI Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils.wxQrcode;

/**
 * 
 * 
 * @author zhengjiudong
 * @version 1.0
 * @since 2015年4月9日
 */
public class TicketInfo {
	
	private String ticket;       //二维码ticket凭证
	private long expire_seconds; //有效时间
	private String url;//二维码图片解析后的地址
	
	public String getTicket() {
		return ticket;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public long getExpire_seconds() {
		return expire_seconds;
	}

	public void setExpire_seconds(long expire_seconds) {
		this.expire_seconds = expire_seconds;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
