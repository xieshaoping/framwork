package com.isimpo.tech.framework.applet.controller.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraItem;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraSupp;
import com.isimpo.tech.framework.applet.service.onroad.everyTrip.TraItemService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;


/**
 * 行程事项
 * @author wangxinhai
 * @version V1.0
 * @since 2019/2/18
 */
@RestController
@RequestMapping("/onroad/traItem")
public class TraItemController extends BaseController<TraItemService, TraItem> {


    /**
     * 增加
     * @param entity
     * @return
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResponse add(@RequestBody TraItem entity) {
        baseService.insertSelective(entity);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 修改
     * @param entity
     * @return
     */
    @PostMapping("/update")
    @ResponseBody
    public AjaxResponse update(@RequestBody TraItem entity) {
        baseService.updateSelectiveById(entity);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    @Override
    @DeleteMapping("/{id}")
    @ResponseBody
    public AjaxResponse remove(@PathVariable String id) {
        baseService.deleteById(id);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 行程补充添加
     * @param traSupp
     * @return
     */
    @ResponseBody
    @PostMapping("/addTraSupp")
    public AjaxResponse addTraSupp(@RequestBody TraSupp traSupp){
        return baseService.addTraSupp(traSupp);
    }

    /**
     * 行程补充修改
     * @param traSupp
     * @return
     */
    @ResponseBody
    @PostMapping("/updateTraSupp")
    public AjaxResponse updateTraSupp(@RequestBody TraSupp traSupp){
        return baseService.updateTraSupp(traSupp);
    }

    /**
     * 行程补充详情
     * @param id
     * @return
     */
    @GetMapping("/getTraSupp")
    public AjaxResponse getTraSupp(String id){
        return AjaxResponse.of(baseService.getTraSupp(id));
    }
}
