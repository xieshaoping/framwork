package com.isimpo.tech.framework.applet.service.onroad;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import com.alibaba.fastjson.JSONObject;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraBase;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatTplMsgItemVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatTplMsgVo;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip.TraItemMapper;
import com.isimpo.tech.framework.applet.utils.WeinXinUtil;
import com.isimpo.tech.framework.applet.utils.utils.HttpClientUtils;
import com.isimpo.tech.wechat.WeChatConfigUtil;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.WechatConstants;
import com.isimpo.tech.wechat.pojo.WechatConfig;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.onroad.news.ConfirmVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.news.NewsVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.news.TraManageVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.NewsMapper;
import com.isimpo.tech.framework.applet.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/13
 *
 */
@Service
public class NewsService extends BaseService<NewsMapper, NewsVo> {

    private Logger logger = LoggerFactory.getLogger(NewsService.class);

    @NotNull
    @Value("${templateId}")
    private String templateId;

    @NotNull
    @Value("${h5Url}")
    private String h5Url;

    @Autowired
    HttpServletRequest request;

    @Autowired
    private TraItemMapper traItemMapper;

    /**
     * 分页查询可乐消息列表
     * @param query
     * @return
     */
    public AjaxResponse getNews(Query query) {
        // 从缓存中获取对象
        UserInfoVo uservo = UserInfoUtils.getUserInfo(request);

        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<NewsVo> list = mapper.listNews(query);
        //查询所有消息的确认列表,如果该行程没有消息，则直接返回
        if(list.size()>0){
            List<MemberVo> members = mapper.getConfirmList(list);
            //遍历两个列表，循环匹配
            for(NewsVo news: list){
                List<MemberVo> temp = new ArrayList<>();
                for(MemberVo member: members){
                    if(StringUtils.equals(news.getId(),member.getNewsId())){
                        temp.add(member);
                        // 如果确认列表里包含当前登录人，则将当前消息的确认设置为已确认
                        if(StringUtils.equals(uservo.getWecharId(),member.getWecharId())){
                            news.setConfirmFlag("1");
                        }
                    }
                }
                news.setConfirmList(temp);
            }
        }
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }

    /**
     * 查询可乐消息详情
     * @param newsId
     * @return
     */
    public AjaxResponse getNewsDetail(String newsId) {
        if(newsId == null || newsId.trim().isEmpty()){
            return AjaxResponse.of(ResponseCode.FAIL);
        }

        // 从缓存中获取对象
        UserInfoVo uservo = UserInfoUtils.getUserInfo(request);
        NewsVo news = mapper.getNewsDetail(newsId);
        if (news == null) {
            return AjaxResponse.of(20001,"改行程已被作者删除!");
        }
        List<NewsVo> list = new ArrayList<>();
        list.add(news);
        List<MemberVo> members = mapper.getConfirmList(list);
        for(MemberVo member: members){
            // 如果确认列表里包含当前登录人，则将当前消息的确认设置为已确认
            if(StringUtils.equals(uservo.getWecharId(),member.getWecharId())){
                news.setConfirmFlag("1");
            }
        }
        news.setConfirmList(members);
        return AjaxResponse.of(list);
    }

    /**
     * 删除可乐消息
     * @param news
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delNews(NewsVo news) {
        EntityUtils.setUpdatedInfo(news);
        int count = mapper.delNews(news);
        if (count > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 确认可乐消息
     * @param newsId memberId
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse confirmNews(String newsId,String memId) {
        ConfirmVo confirm = new ConfirmVo();
        confirm.setMemId(memId);
        confirm.setNewsId(newsId);
        // 首先检查用户是否已经确认过该消息，如果已经确认则直接返回
        int isConfirm = mapper.checkConfirm(confirm);
        if(isConfirm>0){
            return AjaxResponse.of(ResponseCode.FAIL,"该用户已经确认");
        }
        EntityUtils.setCreatAndUpdatInfo(confirm);
        int count = mapper.confirmNews(confirm);
        if (count > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 添加可乐消息
     * @param news
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addNews(NewsVo news) {
        news.setContent(SensitiveWordUtils.filterStr(news.getContent().toString()));
        EntityUtils.setCreatAndUpdatInfo(news);
        int result = mapper.addNews(news);
        if (result > 0) {
            setTemplantDate("可乐消息发布",news.getContent(),news.getTraId(),news.getHousekeeperId(),news.getId());
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 发送模板消息
     *
     * @param name
     * @param content
     * @param traId
     */
    public void setTemplantDate(String name, String content,String traId,String memId,String newsId) {
        //查询该行程所在的成员  openId
        //List<String> authPeoples = traItemMapper.getMemberListByTraId(traId).stream().map(Member::getOpenId).collect(Collectors.toList());
        List<Member> list = traItemMapper.getMemberListByTraId(traId);
        List<Member> memberList = traItemMapper.findAllFlagMember();
        Member member = traItemMapper.getMemberOpenId(memId);
        list.addAll(memberList);
        list.add(member);
        TraBase traBase = traItemMapper.getTramById(traId);
        List<String> openIds = new ArrayList<>();
        openIds.add("1");
        for (int i = 0;i<list.size();i++) {
            //发送模板消息
            WechatTplMsgVo tplMsgVo = new WechatTplMsgVo();
            tplMsgVo.setTemplate_id(templateId);
            tplMsgVo.setUrl(h5Url + "static/page/onroad/news/newsDetail.html?newsId=" + newsId);
            Map<String, WechatTplMsgItemVo> map = new HashMap<>();
            map.put("first",new WechatTplMsgItemVo("尊敬的"+list.get(i).getName()+"，您好，可乐国旅温馨提醒。"));
            map.put("keyword1",new WechatTplMsgItemVo(traBase.getName()));
            map.put("keyword2",new WechatTplMsgItemVo("可乐消息"));
            map.put("keyword3",new WechatTplMsgItemVo(content));
            map.put("remark", new WechatTplMsgItemVo(""));
            tplMsgVo.setData(map);
            if(openIds.contains(list.get(i).getOpenId())){
                continue;
            }
            if(list.get(i).getOpenId() != null){
                openIds.add(list.get(i).getOpenId());
                sendTplMsg(tplMsgVo, list.get(i).getOpenId());
            }else{
                logger.error("发送模版消息失败：token:{} 或 没有审核人员");
            }
        }
    }

    public boolean sendTplMsg(WechatTplMsgVo tplMsgVo, String openId){
        WechatConfig wechatConfig = WeChatConfigUtil.getWechatConfig();
        String accessToken = WechatApi.getToken();//WeinXinUtil.getAccessToken(wechatConfig.getAppId(),wechatConfig.getSecret());//WechatApi.getToken();
        Boolean success = false;
        if (StringUtils.isNotEmpty(openId) && StringUtils.isNotEmpty(accessToken)) {
            String requestUrl = WechatConstants.WECHAT_SEND_WECHAT_URL.replace("#ACCESS_TOKEN#", accessToken);
            tplMsgVo.setTouser(openId);
            String params = JSONObject.toJSONString(tplMsgVo);
            params = stringUncode(params);
            try {
                String result = HttpClientUtils.sendPostSSLRequest(requestUrl, params);
                if (StringUtils.isNotBlank(result)) {
                    JSONObject jsonObject = JSONObject.parseObject(result);
                    if (jsonObject.containsKey("errcode") && jsonObject.getIntValue("errcode") == 0) {
                        success = true;
                        logger.info("发送模版消息成功：token:{}：{}：{}", accessToken, params, result);
                    } else {
                        logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                    }
                } else {
                    logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                }
            } catch (Exception ex) {
                logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, ex);
            }
        } else {
            logger.error("发送模版消息失败：token:{} 或 没有审核人员", accessToken);
        }
        return success;
    }

    /**
     * 发送给模版消息
     * @param tplMsgVo 消息内容
     * @param list  用户openid集合
     * @return 是否有发送成功的
     *//*
    public boolean sendTplMsgs(WechatTplMsgVo tplMsgVo, List<Member> list, int checkNum) {
        WechatConfig wechatConfig = WeChatConfigUtil.getWechatConfig();
        String accessToken = WeinXinUtil.getAccessToken(wechatConfig.getAppId(),wechatConfig.getSecret());//WechatApi.getToken();
        Boolean success = false;
        if (!CollectionUtils.isEmpty(list) && StringUtils.isNotEmpty(accessToken)) {
            String requestUrl = WechatConstants.WECHAT_SEND_WECHAT_URL.replace("#ACCESS_TOKEN#", accessToken);
            for (int i = 0; i < list.size(); i++) {
                tplMsgVo.setTouser(list.get(i).getOpenId());
                String params = JSONObject.toJSONString(tplMsgVo);
                params = stringUncode(params);
                try {
                    String result = HttpClientUtils.sendPostSSLRequest(requestUrl, params);
                    if (StringUtils.isNotBlank(result)) {
                        JSONObject jsonObject = JSONObject.parseObject(result);
                        if (jsonObject.containsKey("errcode") && jsonObject.getIntValue("errcode") == 0) {
                            success = true;
                            logger.info("发送模版消息成功：token:{}：{}：{}", accessToken, params, result);
                        } else {
                            logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                        }
                    } else {
                        logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                    }
                } catch (Exception ex) {
                    logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, ex);
                }
            }
        } else {
            logger.error("发送模版消息失败：token:{} 或 没有审核人员", accessToken);
        }
        return success;
    }*/

    /**
     * 特殊字符转码
     *
     * @param param
     * @return
     */
    public static String stringUncode(String param) {
        if (param != null && !param.trim().equals("")) {
            try {
                param = URLEncoder.encode(param, "utf-8");//转码
                param = URLDecoder.decode(param, "UTF-8");//解码
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return param;
    }

    /**
     * 查询行程列表
     * @return
     */
    public AjaxResponse getTravelList() {
        List<TraManageVo> list = mapper.listTravel();
        return AjaxResponse.of(list);
    }

    /**
     * 查询成员信息--头像与昵称
     * @param traId
     * @return
     */
    public AjaxResponse getMemberList(String traId) {
        List<MemberVo> list = mapper.listMember(traId);
        return AjaxResponse.of(list);
    }


}
