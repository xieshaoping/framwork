package com.isimpo.tech.framework.applet.auto.mapper.homePage;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface MemberMapper extends Mapper<Member> {

    List<Member> findList(Query query);

}
