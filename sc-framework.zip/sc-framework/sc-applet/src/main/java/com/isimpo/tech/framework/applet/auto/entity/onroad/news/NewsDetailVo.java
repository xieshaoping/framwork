package com.isimpo.tech.framework.applet.auto.entity.onroad.news;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/2/11
 */
public class NewsDetailVo extends NewsVo {

    // 确认会员昵称
    private List<String> confirmNickNames;

    public List<String> getConfirmNickNames() {
        return confirmNickNames;
    }

    public void setConfirmNickNames(List<String> confirmNickNames) {
        this.confirmNickNames = confirmNickNames;
    }
}
