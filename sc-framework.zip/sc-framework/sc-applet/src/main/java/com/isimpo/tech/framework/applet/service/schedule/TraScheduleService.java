package com.isimpo.tech.framework.applet.service.schedule;

import com.alibaba.fastjson.JSONObject;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.*;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatTplMsgItemVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatTplMsgVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WxConfig;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip.TraBaseMapper;
import com.isimpo.tech.framework.applet.service.wechat.WxConfigService;
import com.isimpo.tech.framework.applet.utils.WeinXinUtil;
import com.isimpo.tech.framework.applet.utils.utils.HttpClientUtils;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.wechat.WeChatConfigUtil;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.WechatConstants;
import com.isimpo.tech.wechat.pojo.WechatConfig;
import com.xiaoleilu.hutool.util.RandomUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotNull;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 行程定时任务
 * @author wangxinhai
 * @version V1.0
 * @since 2019年5月23日
 */
@Service
public class TraScheduleService extends BaseService<TraBaseMapper, TraBase> {

    private static final Logger logger = LoggerFactory.getLogger(TraScheduleService.class);

    @NotNull
    @Value("${templateId}")
    private String templateId;

    @NotNull
    @Value("${templateId1}")
    private String templateId1;

    @NotNull
    @Value("${templateId2}")
    private String templateId2;

    @NotNull
    @Value("${templateId3}")
    private String templateId3;

    @NotNull
    @Value("${h5Url}")
    private String h5Url;

    @Autowired
    private WxConfigService wxConfigService;




    /**
     * 发送模版消息
     * @throws Exception
     * //类型（1：出发前第一次提醒，2：提前3天的提醒，3：提前1天的提醒，11：每天早上提醒，12：每天中午提醒，13：每天下午提醒，
     * 14：管家每天少于3个可乐消息的提醒，21：返程提醒，22：结束评价提醒
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void sendMessage()throws Exception{
        logger.info("定时任务Start，发送消息给管家领队 [sendMessage]");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfss = new SimpleDateFormat("HH:mm:ss");
        SimpleDateFormat s = new SimpleDateFormat("HH:mm");
        //当前时间
        Date now = sdf.parse(sdf.format(new Date()));
        //获取制定中的行程  第一次提醒
        List<TraBase> traBaseListType0 = mapper.findListType("0");
        if (traBaseListType0.size() > 0) {
            traBaseListType0.stream().forEach(e -> {
                logger.info("[第一次提醒 行程"+e.getName()+"]-----提醒时间===" + e.getFirstRemind());
                //行程误差 时间差
                if (e.getTimeDiff() != null && e.getFirstRemind() != null) {
                    //第一次提醒--------------------开始
                    Date firstRemind = e.getFirstRemind();
                    //当前时间 > 第一次提醒时间
                    if (compareDate(now,firstRemind) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"1",null);
                        //先判断有无领队 有发送给领队 无发送管家
                        List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                        //送记录没有信息 -》发送模版消息提醒管家
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            //有领队
                            if (memberList.size() > 0) {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"2");
                            } else {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"1");
                            }
                            if (flag) {
                                //插入发送记录表
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("1");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(now);
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                                System.out.println(a);
                            }

                            //new TraScheduleService().insertTraWeRemind(e.getId(),"1","",addDateMinut(now,timeDiff));
                        }
                    }
                    //第一次提醒--------------------结束
                } else {
                    logger.error("改行程暂无第一次提醒时间或时间差");
                }
            });
        } else {
            logger.error("暂无制定中的行程------[第一次提醒]");
        }

        //获取旅行中的行程  早中晚提醒
        List<TraBase> traBaseListType1 = mapper.findListType("1");
        Date nows = sdfss.parse(sdfss.format(new Date()));
        if (traBaseListType1.size() > 0) {
            traBaseListType1.stream().forEach(e -> {
                logger.info("[早中晚提醒 行程"+e.getName()+"]-----提醒时间===" + e.getMornRemind() + "--" + e.getNoonRemind() + "--" + e.getNightRemind());
                if (e.getTimeDiff() != null && e.getMornRemind() != null && e.getNoonRemind() != null && e.getNightRemind() != null) { //行程误差 时间差
                    Integer timeDiff = e.getTimeDiff();
                    //早中晚提醒--------------------开始
                    //早上提醒
                    Date mornRemind =  e.getMornRemind();
                    Date mornd = null;
                    try {
                        mornd = sdf.parse(sdfs.format(new Date()) + " 00:00:00"); //2019-05-26 00:00:00
                        //中午提醒
                        Date noonremind = e.getNoonRemind();
                        //晚上时间
                        Date nightRemind = e.getNightRemind();
                        Date morning = sdf.parse(sdfs.format(new Date()) + " " + sdfss.format(mornRemind));
                        Date nooning = sdf.parse(sdfs.format(new Date()) + " " + sdfss.format(noonremind));
                        Date nighting = sdf.parse(sdfs.format(new Date()) + " " + sdfss.format(nightRemind));
                        //当前时间 >= 早上提醒时间+时差  & 当前时间< 中午提醒时间+时差
                        if (compareDate(nows,sdfss.parse(sdfss.format(addDateMinut(mornRemind,timeDiff)))) >= 0 && compareDate(nows,sdfss.parse(sdfss.format(addDateMinut(noonremind,timeDiff)))) < 0) {
                            //查询消息 早上时间以前（0点到早上时间） + 时差
                            List<TraNews> traNewsList = mapper.findTraNewsList(e.getId(), e.getHousekeeperId(), addDateMinut(mornd,timeDiff), addDateMinut(morning,timeDiff));
                            //查询发送记录表
                            List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"11",sdfs.format(now));
                            //没有发送可乐消息 && 发送记录没有信息 -》发送模版消息提醒管家
                            if (traNewsList.size() == 0 && traWecharRemindList.size() == 0) {
                                boolean flag = false;
                                //1:管家，2：领队
                                //先判断有无领队 有发送给领队 无发送管家
                                List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                                //有领队 发送给领队
                                if (memberList.size() > 0) {
                                    flag = setTemplantDate(e,"1",s.format(mornRemind),"2");
                                } else{ //无领队 发送给管家
                                    flag = setTemplantDate(e,"1",s.format(mornRemind),"1");
                                }
                                if (flag) {
                                    TraWecharRemind traWecharRemind = new TraWecharRemind();
                                    traWecharRemind.setId(RandomUtil.simpleUUID());
                                    traWecharRemind.setAddUserId("admin");
                                    traWecharRemind.setUpdUserId("admin");
                                    traWecharRemind.setAddTime(new Date());
                                    traWecharRemind.setUpdTime(new Date());
                                    traWecharRemind.setDelFlag("0");
                                    traWecharRemind.setTraId(e.getId());
                                    traWecharRemind.setType("11");
                                    traWecharRemind.setContent("");
                                    traWecharRemind.setRemindDt(now);
                                    traWecharRemind.setAddMark("");
                                    traWecharRemind.setUpdMark("");
                                    int a = mapper.insertTraWeRemind(traWecharRemind);
                                }

                                //new TraScheduleService().insertTraWeRemind(e.getId(),"11","",addDateMinut(now,timeDiff));
                            }
                        } else if (compareDate(nows,sdfss.parse(sdfss.format(addDateMinut(noonremind,timeDiff)))) >= 0 && compareDate(nows,sdfss.parse(sdfss.format(addDateMinut(nightRemind,timeDiff)))) < 0) { //当前时间 >= 中午提醒时间+时差  & 当前时间< 晚上提醒时间+时差
                            //查询消息 中午时间以前（早上-中午）

                            List<TraNews> traNewsList = mapper.findTraNewsList(e.getId(), e.getHousekeeperId(), addDateMinut(morning,timeDiff), addDateMinut(nooning,timeDiff));
                            //查询发送记录表
                            List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"12",sdfs.format(now));
                            //没有发送可乐消息 && 发送记录没有信息 -》 发送模版消息提醒管家
                            if (traNewsList.size() == 0 && traWecharRemindList.size() == 0) {
                                //1:管家，2：领队
                                //先判断有无领队 有发送给领队 无发送管家
                                List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                                boolean flag = false;
                                //有领队 发送给领队
                                if (memberList.size() > 0) {
                                    flag = setTemplantDate(e, "2", s.format(noonremind), "2");
                                }else{
                                    flag = setTemplantDate(e,"2",s.format(mornRemind),"1");
                                }
                                    if (flag) {
                                        TraWecharRemind traWecharRemind = new TraWecharRemind();
                                        traWecharRemind.setId(RandomUtil.simpleUUID());
                                        traWecharRemind.setAddUserId("admin");
                                        traWecharRemind.setUpdUserId("admin");
                                        traWecharRemind.setAddTime(new Date());
                                        traWecharRemind.setUpdTime(new Date());
                                        traWecharRemind.setDelFlag("0");
                                        traWecharRemind.setTraId(e.getId());
                                        traWecharRemind.setType("12");
                                        traWecharRemind.setContent("");
                                        traWecharRemind.setRemindDt(now);
                                        traWecharRemind.setAddMark("");
                                        traWecharRemind.setUpdMark("");
                                        int a = mapper.insertTraWeRemind(traWecharRemind);
                                    }
                                    //new TraScheduleService().insertTraWeRemind(e.getId(),"12","",addDateMinut(now,timeDiff));
                                //} else {
                                    //无领队 不发送 管家一天只发送一次
                                //}
                            }
                        } else if (compareDate(nows,sdfss.parse(sdfss.format(addDateMinut(nightRemind,timeDiff)))) >= 0) { //当前时间 >= 晚上提醒时间 + 时差
                            //查询消息 中午时间以前（中午-晚上）
                            List<TraNews> traNewsList = mapper.findTraNewsList(e.getId(), e.getHousekeeperId(), addDateMinut(nooning,timeDiff), addDateMinut(nighting,timeDiff));
                            //查询发送记录表
                            List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"13",sdfs.format(now));
                            //没有发送可乐消息 && 发送记录没有信息 -》 发送模版消息提醒管家
                            if (traNewsList.size() == 0 && traWecharRemindList.size() ==0) {
                                //1:管家，2：领队
                                //先判断有无领队 有发送给领队 无发送管家
                                List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                                //有领队 发送给领队
                                boolean flag = false;
                                if (memberList.size() > 0) {
                                    flag = setTemplantDate(e, "3", s.format(nightRemind), "2");
                                }else {
                                    flag = setTemplantDate(e, "3", s.format(nightRemind), "1");
                                }
                                    if (flag) {
                                        TraWecharRemind traWecharRemind = new TraWecharRemind();
                                        traWecharRemind.setId(RandomUtil.simpleUUID());
                                        traWecharRemind.setAddUserId("admin");
                                        traWecharRemind.setUpdUserId("admin");
                                        traWecharRemind.setAddTime(new Date());
                                        traWecharRemind.setUpdTime(new Date());
                                        traWecharRemind.setDelFlag("0");
                                        traWecharRemind.setTraId(e.getId());
                                        traWecharRemind.setType("13");
                                        traWecharRemind.setContent("");
                                        traWecharRemind.setRemindDt(now);
                                        traWecharRemind.setAddMark("");
                                        traWecharRemind.setUpdMark("");
                                        int a = mapper.insertTraWeRemind(traWecharRemind);
                                    }

                                    //new TraScheduleService().insertTraWeRemind(e.getId(),"13","",addDateMinut(now,timeDiff));
                                //} else {
                                    //无领队 不发送 管家一天只发送一次
                                //}
                            }
                        }
                        //早中晚提醒--------------------结束
                    } catch (ParseException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    logger.error("改行程暂无早中晚提醒时间或时间差");
                }
            });
        } else {
            logger.error("暂无旅行中的行程------[早中晚提醒]");
        }

        //获取所有行程 已取消 制定中除外   返程提醒
        List<TraBase> traBaseList = mapper.findList();
        if (traBaseList.size() > 0) {
            traBaseList.stream().forEach(e -> {
                logger.info("[总结提醒 行程"+e.getName()+"]-----提醒时间===" + e.getSumRemind());
                if (e.getTimeDiff() != null && e.getSumRemind() != null) { //行程误差 时间差
                    Integer timeDiff = e.getTimeDiff();
                    //总结提醒----------------------开始
                    Date sumRemind = e.getSumRemind();
                    ////当前时间 > 返程提醒时间 + 时差
                    if (compareDate(now,addDateMinut(sumRemind,timeDiff)) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"21",null);
                        //送记录没有信息 -》发送模版消息提醒管家
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            //先判断有无领队 有发送给领队 无发送管家
                            List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                            //if (memberList.size() > 0) {
                                flag = setTemplantSumRemind(e,sdfs.format(e.getEndDate()),"2");
                            //} else {
                                flag = setTemplantSumRemind(e,sdfs.format(e.getEndDate()),"1");
                            //}
                            if (flag) {
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("21");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(now);
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                            }
                        }
                    }
                    //总结提醒----------------------结束

                    //行程结束 提醒成员做出评价-------开始
                    //当前时间 >= 评价提醒时间
                    if (e.getEvalRemind() != null) {
                        if (compareDate(now,e.getEvalRemind()) >= 0) {
                            //查询发送记录表
                            List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"22",null);
                            //送记录没有信息 -》发送模版消息提醒行程中的会员
                            if (traWecharRemindList.size() == 0) {
                                boolean flag = false;
                                flag = setTemplantSumEval(e,sdfs.format(e.getEndDate()));
                                if (flag) {
                                    TraWecharRemind traWecharRemind = new TraWecharRemind();
                                    traWecharRemind.setId(RandomUtil.simpleUUID());
                                    traWecharRemind.setAddUserId("admin");
                                    traWecharRemind.setUpdUserId("admin");
                                    traWecharRemind.setAddTime(new Date());
                                    traWecharRemind.setUpdTime(new Date());
                                    traWecharRemind.setDelFlag("0");
                                    traWecharRemind.setTraId(e.getId());
                                    traWecharRemind.setType("22");
                                    traWecharRemind.setContent("");
                                    traWecharRemind.setRemindDt(now);
                                    traWecharRemind.setAddMark("");
                                    traWecharRemind.setUpdMark("");
                                    int a = mapper.insertTraWeRemind(traWecharRemind);
                                }
                            }
                        }
                    }
                    //行程结束 提醒成员做出评价-------结束
                } else {
                    logger.error("改行程暂总结提醒时间或时间差");
                }
            });
        } else {
            logger.error("暂无已取消、制定中的行程------[总结提醒]");
        }
        logger.info("定时任务End，发送消息给管家领队[sendMessage]");
    }


    /**
     * 发送模版消息
     * @throws Exception
     * //类型（1：出发前第一次提醒，2：提前3天的提醒，3：提前1天的提醒，11：每天早上提醒，12：每天中午提醒，13：每天下午提醒，
     * 14：管家每天少于3个可乐消息的提醒，21：返程提醒，22：结束评价提醒
     *//*
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void sendMessage()throws Exception{
        logger.info("定时任务Start，发送消息给管家领队 [sendMessage]");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfss = new SimpleDateFormat("HH:mm:ss");
        SimpleDateFormat s = new SimpleDateFormat("HH:mm");
        //当前时间
        Date now = sdf.parse(sdf.format(new Date()));
        //获取制定中的行程  第一次提醒
        List<TraBase> traBaseListType0 = mapper.findListType("0");
        if (traBaseListType0.size() > 0) {
            traBaseListType0.stream().forEach(e -> {
                logger.info("[第一次提醒 行程"+e.getName()+"]-----提醒时间===" + e.getFirstRemind());
                //行程误差 时间差
                if (e.getTimeDiff() != null && e.getFirstRemind() != null) {
                    Integer timeDiff = e.getTimeDiff();
                    //第一次提醒--------------------开始
                    Date firstRemind = e.getFirstRemind();
                    //当前时间 > 第一次提醒时间
                    if (compareDate(now,firstRemind) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"1",null);
                        //先判断有无领队 有发送给领队 无发送管家
                        List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                        //送记录没有信息 -》发送模版消息提醒管家
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            //有领队
                            if (memberList.size() > 0) {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"2");
                            } else {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"1");
                            }
                            if (flag) {
                                //插入发送记录表
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("1");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(addDateMinut(now,timeDiff));
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                                System.out.println(a);
                            }

                            //new TraScheduleService().insertTraWeRemind(e.getId(),"1","",addDateMinut(now,timeDiff));
                        }
                    }
                    //第一次提醒--------------------结束
                } else {
                    logger.error("改行程暂无第一次提醒时间或时间差");
                }
            });
        } else {
            logger.error("暂无制定中的行程------[第一次提醒]");
        }

        //获取旅行中的行程  早中晚提醒
        List<TraBase> traBaseListType1 = mapper.findListType("1");
        Date nows = sdfss.parse(sdfss.format(new Date()));
        if (traBaseListType1.size() > 0) {
            traBaseListType1.stream().forEach(e -> {
                logger.info("[早中晚提醒 行程"+e.getName()+"]-----提醒时间===" + e.getMornRemind() + "--" + e.getNoonRemind() + "--" + e.getNightRemind());
                if (e.getTimeDiff() != null && e.getMornRemind() != null && e.getNoonRemind() != null && e.getNightRemind() != null) { //行程误差 时间差
                    Integer timeDiff = e.getTimeDiff();
                    //早中晚提醒--------------------开始
                    //早上提醒
                    Date mornRemind =  e.getMornRemind();
                    Date mornd = null;
                    try {
                        mornd = sdf.parse(sdfs.format(new Date()) + " 00:00:00"); //2019-05-26 00:00:00
                        //中午提醒
                        Date noonremind = e.getNoonRemind();
                        //晚上时间
                        Date nightRemind = e.getNightRemind();
                        Date morning = sdf.parse(sdfs.format(new Date()) + " " + sdfss.format(mornRemind));
                        Date nooning = sdf.parse(sdfs.format(new Date()) + " " + sdfss.format(noonremind));
                        Date nighting = sdf.parse(sdfs.format(new Date()) + " " + sdfss.format(nightRemind));
                        //当前时间 >= 早上提醒时间  & 当前时间< 中午提醒时间
                        if (compareDate(nows,sdfss.parse(sdfss.format(mornRemind))) >= 0 && compareDate(nows,sdfss.parse(sdfss.format(noonremind))) < 0) {
                            //查询消息 早上时间以前（0点到早上时间）
                            List<TraNews> traNewsList = mapper.findTraNewsList(e.getId(), e.getHousekeeperId(), mornd, morning);
                            //查询发送记录表
                            List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"11",sdfs.format(addDateMinut(now,timeDiff)));
                            //没有发送可乐消息 && 发送记录没有信息 -》发送模版消息提醒管家
                            if (traNewsList.size() == 0 && traWecharRemindList.size() == 0) {
                                boolean flag = false;
                                //1:管家，2：领队
                                //先判断有无领队 有发送给领队 无发送管家
                                List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                                //有领队 发送给领队
                                if (memberList.size() > 0) {
                                    flag = setTemplantDate(e,"1",s.format(mornRemind),"2");
                                } else{ //无领队 发送给管家
                                    flag = setTemplantDate(e,"1",s.format(mornRemind),"1");
                                }
                                if (flag) {
                                    TraWecharRemind traWecharRemind = new TraWecharRemind();
                                    traWecharRemind.setId(RandomUtil.simpleUUID());
                                    traWecharRemind.setAddUserId("admin");
                                    traWecharRemind.setUpdUserId("admin");
                                    traWecharRemind.setAddTime(new Date());
                                    traWecharRemind.setUpdTime(new Date());
                                    traWecharRemind.setDelFlag("0");
                                    traWecharRemind.setTraId(e.getId());
                                    traWecharRemind.setType("11");
                                    traWecharRemind.setContent("");
                                    traWecharRemind.setRemindDt(addDateMinut(now,timeDiff));
                                    traWecharRemind.setAddMark("");
                                    traWecharRemind.setUpdMark("");
                                    int a = mapper.insertTraWeRemind(traWecharRemind);
                                }

                                //new TraScheduleService().insertTraWeRemind(e.getId(),"11","",addDateMinut(now,timeDiff));
                            }
                        } else if (compareDate(nows,sdfss.parse(sdfss.format(noonremind))) >= 0 && compareDate(nows,sdfss.parse(sdfss.format(nightRemind))) < 0) { //当前时间 >= 中午提醒时间  & 当前时间< 晚上提醒时间
                            //查询消息 中午时间以前（早上-中午）

                            List<TraNews> traNewsList = mapper.findTraNewsList(e.getId(), e.getHousekeeperId(), morning, nooning);
                            //查询发送记录表
                            List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"12",sdfs.format(addDateMinut(now,timeDiff)));
                            //没有发送可乐消息 && 发送记录没有信息 -》 发送模版消息提醒管家
                            if (traNewsList.size() == 0 && traWecharRemindList.size() == 0) {
                                //1:管家，2：领队
                                //先判断有无领队 有发送给领队 无发送管家
                                List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                                //有领队 发送给领队
                                if (memberList.size() > 0) {
                                    boolean flag = false;
                                    flag = setTemplantDate(e,"2",s.format(noonremind),"2");
                                    if (flag) {
                                        TraWecharRemind traWecharRemind = new TraWecharRemind();
                                        traWecharRemind.setId(RandomUtil.simpleUUID());
                                        traWecharRemind.setAddUserId("admin");
                                        traWecharRemind.setUpdUserId("admin");
                                        traWecharRemind.setAddTime(new Date());
                                        traWecharRemind.setUpdTime(new Date());
                                        traWecharRemind.setDelFlag("0");
                                        traWecharRemind.setTraId(e.getId());
                                        traWecharRemind.setType("12");
                                        traWecharRemind.setContent("");
                                        traWecharRemind.setRemindDt(addDateMinut(now,timeDiff));
                                        traWecharRemind.setAddMark("");
                                        traWecharRemind.setUpdMark("");
                                        int a = mapper.insertTraWeRemind(traWecharRemind);
                                    }
                                    //new TraScheduleService().insertTraWeRemind(e.getId(),"12","",addDateMinut(now,timeDiff));
                                } else {
                                    //无领队 不发送 管家一天只发送一次
                                }
                            }
                        } else if (compareDate(nows,sdfss.parse(sdfss.format(nightRemind))) >= 0) { //当前时间 >= 晚上提醒时间
                            //查询消息 中午时间以前（中午-晚上）
                            List<TraNews> traNewsList = mapper.findTraNewsList(e.getId(), e.getHousekeeperId(), nooning, nighting);
                            //查询发送记录表
                            List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"13",sdfs.format(addDateMinut(now,timeDiff)));
                            //没有发送可乐消息 && 发送记录没有信息 -》 发送模版消息提醒管家
                            if (traNewsList.size() == 0 && traWecharRemindList.size() ==0) {
                                //1:管家，2：领队
                                //先判断有无领队 有发送给领队 无发送管家
                                List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                                //有领队 发送给领队
                                if (memberList.size() > 0) {
                                    boolean flag = false;
                                    flag = setTemplantDate(e,"3",s.format(nightRemind),"2");
                                    if (flag) {
                                        TraWecharRemind traWecharRemind = new TraWecharRemind();
                                        traWecharRemind.setId(RandomUtil.simpleUUID());
                                        traWecharRemind.setAddUserId("admin");
                                        traWecharRemind.setUpdUserId("admin");
                                        traWecharRemind.setAddTime(new Date());
                                        traWecharRemind.setUpdTime(new Date());
                                        traWecharRemind.setDelFlag("0");
                                        traWecharRemind.setTraId(e.getId());
                                        traWecharRemind.setType("13");
                                        traWecharRemind.setContent("");
                                        traWecharRemind.setRemindDt(addDateMinut(now,timeDiff));
                                        traWecharRemind.setAddMark("");
                                        traWecharRemind.setUpdMark("");
                                        int a = mapper.insertTraWeRemind(traWecharRemind);
                                    }

                                    //new TraScheduleService().insertTraWeRemind(e.getId(),"13","",addDateMinut(now,timeDiff));
                                } else {
                                    //无领队 不发送 管家一天只发送一次
                                }
                            }
                        }
                        //早中晚提醒--------------------结束
                    } catch (ParseException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    logger.error("改行程暂无早中晚提醒时间或时间差");
                }
            });
        } else {
            logger.error("暂无旅行中的行程------[早中晚提醒]");
        }

        //获取所有行程 已取消 制定中除外   返程提醒
        List<TraBase> traBaseList = mapper.findList();
        if (traBaseList.size() > 0) {
            traBaseList.stream().forEach(e -> {
                logger.info("[总结提醒 行程"+e.getName()+"]-----提醒时间===" + e.getSumRemind());
                if (e.getTimeDiff() != null && e.getSumRemind() != null) { //行程误差 时间差
                    Integer timeDiff = e.getTimeDiff();
                    //总结提醒----------------------开始
                    Date sumRemind = e.getSumRemind();
                    ////当前时间 > 总结提醒时间
                    if (compareDate(now,sumRemind) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"21",null);
                        //送记录没有信息 -》发送模版消息提醒管家
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            //先判断有无领队 有发送给领队 无发送管家
                            List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                            if (memberList.size() > 0) {
                                flag = setTemplantSumRemind(e,sdfs.format(e.getEndDate()),"2");
                            } else {
                                flag = setTemplantSumRemind(e,sdfs.format(e.getEndDate()),"1");
                            }
                            if (flag) {
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("21");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(addDateMinut(now,timeDiff));
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                            }
                        }
                    }
                    //总结提醒----------------------结束

                    //行程结束 提醒成员做出评价-------开始
                    //当前时间 >= 评价提醒时间
                    if (compareDate(now,e.getEvalRemind()) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"22",null);
                        //送记录没有信息 -》发送模版消息提醒行程中的会员
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            flag = setTemplantSumEval(e,sdfs.format(e.getEndDate()));
                            if (flag) {
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("22");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(now);
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                            }
                        }
                    }
                    //行程结束 提醒成员做出评价-------结束
                } else {
                    logger.error("改行程暂总结提醒时间或时间差");
                }
            });
        } else {
            logger.error("暂无已取消、制定中的行程------[总结提醒]");
        }
        logger.info("定时任务End，发送消息给管家领队[sendMessage]");
    }*/

    /**
     * 发送模版消息 前1天、3天提醒
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void sendMbMessage() throws ParseException {
        logger.info("定时任务Start，发送消息给管家领队 [sendMbMessage]");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd");
        //当前时间
        Date now = sdf.parse(sdf.format(new Date()));
        Date nows = sdfs.parse(sdf.format(new Date()));
        //获取制定中的行程  第一次提醒
        List<TraBase> traBaseListType0 = mapper.findListType("0");
        if (traBaseListType0.size() > 0) {
            traBaseListType0.stream().forEach(e -> {
                //前1天--------------------开始
                try {
                    // 行程开始时间
                    Date startDate = sdfs.parse(sdfs.format(e.getStartDate()));
                    // 前一天的时间
                    Date beforeDate = sdfs.parse(sdfs.format(addDateMinut(startDate,-24)));
                    //当前时间 > 前一天的时间
                    logger.info("前一天提醒====[前一天时间：]" + beforeDate);
                    if (compareDate(nows,beforeDate) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"3",null);
                        //先判断有无领队 有发送给领队 无发送管家
                        List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                        //送记录没有信息 -》发送模版消息提醒管家
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            //有领队
                            //if (memberList.size() > 0) {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"2");
                            //} else {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"1");
                            //}
                            if (flag) {
                                //插入发送记录表
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("3");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(now);
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                            }
                            //new TraScheduleService().insertTraWeRemind(e.getId(),"3","",addDateMinut(now,timeDiff));
                        }
                    }
                    //前1天--------------------结束

                    //前3天--------------------开始
                    //前三天的时间
                    Date before3Date = sdfs.parse(sdfs.format(addDateMinut(startDate, -72)));
                    //当前时间 > 前三天的时间
                    logger.info("前三天提醒====[前一天时间：]" + before3Date);
                    if (compareDate(nows,before3Date) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"2",null);
                        //先判断有无领队 有发送给领队 无发送管家
                        List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                        //送记录没有信息 -》发送模版消息提醒管家
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            //有领队
                            //if (memberList.size() > 0) {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"2");
                            //} else {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"1");
                            //}
                            if (flag) {
                                //插入发送记录表
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("2");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(now);
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                            }
                            //new TraScheduleService().insertTraWeRemind(e.getId(),"2","",addDateMinut(now,timeDiff));
                        }
                    }
                    //前3天--------------------结束
                } catch (ParseException ex) {
                    ex.printStackTrace();
                }
            });
        } else {
            logger.error("暂无制定中的行程------[前1天、3天提醒]");
        }
        logger.info("定时任务End，发送消息给管家领队 [sendMbMessage]");
    }

    /**
     * 发送模版消息 前1天、3天提醒
     *//*
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void sendMbMessage() throws ParseException {
        logger.info("定时任务Start，发送消息给管家领队 [sendMbMessage]");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd");
        //当前时间
        Date now = sdf.parse(sdf.format(new Date()));
        Date nows = sdfs.parse(sdf.format(new Date()));
        //获取制定中的行程  第一次提醒
        List<TraBase> traBaseListType0 = mapper.findListType("0");
        if (traBaseListType0.size() > 0) {
            traBaseListType0.stream().forEach(e -> {
                //行程误差 时间差
                Integer timeDiff = e.getTimeDiff();
                //前1天--------------------开始
                try {
                    // 行程开始时间
                    Date startDate = sdfs.parse(sdfs.format(e.getStartDate()));
                    // 前一天的时间
                    Date beforeDate = sdfs.parse(sdfs.format(addDateMinut(startDate,-24)));
                    //当前时间 > 前一天的时间
                    logger.info("前一天提醒====[前一天时间：]" + beforeDate);
                    if (compareDate(nows,beforeDate) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"3",null);
                        //先判断有无领队 有发送给领队 无发送管家
                        List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                        //送记录没有信息 -》发送模版消息提醒管家
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            //有领队
                            if (memberList.size() > 0) {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"2");
                            } else {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"1");
                            }
                            if (flag) {
                                //插入发送记录表
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("3");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(addDateMinut(now,timeDiff));
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                            }
                            //new TraScheduleService().insertTraWeRemind(e.getId(),"3","",addDateMinut(now,timeDiff));
                        }
                    }
                    //前1天--------------------结束

                    //前3天--------------------开始
                    //前三天的时间
                    Date before3Date = sdfs.parse(sdfs.format(addDateMinut(startDate, -72)));
                    //当前时间 > 前三天的时间
                    logger.info("前三天提醒====[前一天时间：]" + before3Date);
                    if (compareDate(nows,before3Date) >= 0) {
                        //查询发送记录表
                        List<TraWecharRemind> traWecharRemindList = mapper.findTraWeRemList(e.getId(),"2",null);
                        //先判断有无领队 有发送给领队 无发送管家
                        List<Member> memberList = mapper.getMemberListByTraId(e.getId(),"2");
                        //送记录没有信息 -》发送模版消息提醒管家
                        if (traWecharRemindList.size() == 0) {
                            boolean flag = false;
                            //有领队
                            if (memberList.size() > 0) {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"2");
                            } else {
                                flag = setTemplantFirst(e,sdfs.format(e.getStartDate()),"1");
                            }
                            if (flag) {
                                //插入发送记录表
                                TraWecharRemind traWecharRemind = new TraWecharRemind();
                                traWecharRemind.setId(RandomUtil.simpleUUID());
                                traWecharRemind.setAddUserId("admin");
                                traWecharRemind.setUpdUserId("admin");
                                traWecharRemind.setAddTime(new Date());
                                traWecharRemind.setUpdTime(new Date());
                                traWecharRemind.setDelFlag("0");
                                traWecharRemind.setTraId(e.getId());
                                traWecharRemind.setType("2");
                                traWecharRemind.setContent("");
                                traWecharRemind.setRemindDt(addDateMinut(now,timeDiff));
                                traWecharRemind.setAddMark("");
                                traWecharRemind.setUpdMark("");
                                int a = mapper.insertTraWeRemind(traWecharRemind);
                            }
                            //new TraScheduleService().insertTraWeRemind(e.getId(),"2","",addDateMinut(now,timeDiff));
                        }
                    }
                    //前3天--------------------结束
                } catch (ParseException ex) {
                    ex.printStackTrace();
                }
            });
        } else {
            logger.error("暂无制定中的行程------[前1天、3天提醒]");
        }
        logger.info("定时任务End，发送消息给管家领队 [sendMbMessage]");
    }*/


    /**
     * 发送模板消息 (早上 中午 晚上 消息提醒管家or领队发送可乐消息)
     * @param traBase
     * @param type 1早上 2中午 3晚上
     * @param date 截止{date}时间未发送行程可乐消息
     * @param role 1管家 2领队
     */
    public boolean setTemplantDate(TraBase traBase,String type,String date,String role) {
        //模版id QmuOsxAPg4zlp3OwJ4giI9XHDPcELcOIhQYVFMahor8
        //查询该行程所在的成员  openId
        String name = null;
        List<Member> list = null;
        // 领队
        if("2".equals(role)){
            name = "领队";
            list = mapper.getMemberListByTraId(traBase.getId(),"2");
        } else { // 管家
            name = "管家";
            list = mapper.findMemberOpenIds(traBase.getHousekeeperId());
//            list = mapper.findAllMemberOpenIds();                       //所有管家
        }
        List<String> openIds = new ArrayList<>();
        openIds.add("1");
        boolean flag = false;
        for (int i = 0;i<list.size();i++) {
            //发送模板消息
            WechatTplMsgVo tplMsgVo = new WechatTplMsgVo();
            tplMsgVo.setTemplate_id(templateId);
            tplMsgVo.setUrl(h5Url + "static/page/onroad/news/newsAdd.html?traIds=" + traBase.getId());
            Map<String, WechatTplMsgItemVo> map = new HashMap<>();
            map.put("first",new WechatTplMsgItemVo("可乐" + name + "，" + list.get(i).getName() + "，您好。"));
            map.put("keyword1",new WechatTplMsgItemVo(traBase.getName()));
            map.put("keyword2",new WechatTplMsgItemVo(getType(type) + "可乐消息"));
            map.put("keyword3",new WechatTplMsgItemVo("截止到" + date + "未发送行程可乐消息，请及时发送可乐消息。"));
            map.put("remark", new WechatTplMsgItemVo(""));
            tplMsgVo.setData(map);
            if(openIds.contains(list.get(i).getOpenId())){
                continue;
            }
            if(list.get(i).getOpenId() != null){
                openIds.add(list.get(i).getOpenId());
                flag = sendTplMsg(tplMsgVo, list.get(i).getOpenId());
            }else{
                logger.error("发送模版消息失败：token:{} 或 没有审核人员");
            }
        }
        return flag;
    }

    /**
     * 发送模板消息 (总结提醒)
     * @param traBase
     * @param date 行程结束日期
     * @param role 1管家 2领队
     */
    public boolean setTemplantSumRemind(TraBase traBase,String date,String role) {
        /**
         * 模版ID zvFZ-lHN5_1PTWIzBr4bOoDjCG-EJSFgskdhiopqmd8
         * 开发者调用模版消息接口时需提供模版ID
         * 标题 行程结束通知
         * 行业 酒店旅游 - 旅游
         * 详细内容
         *  {{first.DATA}}
         *  行程名称：{{keyword1.DATA}}
         *  结束日期：{{keyword2.DATA}}
         *  {{remark.DATA}}
         */
        //查询该行程所在的成员  openId
        String name = null;
        List<Member> list = null;
        // 领队
        if("2".equals(role)){
            name = "领队";
            list = mapper.getMemberListByTraId(traBase.getId(),"2");
        } else { // 管家
            name = "管家";
            //list = mapper.findMemberOpenIds(traBase.getHousekeeperId());//一个管家
            list = mapper.findAllMemberOpenIds();                       //所有管家
        }
        List<String> openIds = new ArrayList<>();
        openIds.add("1");
        boolean flag = false;
        for (int i = 0;i<list.size();i++) {
            //发送模板消息
            WechatTplMsgVo tplMsgVo = new WechatTplMsgVo();
            tplMsgVo.setTemplate_id(templateId3);
            tplMsgVo.setUrl(h5Url + "static/page/onroad/news/newsAdd.html?traIds=" + traBase.getId());
            Map<String, WechatTplMsgItemVo> map = new HashMap<>();
            map.put("first",new WechatTplMsgItemVo("可乐" + name + "，" + list.get(i).getName() + "，您好。"));
            map.put("keyword1",new WechatTplMsgItemVo(traBase.getName()));
            map.put("keyword2",new WechatTplMsgItemVo(date));
            map.put("remark", new WechatTplMsgItemVo("该行程已经结束，请及时提醒团队成员，做好返程准备。"));
            tplMsgVo.setData(map);
            if(openIds.contains(list.get(i).getOpenId())){
                continue;
            }
            if(list.get(i).getOpenId() != null){
                openIds.add(list.get(i).getOpenId());
                flag = sendTplMsg(tplMsgVo, list.get(i).getOpenId());
            }else{
                logger.error("发送模版消息失败：没有审核人员");
            }
        }
        return flag;
    }

    /**
     * 发送模板消息 (会员评价提醒)
     * @param traBase
     * @param date 行程结束日期
     */
    public boolean setTemplantSumEval(TraBase traBase,String date) {
        /**
         * 模版ID M5BZiN2jVqD1_gRCCGxLzUbkWw2K2WZJTLED-8m3WE0
         * 开发者调用模版消息接口时需提供模版ID
         * 标题 行程结束通知
         * 行业 酒店旅游 - 旅游
         * 详细内容
         *  {{first.DATA}}
         *  行程名称：{{keyword1.DATA}}
         *  结束日期：{{keyword2.DATA}}
         *  {{remark.DATA}}
         */
        //查询该行程所在的成员  openId
        List<Member> list = mapper.getMemberListByTraId(traBase.getId(),"4");
        List<String> openIds = new ArrayList<>();
        openIds.add("1");
        boolean flag = false;
        for (int i = 0;i<list.size();i++) {
            //发送模板消息
            WechatTplMsgVo tplMsgVo = new WechatTplMsgVo();
            tplMsgVo.setTemplate_id(templateId2);
            tplMsgVo.setUrl(h5Url + "static/page/onroad/everyTrip/tripEvaluation.html?traId=" + traBase.getId());
            Map<String, WechatTplMsgItemVo> map = new HashMap<>();
            map.put("first",new WechatTplMsgItemVo("尊敬的" + list.get(i).getName() + "，您好。"));
            map.put("keyword1",new WechatTplMsgItemVo(traBase.getName()));
            map.put("keyword2",new WechatTplMsgItemVo(date));
            map.put("remark", new WechatTplMsgItemVo("美好的旅行结束了，请点击详情给这次旅行来个评价吧！"));
            tplMsgVo.setData(map);
            if(openIds.contains(list.get(i).getOpenId())){
                continue;
            }
            if(list.get(i).getOpenId() != null){
                openIds.add(list.get(i).getOpenId());
                flag = sendTplMsg(tplMsgVo, list.get(i).getOpenId());
            }else{
                logger.error("发送模版消息失败：没有审核人员");
            }
        }
        return flag;
    }


    /**
     * 发送模板消息 (第一次提醒 前一天 前三天)
     * @param traBase
     * @param date 行程时间
     * @param role 1管家 2领队
     */
    public boolean setTemplantFirst(TraBase traBase,String date,String role) {
        //模版 id  77OSxR-xT_07TPRbLVYuv62tYNJ1dniNV8ZR1GaHjyQ
        /**
         * 模版ID
         * 77OSxR-xT_07TPRbLVYuv62tYNJ1dniNV8ZR1GaHjyQ
         * 开发者调用模版消息接口时需提供模版ID
         * 标题 行程安排提醒
         * 行业 酒店旅游 - 旅游
         * 详细内容
         *  {{first.DATA}}
         *  行程时间：{{keyword1.DATA}}
         *  行程安排：{{keyword2.DATA}}
         *  {{remark.DATA}}
         * 在发送时，需要将内容中的参数（{{.DATA}}内为参数）赋值替换为需要的信息
         */
        //查询该行程所在的成员  openId
        String name = null;
        List<Member> list = null;
        // 领队
        if("2".equals(role)){
            name = "领队";
            list = mapper.getMemberListByTraId(traBase.getId(),"2");
        } else { // 管家
            name = "管家";
            list = mapper.findMemberOpenIds(traBase.getHousekeeperId());//一个管家
//            list = mapper.findAllMemberOpenIds();                       //所有管家
        }
        List<String> openIds = new ArrayList<>();
        openIds.add("1");
        boolean flag = false;
        for (int i = 0;i<list.size();i++) {
            //发送模板消息
            WechatTplMsgVo tplMsgVo = new WechatTplMsgVo();
            tplMsgVo.setTemplate_id(templateId1);
            tplMsgVo.setUrl(h5Url + "static/page/onroad/news/newsAdd.html?traIds=" + traBase.getId());
            Map<String, WechatTplMsgItemVo> map = new HashMap<>();
            map.put("first",new WechatTplMsgItemVo("可乐" + name + "，" + list.get(i).getName() + "，您好。"));
            map.put("keyword1",new WechatTplMsgItemVo(date));
            map.put("keyword2",new WechatTplMsgItemVo(traBase.getName()));
            map.put("remark", new WechatTplMsgItemVo("请及时提醒团队成员，提前做好出行准备。"));
            tplMsgVo.setData(map);
            if(openIds.contains(list.get(i).getOpenId())){
                continue;
            }
            if(list.get(i).getOpenId() != null){
                openIds.add(list.get(i).getOpenId());
                flag = sendTplMsg(tplMsgVo, list.get(i).getOpenId());
            }else{
                logger.error("发送模版消息失败：token:{} 或 没有审核人员");
            }
        }
        return flag;
    }

    public boolean sendTplMsg(WechatTplMsgVo tplMsgVo, String openId){
        WechatConfig wechatConfig = WeChatConfigUtil.getWechatConfig();
        WxConfig wxConfig = wxConfigService.getWxConfig();
        //String accessToken = WeinXinUtil.getAccessToken(wechatConfig.getAppId(),wechatConfig.getSecret());//WechatApi.getToken();
        String accessToken = WechatApi.getToken();//WeinXinUtil.getAccessToken(wxConfig.getAppId(),wxConfig.getAppSecret());//WechatApi.getToken();
        Boolean success = false;
        if (StringUtils.isNotEmpty(openId) && StringUtils.isNotEmpty(accessToken)) {
            String requestUrl = WechatConstants.WECHAT_SEND_WECHAT_URL.replace("#ACCESS_TOKEN#", accessToken);
            tplMsgVo.setTouser(openId);
            String params = JSONObject.toJSONString(tplMsgVo);
            params = stringUncode(params);
            try {
                String result = HttpClientUtils.sendPostSSLRequest(requestUrl, params);
                if (StringUtils.isNotBlank(result)) {
                    JSONObject jsonObject = JSONObject.parseObject(result);
                    if (jsonObject.containsKey("errcode") && jsonObject.getIntValue("errcode") == 0) {
                        success = true;
                        logger.info("发送模版消息成功：token:{}：{}：{}", accessToken, params, result);
                    } else {
                        logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                    }
                } else {
                    logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                }
            } catch (Exception ex) {
                logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, ex);
            }
        } else {
            logger.error("发送模版消息失败：token:{} 或 没有审核人员", accessToken);
        }
        return success;
    }

    /**
     * 插入微信消息发送记录表
     * @param traId
     * @param type
     * @param content
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void insertTraWeRemind(String traId,String type,String content,Date date){
        TraWecharRemind traWecharRemind = new TraWecharRemind();
        traWecharRemind.setId(RandomUtil.simpleUUID());
        traWecharRemind.setAddUserId("admin");
        traWecharRemind.setUpdUserId("admin");
        traWecharRemind.setAddTime(new Date());
        traWecharRemind.setUpdTime(new Date());
        traWecharRemind.setDelFlag("0");
        traWecharRemind.setTraId(traId);
        traWecharRemind.setType(type);
        traWecharRemind.setContent(content);
        traWecharRemind.setRemindDt(date);
        traWecharRemind.setAddMark("");
        traWecharRemind.setUpdMark("");
        int a = mapper.insertTraWeRemind(traWecharRemind);
        System.out.println(a);
    }

    /**
     * 特殊字符转码
     *
     * @param param
     * @return
     */
    public static String stringUncode(String param) {
        if (param != null && !param.trim().equals("")) {
            try {
                param = URLEncoder.encode(param, "utf-8");//转码
                param = URLDecoder.decode(param, "UTF-8");//解码
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return param;
    }

    public static String getType(String type){
        if ("1".equals(type)) {
            return "早上";
        } else if ("2".equals(type)) {
            return "中午";
        } else if ("3".equals(type)) {
            return "晚上";
        }
        return null;
    }

    /**
     * 日期比较大小
     * @param date1
     * @param date2
     * @return
     */
    public static int compareDate(Date date1,Date date2){
        if (date1.getTime() > date2.getTime()) {
            return 1;
        } else if (date1.getTime() < date2.getTime()) {
            return -1;
        }
        return 0;
    }

    /**
     * 给时间加上几个小时
     * @param date 当前时间
     * @param hour 需要加的时间
     * @return
     */
    public static Date addDateMinut(Date date, int hour){
        if (date == null)
            return date;
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.HOUR, hour);// 24小时制
        date = cal.getTime();
        return date;
    }
}
