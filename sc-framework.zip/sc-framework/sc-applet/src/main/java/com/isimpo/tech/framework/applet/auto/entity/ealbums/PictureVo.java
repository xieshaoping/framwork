/*
 * @(#) PictureVo.java 2019年02月18日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.ealbums;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月18日
 */
public class PictureVo {
    /**游记表主键*/
    private String id;
    /**类型（1文字2图片）*/
    private String type;
    /**类型为1时是文字，类型为2时是图片地址*/
    private String content;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
