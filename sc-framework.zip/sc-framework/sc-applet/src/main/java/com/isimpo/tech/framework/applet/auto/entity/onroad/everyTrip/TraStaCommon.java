package com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip;

import java.util.List;

public class TraStaCommon {
    //行程评价
    private TraEvaluate traEvaluate;
    //领队管家
    private List<TraStaffEvaluate> traStaffEvaluateList;

    public TraEvaluate getTraEvaluate() {
        return traEvaluate;
    }

    public void setTraEvaluate(TraEvaluate traEvaluate) {
        this.traEvaluate = traEvaluate;
    }

    public List<TraStaffEvaluate> getTraStaffEvaluateList() {
        return traStaffEvaluateList;
    }

    public void setTraStaffEvaluateList(List<TraStaffEvaluate> traStaffEvaluateList) {
        this.traStaffEvaluateList = traStaffEvaluateList;
    }
}
