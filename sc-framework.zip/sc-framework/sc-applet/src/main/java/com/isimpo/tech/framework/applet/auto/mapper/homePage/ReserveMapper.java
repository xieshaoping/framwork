package com.isimpo.tech.framework.applet.auto.mapper.homePage;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Reserve;
import com.isimpo.tech.framework.applet.auto.entity.homePage.SysDict;
import com.isimpo.tech.framework.applet.auto.entity.sysBase.SysConfigure;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface ReserveMapper extends Mapper<Reserve> {

    String getEmailList();

    SysConfigure getSysConfigure();

    List<SysDict> getPlace();

}
