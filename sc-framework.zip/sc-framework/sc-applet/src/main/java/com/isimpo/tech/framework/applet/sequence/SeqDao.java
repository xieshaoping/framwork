/*
 * @(#) SeqDao.java 2015年11月19日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.sequence;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.isimpo.tech.framework.common.util.DateUtil;


/**
 * 获取序列号
 *
 * @author ZHang.WenBin
 * @version 1.0
 * @since 2015年11月19日
 */
@Repository
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class SeqDao {

    private static final String DATE_PATTERN = "yyyyMMdd";

    private static final String FIX_LEN_DATE = "2015111100";

    @Autowired
    @Qualifier("jdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    /**
     * 获得序列号
     */
    public String getSeqNO(final SeqType seqType) {
        // 不含日期的编码
        if (seqType.isHasYMD()) {
            // 含有yyyyMMdd格式日期的编码
            return getSeqYMD(seqType);
        }
        return getSeqOnly(seqType);
    }

    /**
     * 获得订单详情编号
     */
    public String getOrderDetailNO(String orderNO) {
        return orderNO + "_" + executeProGetNum(orderNO, "ODN", 3);
    }

    /**
     * 格式：前缀+序列号
     */
    private String getSeqOnly(SeqType seqType) {
        return seqType.getPrefix() + executeProGetNum(FIX_LEN_DATE, seqType.getPrefix(), seqType.getSerialLen());
    }

    /**
     * 格式：前缀+yyyyMMdd+ 序列号
     */
    private String getSeqYMD(SeqType seqType) {
        return executeProGetNum(DateUtil.getDate(DATE_PATTERN), seqType.getPrefix(), seqType.getSerialLen());
    }

    private String executeProGetNum(final String noDate, final String noType, final int noLength) {
        return jdbcTemplate.execute((Connection con) -> {
            // 调用的SQL
            String storedProc = "{call pro_get_number(?,?,?,?)}";
            CallableStatement cs = con.prepareCall(storedProc);
            cs.setString(1, noDate);
            cs.setString(2, noType);
            cs.setInt(3, noLength);
            cs.registerOutParameter(4, java.sql.Types.VARCHAR);
            return cs;
        }, (CallableStatement cs) -> {
            cs.execute();
            // 获取输出参数的值
            return cs.getString(4);
        });
    }
}
