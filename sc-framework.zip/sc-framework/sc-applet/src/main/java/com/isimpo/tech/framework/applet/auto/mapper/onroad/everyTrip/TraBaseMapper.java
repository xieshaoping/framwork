package com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.*;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.Date;
import java.util.List;

public interface TraBaseMapper extends Mapper<TraBase> {

    List<TraBase> findList();

    List<TraBase> findListType(@Param("state") String state); //0 制定中 1 旅行中，

    List<TraNews> findTraNewsList(@Param("traId") String traId, @Param("housekeeperId") String housekeeperId, @Param("startTime") Date startTime, @Param("endTime") Date endTime);

    List<Member> findMemberOpenIds(@Param("id") String id);

    List<Member> findAllMemberOpenIds();

    //查询是否已经发送消息
    List<TraWecharRemind> findTraWeRemList(@Param("traId") String traId, @Param("type") String type, @Param("date") String  date);

    int insertTraWeRemind(TraWecharRemind traWecharRemind);

    List<Member> getMemberListByTraId(@Param("traId") String traId, @Param("role") String role);
}