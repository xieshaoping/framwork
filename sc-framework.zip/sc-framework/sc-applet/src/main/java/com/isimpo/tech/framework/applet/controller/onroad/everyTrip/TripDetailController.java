/*
 * @(#) TripDetailController.java 2019年02月23日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TripItemVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TripPlaceVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.service.onroad.everyTrip.TripDetailService;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月23日
 */
@RestController
@RequestMapping("tripDetail")
public class TripDetailController extends BaseController<TripDetailService, TripPlaceVo> {

    /**
     * 地点详情
     */
    @RequestMapping("tripPlaceDetail")
    public AjaxResponse tripPlaceDetail(TripPlaceVo tripPlaceVo) {
        return AjaxResponse.of(baseService.tripPlaceDetail(tripPlaceVo));
    }

    /**
     * 事项详情
     */
    @RequestMapping("tripItemDetail")
    public AjaxResponse tripItemDetail(TripItemVo tripItemVo) {
        return AjaxResponse.of(baseService.tripItemDetail(tripItemVo));
    }

    /**
     * 补充事项详情
     * @param id
     * @return
     */
    @RequestMapping("/tripSuppDetail")
    public AjaxResponse tripSuppDetail(String id){
        return AjaxResponse.of(baseService.tripSuppDetail(id));
    }
}
