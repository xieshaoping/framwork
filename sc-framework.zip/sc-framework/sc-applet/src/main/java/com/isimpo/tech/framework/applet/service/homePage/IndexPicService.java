/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.homePage;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.homePage.*;
import com.isimpo.tech.framework.applet.auto.entity.resound.strategy.StrategyVo;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.IndexPicMapper;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.CacheUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;
import com.xiaoleilu.hutool.util.StrUtil;
import tk.mybatis.mapper.entity.Example;

/**
 * @author zx
 * @version 1.0
 * @since 2018/4/24
 */
@Service
public class IndexPicService extends BaseService<IndexPicMapper, IndexPic> {

    /**
     * H5端，获取H5首页的轮播图
     */
    public List<IndexPic> getH5Banner() {
        return mapper.getH5Banner();
    }

       /**
     * H5端，获取H5首页的轮播图
     */
    public List<Housekeeper> getH5Housekeeper(String type) {
        if (StrUtil.equals(type,"all")){
            return mapper.getAllHousekeeper();
        }
        return mapper.getH5Housekeeper();
    }

    public TableResultResponse<Housekeeper> selectHkList(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<Housekeeper> list = mapper.findHkList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }


    public String  getPhone() {
        return mapper.getPhone();
    }


    public Housekeeper getOneHousekeeper(String id) {
        return mapper.getOneHousekeeper(id);
    }



    public List<Route> getH5Route() {
        return mapper.getH5Route();
    }

    public List<Article> getH5Article() {
        return mapper.getH5Article();
    }

    public List<TravelerTalk> getH5TravelerTalk() {
        return mapper.getH5TravelerTalk();
    }

    public List<StrategyVo> indexStrategy() {
        return mapper.indexStrategy();
    }

    public List<Route> getMyRouteList() {
        return mapper.getMyRouteList();
    }


}
