package com.isimpo.tech.framework.applet.service.my;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Route;
import com.isimpo.tech.framework.applet.auto.entity.my.CsrOrder;
import com.isimpo.tech.framework.applet.auto.mapper.my.CsrOrderMapper;
import com.isimpo.tech.framework.applet.sequence.SeqDao;
import com.isimpo.tech.framework.applet.sequence.SeqType;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

/**
 * 订单管理
 * @author wangxinhai
 * @since 2019/4/18
 */
@Service
public class CsrOrderService extends BaseService<CsrOrderMapper, CsrOrder> {

    @Autowired
    private SeqDao seqDao;

    @Autowired
    private HttpServletRequest request;

    /**
     * 查询订单列表
     * @param query 分页信息
     * @return TableResultResponse<> 会员祝福列表
     */
    @Override
    public TableResultResponse<CsrOrder> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<CsrOrder> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 查看订单
     * @param id
     * @return
     */
    @Override
    public CsrOrder selectById(Object id) {
        return mapper.selectById(id);
    }

    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse addOrder(CsrOrder csrOrder,HttpServletRequest request){
        EntityUtils.setCreatAndUpdatInfo(csrOrder);
        csrOrder.setMemId(UserInfoUtils.getUserInfo(request).getMemId());
        String num = seqDao.getSeqNO(SeqType.ORDER_NO);//订单编号
        csrOrder.setOrderNo(num);
        csrOrder.setOrderTime(new Date());
        csrOrder.setPayState("0"); //支付状态
        Route route = mapper.getRouteById(csrOrder.getRouteId());
        //订单状态
        if ((csrOrder.getAmunt() + route.getRealAmount()) == route.getPlanAmount()) {
            //代表这个订单 待出行
            csrOrder.setState("2");
        } else {
            csrOrder.setState("0");
        }
        route.setRealAmount(csrOrder.getAmunt());
        EntityUtils.setUpdatedInfo(route);
        int result = mapper.updateRoute(route);
        int re = mapper.insertSelective(csrOrder);
        if (re > 0 && result > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 获取订单类型个数 个人中心
     * @return
     */
    public Map<String,Object> getOrderTypeNum(){
        Map<String,Object> map = new HashMap<>();
        List<CsrOrder> list = mapper.findAllList(UserInfoUtils.getUserInfo(request).getMemId());
        int ybmNum = list.stream().filter(csrOrder -> csrOrder.getState().equals("1")).collect(Collectors.toList()).size();
        int dcxNum = list.stream().filter(csrOrder -> csrOrder.getState().equals("2")).collect(Collectors.toList()).size();
        int wxtNum = list.stream().filter(csrOrder -> csrOrder.getState().equals("5")).collect(Collectors.toList()).size();
        int dzfNum = list.stream().filter(csrOrder -> csrOrder.getState().equals("0")).collect(Collectors.toList()).size();
        map.put("ybmNum",ybmNum);
        map.put("dcxNum",dcxNum);
        map.put("wctNum",wxtNum);
        map.put("dzfNum",dzfNum);
        return map;
    }

}
