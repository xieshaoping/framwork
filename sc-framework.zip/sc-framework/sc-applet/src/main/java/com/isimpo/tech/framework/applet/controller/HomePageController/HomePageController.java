/*
* Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
* SIMPO Technology. CONFIDENTIAL
*/
package com.isimpo.tech.framework.applet.controller.HomePageController;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.homePage.IndexPic;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Reserve;
import com.isimpo.tech.framework.applet.service.homePage.IndexPicService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.util.Query;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zx
 * @version 1.0
 * @since 2018/4/24
 */
@RestController
@RequestMapping("/homePage/index")
@Api(tags = "商家首页controller")
public class HomePageController extends BaseController<IndexPicService, IndexPic> {

	/**
	 * H5端，获取H5首页的轮播图
	 */
	@RequestMapping(value = "/getH5Banner")
	public AjaxResponse getH5Banner() {
		return AjaxResponse.of(baseService.getH5Banner());
	}

	/**
	 * H5端，获取H5首页的推荐管家list
	 */
	@RequestMapping(value = "/getH5Housekeeper")
	public AjaxResponse getH5Housekeeper(String type) {
		return AjaxResponse.of(baseService.getH5Housekeeper(type));
	}





    @GetMapping("/getAllHousekeeper")
    @ResponseBody
    public AjaxResponse getAllHousekeeper(@RequestParam Map<String, Object> params) {
        // 查询列表数据
        System.out.println(params);
        Query query = new Query(params);
        return AjaxResponse.of(baseService.selectHkList(query));
    }


	@RequestMapping(value = "/getPhone")
	public AjaxResponse getPhone() {
		return AjaxResponse.of(baseService.getPhone());
	}


	/**
	 * H5端，获取一个推荐管家详情
	 */
	@GetMapping("/getOneHousekeeper")
	@ResponseBody
	public AjaxResponse getOneHousekeeper(String id) {
		return AjaxResponse.of(baseService.getOneHousekeeper(id));
	}


	/**
	 * H5端，获取H5首页的经典定制（推荐路线）list
	 */
	@RequestMapping(value = "/getH5Route")
	public AjaxResponse getH5Route() {
		return AjaxResponse.of(baseService.getH5Route());
	}


    /**
     * H5端，获取H5首页的推薦文章list
     */
    @RequestMapping(value = "/getH5Article")
    public AjaxResponse getH5Article() {
        return AjaxResponse.of(baseService.getH5Article());
    }


    /**
     * H5端，获取H5首页的旅咖说list
     */
    @RequestMapping(value = "/getH5TravelerTalk")
    public AjaxResponse getH5TravelerTalk() {
        return AjaxResponse.of(baseService.getH5TravelerTalk());
    }


	/**
	 * H5端，获取H5首页的旅咖说list
	 */
	@RequestMapping(value = "/indexStrategy")
	public AjaxResponse indexStrategy() {
		return AjaxResponse.of(baseService.indexStrategy());
	}


	/**
	 * 可可粉获取 路线
	 * @return
	 */
	@RequestMapping(value = "/getMyRouteList")
	public AjaxResponse getMyRouteList() {
		return AjaxResponse.of(baseService.getMyRouteList());
	}



}
