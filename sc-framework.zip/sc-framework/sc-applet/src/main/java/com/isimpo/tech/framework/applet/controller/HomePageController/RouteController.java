/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller.HomePageController;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Reserve;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Route;
import com.isimpo.tech.framework.applet.service.homePage.ReserveService;
import com.isimpo.tech.framework.applet.service.homePage.RouteService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zx
 * @version 1.0
 * @since 2018/4/24
 */
@RestController
@RequestMapping("/homePage/route")
public class RouteController extends BaseController<RouteService, Route> {


    @GetMapping("/getOneRoute")
    @ResponseBody
    public AjaxResponse getOneRoute(String id) {
        return AjaxResponse.of(baseService.selectById(id));
    }

    @Override
    @GetMapping("/page")
    public AjaxResponse list(@RequestParam Map<String, Object> params) {
        Map<String, String> orderByMap = new HashMap<>();
        orderByMap.put("addTime", CommonConstants.ORDER_BY_DESC);
        params.put(CommonConstants.ORDER_BY_PARAM, orderByMap);
        return super.list(params);
    }


}
