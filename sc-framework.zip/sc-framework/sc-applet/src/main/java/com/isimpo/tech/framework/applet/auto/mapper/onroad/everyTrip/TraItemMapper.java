package com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.auto.entity.homePage.SysDict;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.*;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.Date;
import java.util.List;

public interface TraItemMapper extends Mapper<TraItem> {
    //会员
    List<TraBase> getTraItemById(@Param("memId") String memId);

    List<Member> getMemberListByTraId(String traId);

    List<TraCalendar> getCalendarByTraId(String traId);

    List<TraPlaceTraItem> getPlaceTraItemList(TraPlace traPlace);

    String getPhoneByTraId(String traId);

    int saveTraWish(TraWish traWish);

    int saveTraComplaint(TraComplain traComplain);

    Member getMemberById(String id);

    TraBase getTramById(String id);

    TraCalendar getCalendarById(String id);

    CocoCard getCocoCard();

    //管家 查看全部
    List<TraBase> getTraItemHouseKeep(@Param("memId") String memId,@Param("allFlag") String allFlag);
    //领队 管家
    List<TraBase> getTraItemGuide(@Param("memId") String memId);
    //领队 管家
    List<TraBase> getListAll(@Param("memId") String memId);

    int checkMemberTram(@Param("memId") String memId, @Param("traId") String traId);


    int checkTraBase(@Param("memId") String memId, @Param("traId") String traId);

    List<Member> findAllFlagMember();

    Member getMemberOpenId(String id);

    Member getHouseKeppInfo(String id);

    List<Member> getGuideInfo(String traId);

    List<TraCalendar> getTraCalendarByTraIdAndDate(@Param("traId") String traId, @Param("date") Date date);

    int addTraCalendar(TraCalendar traCalendar);

    List<SysDict> getItemType();

    TraCalendar getCalendar(String id);

    int insertTraSupp(TraSupp traSupp);

    int updateTraSupp(TraSupp traSupp);

    TraSupp getTraSupp(String id);

    int getTraPlaceMaxSort(TraPlace traPlace);

    int insertTraPlace(TraPlace traPlace);
}