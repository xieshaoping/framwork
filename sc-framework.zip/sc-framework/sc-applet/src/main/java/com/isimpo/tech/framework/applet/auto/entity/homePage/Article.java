package com.isimpo.tech.framework.applet.auto.entity.homePage;

import java.util.Date;
import javax.persistence.*;

@Table(name = "cont_article")
public class Article {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 标题
     */
    private String title;

    /**
     * 摘要
     */
    private String digest;

    /**
     * 封面
     */
    private String cover;

    /**
     * 显示状态（0：隐藏，1：显示）
     */
    private String state;

    /**
     * 作者
     */
    private String author;

    /**
     * 微信文章地址
     */
    private String url;

    /**
     * 素材id
     */
    @Column(name = "thumb_media_id")
    private String thumbMediaId;

    /**
     * 图文消息的原文地址
     */
    @Column(name = "content_source_url")
    private String contentSourceUrl;

    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private Date updateTime;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * 内容
     */
    private String content;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取摘要
     *
     * @return digest - 摘要
     */
    public String getDigest() {
        return digest;
    }

    /**
     * 设置摘要
     *
     * @param digest 摘要
     */
    public void setDigest(String digest) {
        this.digest = digest;
    }

    /**
     * 获取封面
     *
     * @return cover - 封面
     */
    public String getCover() {
        return cover;
    }

    /**
     * 设置封面
     *
     * @param cover 封面
     */
    public void setCover(String cover) {
        this.cover = cover;
    }

    /**
     * 获取显示状态（0：隐藏，1：显示）
     *
     * @return state - 显示状态（0：隐藏，1：显示）
     */
    public String getState() {
        return state;
    }

    /**
     * 设置显示状态（0：隐藏，1：显示）
     *
     * @param state 显示状态（0：隐藏，1：显示）
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * 获取作者
     *
     * @return author - 作者
     */
    public String getAuthor() {
        return author;
    }

    /**
     * 设置作者
     *
     * @param author 作者
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * 获取素材id
     *
     * @return thumb_media_id - 素材id
     */
    public String getThumbMediaId() {
        return thumbMediaId;
    }

    /**
     * 设置素材id
     *
     * @param thumbMediaId 素材id
     */
    public void setThumbMediaId(String thumbMediaId) {
        this.thumbMediaId = thumbMediaId;
    }

    /**
     * 获取图文消息的原文地址
     *
     * @return content_source_url - 图文消息的原文地址
     */
    public String getContentSourceUrl() {
        return contentSourceUrl;
    }

    /**
     * 设置图文消息的原文地址
     *
     * @param contentSourceUrl 图文消息的原文地址
     */
    public void setContentSourceUrl(String contentSourceUrl) {
        this.contentSourceUrl = contentSourceUrl;
    }

    /**
     * 获取更新时间
     *
     * @return update_time - 更新时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 获取删除标识(1:已删除,0:正常)
     *
     * @return del_flag - 删除标识(1:已删除,0:正常)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:已删除,0:正常)
     *
     * @param delFlag 删除标识(1:已删除,0:正常)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建备注
     *
     * @return add_mark - 创建备注
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建备注
     *
     * @param addMark 创建备注
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新备注
     *
     * @return upd_mark - 更新备注
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新备注
     *
     * @param updMark 更新备注
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    /**
     * 获取内容
     *
     * @return content - 内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置内容
     *
     * @param content 内容
     */
    public void setContent(String content) {
        this.content = content;
    }
}
