/*
 * @(#) AlbumPicVo.java 2019年02月14日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.ealbums;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月14日
 */
@Table(name = "tra_album_pic")
public class AlbumPicVo extends BaseVo {

    @Id
    private String id;
    /**相册id*/
    private String albumId;
    /**文件名称*/
    private String name;
    /**图片url*/
    private String urlPath;
    /**内容*/
    private String content;
    /**排序*/
    private Integer sort;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAlbumId() {
        return albumId;
    }

    public void setAlbumId(String albumId) {
        this.albumId = albumId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrlPath() {
        return urlPath;
    }

    public void setUrlPath(String urlPath) {
        this.urlPath = urlPath;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }
}
