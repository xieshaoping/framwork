/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.homePage;

import com.isimpo.tech.framework.applet.auto.entity.homePage.SysDict;
import com.isimpo.tech.framework.applet.auto.entity.sysBase.SysConfigure;
import com.xiaoleilu.hutool.extra.mail.MailAccount;
import com.xiaoleilu.hutool.extra.mail.MailUtil;

import com.alibaba.druid.util.StringUtils;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Reserve;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.ReserveMapper;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * @author zx
 * @version 1.0
 * @since 2018/4/24
 */
@Service
public class ReserveService extends BaseService<ReserveMapper, Reserve> {

    static Logger logger = LogManager.getLogger(ReserveService.class.getName());

    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addReserve(Reserve entity, HttpServletRequest request) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        entity.setState("0");
        entity.setYsncState("0");
        UserInfoVo loginUser = UserInfoUtils.getUserInfo(request);
        String memId;
        if (loginUser == null) {
            entity.setAddUserId("游客添加");
            entity.setAddMark("游客添加");
        } else {
            memId = loginUser.getMemId();
            if (!StringUtils.isEmpty(memId)) {
                entity.setAddUserId(memId);
                entity.setMemId(memId);
                entity.setAddMark("会员添加");
            } else {
                entity.setAddUserId("游客添加");
                entity.setAddMark("游客添加");
            }
        }
        int result = mapper.insertSelective(entity);
        if (result == 1) {
            //  从基础设置sys_base里获取提醒邮箱List
            String emails = mapper.getEmailList();
            String[] emailList = emails.split(",");
            List<String> list = new ArrayList<>();
            for (String email : emailList) {
                list.add(email);
            }
            // 从数据库获取系统发件人邮箱地址、密码
            SysConfigure sysConfigure = mapper.getSysConfigure();
            // 开始发送邮件
            MailAccount account = new MailAccount();
            String emailName = "【咨询】" + "称呼:" + entity.getTitle() + ";电话:" + entity.getPhone();
            account.setHost("smtp.qq.com");
            account.setAuth(true);
            account.setPort(465);
            account.setFrom(sysConfigure.getSendEmail());
            account.setUser(sysConfigure.getSendEmail());// 发件人邮箱
            account.setPass(sysConfigure.getEmailPwd());// 发件人密码
            account.setStartttlsEnable(true);
            StringBuilder html = new StringBuilder();
            // 邮件内容
            //html.append(entity.getMessage());
            //  循环邮箱list
            for (String email : list) {
                try {
                    MailUtil.send(account, email, emailName, html.toString(), true);
                } catch (Exception e) {
                    logger.error(email + "：该邮件地址不存在！");
                }
            }
            // 发送邮件结束
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    public List<SysDict> getPlace(){
        return mapper.getPlace();
    }


}
