package com.isimpo.tech.framework.applet.auto.entity.onroad.timememory;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
public class TimeMemoryVo extends TravelRecordVo {

    // 发布人昵称
    private String nickName;

    // 发布人微信头像
    private String photo;

    private String dateFlag;

    private List<PraiseRecordVo> praiseUsers;

    // 游记下的评论列表
    private List<CommentVo> comments;

    public List<PraiseRecordVo> getPraiseUsers() {
        return praiseUsers;
    }

    public void setPraiseUsers(List<PraiseRecordVo> praiseUsers) {
        this.praiseUsers = praiseUsers;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public List<CommentVo> getComments() {
        return comments;
    }

    public void setComments(List<CommentVo> comments) {
        this.comments = comments;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getAddTime() {
        return super.getAddTime();
    }

    public String getDateFlag() {
        return dateFlag;
    }

    public void setDateFlag(String dateFlag) {
        this.dateFlag = dateFlag;
    }
}
