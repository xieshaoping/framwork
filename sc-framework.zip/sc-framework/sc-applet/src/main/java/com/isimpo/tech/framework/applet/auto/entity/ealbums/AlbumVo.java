/*
 * @(#) AlbumVo.java 2019年02月14日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.ealbums;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.List;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月14日
 */
@Table(name = "tra_album")
public class AlbumVo extends BaseVo {

    @Id
    private String id;
    /**行程id*/
    private String traId;
    /**会员Id*/
    private String memId;
    /**名称*/
    private String name;
    /**模板类型（1：长图模板，2：动态相册）*/
    private String template;
    /**创建时间*/
    private String createTime;
    /**图片地址*/
    private String urlPath;
    /**图片列表*/
    @Transient
    private List<AlbumPicVo> picList;

    @Transient
    private String date;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUrlPath() {
        return urlPath;
    }

    public void setUrlPath(String urlPath) {
        this.urlPath = urlPath;
    }

    public List<AlbumPicVo> getPicList() {
        return picList;
    }

    public void setPicList(List<AlbumPicVo> picList) {
        this.picList = picList;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
