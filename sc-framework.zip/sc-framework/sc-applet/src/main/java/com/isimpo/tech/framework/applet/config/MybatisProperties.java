package com.isimpo.tech.framework.applet.config;

import javax.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.io.Resource;
import org.springframework.validation.annotation.Validated;

/**
 * mybatis 个性化配置
 *
 * @author abator
 * @version 1.0
 * @since 2017年12月28日
 */
@ConfigurationProperties(prefix = "mybatis")
@Validated
public class MybatisProperties {

    @NotNull
    private String basePackage;

    @NotNull
    private Resource[] xmlLocation;

    private String typeAliasesPackage;

    public String getTypeAliasesPackage() {
        return typeAliasesPackage;
    }

    public void setTypeAliasesPackage(String typeAliasesPackage) {
        this.typeAliasesPackage = typeAliasesPackage;
    }

    public String getBasePackage() {
        return basePackage;
    }

    public void setBasePackage(String basePackage) {
        this.basePackage = basePackage;
    }

    public Resource[] getXmlLocation() {
        return xmlLocation;
    }

    public void setXmlLocation(Resource[] xmlLocation) {
        this.xmlLocation = xmlLocation;
    }
}
