package com.isimpo.tech.framework.applet.service.resound;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.strategy.StrategyVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.mapper.resound.StrategyMapper;
import com.isimpo.tech.framework.applet.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/21
 *
 */
@Service
public class StrategyService extends BaseService<StrategyMapper, StrategyVo> {

    @Autowired
    HttpServletRequest request;


    /**
     * 获取攻略列表
     * @return
     */
    public AjaxResponse getStrategyList(Query query) {
//        UserInfoVo user = new UserInfoVo();
//        user.setMemId("tank073");
        UserInfoVo user = UserInfoUtils.getUserInfo(request);
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<StrategyVo> list = mapper.getStrategyList(query);
        for(StrategyVo vo:list){
            int check = mapper.checkPraise(vo.getId(),user.getWecharId());
            if(check>0){
                vo.setPraiseFlag("1");
            }
        }
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }

    /**
     * 获取攻略详情
     * @param id
     * @return
     */
    public AjaxResponse getDetail(String id) {
//        UserInfoVo user = new UserInfoVo();
//        user.setMemId("tank073");
        UserInfoVo user = UserInfoUtils.getUserInfo(request);
        StrategyVo vo = mapper.getStrategyDetailById(id);
        List<PraiseRecordVo> prs = mapper.listPraiseRecordById(id);
        List<CommentVo> cms = mapper.listCommentById(id);
        if(vo == null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        int check = mapper.checkPraise(vo.getId(),user.getWecharId());
        if(check>0){
            vo.setPraiseFlag("1");
        }
        vo.setPraiseUsers(prs);
        vo.setComments(cms);
        return AjaxResponse.of(vo);
    }

    /**
     * 检查是否存在攻略
     * @param memId
     * @return boolean
     */
    public AjaxResponse checkExist(String memId) {
        if(memId == null || memId == ""){
            return AjaxResponse.of(false);
        }
        int num = 0;
        num = mapper.checkExist(memId);
        if (num > 0){
            return AjaxResponse.of(true);
        }
        return AjaxResponse.of(false);
    }


    /**
     * 逻辑删除攻略
     * @param vo
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delStrategy(StrategyVo vo) {
        if (mapper.delStrategy(vo) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 点赞
     * @param praiseRecord
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse praise(PraiseRecordVo praiseRecord) {
        EntityUtils.setCreatAndUpdatInfoTwo(praiseRecord, praiseRecord.getMemId());
        if (mapper.addPraiseRecord(praiseRecord) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 取消赞
     * @param praiseRecord
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse unPraise(PraiseRecordVo praiseRecord) {
        if(mapper.delPraiseRecord(praiseRecord) > 0) {
           return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 添加攻略
     * @param vo
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addStrategy(StrategyVo vo) {
        vo.setContent(SensitiveWordUtils.filterStr(vo.getContent().toString()));
        EntityUtils.setCreatAndUpdatInfoTwo(vo, vo.getId());
        // 伪造两条数据
        vo.setAddUserId("11");
        vo.setUpdUserId("11");
        vo.setAddMark("添加攻略");
        vo.setUpdMark("修改攻略");
        if (mapper.addStrategy(vo) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 增加评论
     * @param comment
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addComment(CommentVo comment) {
        comment.setContent(SensitiveWordUtils.filterStr(comment.getContent().toString()));
        EntityUtils.setCreatAndUpdatInfo(comment);
        comment.setAddUserId("11");
        comment.setUpdUserId("11");
        if (mapper.addComment(comment) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        } else {
            return AjaxResponse.of(ResponseCode.FAIL);
        }
    }

    /**
     * 逻辑删除评论
     * @param comment
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delComment(CommentVo comment) {
        EntityUtils.setCreatAndUpdatInfo(comment);
        comment.setAddUserId("11");
        comment.setUpdUserId("11");
        if (mapper.delComment(comment) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

}
