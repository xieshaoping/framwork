package com.isimpo.tech.framework.applet.service.resound;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.TraTravelerTalk;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.mapper.resound.TraTravelerTalkMapper;
import com.isimpo.tech.framework.applet.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/18
 *
 */
@Service
public class TraTravelerTalkService extends BaseService<TraTravelerTalkMapper, TraTravelerTalk> {

    @Autowired
    HttpServletRequest request;
    /**
     * 获取旅咖说列表
     * @return
     */
    public AjaxResponse getTraTalkList(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<TraTravelerTalk> list = mapper.getTraTalkList(query);
        //查询所有消息的确认列表,如果该行程没有消息，则直接返回
        if(list.size()>0){
            //首先获取用户信息   先在此写死，后期从缓存中取
//            UserInfoVo uservo = new UserInfoVo();
//            uservo.setMemId("tank073");
            UserInfoVo uservo = UserInfoUtils.getUserInfo(request);
            // 查询每一条旅咖说的点赞列表与评论列表
            List<PraiseRecordVo> praises = mapper.listPraiseRecord(list);
            List<CommentVo> comments = mapper.listComment(list);
            for(TraTravelerTalk talk :list){
                List<PraiseRecordVo> temp = new ArrayList<>();
                List<CommentVo> temp_cm = new ArrayList<>();
                for(PraiseRecordVo vo:praises){
                    if(StringUtils.equals(talk.getId(),vo.getMainId())){
                        temp.add(vo);
                        if(StringUtils.equals(vo.getMemId(),uservo.getWecharId())){
                            talk.setPraiseFlag("1");
                        }
                    }
                }
                for(CommentVo cm:comments){
                    if(StringUtils.equals(talk.getId(),cm.getMainId())){
                        temp_cm.add(cm);
                    }
                }
                talk.setPraiseUsers(temp);
                talk.setComments(temp_cm);
            }

        }
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }

    /**
     * 获取旅咖说详情
     * @param id
     * @return
     */
    public AjaxResponse getTraTalkDetail(String id) {
        TraTravelerTalk talk = mapper.getTraTalkDetail(id);
        List<PraiseRecordVo> prs = mapper.listPraiseRecordById(id);
        List<CommentVo> cms = mapper.listCommentById(id);
        if(talk == null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        // 先在此写死，后期从缓存中取
//        UserInfoVo vo = new UserInfoVo();
//        vo.setMemId("tank073");
        UserInfoVo vo = UserInfoUtils.getUserInfo(request);
        int check = mapper.checkPraise(talk.getId(),vo.getWecharId());
        if(check>0){
            talk.setPraiseFlag("1");
        }
        talk.setPraiseUsers(prs);
        talk.setComments(cms);
        return AjaxResponse.of(talk);
    }

    /**
     * 逻辑删除旅咖说
     * @param id
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delTraTalk(String id) {
        TraTravelerTalk talk = mapper.getTraTalkDetail(id);
        EntityUtils.setUpdatedInfo(talk);
//        talk.setUpdUserId("11");
        if (mapper.delTraTalk(talk) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 点赞
     * @param praiseRecord
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse praise(PraiseRecordVo praiseRecord) {
        EntityUtils.setCreatAndUpdatInfoTwo(praiseRecord, praiseRecord.getMemId());
        if (mapper.addPraiseRecord(praiseRecord) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 取消赞
     * @param praiseRecord
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse unPraise(PraiseRecordVo praiseRecord) {
        if(mapper.delPraiseRecord(praiseRecord) > 0) {
           return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 添加旅咖说
     * @param talk
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addTraTalk(TraTravelerTalk talk) {
        talk.setDigest(SensitiveWordUtils.filterStr(talk.getDigest().toString()));
        if(talk.getNote() != null){
            talk.setNote(SensitiveWordUtils.filterStr(talk.getNote().toString()));
        }
        EntityUtils.setCreatAndUpdatInfoTwo(talk, talk.getMemId());
        if (mapper.addTraTalk(talk) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 增加评论
     * @param comment
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addComment(CommentVo comment) {
        comment.setContent(SensitiveWordUtils.filterStr(comment.getContent().toString()));
        EntityUtils.setCreatAndUpdatInfo(comment);
//        comment.setAddUserId("11");
//        comment.setUpdUserId("11");
        if (mapper.addComment(comment) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        } else {
            return AjaxResponse.of(ResponseCode.FAIL);
        }
    }

    /**
     * 逻辑删除评论
     * @param comment
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delComment(CommentVo comment) {
        EntityUtils.setCreatAndUpdatInfo(comment);
//        comment.setAddUserId("11");
//        comment.setUpdUserId("11");
        if (mapper.delComment(comment) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }
}
