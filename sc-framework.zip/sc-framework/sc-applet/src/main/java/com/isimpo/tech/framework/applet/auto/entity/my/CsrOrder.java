package com.isimpo.tech.framework.applet.auto.entity.my;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.Date;

@Table(name = "csr_order")
public class CsrOrder {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 路线id
     */
    @Column(name = "route_id")
    private String routeId;

    /**
     * 订单编号
     */
    @Column(name = "order_no")
    private String orderNo;

    /**
     * 人数
     */
    private Integer amunt;

    /**
     * 单价
     */
    private BigDecimal price;

    /**
     * 订金金额
     */
    private BigDecimal money;

    /**
     * 留言
     */
    private String note;

    /**
     * 姓名
     */
    private String name;

    /**
     * 手机号码
     */
    private String phone;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 会员id
     */
    @Column(name = "mem_id")
    private String memId;

    /**
     * 预订时间
     */
    @Column(name = "order_time")
    private Date orderTime;

    /**
     * 支付状态（0：待支付，1：已支付）
     */
    @Column(name = "pay_state")
    private String payState;

    /**
     * 订单状态（0：待支付，1：预报名，2：待出行，5：未成团，9：已完成）
     */
    private String state;

    //路线标题
    @Transient
    private String title;

    //会员名称
    @Transient
    private String memName;

    //订单状态名称
    @Transient
    private String orderState;

    @JsonFormat(pattern = "YYYY-MM-dd")
    @Transient
    private Date startDate;

    @Transient
    private String days;

    //封面
    @Transient
    private String cover;
    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取路线id
     *
     * @return route_id - 路线id
     */
    public String getRouteId() {
        return routeId;
    }

    /**
     * 设置路线id
     *
     * @param routeId 路线id
     */
    public void setRouteId(String routeId) {
        this.routeId = routeId;
    }

    /**
     * 获取订单编号
     *
     * @return order_no - 订单编号
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * 设置订单编号
     *
     * @param orderNo 订单编号
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * 获取人数
     *
     * @return amunt - 人数
     */
    public Integer getAmunt() {
        return amunt;
    }

    /**
     * 设置人数
     *
     * @param amunt 人数
     */
    public void setAmunt(Integer amunt) {
        this.amunt = amunt;
    }

    /**
     * 获取订金金额
     *
     * @return money - 订金金额
     */
    public BigDecimal getMoney() {
        return money;
    }

    /**
     * 设置订金金额
     *
     * @param money 订金金额
     */
    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    /**
     * 获取留言
     *
     * @return note - 留言
     */
    public String getNote() {
        return note;
    }

    /**
     * 设置留言
     *
     * @param note 留言
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * 获取姓名
     *
     * @return name - 姓名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置姓名
     *
     * @param name 姓名
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取手机号码
     *
     * @return phone - 手机号码
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 设置手机号码
     *
     * @param phone 手机号码
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * 获取邮箱
     *
     * @return email - 邮箱
     */
    public String getEmail() {
        return email;
    }

    /**
     * 设置邮箱
     *
     * @param email 邮箱
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * 获取会员id
     *
     * @return mem_id - 会员id
     */
    public String getMemId() {
        return memId;
    }

    /**
     * 设置会员id
     *
     * @param memId 会员id
     */
    public void setMemId(String memId) {
        this.memId = memId;
    }

    /**
     * 获取预订时间
     *
     * @return order_time - 预订时间
     */
    public Date getOrderTime() {
        return orderTime;
    }

    /**
     * 设置预订时间
     *
     * @param orderTime 预订时间
     */
    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    /**
     * 获取支付状态（0：待支付，1：已支付）
     *
     * @return pay_state - 支付状态（0：待支付，1：已支付）
     */
    public String getPayState() {
        return payState;
    }

    /**
     * 设置支付状态（0：待支付，1：已支付）
     *
     * @param payState 支付状态（0：待支付，1：已支付）
     */
    public void setPayState(String payState) {
        this.payState = payState;
    }

    /**
     * 获取订单状态（0：待支付，1：预报名，2：待出行，5：未成团，9：已完成）
     *
     * @return state - 订单状态（0：待支付，1：预报名，2：待出行，5：未成团，9：已完成）
     */
    public String getState() {
        return state;
    }

    /**
     * 设置订单状态（0：待支付，1：预报名，2：待出行，5：未成团，9：已完成）
     *
     * @param state 订单状态（0：待支付，1：预报名，2：待出行，5：未成团，9：已完成）
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * 获取删除标识(1:已删除,0:正常)
     *
     * @return del_flag - 删除标识(1:已删除,0:正常)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:已删除,0:正常)
     *
     * @param delFlag 删除标识(1:已删除,0:正常)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建备注
     *
     * @return add_mark - 创建备注
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建备注
     *
     * @param addMark 创建备注
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新备注
     *
     * @return upd_mark - 更新备注
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新备注
     *
     * @param updMark 更新备注
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMemName() {
        return memName;
    }

    public void setMemName(String memName) {
        this.memName = memName;
    }

    public String getOrderState() {
        return orderState;
    }

    public void setOrderState(String orderState) {
        this.orderState = orderState;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }
}