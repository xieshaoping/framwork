package com.isimpo.tech.framework.applet.service.onroad.timememory;

import cn.hutool.core.util.ImageUtil;
import com.alibaba.fastjson.JSONObject;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraBase;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.TimeMemoryVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.TravelRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatTplMsgItemVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatTplMsgVo;
import com.isimpo.tech.framework.applet.auto.mapper.global.GlobalMapper;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip.TraItemMapper;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.timememory.TimeMemoryMapper;
import com.isimpo.tech.framework.applet.service.onroad.everyTrip.EveryTripService;
import com.isimpo.tech.framework.applet.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.applet.utils.WeinXinUtil;
import com.isimpo.tech.framework.applet.utils.utils.HttpClientUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.isimpo.tech.wechat.WeChatConfigUtil;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.WechatConstants;
import com.isimpo.tech.wechat.pojo.WechatConfig;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sun.misc.BASE64Decoder;

import javax.imageio.ImageIO;
import javax.net.ssl.HttpsURLConnection;
import javax.validation.constraints.NotNull;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * @author zhuyilong
 * @since 2019/2/13
 */
@Service
public class TimeMemoryService extends BaseService<TimeMemoryMapper, PraiseRecordVo> {

    @Autowired
    private GlobalMapper globalMapper;

    private static Logger logger = LoggerFactory.getLogger(TimeMemoryService.class);

    //获取临时素材
    private static final String ALL_MEDIA_URL =
            "https://api.weixin.qq.com/cgi-bin/media/get?access_token=#ACCESS_TOKEN#&media_id=MEDIA_ID";

    public static final String UTF_8 = "UTF-8";

    @Value("${imagePath.path}")
    String path;

    @NotNull
    @Value("${templateId}")
    private String templateId;

    @NotNull
    @Value("${h5Url}")
    private String h5Url;

    @Autowired
    private TraItemMapper traItemMapper;
    /**
     * 获取时光留影列表
     * @return
     */
    public AjaxResponse getTimeMemoryList(Query query) {
        int limit = query.getLimit();
        int offset = (query.getPage() - 1) * limit;
        query.put("offset", offset);
        query.put("limit", limit);
        List<TimeMemoryVo> list = mapper.listTimeMemory(query);
        return AjaxResponse.of(list);
    }

    /**
     * 获取时光留影详情
     * @param id    游记id
     * @param uid   用户id
     * @param wid   用户wechat id
     * @return
     */
    public AjaxResponse getTimeMemory(String id, String uid, String wid) {
        TimeMemoryVo timeMemory = mapper.getTimeMemory(id, uid, wid);
        return AjaxResponse.of(timeMemory);
    }

    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delTimeMemory(TravelRecordVo travelRecord) {
        if (mapper.delTimeMemory(travelRecord) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 获取点赞列表
     * @param praiseRecord
     * @return
     */
    public AjaxResponse getPraiseRecordList(PraiseRecordVo praiseRecord) {
        return AjaxResponse.of(mapper.listPraiseRecord(praiseRecord));
    }

    /**
     * 点赞
     * @param praiseRecord
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse praise(PraiseRecordVo praiseRecord) {
        EntityUtils.setCreatAndUpdatInfoTwo(praiseRecord, praiseRecord.getMemId());
        if (mapper.addPraiseRecord(praiseRecord) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 取消赞
     * @param praiseRecord
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse unPraise(PraiseRecordVo praiseRecord) {
        if(mapper.delPraiseRecord(praiseRecord) > 0) {
           return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 添加行程游记
     * @param travelRecord
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addTravelRecord(TravelRecordVo travelRecord) {
        EntityUtils.setCreatAndUpdatInfoTwo(travelRecord, travelRecord.getMemId());
        // 游记内容敏感词过滤
        travelRecord.setContent(SensitiveWordUtils.filterStr(travelRecord.getContent()));
        if (mapper.addTravelRecord(travelRecord) > 0) {
            setTemplantDate("",travelRecord.getContent(),travelRecord.getRangeId(),travelRecord.getMemId(),travelRecord.getId());
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 逻辑删除行程记录
     * @param travelRecordVo
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delTravelRecord(TravelRecordVo travelRecordVo) {
        EntityUtils.setUpdatedInfoTwo(travelRecordVo, travelRecordVo.getMemId());
        if (mapper.delTimeMemory(travelRecordVo) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 获取行程事项信息
     * @param travelRecord
     * @return
     */
    public AjaxResponse getItemInfo(TravelRecordVo travelRecord) {
        return AjaxResponse.of(mapper.getItemInfo(travelRecord));
    }

    /**
     * 增加评论
     * @param comment
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addComment(CommentVo comment) {
        EntityUtils.setCreatAndUpdatInfoTwo(comment, comment.getMemId());
        comment.setContent(SensitiveWordUtils.filterStr(comment.getContent()));
        if (mapper.addComment(comment) > 0) {
            Map result = new HashMap();
            result.put("id", comment.getId());
            return AjaxResponse.of(result);
        } else {
            return AjaxResponse.of(ResponseCode.FAIL);
        }
    }

    /**
     * 逻辑删除评论
     * @param comment
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delComment(CommentVo comment) {
        EntityUtils.setUpdatedInfoTwo(comment, comment.getMemId());
        if (mapper.delComment(comment) > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 逻辑分页
     * @param list
     * @param query
     * @param <E>
     * @return
     */
    private <E> List<E> logicPageSplit(List<E> list, Query query) {
        int limit = query.getLimit();
        int offset = (query.getPage() - 1) * limit;
        int listLength = list.size();
        // 如果起始索引超出列表长度，返回空列表
        if (listLength <= offset) {
            return list.subList(listLength, listLength);
        }
        // 否则结束下标不超过列表长度
        return list.subList(offset, Math.min(listLength, offset + limit));
    }

    public List<String> uploadBase64(String base64, String mediaId) throws Exception{
        String[] mediaIds = mediaId.split(",");
        String[] base64s = base64.split(",");
        List<String> returnUrl = new ArrayList<>();
        String savePath = path + "wxUpload";
        BASE64Decoder decoder = null;
        for (int j = 0;j<base64s.length;j++) {
            decoder = new BASE64Decoder();
            base64s[j] = base64s[j].replaceAll(" ", "+");
            //System.out.println(base64s[j]);
            byte[] b = decoder.decodeBuffer(base64s[j].replace("data:image/jpeg;base64,", ""));
            for (int i = 0; i < b.length; ++i) {
                if (b[i] < 0) {// 调整异常数据
                    b[i] += 256;
                }
            }
            if (!savePath.endsWith("/")) {
                savePath += File.separator;
            }
            File file = new File(savePath);
            if (!file.exists()) {
                file.mkdir();
            }
            String filePath = savePath + mediaIds[j]+".jpg";
            String upPath = "wxUpload"+ File.separator + mediaIds[j] + ".jpg";

            OutputStream out = new FileOutputStream(filePath);
            out.write(b);
            out.flush();
            out.close();

            mark(filePath, filePath, new Color(248, 246, 231), globalMapper.getSysConfig().getWatermark());
            returnUrl.add(upPath);
        }
        Arrays.asList(returnUrl).stream().forEach(x->{
            System.out.println(x);
        });
        return returnUrl;
    }

    public static String getRandomFileName() {
        SimpleDateFormat simpleDateFormat;
        simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = new Date();
        String str = simpleDateFormat.format(date);
        Random random = new Random();
        int rannum = (int) (random.nextDouble() * (99999 - 10000 + 1)) + 10000;// 获取5位随机数
        return rannum + str;// 当前时间
    }


    /**
     * 微信上传图片
     * @param mediaId
     * @return
     */
    public List<String> getMediaUpload(String mediaId){
        List<String> returnUrl = new ArrayList<>();
        String[] mediaIds = mediaId.split(",");
        String filePath = null;
        String token = WechatApi.getToken();
        InputStream in = null;
        WechatApi.refreshAccessToken();
        BufferedInputStream bis = null;
        FileOutputStream fos = null;
        for (int i = 0;i<mediaIds.length;i++) {
            try {
                String savePath = path + "wxUpload";
                String requestUrl = ALL_MEDIA_URL.replace(WechatConstants.ACCESS_TOKEN, token).replace("MEDIA_ID", mediaIds[i]);
                URL url = new URL(requestUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(120000);
                conn.setReadTimeout(120000);
                conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
                if (!savePath.endsWith("/")) {
                    savePath += File.separator;
                }
                File file = new File(savePath);
                if (!file.exists()) {
                    file.mkdirs();
                }
                // 根据内容类型获取扩展名
                String fileExt = getFileexpandedName(conn.getHeaderField("Content-Type"));
                // 将mediaId作为文件名
                filePath = savePath + mediaIds[i] + fileExt;
                String upPath = "wxUpload"+ File.separator + [mediaIdsi] + fileExt;
                in = conn.getInputStream();

                bis = new BufferedInputStream(in);
                fos = new FileOutputStream(new File(filePath));

                byte[] buf = new byte[1024];
                int size = 0;
                while ((size = bis.read(buf)) != -1) {
                    fos.write(buf, 0, size);
                }

                in.close();
                fos.close();
                bis.close();
                conn.disconnect();

                String info = String.format("下载媒体文件成功，filePath=" + filePath);

                BufferedImage sourceImg = ImageIO.read(new FileInputStream(filePath));

                mark(filePath, filePath, new Color(248, 246, 231), globalMapper.getSysConfig().getWatermark());
                System.out.println(info);
                returnUrl.add(upPath);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return returnUrl;
    }

    /**
     * 根据内容类型判断文件扩展名
     *
     * @param contentType 内容类型
     * @return
     */
    public static String getFileexpandedName(String contentType) {
        String fileEndWitsh = "";
        if ("image/jpeg".equals(contentType))
            fileEndWitsh = ".jpg";
        else if ("audio/mpeg".equals(contentType))
            fileEndWitsh = ".mp3";
        else if ("audio/amr".equals(contentType))
            fileEndWitsh = ".amr";
        else if ("video/mp4".equals(contentType))
            fileEndWitsh = ".mp4";
        else if ("video/mpeg4".equals(contentType))
            fileEndWitsh = ".mp4";
        else if ("image/gif".equals(contentType))
            fileEndWitsh = ".gif";
        else if ("image/png".equals(contentType))
            fileEndWitsh = ".png";
        else if ("image/jpg".equals(contentType))
            fileEndWitsh = ".jpg";
        else fileEndWitsh = ".jpg";
        return fileEndWitsh;
    }

    public static void mark(String srcImgPath, String outImgPath, Color markContentColor, String waterMarkContent) {
        FileOutputStream outImgStream =null;
        try {
            // 读取原图片信息
            logger.info("srcImgPath ==== " + srcImgPath);
            File srcImgFile = new File(srcImgPath);
            Image srcImg = ImageIO.read(srcImgFile);
            int srcImgWidth = srcImg.getWidth(null);
            int srcImgHeight = srcImg.getHeight(null);
            // 加水印
            BufferedImage bufImg = new BufferedImage(srcImgWidth, srcImgHeight, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = bufImg.createGraphics();
            g.drawImage(srcImg, 0, 0, srcImgWidth, srcImgHeight, null);
            //Font font = new Font("Courier New", Font.PLAIN, 12);
            Font font = new Font("宋体", Font.PLAIN, 50);
            g.setColor(markContentColor); //根据图片的背景设置水印颜色

            g.setFont(font);
            int x = srcImgWidth - getWatermarkLength(waterMarkContent, g) - 3 -40;
            int y = srcImgHeight - 3 -40;
            //int x = (srcImgWidth - getWatermarkLength(watermarkStr, g)) / 2;
            //int y = srcImgHeight / 2;
            g.drawString(waterMarkContent, x, y);
            g.dispose();
            // 输出图片
            outImgStream = new FileOutputStream(outImgPath);
            ImageIO.write(bufImg, "jpg", outImgStream);
            outImgStream.flush();
            outImgStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(outImgStream!=null){
                try {
                    outImgStream.close();
                } catch (IOException e) {
// TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 获取水印文字总长度
     * @param waterMarkContent 水印的文字
     * @param g
     * @return 水印文字总长度
     */
    public static int getWatermarkLength(String waterMarkContent, Graphics2D g) {
        return g.getFontMetrics(g.getFont()).charsWidth(waterMarkContent.toCharArray(), 0, waterMarkContent.length());
    }

    /**
     * 发送模板消息
     *
     * @param name
     * @param content
     * @param traId
     */
    public void setTemplantDate(String name, String content,String traId,String memId,String id) {
        //查询该行程所在的成员  openId
        //List<String> authPeoples = traItemMapper.getMemberListByTraId(traId).stream().map(Member::getOpenId).collect(Collectors.toList());
        List<Member> list = traItemMapper.getMemberListByTraId(traId);
        List<Member> memberList = traItemMapper.findAllFlagMember();
        Member member = traItemMapper.getMemberOpenId(memId);
        list.addAll(memberList);
        list.add(member);
        TraBase traBase = traItemMapper.getTramById(traId);
        List<String> openIds = new ArrayList<>();
        openIds.add("1");
        for (int i = 0;i<list.size();i++) {
            //发送模板消息
            WechatTplMsgVo tplMsgVo = new WechatTplMsgVo();
            tplMsgVo.setTemplate_id(templateId);
            tplMsgVo.setUrl(h5Url + "static/page/onroad/timememory/detail.html?id=" + id);
            Map<String, WechatTplMsgItemVo> map = new HashMap<>();
            map.put("first",new WechatTplMsgItemVo("尊敬的"+list.get(i).getName()+"，您好，可乐国旅温馨提醒。"));
            map.put("keyword1",new WechatTplMsgItemVo(traBase.getName()));
            map.put("keyword2",new WechatTplMsgItemVo("游记"));
            map.put("keyword3",new WechatTplMsgItemVo(content));
            map.put("remark", new WechatTplMsgItemVo(""));
            tplMsgVo.setData(map);
            if(openIds.contains(list.get(i).getOpenId())){
                continue;
            }
            if(list.get(i).getOpenId() != null){
                openIds.add(list.get(i).getOpenId());
                sendTplMsg(tplMsgVo, list.get(i).getOpenId());
            }else{
                logger.error("发送模版消息失败：token:{} 或 没有审核人员");
            }
        }
    }

    public boolean sendTplMsg(WechatTplMsgVo tplMsgVo, String openId){
        WechatConfig wechatConfig = WeChatConfigUtil.getWechatConfig();
        String accessToken = WechatApi.getToken();//WeinXinUtil.getAccessToken(wechatConfig.getAppId(),wechatConfig.getSecret());//WechatApi.getToken();
        Boolean success = false;
        if (StringUtils.isNotEmpty(openId) && StringUtils.isNotEmpty(accessToken)) {
            String requestUrl = WechatConstants.WECHAT_SEND_WECHAT_URL.replace("#ACCESS_TOKEN#", accessToken);
            tplMsgVo.setTouser(openId);
            String params = JSONObject.toJSONString(tplMsgVo);
            params = stringUncode(params);
            try {
                String result = HttpClientUtils.sendPostSSLRequest(requestUrl, params);
                if (StringUtils.isNotBlank(result)) {
                    JSONObject jsonObject = JSONObject.parseObject(result);
                    if (jsonObject.containsKey("errcode") && jsonObject.getIntValue("errcode") == 0) {
                        success = true;
                        logger.info("发送模版消息成功：token:{}：{}：{}", accessToken, params, result);
                    } else {
                        logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                    }
                } else {
                    logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                }
            } catch (Exception ex) {
                logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, ex);
            }
        } else {
            logger.error("发送模版消息失败：token:{} 或 没有审核人员", accessToken);
        }
        return success;
    }

    /**
     * 特殊字符转码
     *
     * @param param
     * @return
     */
    public static String stringUncode(String param) {
        if (param != null && !param.trim().equals("")) {
            try {
                param = URLEncoder.encode(param, "utf-8");//转码
                param = URLDecoder.decode(param, "UTF-8");//解码
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return param;
    }
}
