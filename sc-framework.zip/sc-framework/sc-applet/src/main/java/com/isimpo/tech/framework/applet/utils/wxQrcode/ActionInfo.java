/*
 * @(#) ActionInfo.java 2015年4月9日
 *
 * Copyright (c) 2010, HMI Technology. All Rights Reserved.
 * HMI Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils.wxQrcode;

/**
 * 二维码详细信息Vo
 * 
 * @author zhengjiudong
 * @version 1.0
 * @since 2015年4月9日
 */
public class ActionInfo {
	
	private SceneInfo scene;
	
	public SceneInfo getScene() {
		return scene;
	}

	public void setScene(SceneInfo scene) {
		this.scene = scene;
	}

}
