/*
 * @(#) WechatController.java 2019年02月13日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller.wechat;

import com.isimpo.tech.framework.applet.service.wechat.WechatUserService;
import com.isimpo.tech.framework.applet.utils.utils.StringUtilEXT;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.wechat.SignUtil;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.message.WechatMessageUtil;
import com.isimpo.tech.wechat.pojo.ReceiveMsg;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.util.Map;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月13日
 */
@RestController
@RequestMapping("wechat")
public class WechatController {

    @Autowired
    private WechatUserService wechatUserService;

    /**
     * 微信关注
     */
    @ResponseBody
    @RequestMapping(value = "receiveMsg", produces = { "text/plain;charset=UTF-8" })
    public String receiveMsg(HttpServletRequest request, HttpServletResponse response){
        String resultStr = "";// 返回值
        // 微信加密签名
        String signature = request.getParameter("signature");
        // 时间戳
        String timestamp = request.getParameter("timestamp");
        // 随机数
        String nonce = request.getParameter("nonce");
        // 随机字符串
        String echostr = request.getParameter("echostr");

        // 认证服务器
        if (StringUtils.isNotBlank(echostr)) {
            // 请求校验，若校验成功则原样返回echostr，表示接入成功，否则接入失败
            if (SignUtil.checkStuts(signature, timestamp, nonce)) {
                return echostr;
            }
        } else {
            // 调用核心业务类接收消息、处理消息
            try {
                request.setCharacterEncoding("UTF-8");
                response.setCharacterEncoding("UTF-8");
                resultStr = msgHandle(request);
            } catch (Exception e) {
                resultStr = "error";
            }
        }
        return resultStr;
    }

    /**
     *处理微信共通消息共通方法
     */
    private String msgHandle(HttpServletRequest request) {
        String responseMsg = "";
        InputStream inputStream = null;
        try {
            inputStream = request.getInputStream();
            String receiveMsg = StringUtilEXT.convertStreamToString(inputStream);
            if (StringUtilEXT.IsNullOrEmpty(receiveMsg)) {
                return "";
            }
            ReceiveMsg receiveMsgVo = WechatApi.getReceiveMsg(receiveMsg);
            // 第一种情况：微信用户关注该公众号的业务处理
            if (WechatMessageUtil.REQ_MESSAGE_TYPE_EVENT.equals(receiveMsgVo.getMsgType()) && WechatMessageUtil.EVENT_TYPE_SUBSCRIBE.equals(receiveMsgVo.getEvent())) {
                return wechatUserService.updateTxWechatSubscribe(receiveMsgVo);
            }
        } catch (Exception e) {

        }
        return responseMsg;
    }

    /**
     * 获取微信分享签名参数
     */
    @GetMapping("getWechatConfig")
    public AjaxResponse getWechatConfig(String linkUrl) {
        Map<String,String> s = wechatUserService.getWxConfig(linkUrl);
        return AjaxResponse.of(s);
    }
}
