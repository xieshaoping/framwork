/*
 * @(#) WechatUserVo.java 2019年02月14日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.entity.wechat;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月14日
 */
@Table(name = "csr_wechar_user")
public class WechatUserVo extends BaseVo {

    @Id
    private String id;
    /**微信用户开放id*/
    private String openId;
    /**昵称*/
    private String nickName;
    /**头像*/
    private String photo;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
