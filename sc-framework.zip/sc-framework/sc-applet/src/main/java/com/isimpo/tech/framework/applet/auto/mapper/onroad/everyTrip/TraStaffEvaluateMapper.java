package com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraStaffEvaluate;
import tk.mybatis.mapper.common.Mapper;

public interface TraStaffEvaluateMapper extends Mapper<TraStaffEvaluate> {
}