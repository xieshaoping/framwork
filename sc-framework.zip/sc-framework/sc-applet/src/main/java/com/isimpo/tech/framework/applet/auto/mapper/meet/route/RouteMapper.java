package com.isimpo.tech.framework.applet.auto.mapper.meet.route;

import com.isimpo.tech.framework.applet.auto.entity.meet.route.RouteVo;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Component("routeManageMapper")
public interface RouteMapper extends Mapper<RouteVo> {
    /**
     * 查询路线列表
     * @param query
     * @return
     */
    List<RouteVo> listRoute(Query query);
}