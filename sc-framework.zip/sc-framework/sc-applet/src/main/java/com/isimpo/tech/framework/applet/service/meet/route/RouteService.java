package com.isimpo.tech.framework.applet.service.meet.route;

import com.isimpo.tech.framework.applet.auto.entity.meet.route.RouteVo;
import com.isimpo.tech.framework.applet.auto.mapper.meet.route.RouteMapper;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/2/27
 */
@Service("routeMangeService")
public class RouteService extends BaseService<RouteMapper, RouteVo> {

    /**
     * 分页获取路线列表
     * @param query
     * @return
     */
    public AjaxResponse getRouteList(Query query) {
        int limit = query.getLimit();
        int offset = (query.getPage() - 1) * limit;
        query.put("offset", offset);
        query.put("limit", limit);
        List<RouteVo> list = mapper.listRoute(query);
        return AjaxResponse.of(list);
    }
}
