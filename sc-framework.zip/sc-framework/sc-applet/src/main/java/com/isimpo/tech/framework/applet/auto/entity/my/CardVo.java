package com.isimpo.tech.framework.applet.auto.entity.my;

import java.util.Date;
import java.util.List;

import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberVo;
import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 * 可乐名片
 * @author Tank
 * @version V1.0
 * @since 2019/2/26
 *
 */
@Table(name="sys_base")
public class CardVo extends BaseVo {
    /**id*/
    private String id;

    /**网址*/
    private String website;

    /**电话*/
    private String telephone;

    /**地址*/
    private String address;

    /**位置-经纬度*/
    private String position;

    /**公众号名称*/
    private String qrcodeName;

    /**介绍*/
    private String introduction;

    /**公众号二维码*/
    private String qrcodePath;

    /**紧急联系电话*/
    private String urgentPhone;

    /**提醒邮箱*/
    private String noticeEmail;

    /**系统邮箱*/
    private String sendEmail;

    /**系统邮箱密码*/
    private String emailPwd;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getQrcodeName() {
        return qrcodeName;
    }

    public void setQrcodeName(String qrcodeName) {
        this.qrcodeName = qrcodeName;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getQrcodePath() {
        return qrcodePath;
    }

    public void setQrcodePath(String qrcodePath) {
        this.qrcodePath = qrcodePath;
    }

    public String getUrgentPhone() {
        return urgentPhone;
    }

    public void setUrgentPhone(String urgentPhone) {
        this.urgentPhone = urgentPhone;
    }

    public String getNoticeEmail() {
        return noticeEmail;
    }

    public void setNoticeEmail(String noticeEmail) {
        this.noticeEmail = noticeEmail;
    }

    public String getSendEmail() {
        return sendEmail;
    }

    public void setSendEmail(String sendEmail) {
        this.sendEmail = sendEmail;
    }

    public String getEmailPwd() {
        return emailPwd;
    }

    public void setEmailPwd(String emailPwd) {
        this.emailPwd = emailPwd;
    }
}
