/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.service.onroad.everyTrip.MemberService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.CacheUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 *
 * @author wangxinhai
 * @version 1.0
 * @since 2019年02月28日
 */
@RestController
@RequestMapping("/onroad/member")
public class MemberController extends BaseController<MemberService, Member> {

    @Override
    @GetMapping("/page")
    @ResponseBody
    public AjaxResponse list(@RequestParam Map<String, Object> params) {
        Query query = new Query(params);
        return AjaxResponse.of(baseService.selectByQuery(query));
    }

}
