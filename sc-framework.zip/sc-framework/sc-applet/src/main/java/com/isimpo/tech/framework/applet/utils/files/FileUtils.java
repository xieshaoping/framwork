/*
 * @(#) FileUtils.java 2019年02月26日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils.files;

import java.io.File;
import java.util.Calendar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.xiaoleilu.hutool.util.RandomUtil;
import it.sauronsoftware.jave.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月26日
 */
@Component
public class FileUtils {

    private static ExecutorService executorService = Executors.newCachedThreadPool();

    private static String filePath;

    @Value("${imagePath.path}")
    public void setFilePath(String filePath) {
        FileUtils.filePath = filePath;
    }

    /**
     * 视频压缩
     * @param fileUrl 视频地址
     */
    public static void compressedFile(String fileUrl, String saveUrl) {
        //文件地址
        String fileUrlPath = filePath + fileUrl;
        String saveUrlPath = filePath + saveUrl;
        File source = new File(fileUrlPath);
        File target = new File(saveUrlPath);
        if (!target.getParentFile().exists()) {
            // 如果不存在就创建这个文件夹
            target.getParentFile().mkdirs();
        }
        try {
            // 音频编码设置
            AudioAttributes audio = new AudioAttributes();
            audio.setCodec("AAC");
            audio.setBitRate(new Integer(64000));
            audio.setChannels(new Integer(1));
            audio.setSamplingRate(new Integer(22050));

            // 视频编码设置
            VideoAttributes video = new VideoAttributes();
            video.setCodec("h264");
            video.setBitRate(new Integer(160000));
            video.setFrameRate(new Integer(15));
            video.setSize(new VideoSize(400, 300));

            // 视频转码编码设置
            EncodingAttributes attrs = new EncodingAttributes();
            attrs.setFormat("mp4");
            attrs.setAudioAttributes(audio);
            attrs.setVideoAttributes(video);

            // 编码器
            Encoder encoder = new Encoder();
            encoder.encode(source, target, attrs);

            System.out.println("压缩完成...");
        } catch (EncoderException e) {
            e.printStackTrace();
        }
    }

    /**
     * 视频压缩
     * @param fileUrl 视频地址
     * @return 压缩后保存到数据库中的地址
     */
    public static String compressedVideo(String fileUrl) {
        //文件保存地址
        Calendar cal = Calendar.getInstance();
        String year = cal.get(cal.YEAR) + "";
        String month = (cal.get(cal.MONTH) + 1) + "";
        String day = cal.get(cal.DATE) + "";
        String saveUrl = "/".concat(year)
                        .concat("/").concat(month)
                        .concat("/").concat(day)
                        .concat("/video/")
                        .concat(RandomUtil.simpleUUID()).concat(".mp4");
        executorService.submit(new Runnable() {
            @Override public void run() {
                compressedFile(fileUrl,saveUrl);
            }
        });
        return saveUrl;
    }

    public static void main(String[] args) {
        String source = "D:\\upload\\2019\\3\\4\\video\\aa.mp4";
        String save = compressedVideo(source);
        System.out.println(save);
        System.out.println();
    }
}
