package com.isimpo.tech.framework.applet.utils.response;

import com.isimpo.tech.framework.common.response.BaseResponse;

import java.util.List;

/**
 * 搜索页分页专用response
 * @param <T>
 */
public class SearchTableResponse<T> extends BaseResponse {

    TableData<T> data;

    public SearchTableResponse(long total, List<T> rows,int allDeviceNum, List<String> shopList) {
        this.data = new TableData<T>(total, rows,allDeviceNum,shopList);
    }

    public SearchTableResponse() {
        this.data = new TableData<T>();
    }

    SearchTableResponse<T> total(int total) {
        this.data.setTotal(total);
        return this;
    }

    SearchTableResponse<T> total(List<T> rows) {
        this.data.setRows(rows);
        return this;
    }

    public TableData<T> getData() {
        return data;
    }

    public void setData(TableData<T> data) {
        this.data = data;
    }

    class TableData<S> {
        long total;
        List<S> rows;
        int allDeviceNum;
        List<String> shopList;

        public int getAllDeviceNum() {
            return allDeviceNum;
        }

        public void setAllDeviceNum(int allDeviceNum) {
            this.allDeviceNum = allDeviceNum;
        }

        public TableData(long total, List<S> rows,int allDeviceNum, List<String> shopList) {
            this.total = total;
            this.rows = rows;
            this.allDeviceNum = allDeviceNum;
            this.shopList = shopList;
        }

        public TableData() {
        }

        public long getTotal() {
            return total;
        }

        public void setTotal(long total) {
            this.total = total;
        }

        public List<String> getShopList() {
            return shopList;
        }

        public void setShopList(List<String> shopList) {
            this.shopList = shopList;
        }

        public List<S> getRows() {
            return rows;
        }

        public void setRows(List<S> rows) {
            this.rows = rows;
        }
    }
}
