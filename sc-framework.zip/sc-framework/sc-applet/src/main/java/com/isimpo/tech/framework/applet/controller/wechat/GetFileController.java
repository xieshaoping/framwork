/*
 * @(#) GetFileController.java 2019年02月27日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller.wechat;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月27日
 */
@RestController
@RequestMapping("/")
public class GetFileController {

    @Value("${MP_verify_id}")
    String MP_verify_id;

    //@RequestMapping({"MP_verify_IEdMD76gCWWGvTp6.txt"})  //test
    @RequestMapping({"MP_verify_FtKRXEe49flmgQUH.txt"})    //prod
    private String returnConfigFile(HttpServletResponse response) {
        return MP_verify_id;
    }
}
