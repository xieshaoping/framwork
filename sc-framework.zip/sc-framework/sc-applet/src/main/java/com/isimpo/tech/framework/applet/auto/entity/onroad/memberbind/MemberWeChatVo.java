package com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind;

import com.isimpo.tech.framework.common.entity.BaseVo;


/**
 * 会员微信关系
 * @author Tank
 * @version V1.0
 * @since 2019/2/20
 *
 */
public class MemberWeChatVo extends BaseVo {
    // 关系表 id
    private String id;

    // 会员 id
    private String memId;

    // 微信用户表 id
    private String wecharId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }

    public String getWecharId() {
        return wecharId;
    }

    public void setWecharId(String wecharId) {
        this.wecharId = wecharId;
    }
}
