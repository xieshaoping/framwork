package com.isimpo.tech.framework.applet.auto.mapper.homePage;

import com.isimpo.tech.framework.applet.auto.entity.homePage.TravelerTalk;
import tk.mybatis.mapper.common.Mapper;

public interface TravelerTalkMapper extends Mapper<TravelerTalk> {
}
