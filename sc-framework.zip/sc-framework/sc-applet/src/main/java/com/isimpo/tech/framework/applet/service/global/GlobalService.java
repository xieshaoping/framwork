package com.isimpo.tech.framework.applet.service.global;

import com.isimpo.tech.framework.applet.auto.entity.sysBase.SysConfigure;
import com.isimpo.tech.framework.applet.auto.mapper.global.GlobalMapper;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import org.springframework.stereotype.Service;

/**
 * @author zhuyilong
 * @since 2019/3/1
 */
@Service
public class GlobalService extends BaseService<GlobalMapper, SysConfigure> {
    /**
     * 查询系统
     * @return
     */
    public AjaxResponse getSysConfig() {
        return AjaxResponse.of(mapper.getSysConfig());
    }
}
