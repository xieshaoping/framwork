/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.homePage;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Reserve;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Route;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.ReserveMapper;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.RouteMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author zx
 * @version 1.0
 * @since 2018/4/24
 */
@Service
public class RouteService extends BaseService<RouteMapper, Route> {

    @Override
    public TableResultResponse<Route> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<Route> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

}
