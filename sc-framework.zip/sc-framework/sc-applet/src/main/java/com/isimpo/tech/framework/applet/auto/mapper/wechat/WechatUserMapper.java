/*
 * @(#) WechatUserMapper.java 2019年02月14日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.auto.mapper.wechat;

import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.auto.entity.wechat.WechatUserVo;
import org.springframework.stereotype.Component;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月14日
 */
@Component
public interface WechatUserMapper {

    /**
     * 保存用户微信信息
     */
    Integer wechatUserSave(WechatUserVo userVo);

    /**
     * 更新用户微信信息
     */
    Integer wechatUserUpd(WechatUserVo userVo);

    /**
     * 查询用户信息
     */
    UserInfoVo userInfo(String openId);
}
