package com.isimpo.tech.framework.applet.controller.my;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.applet.auto.entity.my.CardVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.service.my.CardService;
import com.isimpo.tech.framework.applet.service.my.UserService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;

/**
 * 修改个人信息
 * @author Tank
 * @version V1.0
 * @since 2019/2/26
 *
 */
@RestController
@RequestMapping("/user")
public class UserController extends BaseController<UserService, UserInfoVo> {

    /**编辑个人信息
     * @param
     * @return
     */
    @PostMapping("/edit")
    public AjaxResponse updateUser(@RequestBody UserInfoVo user) {
        return baseService.updateUserInfo(user);
    }

    /**
     * 从数据库获取个人信息
     * @param  openId 用户的openId
     * @return userInfoVo
     */
    @GetMapping("/current")
    public AjaxResponse getCurrentUserByOpenId(String openId) {
        return baseService.getCurrentUserByOpenId(openId);
    }


}
