package com.isimpo.tech.framework.applet.auto.mapper.homePage;

import com.isimpo.tech.framework.applet.auto.entity.homePage.*;
import com.isimpo.tech.framework.applet.auto.entity.resound.strategy.StrategyVo;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;
import com.isimpo.tech.framework.common.util.Query;

public interface IndexPicMapper extends Mapper<IndexPic> {

    /**
     * H5端，获取H5首页的轮播图
     */
    List<IndexPic> getH5Banner();

    /**
     * H5端，获取H5首页的推荐管家
     */
    List<Housekeeper> getH5Housekeeper();

    List<Housekeeper> getAllHousekeeper();

    List<Housekeeper> findHkList(Query query);

    Housekeeper getOneHousekeeper(@Param("id") String id);

    List<Route> getH5Route();

    List<Article> getH5Article();

    List<TravelerTalk> getH5TravelerTalk();

    List<StrategyVo>  indexStrategy();

    String getPhone();

    List<Route> getMyRouteList();
}
