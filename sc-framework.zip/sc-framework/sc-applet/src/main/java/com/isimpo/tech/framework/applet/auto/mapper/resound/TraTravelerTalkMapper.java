package com.isimpo.tech.framework.applet.auto.mapper.resound;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.TimeMemoryVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.TravelRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.TraTravelerTalk;

import tk.mybatis.mapper.common.Mapper;

/**
 * 旅咖说
 * @author Tank
 * @version V1.0
 * @since 2019/2/18
 *
 */
public interface TraTravelerTalkMapper extends Mapper<TraTravelerTalk> {
    /**
     * 查询旅咖说列表
     * @param params
     * @return
     */
    List<TraTravelerTalk> getTraTalkList(Map<String, Object> params);

    /**
     * 根据id查询旅咖说详情
     * @param id
     */
    TraTravelerTalk getTraTalkDetail(String id);

    /**
     * 逻辑删除旅咖说
     * @param talk
     * @return
     */
    int delTraTalk(TraTravelerTalk talk);

    /**
     * 查询旅咖说点赞记录列表
     * @param list
     * @return
     */
    List<PraiseRecordVo> listPraiseRecord(List<TraTravelerTalk> list);

    /**
     * 根据旅咖说id查询旅咖说点赞记录列表
     * @param mainId
     * @return
     */
    List<PraiseRecordVo> listPraiseRecordById(String mainId);


    /**
     * 查询旅咖说评论列表
     * @param list
     * @return
     */
    List<CommentVo> listComment(List<TraTravelerTalk> list);

    /**
     * 根据旅咖说id查询旅咖说评论列表
     * @param mainId
     * @return
     */
    List<CommentVo> listCommentById(String mainId);

    /**
     * 添加点赞记录
     * @param praiseRecord
     * @return
     */
    int addPraiseRecord(PraiseRecordVo praiseRecord);

    /**
     * 查询当前用户是否已点赞
     * @param mainId-旅咖说的id
     * @param memId -当前用户di
     * @return
     */
    int checkPraise(@Param("mainId") String mainId,@Param("memId") String memId);

    /**
     * 删除点赞记录
     * @param praiseRecord
     * @return
     */
    int delPraiseRecord(PraiseRecordVo praiseRecord);

    /**
     * 添加旅咖说
     * @param talk
     * @return
     */
    int addTraTalk(TraTravelerTalk talk);

    /**
     * 添加评论
     * @param comment
     * @return
     */
    int addComment(CommentVo comment);

    /**
     * 删除评论
     * @param comment
     * @return
     */
    int delComment(CommentVo comment);
}
