package com.isimpo.tech.framework.applet.auto.entity.onroad.news;

import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/14
 *
 */

public class ConfirmVo extends BaseVo {

    private String id;

    private String newsId;

    private String memId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }



}
