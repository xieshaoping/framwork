package com.isimpo.tech.framework.applet.controller.onroad;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.applet.auto.entity.onroad.wish.WishVo;
import com.isimpo.tech.framework.applet.service.onroad.WishService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 
 * @author Tank
 * @version V1.0
 * @since 2019/2/13
 *
 */
@RestController
@RequestMapping("/wish")
public class WishController extends BaseController<WishService, WishVo> {

    /**
     * 查询会员祝福列表
     * @param params
     * @return
     */
    @GetMapping("/list")
    public AjaxResponse getNewsList(@RequestParam Map<String, Object> params) {
        Query query = new Query(params);
        return baseService.getWishes(query);
    }

    @GetMapping("/listAll")
    public AjaxResponse getNewsListAll(String traId) {
        Map<String,Object> id = new HashMap<>(2);
        id.put("traId",traId);
        return AjaxResponse.of(baseService.getWishesAll(new Query(id)));
    }

    /**
     * 删除会员祝福
     * @param wish
     * @return
     */
    @GetMapping("/del")
    public AjaxResponse delWish(WishVo wish) {
        return baseService.delWish(wish);
    }

   
    /**
     * 添加会员祝福
     * @param wish
     * @return
     */
    @PostMapping("/add")
    public AjaxResponse addWish(@RequestBody WishVo wish) {
        return baseService.addWish(wish);
    }

    
}
