package com.isimpo.tech.framework.applet.auto.entity.onroad.news;

import java.util.Date;
import java.util.List;

import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.applet.auto.entity.onroad.memberbind.MemberVo;
import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 * 
 * @author Tank
 * @version V1.0
 * @since 2019/2/13
 *
 */

public class NewsVo extends BaseVo {

    // 可乐消息id
    private String id;

    // 行程id
    private String traId;

    // 行程事项id
    private String itemId;

    // 管家id
    private String housekeeperId;

    // 发布人名
    private String name;

    // 行程名
    private String traName;

    // 消息内容
    private String content;

    // 文件类型 1.图片 2.视频
    private String type;

    // 文件地址
    private String filePath;

    // 管家或领队昵称
    private String nickName;

    // 管家或领队头像
    private String photo;

    // 管家或领队头衔
    private String title;

    // 消息的会员id与名字
    @Transient
    private List<MemberVo> confirmList;

    private String mediaId;

    // 会员是否确认该消息标识 0-未确认，1-已确认
    private String confirmFlag = "0";


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTraName() {
        return traName;
    }

    public void setTraName(String traName) {
        this.traName = traName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getHousekeeperId() {
        return housekeeperId;
    }

    public void setHousekeeperId(String housekeeperId) {
        this.housekeeperId = housekeeperId;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getAddTime() {
        return super.getAddTime();
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getUpdTime() {
        return super.getUpdTime();
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<MemberVo> getConfirmList() {
        return confirmList;
    }

    public void setConfirmList(List<MemberVo> confirmList) {
        this.confirmList = confirmList;
    }

    public String getConfirmFlag() {
        return confirmFlag;
    }

    public void setConfirmFlag(String confirmFlag) {
        this.confirmFlag = confirmFlag;
    }

    public String getMediaId() {
        return mediaId;
    }

    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }
}
