package com.isimpo.tech.framework.applet.controller.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.*;
import com.isimpo.tech.framework.applet.service.onroad.everyTrip.EveryTripService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * 每日行程
 * @author wangxinhai
 * @version V1.0
 * @since 2019/2/23
 */
@RestController
@RequestMapping("/onroad/everyTrip")
public class EveryTripController extends BaseController<EveryTripService, TraItem> {

    //@RequestParam
    /**
     * 校验当前用户有没有绑定会员
     * @param request
     * @return
     */
    @RequestMapping("checkMemberBind")
    @ResponseBody
    public AjaxResponse checkMemberBind(HttpServletRequest request){
        return baseService.checkMemberBind(request);
    }

    /**
     * 根据当前会员id查询行程列表
     * @param memId
     * @return
     */
    @RequestMapping("getTraItemById")
    @ResponseBody
    public AjaxResponse getTraItemById(String memId, String type){
        return AjaxResponse.of(baseService.getTraItemById(memId,type));
    }

    /**
     * 根据行程id查询会员列表
     * @param traId
     * @return
     */
    @RequestMapping("getMemberListByTraId")
    @ResponseBody
    public AjaxResponse getMemberListByTraId(String traId){
        return AjaxResponse.of(baseService.getMemberListByTraId(traId));
    }

    /**
     * 根据行程id获取日历
     * @param traId
     * @return
     */
    @RequestMapping("/getCalendarByTraId")
    @ResponseBody
    public AjaxResponse getCalendarByTraId(String traId){
        return AjaxResponse.of(baseService.getCalendarByTraId(traId));
    }

    /**
     * 根据行程 日历获取行程列表
     * @param traPlace
     * @return
     */
    @RequestMapping("/getTraPlaceItemList")
    @ResponseBody
    public AjaxResponse getTraPlaceItemList(@RequestBody TraPlace traPlace){
        return AjaxResponse.of(baseService.getTraPlaceItemList(traPlace));
    }

    /**
     * 根据行程id获取紧急联系电话
     * @param traId
     * @return
     */
    @RequestMapping("/getPhoneByTraId")
    @ResponseBody
    public AjaxResponse getPhoneByTraId(String traId){
        return AjaxResponse.of(baseService.getPhoneByTraId(traId));
    }

    /**
     * 保存祝福内容
     * @param traWish
     * @return
     */
    @RequestMapping("saveTraWish")
    @ResponseBody
    public AjaxResponse saveTraWish(@RequestBody TraWish traWish){
        return baseService.saveTraWish(traWish);
    }

    /**
     * 保存投诉内容
     * @param traComplain
     * @return
     */
    @RequestMapping("/saveTraComplaint")
    @ResponseBody
    public AjaxResponse saveTraComplaint(@RequestBody TraComplain traComplain){
        return baseService.saveTraComplaint(traComplain);
    }

    /**
     * 根据id获取行程
     * @param traId
     * @return
     */
    @RequestMapping("/getTraById")
    @ResponseBody
    public AjaxResponse getTraById(String traId){
        return AjaxResponse.of(baseService.getTraById(traId));
    }

    /**
     * 根据id获取日历
     * @param id
     */
    @RequestMapping("/getCalendarById")
    @ResponseBody
    public AjaxResponse getCalendarById(String id){
        return AjaxResponse.of(baseService.getCalendarById(id));
    }

    /**
     * 获取系统配置
     * @return
     */
    @RequestMapping("/getSysBase")
    @ResponseBody
    public AjaxResponse getSysBase(){
        return AjaxResponse.of(baseService.getSysBase());
    }

    @GetMapping("/checkMemberTram")
    @ResponseBody
    public AjaxResponse checkMemberTram(String memId, String traId){
        return baseService.checkMemberTram(memId, traId);
    }

    /**
     * 根据行程id获取管家信息
     * @param traId
     * @return
     */
    @GetMapping("/getHouseKeppInfo")
    @ResponseBody
    public AjaxResponse getHouseKeppInfo(String traId){
        return AjaxResponse.of(baseService.getHouseKeppInfo(traId));
    }

    /**
     * 根据行程id获取领队信息
     * @param traId
     * @return
     */
    @GetMapping("/getGuideInfo")
    @ResponseBody
    public AjaxResponse getGuideInfo(String traId){
        return AjaxResponse.of(baseService.getGuideInfo(traId));
    }

    /**
     * 行程日历添加
     * @author wangxinhai
     * @param traCalendar
     * @return
     */
    @PostMapping("/addCalendar")
    @ResponseBody
    public AjaxResponse addTraCalendar(@RequestBody TraCalendar traCalendar){
        return baseService.addTraCalendar(traCalendar);
    }

    /**
     * 行程地点添加
     * @author wangxinhai
     * @param traPlace
     * @return
     */
    @PostMapping("/addTraPlace")
    @ResponseBody
    public AjaxResponse addTraPlace(@RequestBody TraPlace traPlace){
        return baseService.addTraPlace(traPlace);
    }

    /**
     * 获取itemType类型字典
     * @return
     */
    @GetMapping("getItemType")
    @ResponseBody
    public AjaxResponse getItemType() {
        return AjaxResponse.of(baseService.getItemType());
    }
}
