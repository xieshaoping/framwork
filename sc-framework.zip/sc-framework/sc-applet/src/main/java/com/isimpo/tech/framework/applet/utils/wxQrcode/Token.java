/*
 * @(#) Token.java 2017年5月16日
 *
 * Copyright (c) 2017, Simpo Technology. All Rights Reserved.
 * Simpo Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.utils.wxQrcode;

import java.io.Serializable;

/**
 * 凭证
 *
 * @author hunj
 * @version 1.0
 * @since 2014/12/22
 */
public class Token implements Serializable {

	/**
	 * <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 3487358726157575412L;
	
	// 接口访问凭证
	private String access_token;
	// 凭证有效期，单位：秒
	private int expires_in;

	private String ticket;
	private String errcode;// 错误编号
	private String errmsg;// 错误内容

	public String getErrcode() {
		return errcode;
	}

	public void setErrcode(String errcode) {
		this.errcode = errcode;
	}

	public String getErrmsg() {
		return errmsg;
	}

	public void setErrmsg(String errmsg) {
		this.errmsg = errmsg;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public int getExpires_in() {
		return expires_in;
	}

	public void setExpires_in(int expires_in) {
		this.expires_in = expires_in;
	}

	public String getTicket() {
		return ticket;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}