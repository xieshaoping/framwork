package com.isimpo.tech.framework.applet.service.reverberation;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Article;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Housekeeper;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.resound.strategy.StrategyVo;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.ArticleMapper;
import com.isimpo.tech.framework.applet.auto.mapper.resound.StrategyMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/21
 *
 */
@Service
public class ArticleService extends BaseService<ArticleMapper, Article> {

//    /**
//     * 获取攻略列表
//     * @return
//     */
//    public AjaxResponse getArticleList() {
//        List<Article> list = mapper.getArticleList();
//        return AjaxResponse.of(ResponseCode.SUCCESS,list);
//    }

    public TableResultResponse<Article> getArticleList(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<Article> list = mapper.getArticleList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 获取
     * @return
     */
    public AjaxResponse getOne(String id) {
        Article article = mapper.getOne(id);
        return AjaxResponse.of(ResponseCode.SUCCESS,article);
    }
}
