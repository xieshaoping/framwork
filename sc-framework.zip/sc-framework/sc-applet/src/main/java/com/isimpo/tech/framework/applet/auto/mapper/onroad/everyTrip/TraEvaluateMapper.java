package com.isimpo.tech.framework.applet.auto.mapper.onroad.everyTrip;

import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraEvaluate;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraStaffEvaluate;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface TraEvaluateMapper extends Mapper<TraEvaluate> {

    int insertTraEval(TraEvaluate traEvaluate);

    int insertTraStaffEval(List<TraStaffEvaluate> list);

    TraEvaluate getTraEvalu(TraEvaluate traEvaluate);

    List<TraStaffEvaluate> findTraStaff(TraEvaluate traEvaluate);

}