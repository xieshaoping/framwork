//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.isimpo.tech.framework.applet.utils.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.isimpo.tech.wechat.WechatUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StringUtilEXT {
    private static Logger logger = LoggerFactory.getLogger(StringUtilEXT.class);

    public StringUtilEXT() {
    }

    public static boolean IsNullOrEmpty(String p_str) {
        return p_str == null?true:p_str.isEmpty();
    }

    public static String convertStreamToString(InputStream is) {
        InputStreamReader isr = null;
        BufferedReader reader = null;
        StringBuilder sb = new StringBuilder();
        String line = null;

        try {
            isr = new InputStreamReader(is, Charset.forName("UTF-8"));
            reader = new BufferedReader(isr);

            while((line = reader.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException var69) {
            logger.error(var69.getMessage(), var69);
        } finally {
            if(reader != null) {
                try {
                    reader.close();
                } catch (IOException var68) {
                    logger.error(var68.getMessage(), var68);
                }
            }

            if(isr != null) {
                try {
                    isr.close();
                } catch (IOException var67) {
                    logger.error(var67.getMessage(), var67);
                }
            }

            try {
                if(is != null) {
                    is.close();
                }
            } catch (IOException var65) {
                logger.error(var65.getMessage(), var65);
            } finally {
                is = null;
            }

        }

        return sb.toString();
    }

    public static String generateKeyValuePair(Object obj) throws Exception {
        StringBuffer stringA = new StringBuffer();
        Class objClass = obj.getClass();
        Field[] fieldArray = objClass.getDeclaredFields();
        ArrayList fieldNameList = new ArrayList();
        Field[] fieldName = fieldArray;
        int fieldType = fieldArray.length;

        Field fieldVal;
        for(int fieldValStr = 0; fieldValStr < fieldType; ++fieldValStr) {
            fieldVal = fieldName[fieldValStr];
            fieldNameList.add(fieldVal.getName());
        }

        Collections.sort(fieldNameList);
        fieldVal = null;
        String var11 = null;
        Class var12 = null;
        Iterator var9 = fieldNameList.iterator();

        while(var9.hasNext()) {
            String var13 = (String)var9.next();
            if(!"sign".equals(var13)) {
                Object var10 = objClass.getDeclaredMethod("get" + var13.substring(0, 1).toUpperCase() + var13.substring(1), new Class[0]).invoke(obj, new Object[0]);
                if(var10 != null) {
                    var12 = objClass.getDeclaredField(var13).getType();
                    if(var12 == Long.class) {
                        var11 = String.valueOf(var10);
                    } else {
                        var11 = (String)var10;
                    }

                    if("package0".equals(var13)) {
                        var13 = "package";
                    }

                    stringA.append(var13 + "=" + var11 + "&");
                }
            }
        }

        if(!IsNullOrEmpty(stringA.toString())) {
            stringA.deleteCharAt(stringA.length() - 1);
        }

        return stringA.toString();
    }

    public static String generateXml(Object obj) throws Exception {
        StringBuffer stringA = new StringBuffer();
        stringA.append("<xml>");
        Class objClass = obj.getClass();
        Field[] fieldArray = objClass.getDeclaredFields();
        String fieldName = null;
        String fieldVal = null;
        Field[] var9 = fieldArray;
        int var8 = fieldArray.length;

        for(int var7 = 0; var7 < var8; ++var7) {
            Field field = var9[var7];
            fieldName = field.getName();
            fieldVal = (String)objClass.getDeclaredMethod("get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1), new Class[0]).invoke(obj, new Object[0]);
            if(!IsNullOrEmpty(fieldVal)) {
                stringA.append("<" + fieldName + ">" + fieldVal + "</" + fieldName + ">");
            }
        }

        stringA.append("</xml>");
        return stringA.toString();
    }

    public static Object generateObj(String objXml, Class<?> objClass) throws Exception {
        Object obj = objClass.newInstance();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(objXml.getBytes("UTF-8"));
        SAXReader reader = new SAXReader();
        Document document = reader.read(inputStream);
        Element rootElement = document.getRootElement();
        Field[] fieldArray = objClass.getDeclaredFields();
        if(fieldArray != null && fieldArray.length > 0) {
            String fieldName = null;
            Class fieldType = null;
            Object fieldVal = null;
            Element fieldElement = null;
            Field[] var15 = fieldArray;
            int var14 = fieldArray.length;

            for(int var13 = 0; var13 < var14; ++var13) {
                Field field = var15[var13];
                fieldName = field.getName();
                fieldType = field.getType();
                fieldElement = rootElement.element(fieldName);
                if(fieldElement != null) {
                    fieldVal = fieldElement.getTextTrim();
                    if(fieldType == Long.class) {
                        fieldVal = new Long((String)fieldVal);
                    }

                    objClass.getMethod("set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1), new Class[]{fieldType}).invoke(obj, new Object[]{fieldVal});
                }
            }
        }

        return obj;
    }

    public static Date convertTimesStampToDate(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        return c.getTime();
    }

    public static <T> boolean listNotValue(List<T> list) {
        return list != null && list.size() > 0;
    }

    public static boolean contains(String[] stringArray, String source) {
        List tempList = Arrays.asList(stringArray);
        return tempList.contains(source);
    }

    public static Map<String, String> parseXml(String msg) throws Exception {
        ByteArrayInputStream inputStream = null;

        try {
            HashMap map = new HashMap();
            inputStream = new ByteArrayInputStream(msg.getBytes("UTF-8"));
            SAXReader reader = new SAXReader();
            Document document = reader.read(inputStream);
            Element root = document.getRootElement();
            List elementList = root.elements();
            Iterator var8 = elementList.iterator();

            while(var8.hasNext()) {
                Element e = (Element)var8.next();
                map.put(e.getName(), e.getText());
            }

            HashMap var10 = map;
            return var10;
        } finally {
            if(inputStream != null) {
                inputStream.close();
                inputStream = null;
            }

        }
    }

    public static String getJiaMi(String address) {
        StringBuffer sb = new StringBuffer("");

        for(int i = 0; i < address.length() - 1; ++i) {
            sb.append("*");
        }

        return sb.toString() + address.substring(address.length() - 1);
    }

    public static String getEncrypt(String addressByCusNo) {
        String str = "";
        if(addressByCusNo.length() > 7) {
            str = addressByCusNo.substring(addressByCusNo.length() - 7, addressByCusNo.length());
            return "****" + str;
        } else {
            return "****" + addressByCusNo;
        }
    }

    public static String pjId(String ids) {
        String infoIds = "(";
        String[] strArr = ids.split(",");
        String[] var6 = strArr;
        int var5 = strArr.length;

        for(int var4 = 0; var4 < var5; ++var4) {
            String str = var6[var4];
            infoIds = infoIds + "\'" + str + "\',";
        }

        return infoIds.substring(0, infoIds.length() - 1) + ")";
    }

    public static String md532(String plainText) {
        String re_md5 = new String();

        try {
            MessageDigest e = MessageDigest.getInstance("MD5");
            e.update(plainText.getBytes());
            byte[] b = e.digest();
            StringBuffer buf = new StringBuffer("");

            for(int offset = 0; offset < b.length; ++offset) {
                int i = b[offset];
                if(i < 0) {
                    i += 256;
                }

                if(i < 16) {
                    buf.append("0");
                }

                buf.append(Integer.toHexString(i));
            }

            re_md5 = buf.toString();
        } catch (NoSuchAlgorithmException var7) {
            var7.printStackTrace();
        }

        return re_md5;
    }

    public static String generateRandomStringByNumber(int size) {
        char[] charArray = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
        StringBuilder sb = new StringBuilder("");
        Random random = new Random();

        for(int i = 0; i < size; ++i) {
            sb.append(charArray[random.nextInt(10)]);
        }

        return sb.toString();
    }

    public static double distance(double lat1, double long1, double lat2, double long2) {
        double R = 6378137.0D;
        lat1 = lat1 * 3.141592653589793D / 180.0D;
        lat2 = lat2 * 3.141592653589793D / 180.0D;
        double a = lat1 - lat2;
        double b = (long1 - long2) * 3.141592653589793D / 180.0D;
        double sa2 = Math.sin(a / 2.0D);
        double sb2 = Math.sin(b / 2.0D);
        double d = 2.0D * R * Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1) * Math.cos(lat2) * sb2 * sb2));
        return d;
    }

    public static String toString(Object object) {
        return object == null?"":object.toString();
    }

    public static Integer toInteger(Object obj) {
        if(obj == null) {
            return Integer.valueOf(0);
        } else {
            String str = toString(obj);
            Double double1 = Double.valueOf(Double.parseDouble(str));
            return Integer.valueOf(IsNullOrEmpty(str)?0:double1.intValue());
        }
    }

    public static String byteToHex(byte[] hash) {
        Formatter formatter = new Formatter();
        byte[] var5 = hash;
        int var4 = hash.length;

        for(int var3 = 0; var3 < var4; ++var3) {
            byte result = var5[var3];
            formatter.format("%02x", new Object[]{Byte.valueOf(result)});
        }

        String var6 = formatter.toString();
        formatter.close();
        return var6;
    }

    public static String md5(String inStr) {
        StringBuffer sb = new StringBuffer();

        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(inStr.getBytes("UTF-8"));
            byte[] r = md.digest();

            for(int i = 0; i < r.length; ++i) {
                byte b = r[i];
                sb.append(Character.forDigit(b >> 4 & 15, 16));
                sb.append(Character.forDigit(b & 15, 16));
            }
        } catch (Exception var6) {
            ;
        }

        return sb.toString();
    }

    public static String getUUID() {
        return WechatUtils.getUUID().replaceAll("-", "");
    }
}
