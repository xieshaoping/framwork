package com.isimpo.tech.framework.applet.auto.entity.homePage;

import java.util.Date;
import javax.persistence.*;

@Table(name = "csr_reserve")
public class Reserve {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 称呼
     */
    private String title;

    /**
     * 电话
     */
    private String phone;

    /**
     * 目的地
     */
    private String place;

    /**
     * 处理状态（0：未处理，1：已处理）
     */
    private String state;

    /**
     * 管家id
     */
    @Column(name = "housekeeper_id")
    private String housekeeperId;

    /**
     * 处理说明
     */
    private String note;

    /**
     * 处理时间
     */
    @Column(name = "handle_time")
    private Date handleTime;

    /**
     * 同步客户（0：未同步，1：已同步）
     */
    @Column(name = "ysnc_state")
    private String ysncState;

    /**
     * 会员Id
     */
    @Column(name = "mem_id")
    private String memId;

    /**
     * 管家名称
     */
    @Column(name = "hk_name")
    private String hkName;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取称呼
     *
     * @return title - 称呼
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置称呼
     *
     * @param title 称呼
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取电话
     *
     * @return phone - 电话
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 设置电话
     *
     * @param phone 电话
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    /**
     * 获取处理状态（0：未处理，1：已处理）
     *
     * @return state - 处理状态（0：未处理，1：已处理）
     */
    public String getState() {
        return state;
    }

    /**
     * 设置处理状态（0：未处理，1：已处理）
     *
     * @param state 处理状态（0：未处理，1：已处理）
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * 获取管家id
     *
     * @return housekeeper_id - 管家id
     */
    public String getHousekeeperId() {
        return housekeeperId;
    }

    /**
     * 设置管家id
     *
     * @param housekeeperId 管家id
     */
    public void setHousekeeperId(String housekeeperId) {
        this.housekeeperId = housekeeperId;
    }

    /**
     * 获取处理说明
     *
     * @return note - 处理说明
     */
    public String getNote() {
        return note;
    }

    /**
     * 设置处理说明
     *
     * @param note 处理说明
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * 获取处理时间
     *
     * @return handle_time - 处理时间
     */
    public Date getHandleTime() {
        return handleTime;
    }

    /**
     * 设置处理时间
     *
     * @param handleTime 处理时间
     */
    public void setHandleTime(Date handleTime) {
        this.handleTime = handleTime;
    }

    /**
     * 获取同步客户（0：未同步，1：已同步）
     *
     * @return ysnc_state - 同步客户（0：未同步，1：已同步）
     */
    public String getYsncState() {
        return ysncState;
    }

    /**
     * 设置同步客户（0：未同步，1：已同步）
     *
     * @param ysncState 同步客户（0：未同步，1：已同步）
     */
    public void setYsncState(String ysncState) {
        this.ysncState = ysncState;
    }

    /**
     * 获取会员Id
     *
     * @return mem_id - 会员Id
     */
    public String getMemId() {
        return memId;
    }

    /**
     * 设置会员Id
     *
     * @param memId 会员Id
     */
    public void setMemId(String memId) {
        this.memId = memId;
    }

    /**
     * 获取删除标识(1:已删除,0:正常)
     *
     * @return del_flag - 删除标识(1:已删除,0:正常)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:已删除,0:正常)
     *
     * @param delFlag 删除标识(1:已删除,0:正常)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建备注
     *
     * @return add_mark - 创建备注
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建备注
     *
     * @param addMark 创建备注
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新备注
     *
     * @return upd_mark - 更新备注
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新备注
     *
     * @param updMark 更新备注
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    public String getHkName() {
        return hkName;
    }

    public void setHkName(String hkName) {
        this.hkName = hkName;
    }
}