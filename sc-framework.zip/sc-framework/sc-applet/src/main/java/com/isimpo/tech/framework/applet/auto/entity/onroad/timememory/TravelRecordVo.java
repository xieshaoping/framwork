package com.isimpo.tech.framework.applet.auto.entity.onroad.timememory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Table(name = "tra_travels")
public class TravelRecordVo extends BaseVo {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 会员id
     */
    @Column(name = "mem_id")
    private String memId;

    // 当前用户点赞标识 1.已点赞 2.未点赞
    private String praiseFlag;

    // 当前用户是否可以删除 0.禁止 1.允许
    private String delable;

    /**
     * 查看权限（1：团队内，2：公开）
     */
    @Column(name = "browse_range")
    private String browseRange;

    /**
     * 行程名称
     */
    private String traName;

    /**
     * 内容
     */
    private String content;

    /**
     * 类型（1：图片，2：视频）
     */
    private String type;

    /**
     * 行程id
     */
    @Column(name = "range_id")
    private String rangeId;

    @Column(name = "media_id")
    private String mediaId;

    /**
     * 行程事项id
     */
    @Column(name = "item_id")
    private String itemId;

    // 行程事项名
    private String itemName;

    // 行程事项起始时间
    private Date startTime;

    // 行程事项结束时间
    private Date endTime;

    /**
     * 地点名称
     */
    private String location;

    /**
     * 地点经度
     */
    private String longitude;

    /**
     * 地点维度
     */
    private String latitude;

    /**
     * 点赞数量
     */
    @Column(name = "laud_amount")
    private Integer laudAmount;

    /**
     * 评论数量
     */
    @Column(name = "talk_amount")
    private Integer talkAmount;

    /**
     * 文件地址(视频、图片公用，多个图片地址用英文逗号隔开)
     */
    @Column(name = "file_path")
    private String filePath;

    @Transient
    private String traId;

    @Transient
    private List<String> mediaIds;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取会员id
     *
     * @return mem_id - 会员id
     */
    public String getMemId() {
        return memId;
    }

    /**
     * 设置会员id
     *
     * @param memId 会员id
     */
    public void setMemId(String memId) {
        this.memId = memId;
    }

    /**
     * 获取查看权限（1：团队内，2：公开）
     *
     * @return browse_range - 查看权限（1：团队内，2：公开）
     */
    public String getBrowseRange() {
        return browseRange;
    }

    /**
     * 设置查看权限（1：团队内，2：公开）
     *
     * @param browseRange 查看权限（1：团队内，2：公开）
     */
    public void setBrowseRange(String browseRange) {
        this.browseRange = browseRange;
    }

    public String getTraName() {
        return traName;
    }

    public void setTraName(String traName) {
        this.traName = traName;
    }

    /**
     * 获取内容
     *
     * @return content - 内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置内容
     *
     * @param content 内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取类型（1：图片，2：视频）
     *
     * @return type - 类型（1：图片，2：视频）
     */
    public String getType() {
        return type;
    }

    /**
     * 设置类型（1：图片，2：视频）
     *
     * @param type 类型（1：图片，2：视频）
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 获取行程id
     *
     * @return range_id - 行程id
     */
    public String getRangeId() {
        return rangeId;
    }

    /**
     * 设置行程id
     *
     * @param rangeId 行程id
     */
    public void setRangeId(String rangeId) {
        this.rangeId = rangeId;
    }

    /**
     * 获取行程事项id
     *
     * @return item_id - 行程事项id
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * 设置行程事项id
     *
     * @param itemId 行程事项id
     */
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    /**
     * 获取地点名称
     *
     * @return location - 地点名称
     */
    public String getLocation() {
        return location;
    }

    /**
     * 设置地点名称
     *
     * @param location 地点名称
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * 获取地点经度
     *
     * @return longitude - 地点经度
     */
    public String getLongitude() {
        return longitude;
    }

    /**
     * 设置地点经度
     *
     * @param longitude 地点经度
     */
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    /**
     * 获取地点维度
     *
     * @return latitude - 地点维度
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * 设置地点维度
     *
     * @param latitude 地点维度
     */
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    /**
     * 获取点赞数量
     *
     * @return laud_amount - 点赞数量
     */
    public Integer getLaudAmount() {
        return laudAmount;
    }

    /**
     * 设置点赞数量
     *
     * @param laudAmount 点赞数量
     */
    public void setLaudAmount(Integer laudAmount) {
        this.laudAmount = laudAmount;
    }

    /**
     * 获取评论数量
     *
     * @return talk_amount - 评论数量
     */
    public Integer getTalkAmount() {
        return talkAmount;
    }

    /**
     * 设置评论数量
     *
     * @param talkAmount 评论数量
     */
    public void setTalkAmount(Integer talkAmount) {
        this.talkAmount = talkAmount;
    }

    /**
     * 获取文件地址(视频、图片公用，多个图片地址用英文逗号隔开)
     *
     * @return file_path - 文件地址(视频、图片公用，多个图片地址用英文逗号隔开)
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * 设置文件地址(视频、图片公用，多个图片地址用英文逗号隔开)
     *
     * @param filePath 文件地址(视频、图片公用，多个图片地址用英文逗号隔开)
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getPraiseFlag() {
        return praiseFlag;
    }

    public void setPraiseFlag(String praiseFlag) {
        this.praiseFlag = praiseFlag;
    }

    public String getDelable() {
        return delable;
    }

    public void setDelable(String delable) {
        this.delable = delable;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    public String getMediaId() {
        return mediaId;
    }

    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }

    public List<String> getMediaIds() {
        return mediaIds;
    }

    public void setMediaIds(List<String> mediaIds) {
        this.mediaIds = mediaIds;
    }
}