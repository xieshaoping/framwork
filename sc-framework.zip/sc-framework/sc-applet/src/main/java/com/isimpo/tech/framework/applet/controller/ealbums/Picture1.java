/*
 * @(#) Picture1.java 2019年02月18日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.controller.ealbums;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月18日
 */
public class Picture1 {
    private Graphics2D g        = null;

    /**
     * 导入本地图片到缓冲区
     */
    public BufferedImage loadImageLocal(String imgName) {
        try {
            return ImageIO.read(new File(imgName));
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public BufferedImage modifyImagetogeter(BufferedImage b, BufferedImage d) {

        try {
            int w = 1400;
            int h = 1400;

            g = d.createGraphics();
            g.drawImage(b, 0, -1400, w, h, null);
            g.dispose();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return d;
    }

    /**
     * 生成新图片到本地
     */
    public void writeImageLocal(String newImage, BufferedImage img) {
        if (newImage != null && img != null) {
            try {
                File outputfile = new File(newImage);
                ImageIO.write(img, "jpg", outputfile);
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public static void main(String[] args) {

        Picture1 tt = new Picture1();

        BufferedImage d = tt.loadImageLocal("D:/mnt/1.jpg");
        BufferedImage b = tt.loadImageLocal("D:/mnt/11.jpg");

        tt.writeImageLocal("D:/mnt/new10.jpg", tt.modifyImagetogeter(b, d));
        //将多张图片合在一起
        System.out.println("success");
    }
}
