/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.onroad.everyTrip;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.homePage.Member;
import com.isimpo.tech.framework.applet.auto.mapper.homePage.MemberMapper;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import java.util.*;

/**
 * @author LuoCheng
 * @version 1.0
 * @since 2019年01月26日
 */
@Service
public class MemberService extends BaseService<MemberMapper, Member> {

    @Override
    public TableResultResponse<Member> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<Member> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

}
