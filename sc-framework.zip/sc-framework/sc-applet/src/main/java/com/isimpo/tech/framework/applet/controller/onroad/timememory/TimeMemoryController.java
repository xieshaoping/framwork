package com.isimpo.tech.framework.applet.controller.onroad.timememory;

import com.alibaba.fastjson.JSONObject;
import com.isimpo.tech.framework.applet.auto.entity.onroad.everyTrip.TraBase;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.Base64File;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.CommentVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.PraiseRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.timememory.TravelRecordVo;
import com.isimpo.tech.framework.applet.auto.entity.userInfo.UserInfoVo;
import com.isimpo.tech.framework.applet.service.onroad.everyTrip.EveryTripService;
import com.isimpo.tech.framework.applet.service.onroad.timememory.TimeMemoryService;
import com.isimpo.tech.framework.applet.utils.utils.UserInfoUtils;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author zhuyilong
 * @since 2019/2/13
 */
@RestController
@RequestMapping("/timememory")
public class TimeMemoryController{

    private final TimeMemoryService timeMemoryService;

    private final EveryTripService everyTripService;

    @Autowired
    public TimeMemoryController(TimeMemoryService timeMemoryService, EveryTripService everyTripService) {
        this.timeMemoryService = timeMemoryService;
        this.everyTripService = everyTripService;
    }

    /**
     * 查询游记列表
     * @param params
     * @return
     */
    @GetMapping("/list")
    public AjaxResponse getTravelList(HttpServletRequest request, @RequestParam Map<String, Object> params) {
        // 获取当前登录用户的会员ID，会员id用于查询当前用户是否可删除，wechat id查询是否点赞
        fillUidAndWid(request, params);
        return timeMemoryService.getTimeMemoryList(new Query(params));
    }

    /**
     * 查询时光留影列表
     * @param request
     * @param params
     * @return
     */
    @GetMapping("/timememoryList")
    public AjaxResponse getTimeMemoryList(HttpServletRequest request, @RequestParam Map<String, Object> params) {
        // 获取当前登录用户的会员ID，会员id用于查询当前用户是否可删除，wechat id查询是否点赞
        fillUidAndWid(request, params);
        // 获取行程id
        String rangeId = (String) params.get("rangeId");
        // 如果rangeId不为空，则查询指定行程的游记，则查询全部用户已参与的游记
        if (rangeId == null || "".equals(rangeId)) {
            params.put("travels", getListTra(request));
        }
        return timeMemoryService.getTimeMemoryList(new Query(params));
    }
    /**
     * 查询我的游记列表
     * @param params
     * @return
     */
    @GetMapping("/myList")
    public AjaxResponse getMyTravelRecordList(HttpServletRequest request, @RequestParam Map<String, Object> params) {
        fillUidAndWid(request, params);
        params.put("myUid", getUserInfo(request).getMemId());
        return timeMemoryService.getTimeMemoryList(new Query(params));
    }

    /**
     * 查询时光留影详情
     * @param id
     * @return
     */
    @GetMapping("/detail")
    public AjaxResponse getTimeMemory(HttpServletRequest request, String id) {
        UserInfoVo userInfoVo = getUserInfo(request);
        String uid = userInfoVo.getMemId();
        String wid = userInfoVo.getWecharId();
        return timeMemoryService.getTimeMemory(id, uid, wid);
    }

    /**
     * 添加行程游记
     * @param travelRecord
     * @return
     */
    @PostMapping("/add")
    public AjaxResponse addTravelRecord(HttpServletRequest request,@RequestBody TravelRecordVo travelRecord) {
        travelRecord.setMemId(getUserInfo(request).getMemId());
        return timeMemoryService.addTravelRecord(travelRecord);
    }

    /**
     * 逻辑删除行程游记
     * @param request
     * @param travelRecord
     * @return
     */
    @GetMapping("/del")
    public AjaxResponse delTravelRecord(HttpServletRequest request, TravelRecordVo travelRecord) {
        travelRecord.setMemId(getUserInfo(request).getMemId());
        return timeMemoryService.delTimeMemory(travelRecord);
    }

    /**
     * 点赞
     * @param praiseRecord
     * @return
     */
    @GetMapping("/praise")
    public AjaxResponse praise(HttpServletRequest request, PraiseRecordVo praiseRecord) {
        // 点赞，点赞人使用wechat id
        praiseRecord.setMemId(getUserInfo(request).getWecharId());
        return timeMemoryService.praise(praiseRecord);
    }

    /**
     * 取消赞
     * @param praiseRecord
     * @return
     */
    @GetMapping("/unPraise")
    public AjaxResponse unPraise(HttpServletRequest request, PraiseRecordVo praiseRecord) {
        // 取消点赞，点赞人使用wechat id
        praiseRecord.setMemId(getUserInfo(request).getWecharId());
        return timeMemoryService.unPraise(praiseRecord);
    }

    /**
     * 获取点赞列表
     * @param praiseRecord
     * @return
     */
    @GetMapping("/praiseList")
    public AjaxResponse getPraiseList(PraiseRecordVo praiseRecord) {
        return timeMemoryService.getPraiseRecordList(praiseRecord);
    }

    /**
     * 获取行程事项信息
     * @param travelRecord
     * @return
     */
    @GetMapping("/item")
    public AjaxResponse getItemInfo(TravelRecordVo travelRecord) {
        return timeMemoryService.getItemInfo(travelRecord);
    }

    /**
     * 增加评论
     * @param comment
     * @return
     */
    @PostMapping("/addComment")
    public AjaxResponse addComment(HttpServletRequest request, @RequestBody CommentVo comment) {
        // 增加评论，评论人使用wechat id
        comment.setMemId(getUserInfo(request).getWecharId());
        return timeMemoryService.addComment(comment);
    }

    /**
     * 删除评论
     * @param commentVo
     * @return
     */
    @GetMapping("/delComment")
    public AjaxResponse delComment(HttpServletRequest request, CommentVo commentVo) {
        // 删除评论，评论人使用wechat id
        commentVo.setMemId(getUserInfo(request).getWecharId());
        return timeMemoryService.delComment(commentVo);
    }

    /**
     * 获取用户参与的行程列表
     * @return
     */
    @GetMapping("/listTra")
    public AjaxResponse listTra(HttpServletRequest request) {
        return AjaxResponse.of(getListTra(request));
    }

    /**
     * 获取用户参与的行程列表
     * @param request
     * @return
     */
    private List<TraBase> getListTra(HttpServletRequest request) {
        UserInfoVo userInfo = getUserInfo(request);
        return everyTripService.getTraItemById(userInfo.getMemId(),userInfo.getType());
    }

    /**
     * 填充当前登录用户会员id与wechat id
     * @param request
     * @param params
     */
    private void fillUidAndWid(HttpServletRequest request, Map<String, Object> params) {
        UserInfoVo userInfo = getUserInfo(request);
        params.put("uid", userInfo.getMemId());
        params.put("wid", userInfo.getWecharId());
    }

    /**
     * 获取当前登录用户信息
     * @param request
     * @return
     */
    private UserInfoVo getUserInfo(HttpServletRequest request) {
//        return "1";
        UserInfoVo userInfoVo = UserInfoUtils.getUserInfo(request);
        if (userInfoVo != null) {
            return userInfoVo;
        }
        return null;
    }

    /**
     * 微信上传图片
     * @param mediaId
     * @return
     */
    @RequestMapping("/getMediaUpload")
    @ResponseBody
    public AjaxResponse getMediaUpload(String mediaId) throws IOException {
        return AjaxResponse.of(timeMemoryService.getMediaUpload(mediaId));
    }

    @PostMapping("/uploadBase64")
    @ResponseBody
    public AjaxResponse uploadBase64(@RequestBody String base) throws Exception {
        JSONObject jsonObject = JSONObject.parseObject(base);
        return AjaxResponse.of(timeMemoryService.uploadBase64(jsonObject.getString("base64string"), jsonObject.getString("mediaId")));
    }

}
