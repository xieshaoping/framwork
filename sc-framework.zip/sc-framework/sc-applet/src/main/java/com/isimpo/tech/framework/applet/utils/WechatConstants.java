package com.isimpo.tech.framework.applet.utils;

/**
 * @author abator
 * @version 1.0
 * @since 2018年01月04日
 */
public class WechatConstants {

    public static final String ACCESS_TOKEN = "#ACCESS_TOKEN#";
    public static final String WX_ACCESS_TOKEN = "#WX_ACCESS_TOKEN#";

    public static final String TYPE = "#TYPE#";

    public static final String ALL_ACCESS_TOKEN = "all_access_token";

    public static final String ALL_ACCESS_TOKEN_CREATE_TIME = "all_access_token_createTime";
    public static final String WX_ALL_ACCESS_TOKEN_CREATE_TIME = "wx_all_access_token_createTime";

    public static final String JSAPI_TICKET = "jsapi_ticket";

    public static final String JSAPI_TICKET_CREATE_TIME = "jsapi_ticket_createTime";

    /**
     * access token 过期时间 小于2小时 单位：秒
     */
    public static final int ACCESS_TOKEN_EXPIRED_TIME = 6000;

    /**
     * js api ticket 过期时间 小于2小时 单位：秒
     */
    public static final int JS_API_TOKEN_EXPIRED_TIME = 6000;

    /**
     * js api ticket 过期时间 1小时 单位：秒
     */
    public static final int TOKEN_REFRESH_INTERVAL = 3600;

    public static final String RESULT_OK = "ok";

    protected static final String REDIS_SET_OK = "OK";

    private WechatConstants() {
    }
    /**
     * 临时二维码存放路径，windows系统下上传的文件的存放的路径
     */
    public static final String Windows_File_Path = "E:\\upload\\";

    /**
     * 临时二维码存放路径，linux系统下上传的文件的存放的路径
     */
    public static final String Linux_File_Path = "/mnt/midea";


    /**
     * 临时二维码失效时间
     */
    public static final String QR_STR_SCENE_TIMEOUT = "2592000";
}
