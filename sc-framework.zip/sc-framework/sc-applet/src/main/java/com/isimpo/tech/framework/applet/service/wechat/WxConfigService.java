/*
 * Copyright (c) 2018, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.wechat;

import com.isimpo.tech.framework.applet.auto.entity.wechat.WxConfig;
import com.isimpo.tech.framework.applet.auto.mapper.wechat.WxConfigMapper;
import com.isimpo.tech.framework.common.service.BaseService;
import org.springframework.stereotype.Service;

/**
 * 微信配置service
 *
 * @author wgq
 * @version 1.0
 * @since 2018年01月26日
 */
@Service
public class WxConfigService extends BaseService<WxConfigMapper, WxConfig> {

    /**
     * 获取微信账号配置信息
     *
     * @return 微信账号配置
     */
    public WxConfig getWxConfig() {
        WxConfig wxConfig = new WxConfig();
        wxConfig.setDelFlag("0");
        return mapper.selectOne(wxConfig);
    }

    public String getWxConfigAppId() {
        WxConfig wxConfig = getWxConfig();
        return wxConfig.getAppId();
    }

    public String getWxConfigSecret() {
        WxConfig wxConfig = getWxConfig();
        return wxConfig.getAppSecret();
    }
}
