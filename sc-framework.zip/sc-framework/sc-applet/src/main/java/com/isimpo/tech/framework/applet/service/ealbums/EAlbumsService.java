/*
 * @(#) EAlbumsService.java 2019年02月14日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.applet.service.ealbums;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.ealbums.*;
import com.isimpo.tech.framework.applet.auto.mapper.ealbums.EAlbumsMapper;
import com.isimpo.tech.framework.applet.controller.ealbums.PictureUtil;
import com.isimpo.tech.framework.applet.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.xiaoleilu.hutool.util.RandomUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月14日
 */
@Service
public class EAlbumsService extends BaseService<EAlbumsMapper,AlbumVo> {

    public static final String LONG = "/long/";

    @Value("${imagePath.path}")
    String path2;

    /**
     * 电子相册列表
     */
    public TableResultResponse<AlbumVo> albumList(Map<String, Object> params) {
        Query query = new Query(params);
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<AlbumVo> list = mapper.albumList(query);
        return new TableResultResponse<>(result.getTotal(),list);
    }

    /**
     * 电子相册删除
     */
    @Transactional(readOnly = false)
    public ResponseCode albumDel(AlbumVo albumVo){
        Integer result = mapper.albumDel(albumVo);
        if(result == 0){
            return ResponseCode.FAIL;
        }else{
            return ResponseCode.SUCCESS;
        }
    }

    /**
     * 行程列表
     */
    public List<TravelInfoVo> travelList(AlbumVo albumVo){
        return mapper.travelList(albumVo);
    }

    /**
     * 根据行程查询游记列表
     */
    public List<TravelsVo> travelsList(AlbumVo albumVo) {
        return mapper.travelsList(albumVo);
    }

    /**
     * 电子相册保存
     */
    @Transactional(readOnly = false)
    public ResponseCode albumSave(Map<String,Object> params) throws Exception{
        AlbumVo albumVo = new AlbumVo();
        albumVo.setTraId(params.get("traId").toString());
        albumVo.setMemId(params.get("memId").toString());
        //敏感词过滤
        albumVo.setName(SensitiveWordUtils.filterStr(params.get("albumName").toString()));
        albumVo.setTemplate(params.get("templateType").toString());
        EntityUtils.setCreatAndUpdatInfo(albumVo);
//        EntityUtils.setCreatAndUpdatInfoTwo(albumVo,albumVo.getMemId());
        mapper.albumSave(albumVo);
        List<PictureVo> picList = JSONArray.parseArray(params.get("picArr").toString(),PictureVo.class);
        if("1".equals(albumVo.getTemplate())){
            dealLongPicAlbum(picList,albumVo.getId());
        }else{
            dealGifPicAlbum(picList,albumVo.getId());
        }
        return ResponseCode.SUCCESS;
    }

    /**
     * 生成长图
     */
    @Transactional(readOnly = false)
    public void dealLongPicAlbum(List<PictureVo> picList, String albumId) throws Exception{
        //验证第一条数据是图片还是文字，如果是文字则生成图片
        String path = path2;
        String picUrl = path.concat(LONG).concat(RandomUtil.simpleUUID()).concat(".jpg");
        String contentPicUrl = path.concat(LONG).concat("content.jpg");
        AlbumPicVo albumPicVo = new AlbumPicVo();
                EntityUtils.setCreatAndUpdatInfo(albumPicVo);
//        EntityUtils.setCreatAndUpdatInfoTwo(albumPicVo,"1");
        albumPicVo.setAlbumId(albumId);
        File file = new File(picUrl);
        if (!file.getParentFile().exists()) {
            // 如果不存在就创建这个文件夹
            file.getParentFile().mkdirs();
        }
        if("1".equals(picList.get(0).getType())){
            PictureUtil.pictureMix(SensitiveWordUtils.filterStr(picList.get(0).getContent()),picUrl);
        }else{
            PictureUtil.copyPicture(path+picList.get(0).getContent(),picUrl);
        }
        int border = 0;
        int picLength = picList.size();
        for(int i=1; i<picLength; i++){
            if(i == picLength-1){
                border = 20;
            }
            if("1".equals(picList.get(i).getType())){
                PictureUtil.pictureMix(SensitiveWordUtils.filterStr(picList.get(i).getContent()),contentPicUrl);
                PictureUtil.yPic(picUrl,contentPicUrl,picUrl,border);
            }else{
                PictureUtil.yPic(picUrl,path+picList.get(i).getContent(),picUrl,border);
            }
        }
        String url = picUrl.replace(path,"");
        albumPicVo.setUrlPath(url);
        albumPicVo.setSort(1);
        List<AlbumPicVo> list = new ArrayList<>();
        list.add(albumPicVo);
        mapper.albumPicSave(list);
    }

    /**
     * 生成动图
     */
    public void dealGifPicAlbum(List<PictureVo> picList, String albumId){
        AlbumPicVo albumPicVo = null;
        List<AlbumPicVo>  list = new ArrayList<>();
        int sort = 1;
        for(int i=0; i<picList.size(); i++) {
            albumPicVo = new AlbumPicVo();
            albumPicVo.setAlbumId(albumId);
            albumPicVo.setSort(sort);
                EntityUtils.setCreatAndUpdatInfo(albumPicVo);
//            EntityUtils.setCreatAndUpdatInfoTwo(albumPicVo,"1");
            if("1".equals(picList.get(i).getType())){
                albumPicVo.setUrlPath(picList.get(i+1).getContent());
                albumPicVo.setContent(SensitiveWordUtils.filterStr(picList.get(i).getContent()));
                i++;
            }else{
                albumPicVo.setUrlPath(picList.get(i).getContent());
            }
            list.add(albumPicVo);
            sort++;
        }
        if(!list.isEmpty()){
            mapper.albumPicSave(list);
        }
    }

    /**
     * 动态电子相册详情
     */
    public AlbumVo albumDetail(AlbumVo albumVo) {
        //通过电子相册id获取详情信息
        AlbumVo vo = mapper.getAlbumDetail(albumVo);
        //通过电子相册id获取动态图中所有图片
        vo.setPicList(mapper.getAlbumPic(albumVo));
        return vo;
    }
}
