package com.isimpo.tech.framework.applet.service.my;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.applet.auto.entity.my.CardVo;
import com.isimpo.tech.framework.applet.auto.entity.onroad.wish.WishVo;
import com.isimpo.tech.framework.applet.auto.mapper.my.CardMapper;
import com.isimpo.tech.framework.applet.auto.mapper.onroad.WishMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 可乐名片
 * @author Tank
 * @version V1.0
 * @since 2019/2/26
 *
 */
@Service
public class CardService extends BaseService<CardMapper, CardVo> {

    /**
     * 查询名片信息
     * @param
     * @return AjaxResponse
     */
    public AjaxResponse getCardMess() {
        CardVo card = mapper.getCardMess();
        if(card == null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        return AjaxResponse.of(card);
    }

}
