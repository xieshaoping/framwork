package com.isimpo.tech.framework.customh5.fiter;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.alibaba.fastjson.JSON;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;

/**
 * 拦截器
 *
 * @author simpo
 * @version 1.0
 * @since 2017/12/22
 */
@Component
public class AccessUserInterceptor extends HandlerInterceptorAdapter {

    private static final String DURATION_PROCESS = "duration_process";

    private static final Logger logger = LoggerFactory.getLogger(AccessUserInterceptor.class);

    private com.isimpo.tech.framework.customh5.fiter.TokenProperties tokenProperties;

    /*private WxConfigService wxConfigService;

    public AccessUserInterceptor(TokenProperties tokenProperties, WxConfigService wxConfigService) {
        this.tokenProperties = tokenProperties;
        this.wxConfigService = wxConfigService;
    }*/

    private static String getCookie(HttpServletRequest request, String cookeName) {
        Cookie[] cookies = request.getCookies();
        String value = null;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookeName.equals(cookie.getName())) {
                    value = cookie.getValue();
                    break;
                }
            }
        }
        return value;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
        BaseContextHandler.set(DURATION_PROCESS, System.currentTimeMillis());
        String currentUserToken = getCookie(request, CommonConstants.CONTEXT_KEY_USER_TOKEN);
        //从redis缓存里获取微信用户信息
        /*WxUser wxUser = CacheUtils.get(currentUserToken, WxUser.class);
        //未登录
        if (wxUser == null) {
            AjaxResponse result = AjaxResponse.of(ResponseCode.NOT_LOGIN);
            result.setResult(createWechatOAuth2Url(request));
            writeJsonIntoResponse(response, result);
            return false;
        }
        HandlerMethod h = (HandlerMethod) o;
        UnBindTeacherPhonePermission teacherPhonePermission =
                h.getMethodAnnotation(UnBindTeacherPhonePermission.class);
        if (StringUtils.isEmpty(wxUser.getPhone())) {
            HandlerMethod handler = (HandlerMethod) o;
            UnBindPhonePermission permission = handler.getMethodAnnotation(UnBindPhonePermission.class);
            if (permission == null) {
                //未绑定手机号
                AjaxResponse result = AjaxResponse.of(ResponseCode.NOT_BIND_PHONE);
                result.setResult("/static/bindPhone.html");
                writeJsonIntoResponse(response, result);
                return false;
            }
        } else if (StringUtils.isEmpty(wxUser.getTeacherFlag()) && teacherPhonePermission == null) {
            //未绑定手机号(教师)
            AjaxResponse result = AjaxResponse.of(ResponseCode.NOT_BIND_TEACHER_PHONE);
            result.setResult("/static/bindTeacher.html");
            writeJsonIntoResponse(response, result);
            return false;
        } else if (BusinessConstants.NOT_BIND_CHILD.equals(wxUser.getIsBind())) {
            HandlerMethod handler = (HandlerMethod) o;
            UnBindChildPermission permission = handler.getMethodAnnotation(UnBindChildPermission.class);
            if (permission == null) {
                //实时从数据库获取微信用户信息
                wxUser = wxConfigService.getWxUserInfo(wxUser.getOpenid());
                if (wxUser != null && !BusinessConstants.NOT_BIND_CHILD.equals(wxUser.getIsBind())) {
                    // 准备上下文
                    prepareContext(currentUserToken, wxUser);
                    //更新缓存
                    CacheUtils.set(currentUserToken, wxUser, tokenProperties.getExpireSeconds());
                    return true;
                }
                //未绑定孩子信息时的拦截处理
                AjaxResponse result = AjaxResponse.of(ResponseCode.NOT_BIND_CHILD);
                result.setResult("/static/notBindStudentTip.html");
                writeJsonIntoResponse(response, result);
                return false;
            }
        }
        // 准备上下文
        prepareContext(currentUserToken, wxUser);
        // 更新 token 过期时间
        final String key = currentUserToken;
        CacheUtils.execute(redis -> redis.expire(key, tokenProperties.getExpireSeconds()));*/
        return true;
    }

    /*private void prepareContext(String currentUserToken, WxUser wxUser) {
        BaseContextHandler.setUserID(wxUser.getId());
        BaseContextHandler.setUnionId(wxUser.getUnionid());
        BaseContextHandler.setOpenId(wxUser.getOpenid());
        BaseContextHandler.setToken(currentUserToken);
        BaseContextHandler.setTeacherId(wxUser.getBindId());
    }*/

    private void writeJsonIntoResponse(HttpServletResponse response, AjaxResponse result) throws IOException {
        response.setHeader("Content-type", "application/json;charset=UTF-8");
        try (PrintWriter writer = response.getWriter()) {
            writer.write(JSON.toJSONString(result));
        }
    }

    /**
     * 发起微信授权登录
     *
     * @param request 请求
     * @throws UnsupportedEncodingException 异常
     */
    /*private String createWechatOAuth2Url(HttpServletRequest request) throws UnsupportedEncodingException {
        String path = request.getHeader("referer");
        String backUrl = HttpClientUtils.getWebRootUrl(request) + "/weChat/oauthCallback.html";
        String redirectUri = URLEncoder.encode(backUrl, "utf-8");

        String appId = WeChatConfigUtil.getWechatConfig().getAppId();
        String wxOAuth2Url = WechatApi.WECHAT_OAUTH2_AUTHORIZE_URL.replace("#APPID#", appId)
                .replace("#snsapi_userinfo#", "snsapi_userinfo");
        if (StringUtils.isNotEmpty(path)) {
            wxOAuth2Url = wxOAuth2Url.replace("#STATE#", path);
        }
        wxOAuth2Url = wxOAuth2Url.replace("#REDIRECT_URI#", redirectUri);
        return wxOAuth2Url;
    }*/
    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
            Object o, Exception e) {
        if (logger.isInfoEnabled()) {
            final long duration = System.currentTimeMillis() - (long) BaseContextHandler.get(DURATION_PROCESS);
            logger.info("请求：{} 耗费时间：{} ms", httpServletRequest.getServletPath(), duration);
        }

        BaseContextHandler.remove();
    }

}

