package com.isimpo.tech.framework.customh5;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.ace.cache.EnableAceCache;

/**
 * applet工程启动入口
 * @author guohui
 * @version v1.0.0
 */
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class, scanBasePackages = "com.isimpo.tech")
@EnableAceCache
@EnableTransactionManagement
public class Appleth5Bootstrap {

    public static void main(String[] args) {
        new SpringApplicationBuilder(Appleth5Bootstrap.class).web(true).run(args);
    }
}
