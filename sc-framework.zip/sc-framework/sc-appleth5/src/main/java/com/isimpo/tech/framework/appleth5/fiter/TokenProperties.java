package com.isimpo.tech.framework.customh5.fiter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * token配置参数
 *
 * @author abator
 * @version 1.0
 * @since 2018年02月02日
 */
@Component
@ConfigurationProperties(prefix = "token")
public class TokenProperties {

    /**
     * 过期时间，单位：秒，默认 3 天
     */
    private int expireSeconds = 3 * 24 * 3600;

    public int getExpireSeconds() {
        return expireSeconds;
    }

    public void setExpireSeconds(int expireSeconds) {
        this.expireSeconds = expireSeconds;
    }
}
