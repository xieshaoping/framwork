#工程说明
* sc-admin：运营后台接口
* sc-center：
* sc-common：共通工具类
* sc-config：
* sc-applet：商户/广告主后台      /api/v1/custom
* sc-monitor：
* sc-upload：文件上传共通         /api/v2/upload
