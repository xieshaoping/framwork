package com.isimpo.tech.framework.admin.contorller.content.homePage;

import com.isimpo.tech.framework.admin.auto.entity.content.homePage.IndexPic;
import com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk.TratRavelerTalk;
import com.isimpo.tech.framework.admin.service.content.homePage.IndexPicService;
import com.isimpo.tech.framework.admin.service.content.tratravelertalk.TratRavelerTalkService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 12:37 2019/2/12
 * @Modify By:
 */
@RestController
@RequestMapping("/content/homePage/indexPic")
public class IndexPicController extends BaseController<IndexPicService, IndexPic> {

    //    增加
    @PostMapping
    @ResponseBody
    @Override
    public AjaxResponse add(@RequestBody IndexPic entity) {
        baseService.insertIndexPic(entity);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    //  逻辑删除
    @Override
    @DeleteMapping("/{id}")
    @ResponseBody
    public AjaxResponse remove(@PathVariable String id) {
        return  baseService.deleteIndexPic(id);
    }


    @Override
    @GetMapping("/page")
    public AjaxResponse list(@RequestParam Map<String, Object> params) {
        Map<String, String> orderByMap = new HashMap<>();
        orderByMap.put("addTime", CommonConstants.ORDER_BY_DESC);
        params.put(CommonConstants.ORDER_BY_PARAM, orderByMap);
        return super.list(params);
    }
}
