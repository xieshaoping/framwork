package com.isimpo.tech.framework.admin.auto.mapper.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.NewsVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraManageVo;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
public interface NewsMapper extends Mapper<NewsVo> {

    /**
     * 查询可乐消息列表
     * @param query
     * @return
     */
    List<NewsVo> listNews(Query query);

    /**
     * 获取可乐消息详情
     * @param news
     * @return
     */
    NewsVo getNewsDetail(NewsVo news);

    /**
     * 删除可乐消息
     * @param news
     * @return
     */
    int delNews(NewsVo news);

    /**
     * 添加可乐消息
     * @param news
     * @return
     */
    int addNews(NewsVo news);

    /**
     * 查询行程列表
     * @return
     */
    List<TraManageVo> listTravel();
}
