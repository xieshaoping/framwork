package com.isimpo.tech.framework.admin.service.content.tratravelertalk;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk.TratRavelerTalk;
import com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk.TratRavelerTalkView;
import com.isimpo.tech.framework.admin.auto.mapper.content.tratravelertalk.TratRavelerTalkMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TratRavelerTalkService extends BaseService<TratRavelerTalkMapper, TratRavelerTalk> {

    /**
     * 查询用户分页列表
     *
     * @param query 分页信息
     * @return TableResultResponse<SysUser> 用户分页列表
     */
    @Override
    public TableResultResponse<TratRavelerTalk> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<TratRavelerTalk> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 保存（修改）旅咖说
     *
     * @param tratRavelerTalk
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse saveTratRavelerTalkItem(TratRavelerTalk tratRavelerTalk) {
        tratRavelerTalk.setMemId(BaseContextHandler.getUserID());
        filter(tratRavelerTalk);
        //新增旅咖说
        if (StringUtils.isEmpty(tratRavelerTalk.getId())) {
            insert(tratRavelerTalk);
            return AjaxResponse.of(ResponseCode.SUCCESS);
        } else {
            //更新旅咖说
            updateSelectiveById(tratRavelerTalk);
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
    }

    /**
     * 获取单个旅咖说实体
     *
     * @param tratRavelerTalk
     * @return
     */
    public AjaxResponse getTratRavelerTalkItem(TratRavelerTalk tratRavelerTalk) {
        tratRavelerTalk = selectById(tratRavelerTalk.getId());
        return AjaxResponse.of(tratRavelerTalk);
    }

    /**
     * 删除旅咖说
     *
     * @param tratRavelerTalk
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse delTratRavelerTalk(TratRavelerTalk tratRavelerTalk) {
        if (mapper.delTratRavelerTalk(tratRavelerTalk.getId()) > 0) ;
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 获取旅咖说查看数据
     *
     * @param tratRavelerTalk
     * @return
     */
    public AjaxResponse getTratRavelerTalkView(TratRavelerTalk tratRavelerTalk) {
        if (StringUtils.isNotEmpty(tratRavelerTalk.getId()) && StringUtils.isNotEmpty(tratRavelerTalk.getType())) {
            switch (tratRavelerTalk.getType()) {
                case "1":
                    //平台类型
                    return getTratRavelerTalkViewForSys(tratRavelerTalk.getId());
                case "2":
                    //会员类型
                    return getTratRavelerTalkViewForUser(tratRavelerTalk.getId());
                default:
                    return AjaxResponse.of(ResponseCode.FAIL);

            }

        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 获取旅咖说(平台类型)
     *
     * @param id
     * @return
     */
    public AjaxResponse getTratRavelerTalkViewForSys(String id) {
        Map tratRavelerTalkViewMap = new HashMap();
        TratRavelerTalkView tratRavelerTalkView = mapper.getTratRavelerTalkViewForSys(id);
        tratRavelerTalkViewMap.put("item", tratRavelerTalkView);
        List<TratRavelerTalkView> list = getTalkList(id);
        tratRavelerTalkViewMap.put("list", list);
        return AjaxResponse.of(tratRavelerTalkViewMap);
    }

    public AjaxResponse getTratRavelerTalkViewForUser(String id) {
        Map tratRavelerTalkViewMap = new HashMap();
        TratRavelerTalkView tratRavelerTalkView = mapper.getTratRavelerTalkViewForUser(id);
        tratRavelerTalkViewMap.put("item", tratRavelerTalkView);
        List<TratRavelerTalkView> list = getTalkList(id);
        tratRavelerTalkViewMap.put("list", list);
        return AjaxResponse.of(tratRavelerTalkViewMap);
    }

    /**
     * 根据旅咖说id获取评论list
     *
     * @param id
     * @return
     */
    public List<TratRavelerTalkView> getTalkList(String id) {
        return mapper.getTalkList(id);
    }


    /**
     * 删除某条评论
     *
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse delTalk(String id) {
        if (mapper.delTalk(id) > 0) ;
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 首页管理，查询用户分页列表,过滤了已经是首页展示的
     *
     * @param query 分页信息
     * @return TableResultResponse<SysUser> 用户分页列表
     */
    public TableResultResponse<TratRavelerTalk> selectTalk(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<TratRavelerTalk> list = mapper.findTalkList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    // 敏感词过滤
    private void filter(TratRavelerTalk tratRavelerTalk) {
        tratRavelerTalk.setTitle(SensitiveWordUtils.filterStr(tratRavelerTalk.getTitle()));
        tratRavelerTalk.setName(SensitiveWordUtils.filterStr(tratRavelerTalk.getName()));
        tratRavelerTalk.setNote(SensitiveWordUtils.filterStr(tratRavelerTalk.getNote()));
    }
}
