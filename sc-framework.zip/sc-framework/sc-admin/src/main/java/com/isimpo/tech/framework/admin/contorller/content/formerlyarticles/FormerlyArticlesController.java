package com.isimpo.tech.framework.admin.contorller.content.formerlyarticles;

import java.util.HashMap;
import java.util.Map;

import com.isimpo.tech.framework.common.constant.CommonConstants;
import org.springframework.web.bind.annotation.*;

import com.isimpo.tech.framework.admin.auto.entity.content.formerlyarticles.FormerlyArticles;
import com.isimpo.tech.framework.admin.service.content.formerlyarticles.FormerlyArticlesService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 旅咖说Controller
 */
@RestController
@RequestMapping("/content/formerlyArticles")
public class FormerlyArticlesController extends BaseController<FormerlyArticlesService, FormerlyArticles> {

    /**
     *同步文章
     */
    @RequestMapping("/syncArticles")
    public AjaxResponse syncArticles(){
        return baseService.syncArticles();
    }

    /*首页，文章推荐，过滤掉已经是推荐的文章*/
    @GetMapping("/indexArticleList")
    @ResponseBody
    public AjaxResponse indexArticleList(@RequestParam Map<String, Object> params) {
        // 查询列表数据
        System.out.println(params);
        for (String in : params.keySet()) {
            if (!in.equals(CommonConstants.ORDER_BY_PARAM)) {
                //map.keySet()返回的是所有key的值
                String str = (String) params.get(in);//得到每个key多对用value的值
                str = str.replace("%", "%\\");
                str = str.replace("?", "?\\");
                str = str.replace("_", "_\\");
                params.put(in, str);
            }
        }
        Query query = new Query(params);
        return AjaxResponse.of(baseService.indexArticleList(query));
    }

    @GetMapping("/getArticles")
    @ResponseBody
    public AjaxResponse getArticles(String id){
        return AjaxResponse.of(baseService.getArticles(id));
    }
}
