package com.isimpo.tech.framework.admin.contorller.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraWish;
import com.isimpo.tech.framework.admin.service.travel.TraWishService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

/**
 * 会员祝福
 * @author wangxinhai
 * @since 2019/2/11
 */
@RestController
@RequestMapping("/travel/trawish")
public class TraWishController extends BaseController<TraWishService, TraWish> {

    /**
     * 逻辑删除
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    @ResponseBody
    @Override
    public AjaxResponse remove(@PathVariable String id) {
        baseService.deleteById(id);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }
}
