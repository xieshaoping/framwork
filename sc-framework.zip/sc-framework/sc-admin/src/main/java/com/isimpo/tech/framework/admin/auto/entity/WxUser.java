package com.isimpo.tech.framework.admin.auto.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "wx_user")
public class WxUser {
    @Id
    private String id;

    /**
     * 用户编号（M000000001）
     */
    @Column(name = "user_no")
    private String userNo;

    /**
     * 用户名
     */
    @Column(name = "login_name")
    private String loginName;

    /**
     * 密码
     */
    private String password;

    /**
     * 昵称
     */
    @Column(name = "nick_name")
    private String nickName;

    /**
     * 真实姓名
     */
    private String name;

    /**
     * 电话
     */
    private String phone;

    /**
     * 性别（0：保密，1：男，2：女）
     */
    private String sex;

    /**
     * 生日
     */
    private Date birthday;

    /**
     * 头像
     */
    private String photo;

    /**
     * 是否启用（0：停用，1：启用）
     */
    @Column(name = "use_flag")
    private String useFlag;

    /**
     * 账户余额
     */
    private BigDecimal money;

    /**
     * 积分
     */
    private Integer point;

    /**
     * 锁定积分
     */
    @Column(name = "lock_point")
    private Integer lockPoint;

    /**
     * 支付密码
     */
    @Column(name = "pay_password")
    private String payPassword;

    /**
     * 微信openid
     */
    @Column(name = "wx_open_id")
    private String wxOpenId;

    /**
     * 删除标识（1:已删除,0:正常）
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建人
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建页面ID
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新页面ID
     */
    @Column(name = "upd_mark")
    private String updMark;

    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取用户编号（M000000001）
     *
     * @return user_no - 用户编号（M000000001）
     */
    public String getUserNo() {
        return userNo;
    }

    /**
     * 设置用户编号（M000000001）
     *
     * @param userNo 用户编号（M000000001）
     */
    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    /**
     * 获取用户名
     *
     * @return login_name - 用户名
     */
    public String getLoginName() {
        return loginName;
    }

    /**
     * 设置用户名
     *
     * @param loginName 用户名
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    /**
     * 获取密码
     *
     * @return password - 密码
     */
    public String getPassword() {
        return password;
    }

    /**
     * 设置密码
     *
     * @param password 密码
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * 获取昵称
     *
     * @return nick_name - 昵称
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * 设置昵称
     *
     * @param nickName 昵称
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    /**
     * 获取真实姓名
     *
     * @return name - 真实姓名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置真实姓名
     *
     * @param name 真实姓名
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取电话
     *
     * @return phone - 电话
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 设置电话
     *
     * @param phone 电话
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * 获取性别（0：保密，1：男，2：女）
     *
     * @return sex - 性别（0：保密，1：男，2：女）
     */
    public String getSex() {
        return sex;
    }

    /**
     * 设置性别（0：保密，1：男，2：女）
     *
     * @param sex 性别（0：保密，1：男，2：女）
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * 获取生日
     *
     * @return birthday - 生日
     */
    public Date getBirthday() {
        return birthday;
    }

    /**
     * 设置生日
     *
     * @param birthday 生日
     */
    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    /**
     * 获取头像
     *
     * @return photo - 头像
     */
    public String getPhoto() {
        return photo;
    }

    /**
     * 设置头像
     *
     * @param photo 头像
     */
    public void setPhoto(String photo) {
        this.photo = photo;
    }

    /**
     * 获取是否启用（0：停用，1：启用）
     *
     * @return use_flag - 是否启用（0：停用，1：启用）
     */
    public String getUseFlag() {
        return useFlag;
    }

    /**
     * 设置是否启用（0：停用，1：启用）
     *
     * @param useFlag 是否启用（0：停用，1：启用）
     */
    public void setUseFlag(String useFlag) {
        this.useFlag = useFlag;
    }

    /**
     * 获取账户余额
     *
     * @return money - 账户余额
     */
    public BigDecimal getMoney() {
        return money;
    }

    /**
     * 设置账户余额
     *
     * @param money 账户余额
     */
    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    /**
     * 获取积分
     *
     * @return point - 积分
     */
    public Integer getPoint() {
        return point;
    }

    /**
     * 设置积分
     *
     * @param point 积分
     */
    public void setPoint(Integer point) {
        this.point = point;
    }

    /**
     * 获取锁定积分
     *
     * @return lock_point - 锁定积分
     */
    public Integer getLockPoint() {
        return lockPoint;
    }

    /**
     * 设置锁定积分
     *
     * @param lockPoint 锁定积分
     */
    public void setLockPoint(Integer lockPoint) {
        this.lockPoint = lockPoint;
    }

    /**
     * 获取支付密码
     *
     * @return pay_password - 支付密码
     */
    public String getPayPassword() {
        return payPassword;
    }

    /**
     * 设置支付密码
     *
     * @param payPassword 支付密码
     */
    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword;
    }

    /**
     * 获取微信openid
     *
     * @return wx_open_id - 微信openid
     */
    public String getWxOpenId() {
        return wxOpenId;
    }

    /**
     * 设置微信openid
     *
     * @param wxOpenId 微信openid
     */
    public void setWxOpenId(String wxOpenId) {
        this.wxOpenId = wxOpenId;
    }

    /**
     * 获取删除标识（1:已删除,0:正常）
     *
     * @return del_flag - 删除标识（1:已删除,0:正常）
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识（1:已删除,0:正常）
     *
     * @param delFlag 删除标识（1:已删除,0:正常）
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建人
     *
     * @return add_user_id - 创建人
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建人
     *
     * @param addUserId 创建人
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建页面ID
     *
     * @return add_mark - 创建页面ID
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建页面ID
     *
     * @param addMark 创建页面ID
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新页面ID
     *
     * @return upd_mark - 更新页面ID
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新页面ID
     *
     * @param updMark 更新页面ID
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    /**
     * @return upd_user_id
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * @param updUserId
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }
}