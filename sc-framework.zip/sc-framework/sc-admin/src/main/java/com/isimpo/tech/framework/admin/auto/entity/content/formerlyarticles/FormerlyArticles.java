/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.entity.content.formerlyarticles;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.admin.auto.entity.Common;

/**
 * 往日文章
 * @author LuoCheng
 * @version 1.0
 * @since 2019年01月31日
 */

@Table(name = "cont_article")
public class FormerlyArticles extends Common {

    /**
     * 标题
     */
    private String title;

    /**
     * 摘要
     */
    private String digest;

    /**
     * 封面
     */
    private String cover;

    /**
     * 显示状态
     */
    private String state;

    /**
     * 内容
     */
    private String content;

    /**
     * 作者
     */
    private String author;

    //微信文章地址
    private String url;

    /**
     * 素材id
     */
    @Column(name = "thumb_media_id")
    private String thumbMediaId;

    /**
     * 图文消息的原文地址
     */
    @Column(name = "content_source_url")
    private String contentSourceUrl;

    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private Date updateTime;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDigest() {
        return digest;
    }

    public void setDigest(String digest) {
        this.digest = digest;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getThumbMediaId() {
        return thumbMediaId;
    }

    public void setThumbMediaId(String thumbMediaId) {
        this.thumbMediaId = thumbMediaId;
    }

    public String getContentSourceUrl() {
        return contentSourceUrl;
    }

    public void setContentSourceUrl(String contentSourceUrl) {
        this.contentSourceUrl = contentSourceUrl;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
