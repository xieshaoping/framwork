package com.isimpo.tech.framework.admin.auto.entity;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;
import java.util.List;

/**
 * @Author: xiesp
 * @Despriction:客户实体类
 * @Date:Created in 15:52 2019/1/25
 * @Modify By:
 */
@Table(name = "csr_customer")
public class SysCust extends BaseVo {
    @Id
    private String id;
    private String name;
    private String contact;
    private String phone;
    private String email;
    /*
     * 管家id
     * */
    @Column(name = "housekeeper_id")
    private String housekeeperId;

    /**
     * 来源（关联字典）
     */
    private String source;
    private String address;
    private String note;
    /*
     *更新人姓名
     * */
    private String updName;

    /*
     *hkName管家姓名
     * */
    private String hkName;

    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setHkName(String hkName) {
        this.hkName = hkName;
    }

    public String getUpdName() {
        return updName;
    }

    public void setUpdName(String updName) {
        this.updName = updName;
    }

    public String getHkName() {
        return hkName;
    }


    /*
     *预约id（客户预约转客户的情况）
     * */
    @Column(name = "reserve_id")
    private String reserveId;
    @Column(name = "del_flag")
    private String delFlag;

    @Column(name = "add_time")
    private Date addTime;

    @Column(name = "add_user_id")
    private String addUserId;

    @Column(name = "upd_time")
    private Date updTime;

    @Column(name = "upd_user_id")
    private String updUserId;

    /*
     * 历史行程
     * */
    @Transient
    private List<SysTra> travels;

    public List<SysTra> getTravels() {
        return travels;
    }

    public void setTravels(List<SysTra> travels) {
        this.travels = travels;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHousekeeperId() {
        return housekeeperId;
    }

    public void setHousekeeperId(String housekeeperId) {
        this.housekeeperId = housekeeperId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getReserveId() {
        return reserveId;
    }

    public void setReserveId(String reserveId) {
        this.reserveId = reserveId;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public Date getAddTime() {
        return addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public String getAddUserId() {
        return addUserId;
    }

    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdUserId() {
        return updUserId;
    }

    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

}
