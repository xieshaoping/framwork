/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.mapper;

import com.isimpo.tech.framework.admin.auto.entity.SysConfigure;

import tk.mybatis.mapper.common.Mapper;

/**
 * 系统配置
 *
 * @author LuoCheng
 * @version 1.0
 * @since 2019年02月12日
 */
public interface SysConfigureMapper extends Mapper<SysConfigure> {

    SysConfigure querySysConfigure();

    void updateSysConfigure(SysConfigure sysConfigure);
}
