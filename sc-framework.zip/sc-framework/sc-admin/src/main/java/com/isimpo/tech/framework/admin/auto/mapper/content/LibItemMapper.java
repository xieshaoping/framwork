package com.isimpo.tech.framework.admin.auto.mapper.content;

import com.isimpo.tech.framework.admin.auto.entity.content.LibItem;
import com.isimpo.tech.framework.admin.auto.entity.content.LibSupp;
import tk.mybatis.mapper.common.Mapper;

public interface LibItemMapper extends Mapper<LibItem> {

    int insertLibSupp(LibSupp traSupp);

    int updateLibSupp(LibSupp traSupp);

    int delLibSupp(LibSupp traSupp);

    LibSupp getLibSupp(String id);
}