package com.isimpo.tech.framework.admin.contorller.travel;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.admin.auto.entity.travel.CustomerVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraManageVo;
import com.isimpo.tech.framework.admin.service.travel.CustomerService;
import com.isimpo.tech.framework.admin.service.travel.TraManageService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;


/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/1
 *
 */
@RestController
@RequestMapping("/travel_customer")
public class CustomerController extends BaseController<CustomerService, CustomerVo> {


    /**
     * 行程基本信息客户下拉选
     * @return 返回数据
     */
    @GetMapping("/customer")
    public AjaxResponse getCustomers() {
       return baseService.getCustomers();
    }


}
