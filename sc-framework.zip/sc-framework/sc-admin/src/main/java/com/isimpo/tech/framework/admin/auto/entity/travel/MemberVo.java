/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.entity.travel;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * 行程管理-成员信息
 * @author Tank
 * @version V1.0
 * @since 2019/2/11
 *
 */
@Table(name = "csr_member")
public class MemberVo extends BaseVo {
    /** 成员id*/
    private String id;

    /** 行程id*/
    @Transient
    private String traId;

    /** 成员姓名*/
    private String name;

    /** 成员性别*/
    private String gender;

    /** 成员生日*/
    private Date birthday;

    /** 手机号码*/
    private String phone;

    /** 证件类型*/
    @Column(name = "id_type")
    private String idType;

    /** 证件号码*/
    @Column(name = "id_num")
    private String idNum;

    /** 联系地址*/
    private String source;

    /** 备注*/
    private String note;

    /** 成员类型 1-会员 2-管家 */
    private String type;

    /** 团长标识 0-否 1-是 */
    private String leaderFlag;

    /**
     * 查看全部行程（0：否，1是）
     */
    @Column(name = "all_flag")
    private String allFlag;
    /**昵称*/
    private String nickName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonFormat(pattern="yyyy-MM-dd")
    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLeaderFlag() {
        return leaderFlag;
    }

    public void setLeaderFlag(String leaderFlag) {
        this.leaderFlag = leaderFlag;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    public String getAllFlag() {
        return allFlag;
    }

    public void setAllFlag(String allFlag) {
        this.allFlag = allFlag;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    @Override
    public String toString() {
        return "MemberVo{" + "id='" + id + '\'' + ", traId='" + traId + '\'' + ", name='" + name + '\'' + ", gender='"
                + gender + '\'' + ", birthday=" + birthday + ", phone='" + phone + '\'' + ", idType='" + idType + '\''
                + ", idNum='" + idNum + '\'' + ", source='" + source + '\'' + ", note='" + note + '\'' + ", type='"
                + type + '\'' + ", leaderFlag='" + leaderFlag + '\'' + '}';
    }
}
