package com.isimpo.tech.framework.admin.service.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.*;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraItemMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 行程事项
 * @author wangxinhai
 * @version V1.0
 * @since 2019/2/18
 */
@Service
public class TraItemService extends BaseService<TraItemMapper, TraItem> {

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Object id) {
        TraItem traItem = new TraItem();
        traItem.setId(id.toString());
        traItem.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        EntityUtils.setUpdatedInfo(traItem);
        super.updateSelectiveById(traItem);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertSelective(TraItem entity) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfh = new SimpleDateFormat("HH:mm:ss");
        TraCalendar traCalendar = null;
        if(entity.getCalendarId() != null){
            traCalendar = mapper.getCalendar(entity.getCalendarId());
        }
        String sd = sdf.format(traCalendar.getTraDate()) + " " + sdfh.format(entity.getStartTime());
        String ed = sdf.format(traCalendar.getTraDate()) + " " + sdfh.format(entity.getEndTime());
        Date sdd = null;
        Date edd = null;
        try {
            sdd = sdfs.parse(sd);
            edd = sdfs.parse(ed);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        entity.setStartTime(sdd);
        entity.setEndTime(edd);
        EntityUtils.setCreatAndUpdatInfo(entity);
        // 敏感词过滤
        entity.setName(SensitiveWordUtils.filterStr(entity.getName()));
        entity.setEnName(SensitiveWordUtils.filterStr(entity.getEnName()));
        entity.setOverview(SensitiveWordUtils.filterStr(entity.getOverview()));
        entity.setTips(SensitiveWordUtils.filterStr(entity.getTips()));
        entity.setContent(SensitiveWordUtils.filterStr(entity.getContent()));
        mapper.insertSelective(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateSelectiveById(TraItem entity) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfh = new SimpleDateFormat("HH:mm:ss");
        TraCalendar traCalendar = null;
        if(entity.getCalendarId() != null){
            traCalendar = mapper.getCalendar(entity.getCalendarId());
        }
        String sd = sdf.format(traCalendar.getTraDate()) + " " + sdfh.format(entity.getStartTime());
        String ed = sdf.format(traCalendar.getTraDate()) + " " + sdfh.format(entity.getEndTime());
        Date sdd = null;
        Date edd = null;
        try {
            sdd = sdfs.parse(sd);
            edd = sdfs.parse(ed);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        entity.setStartTime(sdd);
        entity.setEndTime(edd);
        EntityUtils.setUpdatedInfo(entity);
        mapper.updateByPrimaryKeySelective(entity);
    }

    /**
     * 行程补充添加
     * @param traSupp
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse addTraSupp(TraSupp traSupp){
        EntityUtils.setCreatAndUpdatInfo(traSupp);
        // 敏感词过滤
        traSupp.setName(SensitiveWordUtils.filterStr(traSupp.getName()));
        traSupp.setEnName(SensitiveWordUtils.filterStr(traSupp.getEnName()));
        traSupp.setOverview(SensitiveWordUtils.filterStr(traSupp.getOverview()));
        traSupp.setTips(SensitiveWordUtils.filterStr(traSupp.getTips()));
        traSupp.setContent(SensitiveWordUtils.filterStr(traSupp.getContent()));
        int num = mapper.insertTraSupp(traSupp);
        if (num > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 行程补充修改
     * @param traSupp
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updateTraSupp(TraSupp traSupp){
        EntityUtils.setUpdatedInfo(traSupp);
        // 敏感词过滤
        traSupp.setName(SensitiveWordUtils.filterStr(traSupp.getName()));
        traSupp.setEnName(SensitiveWordUtils.filterStr(traSupp.getEnName()));
        traSupp.setOverview(SensitiveWordUtils.filterStr(traSupp.getOverview()));
        traSupp.setTips(SensitiveWordUtils.filterStr(traSupp.getTips()));
        traSupp.setContent(SensitiveWordUtils.filterStr(traSupp.getContent()));
        int num = mapper.updateTraSupp(traSupp);
        if (num > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 行程补充删除
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse delTraSupp(String id){
        TraSupp traSupp = new TraSupp();
        traSupp.setId(id);
        EntityUtils.setUpdatedInfo(traSupp);
        int num = mapper.delTraSupp(traSupp);
        if (num > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 行程补充详情
     * @param id
     * @return
     */
    public TraSupp getTraSupp(String id){
        return mapper.getTraSupp(id);
    }
}
