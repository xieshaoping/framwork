package com.isimpo.tech.framework.admin.auto.mapper.business;

import com.isimpo.tech.framework.admin.auto.entity.SysCust;
import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.admin.auto.entity.business.Reserve;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 15:34 2019/1/31
 * @Modify By:
 */
public interface MyCustMapper extends Mapper<SysCust> {

    /**
     * 查询用户列表
     *
     * @param query 查询参数
     * @return List<SysCust> 用户列表
     */
    List<SysCust> findList(Query query);


    String checkMyId( @Param("id") String id);

}
