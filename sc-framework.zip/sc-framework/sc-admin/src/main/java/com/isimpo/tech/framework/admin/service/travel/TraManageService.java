package com.isimpo.tech.framework.admin.service.travel;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import com.alibaba.fastjson.JSONObject;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.isimpo.tech.framework.admin.auto.entity.content.LibItem;
import com.isimpo.tech.framework.admin.auto.entity.content.LibPlace;
import com.isimpo.tech.framework.admin.auto.entity.content.LibSupp;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.wechat.WechatConstants;
import com.isimpo.tech.wechat.pojo.ticket.WechatBackTicket;
import com.isimpo.tech.wechat.pojo.ticket.WechatTicket;
import com.isimpo.tech.wechat.ticket.WechatTicketUtil;
import com.alibaba.druid.util.StringUtils;
import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.auto.entity.travel.*;
import com.isimpo.tech.framework.common.util.CacheUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraManageMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

import javax.imageio.ImageIO;

/**
 * 行程管理
 * @author Tank
 * @version V1.0
 * @since 2019/1/29
 *
 */
@Service
public class TraManageService extends BaseService<TraManageMapper, TraManageVo> {

    @Value("${htmlToJpg.url}")
    private String path;

    @Value("${htmlToJpg.qrUrl}")
    private String qrUrl;

    //手机号
    public static final String REGEX_MOBILE = "^((17[0-9])|(14[0-9])|(13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$";
    //身份证
    public static final String REGEX_IDCARD = "(^\\d{18}$)|(^\\d{15}$)";
    //台胞证
    public static final String REGEX_TBCARD = "/^\\d{8}|^[a-zA-Z0-9]{10}|^\\d{18}$/";
    //护照
    public static final String REGEX_PASSPORT = "/^([a-zA-z]|[0-9]){5,17}$/";

    /**
     * 行程列表
     * @param query 参数
     * @return 返回数据
     */
    @Override
    public TableResultResponse<TraManageVo> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<TraManageVo> list = mapper.getList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 行程删除
     * @param id 参数
     * @return 返回数据
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse removeTravel(String id) {
        if(id == null || id.trim().isEmpty()){
            return  AjaxResponse.of(ResponseCode.FAIL);
        }
        int num = 0;
        TraManageVo vo = mapper.findTravelById(id);
        EntityUtils.setUpdatedInfo(vo);
        num = mapper.removeTravel(vo);
        if(num>0){
            //逻辑删除成功
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return  AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 获取行程基本信息
     * @param id 参数
     * @return 返回数据
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse findTraById(String id) {
        CacheUtils.set("traId", id, 600);
        if(id == null || id.trim().isEmpty()){
            return  AjaxResponse.of(ResponseCode.FAIL);
        }
        TraManageVo vo = mapper.findTravelById(id);
        if(vo==null){
            return AjaxResponse.of(ResponseCode.NO_FIND_DATA);
        }
        return AjaxResponse.of(vo);
    }

    /**
     * 行程取消
     * @param id 参数
     * @return 返回数据
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse cancelTravel(String id) {
        if(id == null || id.trim().isEmpty()){
            return  AjaxResponse.of(ResponseCode.FAIL);
        }
        int num = 0;
        TraManageVo vo = mapper.findTravelById(id);
        EntityUtils.setUpdatedInfo(vo);
        num = mapper.cancelTravel(vo);
        if(num>0){
            //行程取消成功
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return  AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 行程修改
     * @param traManageVo 参数
     * @return 返回数据
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse editTravel(TraManageVo traManageVo) {
        if(traManageVo == null){
            return  AjaxResponse.of(ResponseCode.FAIL);
        }
        String id = traManageVo.getId();
        TraManageVo vo = new TraManageVo();
        if(id !=null && !id.trim().isEmpty()){
            vo = mapper.findTravelById(id);
            EntityUtils.setUpdatedInfo(vo);
        }
        traManageVo.setUpdUserId(vo.getUpdUserId());
        int num = 0;
        List<TraHk> list = new ArrayList<>();
        TraHk traHk = null;
        mapper.deleteTraHk(traManageVo.getId());
        if(traManageVo.getGuiderIds() != null){
            for(String s : traManageVo.getGuiderIds()){
                traHk = new TraHk();
                EntityUtils.setCreatAndUpdatInfo(traHk);
                traHk.setHkId(s);
                traHk.setTraId(traManageVo.getId());
                list.add(traHk);
            }
        }
        if(list.size() > 0){
            mapper.insertTraHk(list);
        }
        num = mapper.editTravel(traManageVo);
        if(num>0){
            return  AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return  AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 查询指定行程状态列表
     */
    public List<TraManageVo> queryForState(){
        return mapper.queryForState();
    }

    /**
     * 批量更新行程状态
     */
    @Transactional(rollbackFor = Exception.class)
    public void updateState(List<TraManageVo> traManageVoList){
         mapper.updateState(traManageVoList);
    }


    /**
     * 行程增加
     * @Author wangxinhai
     * @param entity
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse add(TraManageVo entity) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        CacheUtils.set("traId", entity.getId(), 600);
        createQrCode(qrUrl + "?traId="+entity.getId(), path, "qrcode" + entity.getId() + ".jpg");
        entity.setQrCode("qrcode" + entity.getId() + ".jpg");
        // 敏感词过滤
        entity.setName(SensitiveWordUtils.filterStr(entity.getName()));
        entity.setContact(SensitiveWordUtils.filterStr(entity.getContact()));
        entity.setNote(SensitiveWordUtils.filterStr(entity.getNote()));

        List<TraHk> list = new ArrayList<>();
        TraHk traHk = null;
        if(entity.getGuiderIds() != null){
            for(String s : entity.getGuiderIds()){
                traHk = new TraHk();
                EntityUtils.setCreatAndUpdatInfo(traHk);
                traHk.setHkId(s);
                traHk.setTraId(entity.getId());
                list.add(traHk);
            }
        }
        if(list.size() > 0){
            mapper.insertTraHk(list);
        }
        mapper.insertSelective(entity);
        return AjaxResponse.of(entity.getId());
    }

    public static String createQrCode(String url, String path, String fileName) {
        try {
            Map<EncodeHintType, String> hints = new HashMap<>();
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            BitMatrix bitMatrix = new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, 400, 400, hints);
            File file = new File(path, fileName);
            if (file.exists() || ((file.getParentFile().exists() || file.getParentFile().mkdirs()) && file.createNewFile())) {
                writeToFile(bitMatrix, "jpg", file);
                System.out.println("搞定：" + file);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    static void writeToFile(BitMatrix matrix, String format, File file) throws IOException {
        BufferedImage image = toBufferedImage(matrix);
        if (!ImageIO.write(image, format, file)) {
            throw new IOException("Could not write an image of format " + format + " to " + file);
        }
    }

    static void writeToStream(BitMatrix matrix, String format, OutputStream stream) throws IOException {
        BufferedImage image = toBufferedImage(matrix);
        if (!ImageIO.write(image, format, stream)) {
            throw new IOException("Could not write an image of format " + format);
        }
    }

    private static final int BLACK = 0xFF000000;
    private static final int WHITE = 0xFFFFFFFF;

    private static BufferedImage toBufferedImage(BitMatrix matrix) {
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                image.setRGB(x, y, matrix.get(x, y) ? BLACK : WHITE);
            }
        }
        return image;
    }

    /**
     * 根据行程id 获取行程日历信息
     * @author wangxinhai
     * @param id
     * @return
     */
    public List<TraCalendar> getTraCalendarByTraId(String id){
        List<TraCalendar> list = mapper.getTraCalendarByTraId(id);
        if(list.size()>0){
            list.get(0).setSelectFlag("1");
        }
        return list;
    }

    /**
     * 行程日历添加
     * @author wangxinhai
     * @param traCalendar
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse addTraCalendar(TraCalendar traCalendar){
        List<TraCalendar> traCalendarList = mapper.getTraCalendarByTraIdAndDate(traCalendar.getTraId(),traCalendar.getTraDate());
        if(traCalendarList.size() > 0){
            return AjaxResponse.of(20001, "该行程日期已存在");
        }
        EntityUtils.setCreatAndUpdatInfo(traCalendar);
        int num = mapper.addTraCalendar(traCalendar);
        if(num > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 修改日历
     * @param traCalendar
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updateTraCalendar(TraCalendar traCalendar){
        EntityUtils.setUpdatedInfo(traCalendar);
        int num  = mapper.updateTraCalendar(traCalendar);
        if(num>0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 日期删除
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse delTraCalendar(String id){
        TraCalendar traCalendar = new TraCalendar();
        traCalendar.setId(id);
        EntityUtils.setUpdatedInfo(traCalendar);
        int num = mapper.delTraCalendar(traCalendar);
        if(num>0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 获取行程日历
     * @param id
     * @return
     */
    public TraCalendar getTraCalendar(String id){
        return mapper.getTraCalendar(id);
    }

    /**
     * 根据行程 日历获取行程列表
     * @author wangxinhai
     * @param traPlace
     * @return
     */
    public List<TraPlaceTraItem> getTraPlaceItemList(TraPlace traPlace){
        return  mapper.getPlaceTraItemList(traPlace);
    }

    /**
     * 行程地点添加
     * @author wangxinhai
     * @param traPlace
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse addTraPlace(TraPlace traPlace){
        int num = mapper.getTraPlaceMaxSort(traPlace);
        traPlace.setSort(++num);
        EntityUtils.setCreatAndUpdatInfo(traPlace);
        // 敏感词过滤
        traPlace.setName(SensitiveWordUtils.filterStr(traPlace.getName()));
        traPlace.setEnName(SensitiveWordUtils.filterStr(traPlace.getEnName()));
        traPlace.setOverview(SensitiveWordUtils.filterStr(traPlace.getOverview()));
        traPlace.setTips(SensitiveWordUtils.filterStr(traPlace.getTips()));
        int result = mapper.insertTraPlace(traPlace);
        if(result > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 获取地点
     * @param id
     * @return
     */
    public TraPlace getTraPlace(String id){
        return mapper.getTraPlaceById(id);
    }

    /**
     * 更新地点
     * @param traPlace
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updateTraPlace(TraPlace traPlace){
        int num  = mapper.updateTraPlace(traPlace);
        if(num>0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 删除地点
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse delTraPlace(String id){
        TraPlace traPlace = new TraPlace();
        traPlace.setId(id);
        EntityUtils.setUpdatedInfo(traPlace);
        int num = mapper.delTraPlace(traPlace);
        if(num > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 切换顺序
     * @param oldId
     * @param newId
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse changeTraItemSort(String oldId,String newId){
        TraPlace traOldPlace = mapper.getTraPlaceById(oldId);
        TraPlace traNewPlace = mapper.getTraPlaceById(newId);
        TraPlace tpOld = new TraPlace();
        TraPlace tpNew = new TraPlace();
        tpOld.setId(traOldPlace.getId());
        tpOld.setSort(traNewPlace.getSort());
        EntityUtils.setUpdatedInfo(tpOld);
        tpNew.setId(traNewPlace.getId());
        tpNew.setSort(traOldPlace.getSort());
        EntityUtils.setUpdatedInfo(tpNew);
        mapper.updatePlace(tpOld);
        mapper.updatePlace(tpNew);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 更新行程总览
     * @param traManageVo
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updOverView(TraManageVo traManageVo){
        EntityUtils.setUpdatedInfo(traManageVo);
        // 敏感词过滤
        traManageVo.setOverview(SensitiveWordUtils.filterStr(traManageVo.getOverview()));
        traManageVo.setTraRemind(SensitiveWordUtils.filterStr(traManageVo.getTraRemind()));
        int num = mapper.updOverView(traManageVo);
        if(num > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 导入
     * @param in
     * @param fileName
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse importExcel(InputStream in,String fileName) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy/MM/dd");
        SimpleDateFormat sdfMin = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Map<String,List<List<Object>>> map= getBankListByExcel(in,fileName);
        List<List<Object>> traListObj = map.get("traList");
        if(traListObj.size() == 0){
            return AjaxResponse.of(ResponseCode.FAIL,"暂无数据!");
        }
        if(traListObj.size() > 1){
            return AjaxResponse.of(ResponseCode.FAIL,"行程基本信息只能导入一条!");
        }
        Query query = new Query(new HashMap<>());
        List<Member> alllist = mapper.findByParm(query);
        List<TraCalendar> calendarAllList = mapper.findCalendarAll();
        List<String> idNumList =alllist.stream().map(Member::getIdNum).collect(Collectors.toList()); //证件号码
        List<String> phoneList = alllist.stream().map(Member::getPhone).collect(Collectors.toList());//手机号码
        List<Date> calendarList = calendarAllList.stream().map(TraCalendar::getTraDate).collect(Collectors.toList());//行程日期
        StringBuilder str = new StringBuilder();
        boolean flag = false;
        //行程-基本信息
        List<TraHk> traHkList = new ArrayList<>(); //领队list
        List<Object> traList = traListObj.get(0);
        if(StringUtils.isEmpty(traList.get(0).toString())){
            str.append("基本信息列行程名称不能为空,");
            flag = true;
        }
        if(StringUtils.isEmpty(traList.get(2).toString())){
            str.append("基本信息列起始日期不能为空,");
            flag = true;
        }
        if(StringUtils.isEmpty(traList.get(3).toString())){
            str.append("基本信息列截止日期不能为空,");
            flag = true;
        }
        if(StringUtils.isEmpty(traList.get(6).toString())){
            str.append("基本信息列行程管家不能为空,");
            flag = true;
        }
        //行程
        TraManageVo traManageVo = new TraManageVo();
        if(!flag){
            EntityUtils.setCreatAndUpdatInfo(traManageVo);
            traManageVo.setName(traList.get(0).toString());
            traManageVo.setCustomerName(traList.get(1).toString());
            traManageVo.setStartDate(sdf.parse(traList.get(2).toString()));
            traManageVo.setEndDate(sdf.parse(traList.get(3).toString()));
            traManageVo.setContact(traList.get(4).toString());
            traManageVo.setPhone(traList.get(5).toString());
            if(!StringUtils.isEmpty(traList.get(6).toString())){
                Member member = mapper.getMemberByName(traList.get(6).toString(),"2");
                if(member != null){
                    traManageVo.setHousekeeperId(member.getId());
                }
            }
            if(7 < traList.size()){
                if(!StringUtils.isEmpty(traList.get(7).toString())){
                    String[] guideStr = traList.get(7).toString().split(",");
                    TraHk traHk = null;
                    for(int i = 0;i<guideStr.length;i++){
                        Member member = mapper.getMemberByName(guideStr[i],"3");
                        traHk = new TraHk();
                        EntityUtils.setCreatAndUpdatInfo(traHk);
                        traHk.setTraId(traManageVo.getId());
                        traHk.setHkId(member.getId());
                        traHkList.add(traHk);
                    }
                }
            }
            if(8 < traList.size()){
                traManageVo.setUrgentPhone(traList.get(8).toString());
            }
            if(9 < traList.size()){
                traManageVo.setNote(traList.get(9).toString());
            }
        }
        //行程-基本信息
        //行程-成员信息
        List<List<Object>> memberListObj = map.get("memberList");
        List<TraMember> traMemberList = new ArrayList<>();//行程会员
        List<Member> memList = new ArrayList<>();//会员
        TraMember traMember = null; //tra_member
        Member member = null;       //csr_member
        if(memberListObj != null){
            for(int i = 0;i<memberListObj.size();i++){
                traMember = new TraMember();
                member = new Member();
                EntityUtils.setCreatAndUpdatInfo(member);
                EntityUtils.setCreatAndUpdatInfo(traMember);
                traMember.setMemId(member.getId());
                traMember.setLeaderFlag("0");
                traMember.setTraId(traManageVo.getId());
                List<Object> memberList = memberListObj.get(i);
                if(StringUtils.isEmpty(memberList.get(0).toString())){
                    str.append("成员信息列第" + (i + 1) + "条数据姓名不能为空,");
                    flag = true;
                }
                if(!StringUtils.isEmpty(memberList.get(1).toString())){
                    if("男".equals(memberList.get(1).toString())){
                        member.setGender("1");
                    }else if("女".equals(memberList.get(1).toString())){
                        member.setGender("0");
                    }else{
                        str.append("成员信息列第" + (i + 1) + "条数据性别不存在,");
                        flag = true;
                    }
                }
                if(StringUtils.isEmpty(memberList.get(2).toString())){
                    str.append("成员信息列第" + (i + 1) + "条数据手机号码不能为空,");
                    flag = true;
                }else{
                    if(!isMobile(memberList.get(2).toString())){
                        str.append("成员信息列第" + (i + 1) + "条手机号码格式不正确,");
                        flag = true;
                    }
                    if(phoneList.contains(memberList.get(2).toString())){
                        str.append("成员信息列第" + (i + 1) + "条手机号码重复,");
                        flag = true;
                    }else{
                        phoneList.add(memberList.get(2).toString());
                    }
                }
                if(StringUtils.isEmpty(memberList.get(3).toString())){
                    str.append("成员信息列第" + (i + 1) + "条数据证件类型不能为空,");
                    flag = true;
                }else{
                    if(idNumList.contains(memberList.get(4).toString())){
                        str.append("成员信息列第" + (i + 1) + "条证件号码重复,");
                        flag = true;
                    }else{
                        idNumList.add(memberList.get(4).toString());
                    }
                    if("身份证".equals(memberList.get(3).toString())){
                        member.setIdType("0");
                    /*if(!isIdCard(memberList.get(4).toString())){
                        str.append("成员信息列第" + (i + 1) + "条数据证件号码格式不正确,");
                        flag = true;
                    }*/
                    }else if("护照".equals(memberList.get(3).toString())){
                        member.setIdType("1");
                    /*if(!isPassPort(memberList.get(4).toString())){
                        str.append("成员信息列第" + (i + 1) + "条数据证件号码格式不正确,");
                        flag = true;
                    }*/
                    }else if("台胞证".equals(memberList.get(3).toString())){
                        member.setIdType("2");
                    /*if(!isTbCard(memberList.get(4).toString())){
                        str.append("成员信息列第" + (i + 1) + "条数据证件号码格式不正确,");
                        flag = true;
                    }*/
                    }else{
                        str.append("成员信息列第" + (i + 1) + "条数据证件类型存在,");
                        flag = true;
                    }
                }
                if(StringUtils.isEmpty(memberList.get(4).toString())){
                    str.append("成员信息列第" + (i + 1) + "条数据证件号码不能为空,");
                    flag = true;
                }
                if(6 < memberList.size()){
                    if(!StringUtils.isEmpty(memberList.get(6).toString())){
                        if("是".equals(memberList.get(6).toString())){
                            member.setTalentFlag("1");
                        }else{
                            member.setTalentFlag("0");
                        }
                    }
                }

                member.setName(memberList.get(0).toString());
                member.setPhone(memberList.get(2).toString());
                member.setIdNum(memberList.get(4).toString());
                if(5 < memberList.size()){
                    member.setSource(memberList.get(5).toString());
                }
                if(7 < memberList.size()){
                    member.setNote(memberList.get(7).toString());
                }
                memList.add(member);
                traMemberList.add(traMember);
            }
        }

        //行程-成员信息
        //行程-行程信息
        List<List<Object>> traItemListObj = map.get("traItemList");
        List<TraCalendar> traCalenList = new ArrayList<>(); //日历
        List<TraPlace> traPlaceList = new ArrayList<>();    //地点
        List<TraItem> itemList = new ArrayList<>();         //行程事项
        TraCalendar traCalendar = null;
        TraPlace traPlace = null;
        TraItem traItem = null;
        List<Map<Date,Object>> l = new ArrayList<>();//日历日期集合List
        List<Map<String,Object>> lp = new ArrayList<>();//地点集合List
        if(traItemListObj != null){
            for(int i = 0;i<traItemListObj.size();i++){
                Map<Date,Object> traDateMap = new HashMap<>();//日历日期集合map
                Map<String,Object> placeMap = new HashMap<>();//地点集合map
                traCalendar = new TraCalendar();
                traPlace = new TraPlace();
                traItem = new TraItem();

                List<Object> traItemList = traItemListObj.get(i);
                if(StringUtils.isEmpty(traItemList.get(0).toString())){
                    str.append("行程信息列第" + (i + 1) + "条数据日期不能为空,");
                    flag = true;
                }else{
                    if(calendarList.contains(sdf.parse(traItemList.get(0).toString()))){
                        str.append("行程信息列第" + (i + 1) + "条数据日期已存在,");
                        flag = true;
                    }else{
                        if(l.size() == 0){
                            EntityUtils.setCreatAndUpdatInfo(traCalendar);
                            EntityUtils.setCreatAndUpdatInfo(traItem);
                            traCalendar.setTraDate(sdf.parse(traItemList.get(0).toString()));
                            traCalendar.setTraId(traManageVo.getId());
                            //事项
                            //判断地点有没有重复
                            if(lp.size() == 0){
                                EntityUtils.setCreatAndUpdatInfo(traPlace);
                                //地点
                                traPlace.setTraId(traManageVo.getId());
                                traPlace.setCalendarId(traCalendar.getId());
                                if(StringUtils.isEmpty(traItemList.get(1).toString())){
                                    str.append("行程信息列第" + (i + 1) + "条数据地点(中文)不能为空,");
                                    flag = true;
                                }else{
                                    traPlace.setName(traItemList.get(1).toString());
                                }
                                traPlace.setEnName(traItemList.get(2).toString());
                                traPlace.setOverview(traItemList.get(3).toString());
                                traPlace.setTips(traItemList.get(4).toString());
                                traPlace.setSort(i);
                                traItem.setPlaceId(traPlace.getId());
                                traPlaceList.add(traPlace);
                                //第一次添加地点 把地点放进map集合 key:地点中文名 value:地点id(placeId)
                                placeMap.put(traPlace.getName(),traPlace.getId());
                                lp.add(placeMap);
                            }else{
                                boolean repeatPlaceFlag = false;//日期重复标识
                                String placeId = "";
                                for(int j = 0;j<lp.size();j++){
                                    if(lp.get(j).get(traItemList.get(1).toString()) == null){ //不重复
                                        repeatPlaceFlag = false;
                                        placeId = traPlace.getId();
                                    }else{
                                        repeatPlaceFlag = true;
                                        placeId = lp.get(j).get(traItemList.get(1).toString()).toString();
                                    }
                                }
                                if(repeatPlaceFlag){//重复
                                    traItem.setPlaceId(placeId);
                                }else{
                                    EntityUtils.setCreatAndUpdatInfo(traPlace);
                                    //地点
                                    traPlace.setTraId(traManageVo.getId());
                                    traPlace.setCalendarId(traCalendar.getId());
                                    if(StringUtils.isEmpty(traItemList.get(1).toString())){
                                        str.append("行程信息列第" + (i + 1) + "条数据地点(中文)不能为空,");
                                        flag = true;
                                    }else{
                                        traPlace.setName(traItemList.get(1).toString());
                                    }
                                    traPlace.setEnName(traItemList.get(2).toString());
                                    traPlace.setOverview(traItemList.get(3).toString());
                                    traPlace.setTips(traItemList.get(4).toString());
                                    traPlace.setSort(i);
                                    traItem.setPlaceId(traPlace.getId());
                                    traPlaceList.add(traPlace);
                                    //第一次添加地点 把地点放进map集合 key:地点中文名 value:地点id(placeId)
                                    placeMap.put(traPlace.getName(),traPlace.getId());
                                    lp.add(placeMap);
                                }
                            }
                            if(StringUtils.isEmpty(traItemList.get(5).toString())){
                                str.append("行程信息列第" + (i + 1) + "条数据事项类型不能为空,");
                                flag = true;
                            }else{
                                if(getTypes(traItemList.get(5).toString()) == null){
                                    str.append("行程信息列第" + (i + 1) + "条数据事项类型不存在,");
                                    flag = true;
                                }else{
                                    traItem.setType(getTypes(traItemList.get(5).toString()));
                                }
                            }
                            if(!StringUtils.isEmpty(traItemList.get(6).toString())){
                                traItem.setStartTime(sdfMin.parse(traItemList.get(0) + " " + traItemList.get(6).toString()));
                            }
                            if(!StringUtils.isEmpty(traItemList.get(7).toString())){
                                traItem.setEndTime(sdfMin.parse(traItemList.get(0) + " " + traItemList.get(7).toString()));
                            }
                            if(StringUtils.isEmpty(traItemList.get(8).toString())){
                                str.append("行程信息列第" + (i + 1) + "条数据事项(中文)不能为空,");
                                flag = true;
                            }else{
                                traItem.setName(traItemList.get(8).toString());
                            }
                            if(9 < traItemList.size()){
                                traItem.setEnName(traItemList.get(9).toString());
                            }
                            if(10 < traItemList.size()){
                                traItem.setLongitude(traItemList.get(10).toString());
                            }
                            if(11 < traItemList.size()){
                                traItem.setLatitude(traItemList.get(11).toString());
                            }
                            if(12 < traItemList.size()){
                                traItem.setOverview(traItemList.get(12).toString());
                            }
                            if(13 < traItemList.size()){
                                traItem.setTips(traItemList.get(13).toString());
                            }
                            if(14 < traItemList.size()){
                                if(!StringUtils.isEmpty(traItemList.get(14).toString())){
                                    if("是".equals(traItemList.get(14).toString())){
                                        traItem.setReserve("1");
                                    }else{
                                        traItem.setReserve("0");
                                    }
                                }
                            }else{
                                traItem.setReserve("0");
                            }
                            if(15 < traItemList.size()){
                                traItem.setContent(traItemList.get(15).toString());
                            }
                            //第一次添加日期 把日期放进map集合 key:日期 value:日期id(calendarId)
                            traDateMap.put(sdf.parse(traItemList.get(0).toString()),traCalendar.getId());
                            l.add(traDateMap);
                            traCalenList.add(traCalendar);
                            itemList.add(traItem);
                        }else{
                            boolean repeatFlag = false;//日期重复标识
                            String calendarId = "";
                            for(int j = 0;j<l.size();j++){
                                if(l.get(j).get(sdf.parse(traItemList.get(0).toString())) == null){
                                    //不重复
                                    repeatFlag = false;
                                    //calendarId = traCalendar.getId();
                                }else{
                                    //重复
                                    repeatFlag = true;
                                    calendarId = l.get(j).get(sdf.parse(traItemList.get(0).toString())).toString();
                                }
                            }
                            if(repeatFlag){ //重复
                                //地点
                                EntityUtils.setCreatAndUpdatInfo(traItem);
                                //事项
                                //判断地点有没有重复
                                if(lp.size() == 0){
                                    EntityUtils.setCreatAndUpdatInfo(traPlace);
                                    //地点
                                    traPlace.setTraId(traManageVo.getId());
                                    //根据重复的日期key 去找添加过的日期的id
                                    traPlace.setCalendarId(calendarId);
                                    if(StringUtils.isEmpty(traItemList.get(1).toString())){
                                        str.append("行程信息列第" + (i + 1) + "条数据地点(中文)不能为空,");
                                        flag = true;
                                    }else{
                                        traPlace.setName(traItemList.get(1).toString());
                                    }
                                    traPlace.setEnName(traItemList.get(2).toString());
                                    traPlace.setOverview(traItemList.get(3).toString());
                                    traPlace.setTips(traItemList.get(4).toString());
                                    traPlace.setSort(i);
                                    traItem.setPlaceId(traPlace.getId());
                                    traPlaceList.add(traPlace);
                                    //第一次添加地点 把地点放进map集合 key:地点中文名 value:地点id(placeId)
                                    placeMap.put(traPlace.getName(),traPlace.getId());
                                    lp.add(placeMap);
                                }else{
                                    boolean repeatPlaceFlag = false;//日期重复标识
                                    String placeId = "";
                                    for(int j = 0;j<lp.size();j++){
                                        if(lp.get(j).get(traItemList.get(1).toString()) == null){ //不重复
                                            repeatPlaceFlag = false;
                                            placeId = traPlace.getId();
                                        }else{
                                            repeatPlaceFlag = true;
                                            placeId = lp.get(j).get(traItemList.get(1).toString()).toString();
                                        }
                                    }
                                    if(repeatPlaceFlag){//重复
                                        traItem.setPlaceId(placeId);
                                    }else{
                                        EntityUtils.setCreatAndUpdatInfo(traPlace);
                                        //地点
                                        traPlace.setTraId(traManageVo.getId());
                                        traPlace.setCalendarId(calendarId);
                                        if(StringUtils.isEmpty(traItemList.get(1).toString())){
                                            str.append("行程信息列第" + (i + 1) + "条数据地点(中文)不能为空,");
                                            flag = true;
                                        }else{
                                            traPlace.setName(traItemList.get(1).toString());
                                        }
                                        traPlace.setEnName(traItemList.get(2).toString());
                                        traPlace.setOverview(traItemList.get(3).toString());
                                        traPlace.setTips(traItemList.get(4).toString());
                                        traPlace.setSort(i);
                                        traItem.setPlaceId(traPlace.getId());
                                        traPlaceList.add(traPlace);
                                        //第一次添加地点 把地点放进map集合 key:地点中文名 value:地点id(placeId)
                                        placeMap.put(traPlace.getName(),traPlace.getId());
                                        lp.add(placeMap);
                                    }
                                }
                                //事项
                                if(StringUtils.isEmpty(traItemList.get(5).toString())){
                                    str.append("行程信息列第" + (i + 1) + "条数据事项类型不能为空,");
                                    flag = true;
                                }else{
                                    if(getTypes(traItemList.get(5).toString()) == null){
                                        str.append("行程信息列第" + (i + 1) + "条数据事项类型不存在,");
                                        flag = true;
                                    }else{
                                        traItem.setType(getTypes(traItemList.get(5).toString()));
                                    }
                                }
                                if(!StringUtils.isEmpty(traItemList.get(6).toString())){
                                    traItem.setStartTime(sdfMin.parse(traItemList.get(0) + " " + traItemList.get(6).toString()));
                                }
                                if(!StringUtils.isEmpty(traItemList.get(7).toString())){
                                    traItem.setEndTime(sdfMin.parse(traItemList.get(0) + " " + traItemList.get(7).toString()));
                                }
                                if(StringUtils.isEmpty(traItemList.get(8).toString())){
                                    str.append("行程信息列第" + (i + 1) + "条数据事项(中文)不能为空,");
                                    flag = true;
                                }else{
                                    traItem.setName(traItemList.get(8).toString());
                                }
                                if(9 < traItemList.size()){
                                    traItem.setEnName(traItemList.get(9).toString());
                                }
                                if(10 < traItemList.size()){
                                    traItem.setLongitude(traItemList.get(10).toString());
                                }
                                if(11 < traItemList.size()){
                                    traItem.setLatitude(traItemList.get(11).toString());
                                }
                                if(12 < traItemList.size()){
                                    traItem.setOverview(traItemList.get(12).toString());
                                }
                                if(13 < traItemList.size()){
                                    traItem.setTips(traItemList.get(13).toString());
                                }
                                if(14 < traItemList.size()){
                                    if(!StringUtils.isEmpty(traItemList.get(14).toString())){
                                        if("是".equals(traItemList.get(14).toString())){
                                            traItem.setReserve("1");
                                        }else{
                                            traItem.setReserve("0");
                                        }
                                    }
                                }else{
                                    traItem.setReserve("0");
                                }
                                if(15 < traItemList.size()){
                                    traItem.setContent(traItemList.get(15).toString());
                                }
                                itemList.add(traItem);
                            }else{//不重复
                                EntityUtils.setCreatAndUpdatInfo(traCalendar);
                                EntityUtils.setCreatAndUpdatInfo(traItem);
                                traCalendar.setTraDate(sdf.parse(traItemList.get(0).toString()));
                                traCalendar.setTraId(traManageVo.getId());
                                //地点
                                //判断地点有没有重复
                                if(lp.size() == 0){
                                    EntityUtils.setCreatAndUpdatInfo(traPlace);
                                    //地点
                                    traPlace.setTraId(traManageVo.getId());
                                    //根据重复的日期key 去找添加过的日期的id
                                    traPlace.setCalendarId(traCalendar.getId());
                                    if(StringUtils.isEmpty(traItemList.get(1).toString())){
                                        str.append("行程信息列第" + (i + 1) + "条数据地点(中文)不能为空,");
                                        flag = true;
                                    }else{
                                        traPlace.setName(traItemList.get(1).toString());
                                    }
                                    traPlace.setEnName(traItemList.get(2).toString());
                                    traPlace.setOverview(traItemList.get(3).toString());
                                    traPlace.setTips(traItemList.get(4).toString());
                                    traPlace.setSort(i);
                                    traItem.setPlaceId(traPlace.getId());
                                    traPlaceList.add(traPlace);
                                    //第一次添加地点 把地点放进map集合 key:地点中文名 value:地点id(placeId)
                                    placeMap.put(traPlace.getName(),traPlace.getId());
                                    lp.add(placeMap);
                                }else{
                                    boolean repeatPlaceFlag = false;//日期重复标识
                                    String placeId = "";
                                    for(int j = 0;j<lp.size();j++){
                                        if(lp.get(j).get(traItemList.get(1).toString()) == null){ //不重复
                                            repeatPlaceFlag = false;
                                            placeId = traPlace.getId();
                                        }else{
                                            repeatPlaceFlag = true;
                                            placeId = lp.get(j).get(traItemList.get(1).toString()).toString();
                                        }
                                    }
                                    if(repeatPlaceFlag){//重复
                                        traItem.setPlaceId(placeId);
                                    }else{
                                        EntityUtils.setCreatAndUpdatInfo(traPlace);
                                        //地点
                                        traPlace.setTraId(traManageVo.getId());
                                        traPlace.setCalendarId(traCalendar.getId());
                                        if(StringUtils.isEmpty(traItemList.get(1).toString())){
                                            str.append("行程信息列第" + (i + 1) + "条数据地点(中文)不能为空,");
                                            flag = true;
                                        }else{
                                            traPlace.setName(traItemList.get(1).toString());
                                        }
                                        traPlace.setEnName(traItemList.get(2).toString());
                                        traPlace.setOverview(traItemList.get(3).toString());
                                        traPlace.setTips(traItemList.get(4).toString());
                                        traPlace.setSort(i);
                                        traItem.setPlaceId(traPlace.getId());
                                        traPlaceList.add(traPlace);
                                        //第一次添加地点 把地点放进map集合 key:地点中文名 value:地点id(placeId)
                                        placeMap.put(traPlace.getName(),traPlace.getId());
                                        lp.add(placeMap);
                                    }
                                }
                                //事项
                                if(StringUtils.isEmpty(traItemList.get(5).toString())){
                                    str.append("行程信息列第" + (i + 1) + "条数据事项类型不能为空,");
                                    flag = true;
                                }else{
                                    if(getTypes(traItemList.get(5).toString()) == null){
                                        str.append("行程信息列第" + (i + 1) + "条数据事项类型不存在,");
                                        flag = true;
                                    }else{
                                        traItem.setType(getTypes(traItemList.get(5).toString()));
                                    }
                                }
                                if(!StringUtils.isEmpty(traItemList.get(6).toString())){
                                    traItem.setStartTime(sdfMin.parse(traItemList.get(0) + " " + traItemList.get(6).toString()));
                                }
                                if(!StringUtils.isEmpty(traItemList.get(7).toString())){
                                    traItem.setEndTime(sdfMin.parse(traItemList.get(0) + " " + traItemList.get(7).toString()));
                                }
                                if(StringUtils.isEmpty(traItemList.get(8).toString())){
                                    str.append("行程信息列第" + (i + 1) + "条数据事项(中文)不能为空,");
                                    flag = true;
                                }else{
                                    traItem.setName(traItemList.get(8).toString());
                                }
                                if(9 < traItemList.size()){
                                    traItem.setEnName(traItemList.get(9).toString());
                                }
                                if(10 < traItemList.size()){
                                    traItem.setLongitude(traItemList.get(10).toString());
                                }
                                if(11 < traItemList.size()){
                                    traItem.setLatitude(traItemList.get(11).toString());
                                }
                                if(12 < traItemList.size()){
                                    traItem.setOverview(traItemList.get(12).toString());
                                }
                                if(13 < traItemList.size()){
                                    traItem.setTips(traItemList.get(13).toString());
                                }
                                if(14 < traItemList.size()){
                                    if(!StringUtils.isEmpty(traItemList.get(14).toString())){
                                        if("是".equals(traItemList.get(14).toString())){
                                            traItem.setReserve("1");
                                        }else{
                                            traItem.setReserve("0");
                                        }
                                    }
                                }else{
                                    traItem.setReserve("0");
                                }
                                if(15 < traItemList.size()){
                                    traItem.setContent(traItemList.get(15).toString());
                                }
                                //添加日期 把日期放进map集合 key:日期 value:日期id(calendarId)
                                traDateMap.put(sdf.parse(traItemList.get(0).toString()),traCalendar.getId());
                                l.add(traDateMap);
                                traCalenList.add(traCalendar);
                                itemList.add(traItem);
                            }
                        }
                    }
                }
            }
        }

        //行程-行程信息
        if (flag) {
            String s = str.substring(0, str.length() - 1);
            return AjaxResponse.of(200001, "导入失败," + s);
        }
        try {
            mapper.insertSelective(traManageVo);            //行程
            if(traHkList.size() > 0){
                mapper.insertTraHk(traHkList);              //领队
            }
            if(memList.size() > 0){
                mapper.insertMemberList(memList);           //会员
            }
            if(traMemberList.size() > 0){
                mapper.insertTraMemberList(traMemberList);  //行程会员
            }
            if(traCalenList.size() > 0){
                mapper.insertCalendarList(traCalenList);    //行程日历
            }
            if(traPlaceList.size() > 0){
                mapper.insertPlaceList(traPlaceList);       //行程地点
            }
            if(itemList.size() > 0){
                mapper.insertTraItemList(itemList);         //行程事项
            }
            return AjaxResponse.of(ResponseCode.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResponse.of(ResponseCode.FAIL,"导入失败");
        }
    }

    /**
     * 获取事项类型
     * @param typeName
     * @return
     */
    public String getTypes(String typeName){
        if("提示".equals(typeName)){
            return "1";
        }else if("机场".equals(typeName)){
            return "2";
        }else if("交通中".equals(typeName)){
            return "3";
        }else if("车站".equals(typeName)){
            return "4";
        }else if("码头".equals(typeName)){
            return "5";
        }else if("住宿".equals(typeName)){
            return "6";
        }else if("购物".equals(typeName)){
            return "7";
        }else if("用餐".equals(typeName)){
            return "8";
        }else if("景点".equals(typeName)){
            return "9";
        }else{
            return null;
        }
    }

    /**
     * 获取多sheet导入的内容
     */
    private final static String Excel_2003 = ".xls"; //2003 版本的excel
    private final static String Excel_2007 = ".xlsx"; //2007 版本的excel
    public Map<String,List<List<Object>>> getBankListByExcel(InputStream in,String fileName) throws Exception{
        Map<String,List<List<Object>>> map = new HashMap<>();

        List<List<Object>> list = null;
        //创建Excel工作簿
        Workbook work = this.getWorkbook(in, fileName);
        if(work == null) {
            throw new Exception("创建Excel工作簿为空！");
        }
        Sheet sheet = null;
        Row row = null;
        Cell cell = null;
        list = new ArrayList<List<Object>>();
        //遍历Excel中的所有sheet
        for(int i = 0; i<work.getNumberOfSheets(); i++) {
            //如果Excel就一页一个sheet则i=0
            if(i==0){
                sheet = work.getSheetAt(i);
                if(sheet == null) {continue;}
                //遍历当前sheet中的所有行
                //int totalRow = sheet.getPhysicalNumberOfRows();//如果excel有格式，这种方式取值不准确
                int totalRow = sheet.getPhysicalNumberOfRows();
                List<List<Object>> traList = new ArrayList<List<Object>>();
                for(int j = 1; j<totalRow; j++) {
                    row = sheet.getRow(j);
                    if(!isRowEmpty(row)) {
                        //if(row != null && !"".equals(row)) {
                        //获取第一个单元格的数据是否存在
                        Cell fristCell=row.getCell(0);
                        if(fristCell!=null){
                            //遍历所有的列
                            List<Object> li = new ArrayList<Object>();
                            //int totalColum = row.getLastCellNum();
                            for(int y = row.getFirstCellNum(); y<row.getLastCellNum(); y++) {
                                cell = row.getCell(y);
                                if(cell == null){
                                    String callCal ="";
                                    li.add(callCal);
                                }else{
                                    String callCal = this.getCellValue(cell)+"";
                                    li.add(callCal);
                                }
                            }
                            list.add(li);
                            traList.add(li);
                        }

                    }else if(isRowEmpty(row)){
                        continue;
                    }
                    map.put("traList",traList);
                }
            }else{
                //如果是第二页sheet要从第二行遍历数据去掉标题行即i>0
                sheet = work.getSheetAt(i);
                if(sheet == null) {continue;}
                //遍历当前sheet中的所有行
                int totalRow = sheet.getPhysicalNumberOfRows();
                //j从第二行读取数据即j=1跳过标题行
                List<List<Object>> memberList = new ArrayList<List<Object>>();;
                List<List<Object>> traItemList = new ArrayList<List<Object>>();;
                for(int j = 1; j<totalRow; j++) {
                    row = sheet.getRow(j);
                    if(!isRowEmpty(row)) {
                        //if(row != null && !"".equals(row)) {
                        //获取第一个单元格的数据是否存在
                        Cell fristCell=row.getCell(0);
                        if(fristCell!=null){
                            //遍历所有的列
                            List<Object> li = new ArrayList<Object>();
                            //int totalColum = row.getLastCellNum();
                            for(int y = row.getFirstCellNum(); y<row.getLastCellNum(); y++) {
                                cell = row.getCell(y);
                                if(cell == null){
                                    String callCal ="";
                                    li.add(callCal);
                                }else{
                                    String callCal = this.getCellValue(cell)+"";
                                    li.add(callCal);
                                }
                            }
                            list.add(li);
                            if(i == 1){
                                memberList.add(li);
                            }else{
                                traItemList.add(li);
                            }
                        }

                    }else if(isRowEmpty(row)){
                        continue;
                    }
                    if(i == 1){
                        map.put("memberList",memberList);
                    }else{
                        map.put("traItemList",traItemList);
                    }

                }
            }
        }
        in.close();
        return map;
    }
    /**
     * 判断行是否为空
     * @param row
     * @return
     */
    public static boolean isRowEmpty(Row row) {
        for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK)
                return false;
        }
        return true;
    }
    /**
     * 描述：根据文件后缀，自动适应上传文件的版本
     * @param inStr,fileName
     * @return
     * @throws Exception
     * */
    public Workbook getWorkbook(InputStream inStr,String fileName) throws Exception {
        Workbook work = null;
        String fileType = fileName.substring(fileName.lastIndexOf("."));
        if(Excel_2003.equals(fileType)){
            work=new HSSFWorkbook(inStr);//2003 版本的excel
        }else if(Excel_2007.equals(fileType)) {
            work=new XSSFWorkbook(inStr);//2007 版本的excel
        }else {
            throw new Exception("解析文件格式有误！");
        }
        return work;
    }

    /**
     * 描述：对表格中数值进行格式化
     * @param cell
     * @return
     * */
    public Object getCellValue(Cell cell) {
        String result = new String();
        switch (cell.getCellType()) {
            case HSSFCell.CELL_TYPE_FORMULA:  //Excel公式
                try {
                    result = String.valueOf(cell.getNumericCellValue());
                } catch (IllegalStateException e) {
                    result = String.valueOf(cell.getRichStringCellValue());
                }
                break;
            case HSSFCell.CELL_TYPE_NUMERIC:// 数字类型
                if (HSSFDateUtil.isCellDateFormatted(cell)) {// 处理日期格式、时间格式
                    SimpleDateFormat sdf;
                    if (cell.getCellStyle().getDataFormat() == HSSFDataFormat
                            .getBuiltinFormat("h:mm")) {
                        sdf = new SimpleDateFormat("HH:mm");
                    } else {// 日期
                        sdf = new SimpleDateFormat("yyyy-MM-dd");
                    }
                    Date date = cell.getDateCellValue();
                    result = sdf.format(date);
                } else if (cell.getCellStyle().getDataFormat() == 58) {
                    //如果导出格式是yyyy/MM/dd那么如下
                    //SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
                    //如果导出格式是例如：9月10日那么如下
                    SimpleDateFormat sdf = new SimpleDateFormat("M月d日");
                    double value = cell.getNumericCellValue();
                    Date date = org.apache.poi.ss.usermodel.DateUtil
                            .getJavaDate(value);
                    result = sdf.format(date);
                } else {
                    double value = cell.getNumericCellValue();
                    CellStyle style = cell.getCellStyle();
                    DecimalFormat format = new DecimalFormat();
                    String temp = style.getDataFormatString();
                    // 单元格设置成常规
                    if (temp.equals("General")) {
                        format.applyPattern("#.##");
                    }
                    result = format.format(value);
                }
                break;
            case HSSFCell.CELL_TYPE_STRING:// String类型
                result = cell.getRichStringCellValue().toString();
                break;
            case HSSFCell.CELL_TYPE_BLANK:
                result = "";
            default:
                result = "";
                break;
        }
        return result;
    }

    public String getFormat(String str) {
        if(str.equals("null")) {
            str="";
            return str;
        }else{
            return str;
        }
    }
    public Integer getFormats(Integer str) {
        if(str==null) {
            str=0;
            return str;
        }else{
            return str;
        }
    }

    /**
     * 获取字符串中的数字订单号、数字金额等，如从"USD 374.69"中获取到374.69、从“交易单号：66666666666”获取到66666666666
     * @param
     * @return
     */
    public static String getFormatNumber(String str){
        str = str.trim();
        Pattern p = Pattern.compile("[0-9]");
        int indexNum = 0;
        int lenght = str.length();
        String num = "";
        for(int i=0;i<lenght;i++){
            num += str.charAt(i);
            Matcher m = p.matcher(num);
            if(m.find()){
                indexNum = i;
                break;
            }
        }
        String formatNumber = str.substring(indexNum,lenght);
        return formatNumber;
    }



    //把list内容逐个取出来放进User实体类中
    public static <T> void listToModel(List<Object> list, T t) throws Exception {
        Field[] fields = t.getClass().getDeclaredFields();
        if (list.size() != fields.length) {
            return;
        }
        for (int k = 0, len = fields.length; k < len; k++) {
            // 根据属性名称,找寻合适的set方法
            String fieldName = fields[k].getName();
            String setMethodName = "set" + fieldName.substring(0, 1).toUpperCase()
                    + fieldName.substring(1);
            Method method = null;
            Class<?> clazz = t.getClass();
            try {
                method = clazz.getMethod(setMethodName, new Class[] { list.get(k).getClass() });
                System.out.println("list.get("+k+").getClass():"+list.get(k).getClass());
            } catch (SecurityException e1) {
                e1.printStackTrace();
                return;
            } catch (NoSuchMethodException e1) {
                String newMethodName = "set" + fieldName.substring(0, 1).toLowerCase()
                        + fieldName.substring(1);
                try {
                    method = clazz.getMethod(newMethodName, new Class[] { list.get(k).getClass() });
                } catch (SecurityException e) {
                    e.printStackTrace();
                    return;
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                    return;
                }
            }
            if (method == null) {
                return;
            }
            method.invoke(t, new Object[] { list.get(k) });
        }
    }

    public static boolean isMobile(String mobile) {
        return Pattern.matches(REGEX_MOBILE, mobile);
    }

    public static boolean isIdCard(String idCard) {
        return Pattern.matches(REGEX_IDCARD, idCard);
    }

    public static boolean isTbCard(String tbCard) {
        return Pattern.matches(REGEX_TBCARD, tbCard);
    }

    public static boolean isPassPort(String passPort) {
        return Pattern.matches(REGEX_PASSPORT, passPort);
    }

    //判断该对象是否: 返回ture表示所有属性为null  返回false表示不是所有属性都是null
    private boolean isAllFieldNull(Object obj) throws Exception{
        Class stuCla = (Class) obj.getClass();// 得到类对象
        Field[] fs = stuCla.getDeclaredFields();//得到属性集合
        boolean flag = true;
        for (Field f : fs) {//遍历属性
            f.setAccessible(true); // 设置属性是可以访问的(私有的也可以)
            Object val = f.get(obj);// 得到此属性的值
            if(val!=null) {//只要有1个属性不为空,那么就不是所有的属性值都为空
                flag = false;
                break;
            }
        }
        return flag;
    }

    //比较两个日期是否相等
    public static boolean sameDate(Date d1, Date d2) {
        if(null == d1 || null == d2)
            return false;
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(d1);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(d2);
        cal2.set(Calendar.HOUR_OF_DAY, 0);
        cal2.set(Calendar.MINUTE, 0);
        cal2.set(Calendar.SECOND, 0);
        cal2.set(Calendar.MILLISECOND, 0);
        return  cal1.getTime().equals(cal2.getTime());
    }

    /**
     * 加入信息库
     */
    @Transactional(readOnly = false)
    public AjaxResponse placeSuppAdd(TraPlace traPlace) {
        TraPlace place = mapper.getTraPlaceById(traPlace.getId());
        if(null == place) {
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        LibPlace libPlace = new LibPlace();
        EntityUtils.setCreateInfo(libPlace);
        libPlace.setName(place.getName());
        libPlace.setEnName(place.getEnName());
        libPlace.setCover(place.getCover());
        mapper.insertLibPlace(libPlace);

        List<LibItem> libItemList = mapper.getLibItem(traPlace.getId());
        List<LibSupp> libSuppList = mapper.getLibSupp(libItemList);
        if(libItemList.isEmpty()) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        String traId = "";
        int sort = 1;
        Map<String,String> itemIdMap = new HashMap<>();
        for(LibItem libItem : libItemList) {
            traId = libItem.getId();
            EntityUtils.setCreateInfo(libItem);
            libItem.setPlaceId(libPlace.getId());
            libItem.setSort(sort);
            sort++;
            itemIdMap.put(traId,libItem.getId());
        }
        mapper.insertLibItem(libItemList);

        if(libSuppList.isEmpty()) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        for(LibSupp libSupp : libSuppList) {
            EntityUtils.setCreateInfo(libSupp);
            libSupp.setItemId(itemIdMap.get(libSupp.getItemId()));
        }
        int result = mapper.insertLibSupp(libSuppList);
        if(result == 0) {
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }
}
