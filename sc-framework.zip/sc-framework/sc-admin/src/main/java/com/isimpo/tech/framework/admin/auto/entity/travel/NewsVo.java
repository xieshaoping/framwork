package com.isimpo.tech.framework.admin.auto.entity.travel;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */

/**
 * 可乐消息VO
 */
public class NewsVo extends BaseVo {

    // 可乐消息id
    private String id;

    // 管家id
    private String housekeeperId;

    // 发布人名
    private String name;

    // 行程id
    private String traId;

    // 行程名
    private String traName;

    // 消息内容
    private String content;

    // 文件类型 1.图片 2.视频
    private String type;

    // 文件地址
    private String filePath;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTraName() {
        return traName;
    }

    public void setTraName(String traName) {
        this.traName = traName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHousekeeperId() {
        return housekeeperId;
    }

    public void setHousekeeperId(String housekeeperId) {
        this.housekeeperId = housekeeperId;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getAddTime() {
        return super.getAddTime();
    }
}
