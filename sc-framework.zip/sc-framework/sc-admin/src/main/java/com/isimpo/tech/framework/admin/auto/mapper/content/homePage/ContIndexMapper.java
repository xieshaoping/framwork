package com.isimpo.tech.framework.admin.auto.mapper.content.homePage;

import com.isimpo.tech.framework.admin.auto.entity.SysHousekeeper;
import com.isimpo.tech.framework.admin.auto.entity.content.formerlyarticles.FormerlyArticles;
import com.isimpo.tech.framework.admin.auto.entity.content.homePage.ContIndex;
import com.isimpo.tech.framework.admin.auto.entity.content.homePage.RecommentStrategyVo;
import com.isimpo.tech.framework.admin.auto.entity.content.strategy.StrategyVo;
import com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk.TratRavelerTalk;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface ContIndexMapper extends Mapper<ContIndex> {

    /*
    * 推荐管家列表
    * */
    List<SysHousekeeper> getIndexHkList(Query query);

    /*
     * 推荐管家列表
     * */
    List<WayMng>  getIndexRouteList();

    /*
     * 推荐文章列表
     * */
    List<FormerlyArticles>  getIndexArticleList();


    /*
     * 推荐文章列表
     * */
    List<TratRavelerTalk>  getIndexTraverlerTalkList();

    /**
     * 推荐攻略列表
     * @return
     */
    List<RecommentStrategyVo> listRecommentedStrategy();

    /**
     * 待推荐攻略列表
     * @param query
     * @return
     */
    List<RecommentStrategyVo> listStrategy(Query query);
}
