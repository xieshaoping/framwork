package com.isimpo.tech.framework.admin.auto.mapper;

import com.isimpo.tech.framework.admin.auto.entity.SysMenu;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface SysMenuMapper extends Mapper<SysMenu> {
    /**
     * 根据用户id获取菜单
     *
     * @param userId 用户id
     * @return 菜单List
     */

    List<SysMenu> selectUserMenu(String userId);
}