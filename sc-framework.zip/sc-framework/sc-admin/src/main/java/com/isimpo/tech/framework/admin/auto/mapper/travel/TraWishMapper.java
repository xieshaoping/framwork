package com.isimpo.tech.framework.admin.auto.mapper.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraWish;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface TraWishMapper extends Mapper<TraWish> {

    List<TraWish> findList(Query query);

    TraWish findById(String id);
}