package com.isimpo.tech.framework.admin.auto.mapper;

import com.isimpo.tech.framework.admin.auto.entity.SysCust;
import com.isimpo.tech.framework.admin.auto.entity.SysDict;
import com.isimpo.tech.framework.admin.auto.entity.SysHousekeeper;
import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface SysHkMapper extends Mapper<SysHousekeeper> {

    List<SysCust> custList(Query query);

    List<SysHousekeeper> getHousekeeper();


    /**
     * 查询管家列表
     *
     * @param query 查询参数
     * @return List<SysHousekeeper> 用户列表
     */
    List<SysHousekeeper> findList(Query query);


    /**
     * 证件类型列表certificates_type
     *
     * @param
     * @return List<SysDict> 用户列表
     */
    List<SysDict> queryCerTypeList();

    /*
    * 添加
    * */
    int  addHouseKeeper(SysHousekeeper sysHousekeeper);

    int addMember(SysHousekeeper sysHousekeeper);

    int updMember(SysHousekeeper sysHousekeeper);

    int updHousekeeper(SysHousekeeper sysHousekeeper);

//    int delMember(SysHousekeeper sysHousekeeper);

    int delHousekeeper(SysHousekeeper sysHousekeeper);

    List<SysHousekeeper> selectList(Query query);

    SysHousekeeper selectOneHk(@Param("id")String id);

    List<SysHousekeeper> selectUser(Query query);

    int delMemWechar(SysHousekeeper sysHousekeeper);

}
