package com.isimpo.tech.framework.admin.service.travel;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.travel.CustomerVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraManageVo;
import com.isimpo.tech.framework.admin.auto.mapper.travel.CustomerMapper;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraManageMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/1
 *
 */
@Service
public class CustomerService extends BaseService<CustomerMapper, CustomerVo> {

    /**
     * 行程列表
     * @return 返回数据
     */
    public AjaxResponse getCustomers() {
        List<CustomerVo> list = mapper.getCustomersAll();
        return  AjaxResponse.of(list);
    }

}
