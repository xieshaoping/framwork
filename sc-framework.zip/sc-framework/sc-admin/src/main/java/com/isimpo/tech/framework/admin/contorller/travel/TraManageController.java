package com.isimpo.tech.framework.admin.contorller.travel;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

import com.github.crab2died.handler.ExcelTemplate;
import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraCalendar;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraPlace;
import com.isimpo.tech.framework.admin.utils.ExcelUtils;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import org.springframework.web.bind.annotation.*;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraManageVo;
import com.isimpo.tech.framework.admin.service.travel.TraManageService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * 行程管理
 * @author Tank
 * @version V1.0
 * @since 2019/1/29
 *
 */
@RestController
@RequestMapping("/travel")
public class TraManageController extends BaseController<TraManageService, TraManageVo> {

    @GetMapping("/myTravel")
    @ResponseBody
    public AjaxResponse myTravel(@RequestParam Map<String, Object> params) {
        // 查询列表数据
        System.out.println(params);
        for (String in : params.keySet()) {
            if (!in.equals(CommonConstants.ORDER_BY_PARAM)) {
                //map.keySet()返回的是所有key的值
                String str = (String) params.get(in);//得到每个key多对用value的值
                str = str.replace("%", "%\\");
                str = str.replace("?", "?\\");
                str = str.replace("_", "_\\");
                params.put(in, str);
            }
        }
        params.put("userId", BaseContextHandler.getUserID());
        Query query = new Query(params);
        return AjaxResponse.of(baseService.selectByQuery(query));
    }


    /**
     * 行程列表
     * @param params 参数 name contact state housekeeperName
     * @return 返回数据
     */
   /* @GetMapping("/list")
    public AjaxResponse travelList(@RequestParam Map<String, Object> params) {
        Query query = new Query(params);
        return baseService.getList(query);
    }*/

    /**
     * 删除行程
     * @param id 参数
     * @return 返回数据
     */
    @GetMapping("/remove")
    public AjaxResponse removeTravel(String id) {
        return baseService.removeTravel(id);
    }

    /**
     * 获取行程基本信息
     * @param id 参数
     * @return 返回数据
     */
    @GetMapping("/find")
    public AjaxResponse findTraById(String id) {
        return baseService.findTraById(id);
    }

    /**
     * 取消行程
     * @param id 参数
     * @return 返回数据
     */
    @GetMapping("/cancel")
    public AjaxResponse cancelTravel(String id) {
        return baseService.cancelTravel(id);
    }

    /**
     * 修改行程
     * @param traManageVo 参数
     * @return 返回数据
     */
    @PostMapping("/edit")
    public AjaxResponse editTravel(@RequestBody TraManageVo traManageVo) {
        return baseService.editTravel(traManageVo);
    }


    /**
     * 更改行程总览
     * @param traManageVo
     * @return
     */
    @PostMapping("/updOverView")
    public AjaxResponse updOverView(@RequestBody TraManageVo traManageVo) {
        return baseService.updOverView(traManageVo);
    }


    /**
     * 行程增加
     * @Author wangxinhai
     * @param entity
     * @return
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResponse add(@RequestBody TraManageVo entity) {
        return baseService.add(entity);
    }


    /**
     * 根据行程id 获取行程日历信息
     * @author wangxinhai
     * @param traId
     * @return
     */
    @GetMapping("getTraCalendarByTraId")
    @ResponseBody
    public AjaxResponse getTraCalendarByTraId(String traId){
        return AjaxResponse.of(baseService.getTraCalendarByTraId(traId));
    }

    /**
     * 行程日历添加
     * @author wangxinhai
     * @param traCalendar
     * @return
     */
    @PostMapping("/addTraCalendar")
    @ResponseBody
    public AjaxResponse addTraCalendar(@RequestBody TraCalendar traCalendar){
        return baseService.addTraCalendar(traCalendar);
    }

    /**
     * 日期修改
     * @param traCalendar
     * @return
     */
    @PostMapping("/updateTraCalendar")
    @ResponseBody
    public AjaxResponse updateTraCalendar(@RequestBody TraCalendar traCalendar){
        return baseService.updateTraCalendar(traCalendar);
    }

    /**
     * 删除日期
     * @param id
     * @return
     */
    @GetMapping("/delTraCalendar")
    public AjaxResponse delTraCalendar(String id){
        return baseService.delTraCalendar(id);
    }

    /**
     * 获取行程日历
     * @param id
     * @return
     */
    @GetMapping("/getTraCalendar")
    @ResponseBody
    public AjaxResponse getTraCalendar(String id){
        return AjaxResponse.of(baseService.getTraCalendar(id));
    }

    /**
     * 根据行程 日历获取行程列表
     * @author wangxinhai
     * @param traPlace
     * @return
     */
    @GetMapping("/getTraPlaceItemList")
    @ResponseBody
    public AjaxResponse getTraPlaceItemList(TraPlace traPlace){
        return AjaxResponse.of(baseService.getTraPlaceItemList(traPlace));
    }

    /**
     * 行程地点添加
     * @author wangxinhai
     * @param traPlace
     * @return
     */
    @PostMapping("/addTraPlace")
    @ResponseBody
    public AjaxResponse addTraPlace(@RequestBody TraPlace traPlace){
        return baseService.addTraPlace(traPlace);
    }

    /**
     * 获取地点
     * @param id
     * @return
     */
    @GetMapping("/getTraPlace")
    @ResponseBody
    public AjaxResponse getTraPlace(String id){
        return AjaxResponse.of(baseService.getTraPlace(id));
    }

    /**
     * 更新地点
     * @param traPlace
     * @return
     */
    @PostMapping("/updateTraPlace")
    @ResponseBody
    public AjaxResponse updateTraPlace(@RequestBody TraPlace traPlace){
        return baseService.updateTraPlace(traPlace);
    }

    /**
     * 删除地点
     * @param id
     * @return
     */
    @GetMapping("/delTraPlace")
    @ResponseBody
    public AjaxResponse delTraPlace(String id){
        return baseService.delTraPlace(id);
    }


    /**
     * 切换顺序
     * @param oldId
     * @param newId
     * @return
     */
    @GetMapping("/changeTraItemSort")
    @ResponseBody
    public AjaxResponse changeTraItemSort(String oldId,String newId){
        return baseService.changeTraItemSort(oldId,newId);
    }

    /**
     * 导出excel模版
     *
     * @param response
     * @throws Exception
     */
    @RequestMapping("/exportExcelModel")
    public void exportExcelModel(HttpServletResponse response) throws Exception {
        List<TraManageVo> list = new ArrayList<>();
        String tempPath = "/excelModal/traImportModal.xlsx";
        Map<String, String> data = new HashMap<>();
        ExcelTemplate excelTemplate = ExcelUtils.getInstance().exportExcelByModuleHandler(tempPath, 0, list, data, TraManageVo.class, false);
        OutputStream outputStream = response.getOutputStream();
        response.reset();
        response.setContentType("application/vnd.ms-excel;charset=utf-8");
        String fileName = URLEncoder.encode("行程管理导入模版.xlsx", "UTF-8");
        if ("FF".equals(getBrowser(request))) { //火狐浏览器
            fileName = new String("行程管理导入模版.xlsx".getBytes("UTF-8"), "iso-8859-1");
        }
        response.setHeader("content-disposition", "attachment;filename=" + fileName);
        excelTemplate.write2Stream(outputStream);
        outputStream.close();
    }

    /**
     * excel导入
     */
    @PostMapping("/importExcel")
    public AjaxResponse importExcel(MultipartFile file) throws Exception {
        return baseService.importExcel(file.getInputStream(),file.getOriginalFilename());
    }

    /**
     * 判断浏览器
     *
     * @param request
     * @return
     */
    public String getBrowser(HttpServletRequest request) {
        String UserAgent = request.getHeader("USER-AGENT").toLowerCase();
        if (UserAgent != null) {
            if (UserAgent.indexOf("msie") >= 0)
                return "IE";
            if (UserAgent.indexOf("firefox") >= 0)
                return "FF";
            if (UserAgent.indexOf("safari") >= 0)
                return "SF";
        }
        return null;
    }

    /**
     * 加入信息库
     * @param traPlace 参数
     */
    @GetMapping("/placeSuppAdd")
    public AjaxResponse placeSuppAdd(TraPlace traPlace) {
        return baseService.placeSuppAdd(traPlace);
    }
}
