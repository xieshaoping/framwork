package com.isimpo.tech.framework.admin.auto.mapper;

import com.isimpo.tech.framework.admin.auto.entity.WxUser;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/**
 * 微信关注用户mapper
 *
 * @author wgq
 * @version 1.0
 * @since 2018年01月04日
 */
public interface WxUserMapper extends Mapper<WxUser> {


    /**
     * 查询微信关注用户列表
     *
     * @param query 分页信息
     * @return 用户列表
     */
    List<WxUser> findList(Query query);

    /**
     * 查询用户记录的条数
     * @param wxUser 微信用户entity
     * @return 用户记录的条数
     */
    Integer selectUserCount(WxUser wxUser);
}