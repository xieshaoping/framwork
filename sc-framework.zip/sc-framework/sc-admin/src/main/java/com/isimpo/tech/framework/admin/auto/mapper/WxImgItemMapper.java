package com.isimpo.tech.framework.admin.auto.mapper;

import java.util.List;

import com.isimpo.tech.framework.admin.auto.entity.WxImgItem;

import tk.mybatis.mapper.common.Mapper;

/**
 * 微信图片消息mapper
 *
 * @author wgq
 * @version 1.0
 * @since 2018年01月07日
 */
public interface WxImgItemMapper extends Mapper<WxImgItem> {

    /**
     * 获取微信图片消息分页数据
     *
     * @return 微信图片消息
     */
    List<WxImgItem> findList();

    /**
     * 批量删除图文消息的合集
     *
     * @param wxImgItem 图文消息entity
     * @return 影响的数据库行数
     */
    int batchDel(WxImgItem wxImgItem);

    /**
     * 根据id集合查询图文消息列表
     *
     * @param list id集合
     * @return 图文消息列表
     */
    List<WxImgItem> queryImgItemListByIds(List<String> list);
}