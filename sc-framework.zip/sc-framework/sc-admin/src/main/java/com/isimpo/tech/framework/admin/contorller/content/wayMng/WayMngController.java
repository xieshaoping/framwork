package com.isimpo.tech.framework.admin.contorller.content.wayMng;

import com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk.TratRavelerTalk;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import com.isimpo.tech.framework.admin.service.content.tratravelertalk.TratRavelerTalkService;
import com.isimpo.tech.framework.admin.service.content.wayMng.WayMngService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 旅咖说Controller
 *
 * @Witer xyh
 * @Date 2019/1/29
 */
@RestController
@RequestMapping("/content/wayMng")
public class WayMngController extends BaseController<WayMngService, WayMng> {


    //    增加
    @Override
    @PostMapping
    @ResponseBody
    public AjaxResponse add(@RequestBody WayMng entity) {
        return  baseService.insertWayMng(entity);
    }

    @Override
    @PutMapping("/{id}")
    @ResponseBody
    public AjaxResponse update(@RequestBody WayMng entity) {
        return baseService.updateWayMng(entity);
    }

    //  逻辑删除
    @Override
    @DeleteMapping("/{id}")
    @ResponseBody
    public AjaxResponse remove(@PathVariable String id) {
        return  baseService.deleteWayMng(id);
    }


    @Override
    @GetMapping("/page")
    public AjaxResponse list(@RequestParam Map<String, Object> params) {
        Map<String, String> orderByMap = new HashMap<>();
        orderByMap.put("addTime", CommonConstants.ORDER_BY_DESC);
        params.put(CommonConstants.ORDER_BY_PARAM, orderByMap);
        return super.list(params);
    }

    // 过滤掉已经是”推荐路线“的路线集合
    @GetMapping("/routeList")
    @ResponseBody
    public AjaxResponse routeList(@RequestParam Map<String, Object> params) {
        // 查询列表数据
        System.out.println(params);
        for (String in : params.keySet()) {
            if (!in.equals(CommonConstants.ORDER_BY_PARAM)) {
                //map.keySet()返回的是所有key的值
                String str = (String) params.get(in);//得到每个key多对用value的值
                str = str.replace("%", "%\\");
                str = str.replace("?", "?\\");
                str = str.replace("_", "_\\");
                params.put(in, str);
            }
        }
        Query query = new Query(params);
        return AjaxResponse.of(baseService.selectRouteList(query));
    }

    /**
     * 启动路线
     * @param id
     * @return
     */
    @GetMapping("/startWayMng")
    @ResponseBody
    public AjaxResponse startWayMng(String id){
        return baseService.startWayMng(id);
    }
}
