package com.isimpo.tech.framework.admin.auto.mapper.content.cocoCard;

import com.isimpo.tech.framework.admin.auto.entity.content.cocoCard.CocoCard;
import tk.mybatis.mapper.common.Mapper;

public interface CocoCardMapper extends Mapper<CocoCard> {
    CocoCard getCocoCard();

    int updateCocoCard(CocoCard cocoCard);

    int insertCocoCard(CocoCard cocoCard);
}