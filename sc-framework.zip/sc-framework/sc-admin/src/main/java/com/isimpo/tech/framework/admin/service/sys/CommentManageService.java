package com.isimpo.tech.framework.admin.service.sys;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.systemmanage.CommentVo;
import com.isimpo.tech.framework.admin.auto.mapper.systemmanage.CommentMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/1/29
 */
@Service
public class CommentManageService extends BaseService<CommentMapper, CommentVo> {
    /**
     * 获取评论列表
     * @return
     */
    public AjaxResponse getComments(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        resoveSpecialChar(query, new String[]{"name", "content"});
        List<CommentVo> list = mapper.listComments(query);
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }

    /**
     * 逻辑删除评论
     * @param comment
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delComment(CommentVo comment) {
        EntityUtils.setUpdatedInfo(comment);
        int count = mapper.delComment(comment);
        if (count > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 处理特殊字符(%)
     * @param query
     * @param keys
     */
    public static void resoveSpecialChar(Query query, String[] keys) {
        for (String key : keys) {
            String value = (String) query.get(key);
            if (value != null && value.contains("%")) {
                value = value.replace("%", "\\%");
                query.put(key, value);
            }
        }
    }
}
