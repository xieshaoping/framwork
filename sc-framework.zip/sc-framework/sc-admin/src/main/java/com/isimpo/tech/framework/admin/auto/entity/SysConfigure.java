/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.entity;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 * 系统配置
 *
 * @author LuoCheng
 * @version 1.0
 * @since 2019年02月12日
 */
public class SysConfigure extends BaseVo {
    @Id
    private String id;

    /**
     * 紧急号码
     */
    @Column(name = "urgent_phone")
    private String urgentPhone;

    /**
     * 公司介绍
     */
    private String introduction;

    /**
     * 公司地址坐标
     */
    @Column(name = "company_position")
    private String companyPosition;

    /**
     * 提醒邮箱
     */
    @Column(name = "notice_email")
    private String noticeEmail;

    /**
     * 公众号名称
     */
    @Column(name = "qrcode_name")
    private String qrcodeName;

    /**
     * 微信公众号二维码
     */
    @Column(name = "qrcode_path")
    private String qrcodePath;

    //系统邮箱（发件邮箱）
    @Column(name = "send_email")
    private String sendEmail;

    // 系统邮箱密码
    @Column(name = "email_pwd")
    private String emailPwd;

    // 图片水印
    private String watermark;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSendEmail() {
        return sendEmail;
    }

    public void setSendEmail(String sendEmail) {
        this.sendEmail = sendEmail;
    }

    public String getEmailPwd() {
        return emailPwd;
    }

    public void setEmailPwd(String emailPwd) {
        this.emailPwd = emailPwd;
    }

    public String getUrgentPhone() {
        return urgentPhone;
    }

    public void setUrgentPhone(String urgentPhone) {
        this.urgentPhone = urgentPhone;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getCompanyPosition() {
        return companyPosition;
    }

    public void setCompanyPosition(String companyPosition) {
        this.companyPosition = companyPosition;
    }

    public String getNoticeEmail() {
        return noticeEmail;
    }

    public void setNoticeEmail(String noticeEmail) {
        this.noticeEmail = noticeEmail;
    }

    public String getQrcodeName() {
        return qrcodeName;
    }

    public void setQrcodeName(String qrcodeName) {
        this.qrcodeName = qrcodeName;
    }

    public String getQrcodePath() {
        return qrcodePath;
    }

    public void setQrcodePath(String qrcodePath) {
        this.qrcodePath = qrcodePath;
    }

    public String getWatermark() {
        return watermark;
    }

    public void setWatermark(String watermark) {
        this.watermark = watermark;
    }
}
