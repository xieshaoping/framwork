package com.isimpo.tech.framework.admin.auto.entity.content.wayMng;

import com.isimpo.tech.framework.admin.auto.entity.SysDict;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

// 路线信息表
@Table(name = "`cont_route_cust`")
public class RouteCust {
    /**
     * 主键
     */
    @Id
    private String id;

    /*标签名*/
    private String label;

    /*值*/
    private String value;

   /*描述*/
    private String description;

    /**
     * 标题
     */
    private String title;

    @Column(name = "route_id")
    private String routeId;

    @Column(name = "dic_id")
    private String dicId;

    /**
     * 行程路线
     */
    private String stroke;

    /**
     * 路线特色
     */
    private String chara;

    /**
     * 行程天数
     */
    private Integer days;

    /**
     * 预计费用
     */
    private BigDecimal cost;

    /**
     * 显示状态（0：隐藏，1：显示）
     */
    private String state;

    /**
     * 封面
     */
    private String cover;

    /**
     * 摘要
     */
    private String summary;

    /**
     * 定制标签
     */
    @Transient
    private List<SysDict> customize;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    /**
     * 详细介绍
     */
    private String content;

    public void setCustomize(List<SysDict> customize) {
        this.customize = customize;
    }

    /**
     * 图片地址(多个图片地址用英文逗号隔开)
     */
    @Column(name = "file_path")
    private String filePath;

    public String getRouteId() {
        return routeId;
    }

    public void setRouteId(String routeId) {
        this.routeId = routeId;
    }

    public String getDicId() {
        return dicId;
    }

    public void setDicId(String dicId) {
        this.dicId = dicId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List getCustomize() {
        return customize;
    }


    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取行程路线
     *
     * @return stroke - 行程路线
     */
    public String getStroke() {
        return stroke;
    }

    /**
     * 设置行程路线
     *
     * @param stroke 行程路线
     */
    public void setStroke(String stroke) {
        this.stroke = stroke;
    }

    /**
     * 获取路线特色
     *
     * @return chara - 路线特色
     */
    public String getChara() {
        return chara;
    }

    /**
     * 设置路线特色
     *
     * @param chara 路线特色
     */
    public void setChara(String chara) {
        this.chara = chara;
    }

    /**
     * 获取行程天数
     *
     * @return days - 行程天数
     */
    public Integer getDays() {
        return days;
    }

    /**
     * 设置行程天数
     *
     * @param days 行程天数
     */
    public void setDays(Integer days) {
        this.days = days;
    }

    /**
     * 获取预计费用
     *
     * @return cost - 预计费用
     */
    public BigDecimal getCost() {
        return cost;
    }

    /**
     * 设置预计费用
     *
     * @param cost 预计费用
     */
    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    /**
     * 获取显示状态（0：隐藏，1：显示）
     *
     * @return state - 显示状态（0：隐藏，1：显示）
     */
    public String getState() {
        return state;
    }

    /**
     * 设置显示状态（0：隐藏，1：显示）
     *
     * @param state 显示状态（0：隐藏，1：显示）
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * 获取封面
     *
     * @return cover - 封面
     */
    public String getCover() {
        return cover;
    }

    /**
     * 设置封面
     *
     * @param cover 封面
     */
    public void setCover(String cover) {
        this.cover = cover;
    }

    /**
     * 获取摘要
     *
     * @return summary - 摘要
     */
    public String getSummary() {
        return summary;
    }

    /**
     * 设置摘要
     *
     * @param summary 摘要
     */
    public void setSummary(String summary) {
        this.summary = summary;
    }

    /**
     * 获取删除标识(1:已删除,0:正常)
     *
     * @return del_flag - 删除标识(1:已删除,0:正常)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:已删除,0:正常)
     *
     * @param delFlag 删除标识(1:已删除,0:正常)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建备注
     *
     * @return add_mark - 创建备注
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建备注
     *
     * @param addMark 创建备注
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新备注
     *
     * @return upd_mark - 更新备注
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新备注
     *
     * @param updMark 更新备注
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    /**
     * 获取详细介绍
     *
     * @return content - 详细介绍
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置详细介绍
     *
     * @param content 详细介绍
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取图片地址(多个图片地址用英文逗号隔开)
     *
     * @return file_path - 图片地址(多个图片地址用英文逗号隔开)
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * 设置图片地址(多个图片地址用英文逗号隔开)
     *
     * @param filePath 图片地址(多个图片地址用英文逗号隔开)
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
