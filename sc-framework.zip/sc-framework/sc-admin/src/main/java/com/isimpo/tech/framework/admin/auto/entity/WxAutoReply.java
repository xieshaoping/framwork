package com.isimpo.tech.framework.admin.auto.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Table(name = "wx_autoreply")
public class WxAutoReply {
    @Id
    private String id;

    /**
     * 消息类型: text ,image
     */
    @Column(name = "msg_type")
    private String msgType;

    /**
     * 文本内容
     */
    private String content;

    /**
     * 图片url
     */
    @Column(name = "pic_url")
    private String picUrl;

    /**
     * 事件 ：subscribe 订阅
     */
    private String event;

    /**
     * 删除标识(1:有效,0:删除)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 规则名
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新页面ID
     */
    @Column(name = "upd_mark")
    private String updMark;

    @Column(name = "media_id")
    private String mediaId;

    @Column(name = "key_word")
    private String keyWord;

    /**
     * 图文消息ids
     */
    @Column(name = "menu_ids")
    private String menuIds;

    /**
     * 1 被关注，2 一般消息，3 关键字
     */
    private String flag;


    /**
     * 回复图文列表
     */
    @Transient
    private List<WxImgItem> textMessageList = new ArrayList<>();


    public List<WxImgItem> getTextMessageList() {
        return textMessageList;
    }

    public void setTextMessageList(List<WxImgItem> textMessageList) {
        this.textMessageList = textMessageList;
    }

    /**
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取消息类型: text ,image
     *
     * @return msg_type - 消息类型: text ,image
     */
    public String getMsgType() {
        return msgType;
    }

    /**
     * 设置消息类型: text ,image
     *
     * @param msgType 消息类型: text ,image
     */
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    /**
     * 获取文本内容
     *
     * @return content - 文本内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置文本内容
     *
     * @param content 文本内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取图片url
     *
     * @return pic_url - 图片url
     */
    public String getPicUrl() {
        return picUrl;
    }

    /**
     * 设置图片url
     *
     * @param picUrl 图片url
     */
    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    /**
     * 获取事件 ：subscribe 订阅
     *
     * @return event - 事件 ：subscribe 订阅
     */
    public String getEvent() {
        return event;
    }

    /**
     * 设置事件 ：subscribe 订阅
     *
     * @param event 事件 ：subscribe 订阅
     */
    public void setEvent(String event) {
        this.event = event;
    }

    /**
     * 获取删除标识(1:有效,0:删除)
     *
     * @return del_flag - 删除标识(1:有效,0:删除)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:有效,0:删除)
     *
     * @param delFlag 删除标识(1:有效,0:删除)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取规则名
     *
     * @return add_mark - 规则名
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置规则名
     *
     * @param addMark 规则名
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新页面ID
     *
     * @return upd_mark - 更新页面ID
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新页面ID
     *
     * @param updMark 更新页面ID
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    /**
     * @return media_id
     */
    public String getMediaId() {
        return mediaId;
    }

    /**
     * @param mediaId
     */
    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }

    /**
     * @return key_word
     */
    public String getKeyWord() {
        return keyWord;
    }

    /**
     * @param keyWord
     */
    public void setKeyWord(String keyWord) {
        this.keyWord = keyWord;
    }

    /**
     * 获取图文消息ids
     *
     * @return menu_ids - 图文消息ids
     */
    public String getMenuIds() {
        return menuIds;
    }

    /**
     * 设置图文消息ids
     *
     * @param menuIds 图文消息ids
     */
    public void setMenuIds(String menuIds) {
        this.menuIds = menuIds;
    }

    /**
     * 获取1 被关注，2 一般消息，3 关键字
     *
     * @return flag - 1 被关注，2 一般消息，3 关键字
     */
    public String getFlag() {
        return flag;
    }

    /**
     * 设置1 被关注，2 一般消息，3 关键字
     *
     * @param flag 1 被关注，2 一般消息，3 关键字
     */
    public void setFlag(String flag) {
        this.flag = flag;
    }
}