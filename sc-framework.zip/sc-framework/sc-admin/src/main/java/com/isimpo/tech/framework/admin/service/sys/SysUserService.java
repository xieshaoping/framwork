package com.isimpo.tech.framework.admin.service.sys;

import java.util.List;
import java.util.stream.Collectors;

import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.admin.auto.entity.SysUserRole;
import com.isimpo.tech.framework.admin.auto.mapper.SysUserMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.xiaoleilu.hutool.util.StrUtil;

/**
 * 系统用户Service
 *
 * @author guohui
 * @version v1.0.0
 */
@Service
public class SysUserService extends BaseService<SysUserMapper, SysUser> {

    /**
     * 新增用户信息
     *
     * @param entity 用户信息
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse insertEntity(SysUser entity) {
        //判断登录名是否重复
        if (mapper.checkLoginName(entity.getLoginName()) > 0) {
            return  AjaxResponse.of(10001,"此登录名已存在！");
        }
        //判断手机号是否重复
        if(mapper.checkPhone(entity) > 0){
            return AjaxResponse.of(10001,"此手机号已存在！");
        }
        EntityUtils.setCreatAndUpdatInfo(entity);
        handleRoles(entity, "add");
        // 敏感词过滤
        entity.setNotes(SensitiveWordUtils.filterStr(entity.getNotes()));
        mapper.insertSelective(entity);
        return  AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 更新用户信息
     *
     * @param entity 用户信息
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updateEntity(SysUser entity) {
        //判断手机号是否重复
        if(mapper.checkPhone(entity) > 0){
            return  AjaxResponse.of(10001,"修改的手机号已存在！");
        }
        EntityUtils.setUpdatedInfo(entity);
        //处理用户角色
        handleRoles(entity, "update");
        // 敏感词过滤
        entity.setNotes(SensitiveWordUtils.filterStr(entity.getNotes()));
        mapper.updateByPrimaryKeySelective(entity);
        return  AjaxResponse.of(ResponseCode.SUCCESS);
    }


    /**
     * 根据id查询用户信息
     *
     * @param id 用户id
     * @return SysRole 用户信息
     */
    @Override
    public SysUser selectById(Object id) {
        SysUser sysUser = mapper.selectUserById(id.toString());
        //根据用户id查询每个用户的角色id集合
        sysUser.setRoles(mapper.getRoleListByUserId(id));
        return sysUser;
    }


    /**
     * 根据用户名获取用户信息
     *
     * @param username 用户名
     * @return SysUser 用户信息
     */
    public SysUser getUserByUsername(String username) {
        SysUser user = new SysUser();
        user.setLoginName(username);
        return mapper.getUserByUsername(user);
    }


    /**
     * 查询用户分页列表
     *
     * @param query 分页信息
     * @return TableResultResponse<SysUser> 用户分页列表
     */
    @Override
    public TableResultResponse<SysUser> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<SysUser> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 处理用户角色
     *
     * @param sysUser 用户信息
     * @param type    add:新增  update：修改
     */
    private void handleRoles(SysUser sysUser, String type) {
        //更新操作，物理删除此用户所有的用户角色
        String t = "update";
        if (StrUtil.equals(type, t)) {
            mapper.deleteRoleByUserId(sysUser.getId());
        }
        List<SysUserRole> userRoles = sysUser.getRoles().stream().map(roleId -> {
            SysUserRole userRole = new SysUserRole();
            EntityUtils.setCreatAndUpdatInfo(userRole);
            userRole.setRoleId(roleId);
            userRole.setUserId(sysUser.getId());
            return userRole;
        }).collect(Collectors.toList());
        //保存用户角色
        mapper.saveUserRole(userRoles);
    }

    /**
     * 根据userId逻辑删除用户信息
     *
     * @param id 用户id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Object id) {
        SysUser sysUser = new SysUser();
        sysUser.setId(id.toString());
        sysUser.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        super.updateSelectiveById(sysUser);

    }

    /**
     * 重置用户登录密码
     *
     * @param sysUser 用户登录信息
     */
    @Transactional(rollbackFor = Exception.class)
    public void resetPassword(SysUser sysUser) {
        sysUser.setPassword("e10adc3949ba59abbe56e057f20f883e");
        super.updateSelectiveById(sysUser);
    }

    /**
     * 用户启用/禁用
     */
    @Transactional(rollbackFor = Exception.class)
    public void updateStatus(SysUser sysUser) {
        String str = "0";
        //用户启用
        if (StrUtil.equals(sysUser.getIsUse(), str)) {
            sysUser.setIsUse("1");
        } else {
            sysUser.setIsUse(str);
        }
        super.updateSelectiveById(sysUser);
    }

    /**
     * 检查用户密码是否正确
     *
     * @param userName    用户名
     * @param oldPassword 旧密码
     * @return 是否正确
     */
    public boolean checkPassword(String userName, String oldPassword) {
        return mapper.checkPassword(userName, oldPassword) > 0;
    }

    @Transactional(rollbackFor = Exception.class)
    public void changePassword(String newPassword) {
        SysUser user = new SysUser();
        user.setId(BaseContextHandler.getUserID());
        user.setPassword(newPassword);
        super.updateSelectiveById(user);
    }
    /**
     * 根据用户登录名查询登录名是否重复
     *
     * @param loginName 登录名
     * @return true : 重复 ，false: 不重复
     */
    public Boolean checkName(String loginName) {
        return mapper.checkLoginName(loginName) > 0 ;
    }

    /**
     * 获取当前登录人信息
     * @return
     */
    public SysUser getCurrentUser(){
        String userId = BaseContextHandler.getUserID();
        return mapper.selectUserById(userId);
    }

    /**
     * 首页修改用户
     * @param entity
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updateUser(SysUser entity) {
        //判断手机号是否重复
        if(mapper.checkPhone(entity) > 0){
            return  AjaxResponse.of(10001,"修改的手机号已存在！");
        }
        EntityUtils.setUpdatedInfo(entity);
        mapper.updateByPrimaryKeySelective(entity);
        return  AjaxResponse.of(ResponseCode.SUCCESS);
    }
}
