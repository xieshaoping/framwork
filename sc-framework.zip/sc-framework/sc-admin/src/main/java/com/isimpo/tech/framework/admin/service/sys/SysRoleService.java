/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.service.sys;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isimpo.tech.framework.admin.auto.entity.SysRole;
import com.isimpo.tech.framework.admin.auto.entity.SysRoleMenu;
import com.isimpo.tech.framework.admin.auto.mapper.SysRoleMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;

/**
 * 角色service实现类
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/22
 */
@Service
public class SysRoleService extends BaseService<SysRoleMapper, SysRole> {

    /**
     * 获取角色列表
     *
     * @return 角色List
     */
    @Override
    public List<SysRole> selectListAll(Map<String, Object> params) {
        List<SysRole> roles = super.selectListAll(params);
        if (roles != null && !roles.isEmpty()) {
            roles.forEach(role -> role.setCheckedMenus(mapper.selectMenuListByRoleIdExcludeParent(role.getId())));
        }
        return roles;
    }

    /**
     * 获取单个角色
     *
     * @param id 角色id
     * @return 角色
     */
    @Override
    public SysRole selectById(Object id) {
        SysRole role = super.selectById(id);
        if (role != null) {
            role.setCheckedMenus(mapper.selectMenuListByRoleIdExcludeParent(role.getId()));
        }
        return role;
    }


    /**
     * 新增角色
     *
     * @param role 角色信息
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertSelective(SysRole role) {
        super.insert(role);
        List<String> checkedMenus = role.getCheckedMenus();
        if (checkedMenus != null && !checkedMenus.isEmpty()) {
            List<SysRoleMenu> roleMenus =
                    role.getCheckedMenus().stream().map(menuId -> generatorRoleMenu(role.getId(), menuId))
                            .collect(Collectors.toList());
            mapper.insertRoleMenus(roleMenus);
        }

    }

    /**
     * 更新角色
     *
     * @param role 角色信息
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateSelectiveById(SysRole role) {
        super.updateSelectiveById(role);
        List<String> menus = role.getCheckedMenus();
        List<String> dbMenus = mapper.selectMenuListByRoleId(role.getId());
        if (menus != null && !menus.isEmpty()) {
            List<String> insertIds;
            List<String> deleteIds = null;
            if (dbMenus != null && !dbMenus.isEmpty()) {
                insertIds = menus.stream().filter(menuId -> !dbMenus.contains(menuId)).collect(Collectors.toList());
                deleteIds = dbMenus.stream().filter(menuId -> !menus.contains(menuId)).collect(Collectors.toList());
            } else {
                insertIds = role.getCheckedMenus();
            }
            if (insertIds != null && !insertIds.isEmpty()) {
                mapper.insertRoleMenus(insertIds.stream().map(menuId -> generatorRoleMenu(role.getId(), menuId))
                        .collect(Collectors.toList()));

            }
            if (deleteIds != null && !deleteIds.isEmpty()) {
                SysRoleMenu menu = new SysRoleMenu();
                EntityUtils.setUpdatedInfo(menu);
                menu.setDelFlag(DBConstants.DEL_FLAG_DELETED);
                menu.setRoleId(role.getId());

                mapper.deleteMenus(menu,deleteIds);
            }
        } else {
            role.setDelFlag(DBConstants.DEL_FLAG_DELETED);
            mapper.deleteMenusById(role);
        }
    }

    /**
     * 生成角色菜单
     *
     * @param roleId 角色id
     * @param menuId 菜单id
     * @return 角色菜单vo
     */
    private SysRoleMenu generatorRoleMenu(String roleId, String menuId) {
        SysRoleMenu menu = new SysRoleMenu();
        EntityUtils.setCreatAndUpdatInfo(menu);
        menu.setRoleId(roleId);
        menu.setMenuId(menuId);
        return menu;
    }

    /**
     * 删除角色
     *
     * @param id 角色id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Object id) {
        SysRole role = new SysRole();
        role.setId(String.valueOf(id));
        role.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        super.updateSelectiveById(role);
        mapper.deleteMenusById(role);
    }

    /**
     * 根据角色名查询角色名是否重复
     *
     * @param name 角色名称
     * @param id 角色id
     * @return true : 重复 ，false: 不重复
     */
    public Boolean checkName(String name,String id) {
        return mapper.getRoleByName(name,id) <= 0 ? false : true;
    }
}
