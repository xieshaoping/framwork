package com.isimpo.tech.framework.admin.service.travel;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraEvaluate;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraEvaluateMapper;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 行程评价
 */
@Service
public class TraEvaluateService extends BaseService<TraEvaluateMapper, TraEvaluate> {
    /**
     * 行程评价列表
     * @param query 参数
     * @return 返回数据
     */
    @Override
    public TableResultResponse<TraEvaluate> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<TraEvaluate> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 查看详情
     * @param id
     * @return
     */
    @Override
    public TraEvaluate selectById(Object id) {
        TraEvaluate traEvaluate = mapper.selectById(id);
        traEvaluate.setTraStaffEvaluateList(mapper.findGuideEva(traEvaluate.getTraId()));
        return traEvaluate;
    }
}
