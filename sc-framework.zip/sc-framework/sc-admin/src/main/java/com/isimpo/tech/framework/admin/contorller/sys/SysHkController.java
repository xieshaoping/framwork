package com.isimpo.tech.framework.admin.contorller.sys;

import com.isimpo.tech.framework.admin.auto.entity.SysHousekeeper;
import com.isimpo.tech.framework.admin.service.sys.SysHkService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * @Author: xiesp
 * @Despriction:管家controller
 * @Date:Created in 9:22 2019/1/26
 * @Modify By:
 */
@RestController
@RequestMapping("/sys/housekeeper")
public class SysHkController extends BaseController<SysHkService, SysHousekeeper> {

    /*
     * 获取所有管家信息id,name
     * */
    @GetMapping("/getHousekeeper")
    public AjaxResponse getHousekeeper() {
        return baseService.getHousekeeper();
    }


    /*
     * 从数据字典中获取证件类型，certificates_type，id，value，lable
     * */
    @GetMapping("/queryCerTypeList")
    public AjaxResponse queryCerTypeList() {
        return baseService.queryCerTypeList();
    }


    /*
     * 添加
     * */
    @RequestMapping("/addHouseKeeper")
    public AjaxResponse addHouseKeeper( @RequestBody SysHousekeeper sysHousekeeper) {
        return baseService.addHouseKeeper(sysHousekeeper);
    }


    @RequestMapping("/updateHousekeeper")
    public AjaxResponse updateHousekeeper( @RequestBody SysHousekeeper sysHousekeeper) {
        return baseService.updateHousekeeper(sysHousekeeper);
    }

    @RequestMapping("/delHousekeeper")
    public AjaxResponse delHousekeeper( @RequestBody SysHousekeeper sysHousekeeper) {
        return baseService.delHousekeeper(sysHousekeeper);
    }

    // 查询管家列表，过滤掉已经添加过得
    @GetMapping("/hkList")
    @ResponseBody
    public AjaxResponse hkList(@RequestParam Map<String, Object> params) {
        // 查询列表数据
        System.out.println(params);
        for (String in : params.keySet()) {
            if (!in.equals(CommonConstants.ORDER_BY_PARAM)) {
                //map.keySet()返回的是所有key的值
                String str = (String) params.get(in);//得到每个key多对用value的值
                str = str.replace("%", "%\\");
                str = str.replace("?", "?\\");
                str = str.replace("_", "_\\");
                params.put(in, str);
            }
        }
        Query query = new Query(params);
        return AjaxResponse.of(baseService.selectHk(query));
    }

    // 查询管家列表，过滤掉已经添加过得
    @GetMapping("/getOneHk")
    @ResponseBody
    public AjaxResponse getOneHk(String id) {
        return AjaxResponse.of(baseService.selectOneHk(id));
    }


    // 添加管家待选用户表
    @GetMapping("/chooseUserList")
    @ResponseBody
    public AjaxResponse chooseUserList(@RequestParam Map<String, Object> params) {
        // 查询列表数据
        System.out.println(params);
        for (String in : params.keySet()) {
            if (!in.equals(CommonConstants.ORDER_BY_PARAM)) {
                //map.keySet()返回的是所有key的值
                String str = (String) params.get(in);//得到每个key多对用value的值
                str = str.replace("%", "%\\");
                str = str.replace("?", "?\\");
                str = str.replace("_", "_\\");
                params.put(in, str);
            }
        }
        Query query = new Query(params);
        return AjaxResponse.of(baseService.selectUser(query));
    }

}
