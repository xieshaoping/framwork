package com.isimpo.tech.framework.admin.contorller.sys;

import com.isimpo.tech.framework.admin.auto.entity.SysOrg;
import com.isimpo.tech.framework.admin.service.sys.SysOrgService;
import com.isimpo.tech.framework.common.controller.BaseController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 组织机构管理controller
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/26
 */
@RestController
@RequestMapping("/sys/org")
public class SysOrgController extends BaseController<SysOrgService, SysOrg> {
}
