package com.isimpo.tech.framework.admin.auto.entity;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @Author: xiesp
 * @Despriction: 历史行程
 * @Date:Created in 15:30 2019/1/26
 * @Modify By:
 */
@Table(name = "tra_base")
public class SysTra extends BaseVo {

    @Id
    private String id;
    private String name;
    @Column(name = "customer_id")
    private String customer_id;

    private String contact;
    private String phone;

    @Column(name = "customer_id")
    private Date start_date;

    @Column(name = "customer_id")
    private Date end_date;

    @Column(name = "customer_id")
    private String housekeeper_id;

    @Column(name = "customer_id")
    private String guide_id;
    private String cover;
    private String note;
    private String overview;
    private String state;

   /*
   * 管家姓名
   * */
    private String hkName;

    /*
    * 领队姓名
    * */
    private String guideName;


    public String getHkName() {
        return hkName;
    }

    public void setHkName(String hkName) {
        this.hkName = hkName;
    }

    public String getGuideName() {
        return guideName;
    }

    public void setGuideName(String guideName) {
        this.guideName = guideName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Date getStart_date() {
        return start_date;
    }

    public void setStart_date(Date start_date) {
        this.start_date = start_date;
    }

    public Date getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Date end_date) {
        this.end_date = end_date;
    }

    public String getHousekeeper_id() {
        return housekeeper_id;
    }

    public void setHousekeeper_id(String housekeeper_id) {
        this.housekeeper_id = housekeeper_id;
    }

    public String getGuide_id() {
        return guide_id;
    }

    public void setGuide_id(String guide_id) {
        this.guide_id = guide_id;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
