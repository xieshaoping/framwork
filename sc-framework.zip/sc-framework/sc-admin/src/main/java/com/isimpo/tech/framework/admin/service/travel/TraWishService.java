package com.isimpo.tech.framework.admin.service.travel;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraWish;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraWishMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * 会员祝福
 * @author wangxinhai
 * @since 2019/2/11
 */
@Service
public class TraWishService extends BaseService<TraWishMapper, TraWish> {

    /**
     * 查询会员祝福分页列表
     * @param query 分页信息
     * @return TableResultResponse<> 会员祝福列表
     */
    @Override
    public TableResultResponse<TraWish> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<TraWish> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 查看会员祝福
     * @param id
     * @return
     */
    @Override
    public TraWish selectById(Object id) {
        return mapper.findById(id.toString());
    }

    /**
     * 逻辑删除
     * @param id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Object id) {
        TraWish traWish = new TraWish();
        traWish.setId(id.toString());
        traWish.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        EntityUtils.setUpdatedInfo(traWish);
        super.updateSelectiveById(traWish);
    }

}
