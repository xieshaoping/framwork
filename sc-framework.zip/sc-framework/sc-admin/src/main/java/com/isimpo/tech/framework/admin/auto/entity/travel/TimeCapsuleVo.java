package com.isimpo.tech.framework.admin.auto.entity.travel;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
public class TimeCapsuleVo extends TravelRecordVo {
}
