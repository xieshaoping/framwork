package com.isimpo.tech.framework.admin.auto.mapper.travel;


import java.util.List;
import java.util.Map;

import com.isimpo.tech.framework.admin.auto.entity.travel.MemberVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraManageVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraMember;
import com.isimpo.tech.framework.common.util.Query;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

/**
 * 行程管理-成员信息
 * @author Tank
 * @version V1.0
 * @since 2019/2/11
 *
 */

public interface TraMemberMapper extends Mapper<MemberVo> {


    /**
     * 成员列表
     * @param id 行程id
     */
    List<MemberVo> getList(Query query);

    /**
     * 成员信息
     * @param id 成员id
     */
    MemberVo findMemberById(@Param("id") String id, @Param("traId") String traId);

    /**
     * 修改成员信息
     * @param membervo 成员信息
     */
    int updateMember(MemberVo membervo);

    /**
     * 根据行程id查找团长数量
     * @param traId 行程id
     */
    int getLeaderNum(String traId);

    /**
     * 转换成员的团长和团员身份
     * @param membervo 成员对象
     */
    int switchLeader(MemberVo membervo);

    /**
     * 插入会员信息表csr_member
     * @param memberVo
     * @return
     */
    int insertCsrMember(MemberVo memberVo);

    /**
     * 插入行程会员表tra_member
     * @param traMember
     * @return
     */
    int insertTraMember(TraMember traMember);

    int updateLeadType(MemberVo memberVo);

    int insertTraMemberList(List<TraMember> list);

    int deleteCsrMember(TraMember traMember);

}