package com.isimpo.tech.framework.admin.auto.mapper.travel;


import java.util.List;

import com.isimpo.tech.framework.admin.auto.entity.travel.CustomerVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraManageVo;
import com.isimpo.tech.framework.common.util.Query;

import tk.mybatis.mapper.common.Mapper;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/1
 *
 */

public interface CustomerMapper extends Mapper<CustomerVo> {


    /**
     * 查询所有客户(id-name)
     * @return 返回数据
     */
    List<CustomerVo> getCustomersAll();


}