package com.isimpo.tech.framework.admin.service.content.strategy;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.content.strategy.StrategyVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.complain.ComplainVo;
import com.isimpo.tech.framework.admin.auto.mapper.content.strategy.StrategyMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/2/25
 */
@Service
public class StrategyService extends BaseService<StrategyMapper, StrategyVo> {
    /**
     * 攻略列表查询
     * @param query
     * @return
     */
    @Override
    public TableResultResponse<StrategyVo> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<StrategyVo> list = mapper.listStrategy(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 新增攻略
     * @param entity
     */
    @Override
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void insertSelective(StrategyVo entity) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        entity.setAuthor(entity.getAddUserId());
        filter(entity);
        super.insertSelective(entity);
    }

    @Override
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void updateSelectiveById(StrategyVo entity) {
        filter(entity);
        super.updateSelectiveById(entity);
    }

    // 敏感词过滤
    private void filter(StrategyVo strategy) {
        strategy.setTitle(SensitiveWordUtils.filterStr(strategy.getTitle()));
        strategy.setCompanion(SensitiveWordUtils.filterStr(strategy.getCompanion()));
        strategy.setContent(SensitiveWordUtils.filterStr(strategy.getContent()));
        strategy.setSummary(SensitiveWordUtils.filterStr(strategy.getSummary()));
    }
}
