package com.isimpo.tech.framework.admin.auto.mapper.travel.complain;

import com.isimpo.tech.framework.admin.auto.entity.travel.complain.ComplainVo;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface ComplainMapper extends Mapper<ComplainVo> {
    /**
     * 获取投诉列表
     * @param query
     * @return
     */
    List<ComplainVo> listComplain(Query query);
}