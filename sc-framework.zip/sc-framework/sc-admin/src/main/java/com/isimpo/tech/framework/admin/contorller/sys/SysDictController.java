package com.isimpo.tech.framework.admin.contorller.sys;

import com.isimpo.tech.framework.admin.auto.entity.SysDict;
import com.isimpo.tech.framework.admin.service.sys.SysDictService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 字典controller
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/28
 */
@RestController
@RequestMapping("/sys/dict")
public class SysDictController extends BaseController<SysDictService,SysDict> {

    /**
     * 字典type列表接口
     *
     * @return 字典type列表
     */
    @GetMapping("listType")
    public AjaxResponse listType() {
        return AjaxResponse.of(baseService.listType());
    }

    @Override
    @GetMapping("/page")
    public AjaxResponse list(@RequestParam Map<String, Object> params) {
        Map<String, String> orderByMap = new HashMap<>();
        orderByMap.put("addTime", CommonConstants.ORDER_BY_ASC);
        params.put(CommonConstants.ORDER_BY_PARAM, orderByMap);
        return super.list(params);
    }

    @GetMapping("/getGroupByType")
    @ResponseBody
    public AjaxResponse getGroupByType() {
        return AjaxResponse.of(baseService.getAll());
    }

    @GetMapping("/getAllByType")
    @ResponseBody
    public AjaxResponse getAllByType(String type) {
        return AjaxResponse.of(baseService.getAllByType(type));
    }
}
