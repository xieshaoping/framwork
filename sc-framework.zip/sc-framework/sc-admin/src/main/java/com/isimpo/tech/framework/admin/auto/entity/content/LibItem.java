package com.isimpo.tech.framework.admin.auto.entity.content;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import java.util.List;
import javax.persistence.*;

@Table(name = "lib_item")
public class LibItem {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 地点id
     */
    @Column(name = "place_id")
    private String placeId;

    /**
     * 类型
     */
    private String type;

    /**
     * 主题图片
     */
    private String cover;

    /**
     * 中文名称
     */
    private String name;

    /**
     * 英文名称
     */
    @Column(name = "en_name")
    private String enName;

    /**
     * 基本介绍
     */
    private String overview;

    /**
     * 温馨提示
     */
    private String tips;

    /**
     * 地点经度
     */
    private String longitude;

    /**
     * 地点维度
     */
    private String latitude;

    /**
     * 起始时间
     */
    @Column(name = "start_time")
    @JsonFormat(pattern="HH:mm")
    private Date startTime;

    /**
     * 结束时间
     */
    @Column(name = "end_time")
    @JsonFormat(pattern="HH:mm")
    private Date endTime;

    /**
     * 是否预订(0：无预订，1：已预订）
     */
    private String reserve;

    /**
     * 排序
     */
    private Integer sort;

    @Transient
    private String icon;

    @Transient
    List<LibSupp> libSuppList;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    /**
     * 详细信息
     */
    private String content;

    /**
     * 附件(多个附件地址逗号隔开)
     */
    private String files;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取地点id
     *
     * @return place_id - 地点id
     */
    public String getPlaceId() {
        return placeId;
    }

    /**
     * 设置地点id
     *
     * @param placeId 地点id
     */
    public void setPlaceId(String placeId) {
        this.placeId = placeId;
    }

    /**
     * 获取类型
     *
     * @return type - 类型
     */
    public String getType() {
        return type;
    }

    /**
     * 设置类型
     *
     * @param type 类型
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 获取主题图片
     *
     * @return cover - 主题图片
     */
    public String getCover() {
        return cover;
    }

    /**
     * 设置主题图片
     *
     * @param cover 主题图片
     */
    public void setCover(String cover) {
        this.cover = cover;
    }

    /**
     * 获取中文名称
     *
     * @return name - 中文名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置中文名称
     *
     * @param name 中文名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取英文名称
     *
     * @return en_name - 英文名称
     */
    public String getEnName() {
        return enName;
    }

    /**
     * 设置英文名称
     *
     * @param enName 英文名称
     */
    public void setEnName(String enName) {
        this.enName = enName;
    }

    /**
     * 获取基本介绍
     *
     * @return overview - 基本介绍
     */
    public String getOverview() {
        return overview;
    }

    /**
     * 设置基本介绍
     *
     * @param overview 基本介绍
     */
    public void setOverview(String overview) {
        this.overview = overview;
    }

    /**
     * 获取温馨提示
     *
     * @return tips - 温馨提示
     */
    public String getTips() {
        return tips;
    }

    /**
     * 设置温馨提示
     *
     * @param tips 温馨提示
     */
    public void setTips(String tips) {
        this.tips = tips;
    }

    /**
     * 获取地点经度
     *
     * @return longitude - 地点经度
     */
    public String getLongitude() {
        return longitude;
    }

    /**
     * 设置地点经度
     *
     * @param longitude 地点经度
     */
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    /**
     * 获取地点维度
     *
     * @return latitude - 地点维度
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * 设置地点维度
     *
     * @param latitude 地点维度
     */
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    /**
     * 获取起始时间
     *
     * @return start_time - 起始时间
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * 设置起始时间
     *
     * @param startTime 起始时间
     */
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * 获取结束时间
     *
     * @return end_time - 结束时间
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * 设置结束时间
     *
     * @param endTime 结束时间
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * 获取是否预订(0：无预订，1：已预订）
     *
     * @return reserve - 是否预订(0：无预订，1：已预订）
     */
    public String getReserve() {
        return reserve;
    }

    /**
     * 设置是否预订(0：无预订，1：已预订）
     *
     * @param reserve 是否预订(0：无预订，1：已预订）
     */
    public void setReserve(String reserve) {
        this.reserve = reserve;
    }

    /**
     * 获取排序
     *
     * @return sort - 排序
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * 设置排序
     *
     * @param sort 排序
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }

    /**
     * 获取删除标识(1:已删除,0:正常)
     *
     * @return del_flag - 删除标识(1:已删除,0:正常)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:已删除,0:正常)
     *
     * @param delFlag 删除标识(1:已删除,0:正常)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建备注
     *
     * @return add_mark - 创建备注
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建备注
     *
     * @param addMark 创建备注
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新备注
     *
     * @return upd_mark - 更新备注
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新备注
     *
     * @param updMark 更新备注
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    /**
     * 获取详细信息
     *
     * @return content - 详细信息
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置详细信息
     *
     * @param content 详细信息
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取附件(多个附件地址逗号隔开)
     *
     * @return files - 附件(多个附件地址逗号隔开)
     */
    public String getFiles() {
        return files;
    }

    /**
     * 设置附件(多个附件地址逗号隔开)
     *
     * @param files 附件(多个附件地址逗号隔开)
     */
    public void setFiles(String files) {
        this.files = files;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public List<LibSupp> getLibSuppList() {
        return libSuppList;
    }

    public void setLibSuppList(List<LibSupp> libSuppList) {
        this.libSuppList = libSuppList;
    }
}