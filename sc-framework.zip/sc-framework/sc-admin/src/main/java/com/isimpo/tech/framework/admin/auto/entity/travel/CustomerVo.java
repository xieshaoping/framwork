/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.entity.travel;

import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 * 客户对象，供行程基本信息的下拉选使用
 * @author Tank
 * @version V1.0
 * @since 2019/2/1
 *
 */
public class CustomerVo extends BaseVo {
    /** 客户id*/
    private String id;
    /** 客户名称*/
    private String name;

    private String contact;

    private String phone;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
