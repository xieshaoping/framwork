package com.isimpo.tech.framework.admin.auto.mapper.wechat;


import com.isimpo.tech.framework.admin.auto.entity.WxConfig;
import tk.mybatis.mapper.common.Mapper;

/**
 * 微信账号配置 mapper
 * @author wgq
 * @version 1.0
 * @since 2018年01月03日
 */
public interface WxConfigMapper extends Mapper<WxConfig> {
}