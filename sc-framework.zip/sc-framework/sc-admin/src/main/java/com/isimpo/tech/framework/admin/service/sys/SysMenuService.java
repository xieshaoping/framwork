package com.isimpo.tech.framework.admin.service.sys;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isimpo.tech.framework.admin.auto.entity.SysMenu;
import com.isimpo.tech.framework.admin.auto.mapper.SysMenuMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;

import tk.mybatis.mapper.entity.Example;

/**
 * 菜单service实现类
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/22
 */
@Service
public class SysMenuService extends BaseService<SysMenuMapper, SysMenu> {
    private static final String IS_EXCLUDE_PARENT = "isExcludeParent";

    @Override
    public List<SysMenu> selectListAll(Map<String, Object> params) {
        Example example = new Example(SysMenu.class);
        Example.Criteria criteria = example.createCriteria();
        if (params != null && params.get(IS_EXCLUDE_PARENT) != null && (boolean) params.get(IS_EXCLUDE_PARENT)) {
            criteria.andIsNotNull("parentId");
            params.remove(IS_EXCLUDE_PARENT);
        }
        super.fillParam(example, params);
        return mapper.selectByExample(example);
    }

    /**
     * 删除菜单
     *
     * @param menu 菜单
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(SysMenu menu) {

        menu.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        EntityUtils.setUpdatedInfo(menu);
        super.updateSelectiveById(menu);
    }

    /**
     * 根据用户id获取菜单
     *
     * @param userId 用户id
     * @return 菜单List
     */
    public List<SysMenu> selectUserMenu(String userId) {
        return mapper.selectUserMenu(userId);
    }
}
