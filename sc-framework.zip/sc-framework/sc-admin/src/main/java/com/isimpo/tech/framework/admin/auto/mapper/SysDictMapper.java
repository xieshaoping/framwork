package com.isimpo.tech.framework.admin.auto.mapper;

import java.util.List;

import com.isimpo.tech.framework.admin.auto.entity.SysDict;

import tk.mybatis.mapper.common.Mapper;

public interface SysDictMapper extends Mapper<SysDict> {

    List<String> listType();


    List<SysDict> findAll();
}