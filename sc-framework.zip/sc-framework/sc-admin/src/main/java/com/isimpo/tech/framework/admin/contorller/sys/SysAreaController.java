/*
* Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
* SIMPO Technology. CONFIDENTIAL
*/
package com.isimpo.tech.framework.admin.contorller.sys;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.admin.auto.entity.SysArea;
import com.isimpo.tech.framework.admin.service.sys.SysAreaService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;


/**
 * 系统区域管理Controller
 *
 * @author xieanan
 * @version 1.0
 * @since 2017/12/28
 */
@RestController
@RequestMapping("/sys/area")
public class SysAreaController extends BaseController<SysAreaService, SysArea> {


    @GetMapping("/findList")
    @ResponseBody
    public AjaxResponse findList(@RequestParam Map<String, Object> params) {
        return AjaxResponse.of(baseService.findList(params));
    }

    @GetMapping("/findAll")
    @ResponseBody
    public AjaxResponse findAll(@RequestParam Map<String, Object> params) {
        return AjaxResponse.of(baseService.findAll(params));
    }

    @GetMapping("/findMore")
    @ResponseBody
    public AjaxResponse findChildList(String id) {
        return AjaxResponse.of(baseService.findChildList(id));
    }
}
