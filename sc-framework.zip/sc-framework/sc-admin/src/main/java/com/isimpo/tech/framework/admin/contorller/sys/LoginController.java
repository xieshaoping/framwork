package com.isimpo.tech.framework.admin.contorller.sys;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.isimpo.tech.framework.admin.auto.entity.CommonDict;
import com.isimpo.tech.framework.admin.auto.entity.SysMenu;
import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.admin.service.sys.SysDictService;
import com.isimpo.tech.framework.admin.service.sys.SysMenuService;
import com.isimpo.tech.framework.admin.service.sys.SysUserService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.CacheUtils;
import com.xiaoleilu.hutool.util.MapUtil;
import com.xiaoleilu.hutool.util.RandomUtil;
import com.xiaoleilu.hutool.util.StrUtil;


/**
 * 登陆controller
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/25
 */
@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private SysUserService sysUserService;

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private SysMenuService sysMenuService;

    @Autowired
    private SysDictService sysDictService;


    /**
     * 登陆接口
     *
     * @param user 登录名和密码
     * @return 10000成功
     */
    @PostMapping("/login")
    public AjaxResponse login(@RequestBody SysUser user,
            HttpServletResponse response) {
        String loginName = user.getLoginName();
        String password = user.getPassword();
        SysUser dbUser = sysUserService.getUserByUsername(loginName);
        if (dbUser == null || DBConstants.DEL_FLAG_DELETED.equals(dbUser.getDelFlag())) {
            return AjaxResponse.of(20000, "未找到该用户");
        }
        if (!DBConstants.IS_USE_ENABLED.equals(dbUser.getIsUse())) {
            return AjaxResponse.of(20000, "该用户已停用");
        }

        if (!StrUtil.equals(password, dbUser.getPassword())) {
            return AjaxResponse.of(20000, "密码错误");
        }
        String token = RandomUtil.simpleUUID();
        CacheUtils.set(token, dbUser, 7200);
        return AjaxResponse.of(ResponseCode.SUCCESS, token);
    }

    /**
     * 退出登陆
     *
     * @return 10000成功
     */
    @GetMapping("/logout")
    public AjaxResponse logout(HttpServletResponse response) {
        Optional.ofNullable(getToken()).ifPresent(CacheUtils::delete);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 刷新用户信息
     *
     * @return 10000, 成功
     */
    @GetMapping("/refresh")
    public AjaxResponse refresh() {
        Optional<String> optional = Optional.ofNullable(getToken());
        if (optional.isPresent()) {
            String token = optional.get();
            SysUser userCache = CacheUtils.get(token, SysUser.class);
            if (userCache != null) {
                SysUser dbUser = sysUserService.getUserByUsername(userCache.getLoginName());
                CacheUtils.set(token, dbUser, 7200);
                List<SysMenu> menuList = sysMenuService.selectListAll(MapUtil.of("isExcludeParent", true));
                List<SysMenu> userMenuList = sysMenuService.selectUserMenu(dbUser.getId());
                List<CommonDict> commonDicts = sysDictService.getAll();
                JSONObject result = new JSONObject();
                dbUser.setPassword(null);
                result.put("user", dbUser);
                result.put("dictList", commonDicts);
                result.put("menuList", menuList);
                result.put("userMenuList", userMenuList);
                return AjaxResponse.of(ResponseCode.SUCCESS, result);
            }
        }
        return AjaxResponse.of(ResponseCode.NOT_LOGIN);
    }


    private String getToken() {
        return request.getHeader(CommonConstants.CONTEXT_KEY_USER_TOKEN);
    }


}
