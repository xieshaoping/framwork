package com.isimpo.tech.framework.admin.auto.mapper.content.tratravelertalk;

import com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk.TratRavelerTalk;
import com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk.TratRavelerTalkView;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Component
public interface TratRavelerTalkMapper extends Mapper<TratRavelerTalk> {
    List<TratRavelerTalk> findList(Query query);

    int delTratRavelerTalk(String id);

    TratRavelerTalkView getTratRavelerTalkViewForSys(String id);

    TratRavelerTalkView getTratRavelerTalkViewForUser(String id);

    List<TratRavelerTalkView> getTalkList(String id);

    int delTalk(String id);

    List<TratRavelerTalk> findTalkList(Query query);
}
