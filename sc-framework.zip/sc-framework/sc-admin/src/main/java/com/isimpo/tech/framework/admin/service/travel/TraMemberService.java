package com.isimpo.tech.framework.admin.service.travel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraMember;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.isimpo.tech.framework.admin.auto.entity.travel.MemberVo;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraMemberMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;

/**
 * 成员信息
 * @author Tank
 * @version V1.0
 * @since 2019/2/11
 *
 */
@Service
public class TraMemberService extends BaseService<TraMemberMapper, MemberVo> {

    public static final String IS_LEADER = "1";


    /**
     * 成员列表信息
     * @param query
     */
    public List<MemberVo> getList(Query query) {
        List<MemberVo> list = mapper.getList(query);
        return list;
    }

    /**
     * 单个成员信息
     * @param id 成员id
     */
    public AjaxResponse getMember(String id) {
        MemberVo vo = mapper.findMemberById(id,null);
        return  AjaxResponse.of(vo);
    }

    /**
     * 根据成员id逻辑删除成员
     * @param id 参数
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse removeMember(String id, String traId) {
        if(id==null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        MemberVo vo = mapper.findMemberById(id, traId);
        TraMember traMember = new TraMember();
        traMember.setMemId(vo.getId());
        traMember.setTraId(traId);
        traMember.setDelFlag("1");
        EntityUtils.setUpdatedInfo(traMember);
        int num = mapper.deleteCsrMember(traMember);
        if(num > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 根据成员id转换团长与团员身份
     * @param id 参数
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse leader(String id, String traId) {
        if(id==null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        //查询当前对象的团长或团员身份
        MemberVo vo = mapper.findMemberById(id, traId);
        //转换身份
        if(IS_LEADER.equals(vo.getLeaderFlag())){
            //团长转为团员
            vo.setLeaderFlag("0");
        }else{
            /*//团员转为团长，首先检查本团团长的数目
            int leaderNum = mapper.getLeaderNum(vo.getTraId());
            if(leaderNum >0){
                return AjaxResponse.of(ResponseCode.FAIL,"该团已经存在团长");
            }*/
            int num = mapper.updateLeadType(vo);
            vo.setLeaderFlag("1");
        }
        EntityUtils.setUpdatedInfo(vo);
        int num = mapper.switchLeader(vo);
        if(num > 0){
            if("0".equals(vo.getLeaderFlag())){
                return AjaxResponse.of(ResponseCode.SUCCESS, "取消团长成功");
            }
            return AjaxResponse.of(ResponseCode.SUCCESS, "设为团长成功");
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }
    /**
     * 修改单个成员信息
     * @param params params
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse updateMember(Map<String,Object> params) {
        if(params==null){
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        MemberVo vo = new MemberVo();
        vo.setName(params.get("name").toString());
        int num = mapper.updateMember(vo);
        if(num > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 行程管理 -添加 -成员信息 -成员添加
     * @author wangxinhai
     * @param memberVo
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse traMemberAdd(MemberVo memberVo){
        EntityUtils.setCreatAndUpdatInfo(memberVo);
        memberVo.setType("1");//会员
        // 敏感词过滤
        memberVo.setName(SensitiveWordUtils.filterStr(memberVo.getName()));
        memberVo.setNote(SensitiveWordUtils.filterStr(memberVo.getNote()));
        memberVo.setSource(SensitiveWordUtils.filterStr(memberVo.getSource()));
        int result = mapper.insertCsrMember(memberVo);
        if(result > 0){
            TraMember traMember = new TraMember();
            traMember.setMemId(memberVo.getId());
            traMember.setTraId(memberVo.getTraId());
            traMember.setLeaderFlag("0");
            EntityUtils.setCreatAndUpdatInfo(traMember);
            int num = mapper.insertTraMember(traMember);
            if(num > 0){
                return AjaxResponse.of(ResponseCode.SUCCESS);
            }
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 成员选择加入 行程会员表
     * @author wangxinhai
     * @param member
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse memberListChoo(Member member){
        List<String> memberIds = member.getMemberId();
        List<TraMember> list = new ArrayList<>();
        TraMember m = null;
        for(String s : memberIds){
            m = new TraMember();
            EntityUtils.setCreatAndUpdatInfo(m);
            m.setTraId(member.getTraId());
            m.setMemId(s);
            m.setLeaderFlag("0");
            list.add(m);
        }
        int num = mapper.insertTraMemberList(list);
        if(num > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

}
