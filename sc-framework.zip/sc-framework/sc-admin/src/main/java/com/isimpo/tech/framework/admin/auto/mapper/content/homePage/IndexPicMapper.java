package com.isimpo.tech.framework.admin.auto.mapper.content.homePage;

import com.isimpo.tech.framework.admin.auto.entity.content.homePage.IndexPic;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface IndexPicMapper extends Mapper<IndexPic> {

    List<IndexPic> findList(Query query);
}
