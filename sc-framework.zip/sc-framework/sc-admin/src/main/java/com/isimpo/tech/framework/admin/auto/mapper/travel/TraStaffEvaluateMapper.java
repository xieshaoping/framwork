package com.isimpo.tech.framework.admin.auto.mapper.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraEvaluate;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraStaffEvaluate;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface TraStaffEvaluateMapper extends Mapper<TraStaffEvaluate> {

    List<TraStaffEvaluate> findList(Query query);

    TraStaffEvaluate selectById(Object id);

}