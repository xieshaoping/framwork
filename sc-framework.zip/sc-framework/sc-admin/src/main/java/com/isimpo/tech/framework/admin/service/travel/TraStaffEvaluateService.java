package com.isimpo.tech.framework.admin.service.travel;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraStaffEvaluate;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraStaffEvaluateMapper;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TraStaffEvaluateService extends BaseService<TraStaffEvaluateMapper, TraStaffEvaluate> {
    /**
     * 行程员工评价列表
     * @param query 参数
     * @return 返回数据
     */
    @Override
    public TableResultResponse<TraStaffEvaluate> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<TraStaffEvaluate> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 查看详情
     * @param id
     * @return
     */
    @Override
    public TraStaffEvaluate selectById(Object id) {
        return mapper.selectById(id);
    }
}
