package com.isimpo.tech.framework.admin.contorller.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TimeCapsuleVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TravelRecordVo;
import com.isimpo.tech.framework.admin.service.travel.TimeCapsuleService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
@RestController
@RequestMapping("/timecapsule")
public class TimeCapsuleController{
    @Autowired
    private TimeCapsuleService baseService;

    /**
     * 获取时光胶囊列表
     * @param params
     * @return
     */
    @GetMapping("/list")
    public AjaxResponse getTimeCapsuleList(@RequestParam Map<String, Object> params) {
        return baseService.getTimeCapsules(new Query(params));
    }

    /**
     * 逻辑删除时光胶囊
     * @param timeCapsule
     * @return
     */
    @GetMapping("/del")
    public AjaxResponse delTimeCapsule(TimeCapsuleVo timeCapsule) {
        return baseService.delTimeCapsules(timeCapsule);
    }

    @GetMapping("/detail")
    public AjaxResponse getTimeCapsuleDetail(TimeCapsuleVo timeCapsule) {
        return baseService.getTimeCapsuleDetail(timeCapsule);
    }
}
