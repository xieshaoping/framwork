/*
* Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
* SIMPO Technology. CONFIDENTIAL
*/
package com.isimpo.tech.framework.admin.utils;

import com.alibaba.fastjson.JSONObject;
import com.isimpo.tech.framework.common.util.CacheUtils;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @author zx
 * @version 1.0
 * @since 2018/7/23
 */
public class WeinXinUtil {
	public static final String WECHAT_TOKEN = "wechat_token";
	public static final String WECHAT_TICKET = "wechat_ticket";

	public static Map<String, String> sign (String jsapi_ticket, String url) {
		Map<String, String> ret = new HashMap<String, String>();
		String nonce_str = create_nonce_str();
		String timestamp = create_timestamp();
		String string1;
		String signature = "";

		//注意这里参数名必须全部小写，且必须有序
		string1 = "jsapi_ticket=" + jsapi_ticket +
				"&noncestr=" + nonce_str +
				"&timestamp=" + timestamp +
				"&url=" + url;

		try
		{
			MessageDigest crypt = MessageDigest.getInstance("SHA-1");
			crypt.reset();
			crypt.update(string1.getBytes("UTF-8"));
			signature = byteToHex(crypt.digest());
		}
		catch (NoSuchAlgorithmException e)
		{
			e.printStackTrace();
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}

		ret.put("url", url);
		ret.put("jsapi_ticket", jsapi_ticket);
		ret.put("nonceStr", nonce_str);
		ret.put("timestamp", timestamp);
		ret.put("signature", signature);

		return ret;
	}

	private static String byteToHex(final byte[] hash) {
		Formatter formatter = new Formatter();
		for (byte b : hash) {
			formatter.format("%02x", b);
		}
		String result = formatter.toString();
		formatter.close();
		return result;
	}

	private static String create_nonce_str () {
		return UUID.randomUUID().toString();
	}

	private static String create_timestamp () {
		return Long.toString(System.currentTimeMillis() / 1000);
	}


	//获取token
	public static String getAccessToken (String wxappId, String wxsecret) {
		String access_token = "";
		String grant_type = "client_credential";//获取access_token填写client_credential
		String AppId = wxappId;//第三方用户唯一凭证
		String secret = wxsecret;//第三方用户唯一凭证密钥，即appsecret
		//这个url链接地址和参数皆不能变
		String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type="+grant_type+"&appid="+AppId+"&secret="+secret;  //访问链接

		try {
			URL urlGet = new URL(url);
			HttpURLConnection http = (HttpURLConnection) urlGet.openConnection();
			http.setRequestMethod("GET"); // 必须是get方式请求
			http.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			http.setDoOutput(true);
			http.setDoInput(true);
            /*System.setProperty("sun.net.client.defaultConnectTimeout", "30000");// 连接超时30秒
            System.setProperty("sun.net.client.defaultReadTimeout", "30000"); // 读取超时30秒 */
			http.connect();
			InputStream is = http.getInputStream();
			int size = is.available();
			byte[] jsonBytes = new byte[size];
			is.read(jsonBytes);
			String message = new String(jsonBytes, "UTF-8");
			JSONObject demoJson = JSONObject.parseObject(message);
			access_token = demoJson.getString("access_token");
			is.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return access_token;
	}

	//获取token
	public static String getToken(String wxappId, String wxsecret){
		String token = CacheUtils.getString(WECHAT_TOKEN);
		if(null == token){
			token = getAccessToken(wxappId,wxsecret);
			CacheUtils.set(WECHAT_TOKEN,token,5400);
		}
		return token;
	}

	//获取ticket
	public static String getTicket (String access_token) {
		String ticket = null;
		String url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token="+ access_token +"&type=jsapi";//这个url链接和参数不能变
		try {
			URL urlGet = new URL(url);
			HttpURLConnection http = (HttpURLConnection) urlGet.openConnection();
			http.setRequestMethod("GET"); // 必须是get方式请求
			http.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			http.setDoOutput(true);
			http.setDoInput(true);
			System.setProperty("sun.net.client.defaultConnectTimeout", "30000");// 连接超时30秒
			System.setProperty("sun.net.client.defaultReadTimeout", "30000"); // 读取超时30秒
			http.connect();
			InputStream is = http.getInputStream();
			int size = is.available();
			byte[] jsonBytes = new byte[size];
			is.read(jsonBytes);
			String message = new String(jsonBytes, "UTF-8");
			JSONObject demoJson = JSONObject.parseObject(message);
			ticket = demoJson.getString("ticket");
			is.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ticket;
	}

	//获取token
	public static String getConfigTicKet(String token){
		String ticket = CacheUtils.getString(WECHAT_TICKET);
		if(null == ticket){
			ticket = getTicket(token);
			CacheUtils.set(WECHAT_TICKET,ticket,5400);
		}
		return ticket;
	}
}
