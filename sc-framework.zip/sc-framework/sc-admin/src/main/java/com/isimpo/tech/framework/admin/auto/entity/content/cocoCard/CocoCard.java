package com.isimpo.tech.framework.admin.auto.entity.content.cocoCard;

import com.fasterxml.jackson.annotation.JsonProperty;
import jdk.nashorn.internal.objects.annotations.Getter;
import jdk.nashorn.internal.objects.annotations.Setter;

import java.util.Date;
import javax.persistence.*;

@Table(name = "sys_base")
public class CocoCard {
    /**
     * 主键
     */
    @Id
    private String id;

    //公司网站
    private String website;

    //公司电话
    private String telephone;

    //公司地址
    private String address;

    //公众号名称
    @Column(name = "qrcode_name")
    private String qrcodeName;

    /**
     * 紧急联系电话，多个用英文逗号隔开。
     */
    @Column(name = "urgent_phone")
    private String urgentPhone;

    /**
     * 公司地址（保存经纬度）
     */
    @Column(name = "company_position")
    private String companyPosition;

    /**
     * 提醒邮箱（个用英文逗号隔开）
     */
    @Column(name = "notice_email")
    private String noticeEmail;

    /**
     * 微信公账号二维码
     */
    @Column(name = "qrcode_path")
    private String qrcodePath;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    /**
     * 公司介绍（可乐名片）
     */
    private String introduction;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取紧急联系电话，多个用英文逗号隔开。
     *
     * @return urgent_phone - 紧急联系电话，多个用英文逗号隔开。
     */
    public String getUrgentPhone() {
        return urgentPhone;
    }

    /**
     * 设置紧急联系电话，多个用英文逗号隔开。
     *
     * @param urgentPhone 紧急联系电话，多个用英文逗号隔开。
     */
    public void setUrgentPhone(String urgentPhone) {
        this.urgentPhone = urgentPhone;
    }

    /**
     * 获取公司地址（保存经纬度）
     *
     * @return company_position - 公司地址（保存经纬度）
     */
    public String getCompanyPosition() {
        return companyPosition;
    }

    /**
     * 设置公司地址（保存经纬度）
     *
     * @param companyPosition 公司地址（保存经纬度）
     */
    public void setCompanyPosition(String companyPosition) {
        this.companyPosition = companyPosition;
    }

    /**
     * 获取提醒邮箱（个用英文逗号隔开）
     *
     * @return notice_email - 提醒邮箱（个用英文逗号隔开）
     */
    public String getNoticeEmail() {
        return noticeEmail;
    }

    /**
     * 设置提醒邮箱（个用英文逗号隔开）
     *
     * @param noticeEmail 提醒邮箱（个用英文逗号隔开）
     */
    public void setNoticeEmail(String noticeEmail) {
        this.noticeEmail = noticeEmail;
    }

    /**
     * 获取微信公账号二维码
     *
     * @return qrcode_path - 微信公账号二维码
     */
    public String getQrcodePath() {
        return qrcodePath;
    }

    /**
     * 设置微信公账号二维码
     *
     * @param qrcodePath 微信公账号二维码
     */
    public void setQrcodePath(String qrcodePath) {
        this.qrcodePath = qrcodePath;
    }

    /**
     * 获取删除标识(1:已删除,0:正常)
     *
     * @return del_flag - 删除标识(1:已删除,0:正常)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:已删除,0:正常)
     *
     * @param delFlag 删除标识(1:已删除,0:正常)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取创建备注
     *
     * @return add_mark - 创建备注
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * 设置创建备注
     *
     * @param addMark 创建备注
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新备注
     *
     * @return upd_mark - 更新备注
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新备注
     *
     * @param updMark 更新备注
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    /**
     * 获取公司介绍（可乐名片）
     *
     * @return introduction - 公司介绍（可乐名片）
     */
    public String getIntroduction() {
        return introduction;
    }

    /**
     * 设置公司介绍（可乐名片）
     *
     * @param introduction 公司介绍（可乐名片）
     */
    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getQrcodeName() {
        return qrcodeName;
    }

    public void setQrcodeName(String qrcodeName) {
        this.qrcodeName = qrcodeName;
    }
}
