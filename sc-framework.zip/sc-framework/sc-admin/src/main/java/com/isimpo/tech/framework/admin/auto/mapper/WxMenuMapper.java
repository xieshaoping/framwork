/*
 * @(#) WxMenuMapper.java 2019年02月27日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.mapper;

import com.isimpo.tech.framework.admin.auto.entity.WxConfig;
import com.isimpo.tech.framework.admin.auto.entity.WxMenu;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月27日
 */
public interface WxMenuMapper extends Mapper<WxMenu> {

    /**
     * 获取菜单列表
     *
     * @param query
     * @return
     */
    List<WxMenu> findList(Query query);

    /**
     * 获取所有的已有菜单
     *
     * @return
     */
    List<WxMenu> getPWXMenu(@Param("id") String id);

    /**
     * 获取实体
     *
     * @param id
     * @return
     */
    WxMenu getDetail(@Param("id") String id);

    /**
     * 查询以及菜单数量
     *
     * @return
     */
    Integer getPMenuNum();

    /**
     * 查询所有的一级菜单CODE
     */
    List<String> getPMenuCode();

    /**
     * 查询所有的子菜单
     *
     * @param code
     * @return
     */
    List<String> getCMenuCode(@Param("code") String code);

    /**
     * 查询二级菜数量
     *
     * @return
     */
    Integer getMenuNum(@Param("code") String code);

    /**
     * 保存菜单
     *
     * @param wxMenu
     * @return
     */
    Integer save(WxMenu wxMenu);

    /**
     * 更新菜单
     *
     * @param wxMenu
     * @return
     */
    Integer update(WxMenu wxMenu);

    /**
     * 批量删除菜单
     *
     * @param
     * @return
     */
    Integer del(@Param("code") String code);

    /**
     * 删除单个菜单
     *
     * @param code
     * @return
     */
    Integer delTwo(@Param("code") String code);


    /**
     * 查询微信菜单集合
     *
     * @return
     */
    public List<WxMenu> searchWxMenu(@Param("type") String type);


    /**
     * 查询子菜单
     *
     * @param code
     * @return
     */
    public List<WxMenu> searchChildWxMenu(@Param("code") String code);

    /**
     * 获取微信配置
     *
     * @return
     */
    WxConfig getWxConfig();
}
