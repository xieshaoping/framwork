package com.isimpo.tech.framework.admin.auto.entity.travel;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */

/**
 * 行程游记VO
 */
public class TravelRecordVo extends BaseVo {

    // 游记信息id
    private String id;

    // 发布人名
    private String name;

    // 行程名称
    private String traName;

    // 文件类型 1.图片 2.视频
    private String type;

    // 查看权限 1.团队内 2.公开
    private String browseRange;

    // 行程游记内容
    private String content;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTraName() {
        return traName;
    }

    public void setTraName(String traName) {
        this.traName = traName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBrowseRange() {
        return browseRange;
    }

    public void setBrowseRange(String browseRange) {
        this.browseRange = browseRange;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getAddTime() {
        return super.getAddTime();
    }
}
