/*
 * @(#) WechatConfig.java 2015年11月6日
 * 
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.entity;

import java.io.Serializable;


/**
 * 微信配置类
 * 
 * @author fanhyz
 * @version 1.0
 * @since 2015年11月6日
 */
public class WechatConfig implements Serializable {

	private static final long serialVersionUID = 9158810688104287217L;

	private String appId;// 微信appid
	private String secret;// 唯一凭证密钥
	private String mch_id;// 微信支付 商户号
	private String paySecretId;// 微信支付密钥
	private String token;//

	/**
	 * @return appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId appId
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}

	/**
	 * @return secret
	 */
	public String getSecret() {
		return secret;
	}

	/**
	 * @param secret secret
	 */
	public void setSecret(String secret) {
		this.secret = secret;
	}

	/**
	 * @return mch_id
	 */
	public String getMch_id() {
		return mch_id;
	}

	/**
	 * @param mch_id mch_id
	 */
	public void setMch_id(String mch_id) {
		this.mch_id = mch_id;
	}

	/**
	 * @return paySecretId
	 */
	public String getPaySecretId() {
		return paySecretId;
	}

	/**
	 * @param paySecretId paySecretId
	 */
	public void setPaySecretId(String paySecretId) {
		this.paySecretId = paySecretId;
	}

	/**
	 * @return token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token token
	 */
	public void setToken(String token) {
		this.token = token;
	}

}
