package com.isimpo.tech.framework.admin.contorller.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TravelRecordVo;
import com.isimpo.tech.framework.admin.service.travel.TravelRecordService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
@RestController
@RequestMapping("/travelrecord")
public class TravelRecordController extends BaseController<TravelRecordService, TravelRecordVo> {
    /**
     * 获取行程游记列表
     * @param params
     * @return
     */
    @PostMapping("/list")
    public AjaxResponse getTravelRecordList(@RequestBody Map<String, Object> params) {
        return baseService.getTravelRecords(new Query(params));
    }

    /**
     * 删除行程游记
     * @param travelRecord
     * @return
     */
    @GetMapping("/del")
    public AjaxResponse delTravelRecord(TravelRecordVo travelRecord) {
        return baseService.delTravelRecord(travelRecord);
    }

    /**
     * 获取行程记录详情
     * @param travelRecord
     * @return
     */
    @GetMapping("/detail")
    public AjaxResponse getTravelRecordDetail(TravelRecordVo travelRecord) {
        return baseService.getTravelRecordDetail(travelRecord);
    }
}
