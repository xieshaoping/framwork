package com.isimpo.tech.framework.admin.auto.mapper;

import com.isimpo.tech.framework.admin.auto.entity.SysSensitive;

import tk.mybatis.mapper.common.Mapper;

public interface SysSensitiveMapper extends Mapper<SysSensitive> {

}