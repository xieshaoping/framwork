package com.isimpo.tech.framework.admin.contorller.sys;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.admin.service.sys.SysUserService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.CacheUtils;
import com.xiaoleilu.hutool.util.StrUtil;


/**
 * 系统用户Controller
 *
 * @author guohui
 * @version v1.0.0
 */
@RestController
@RequestMapping("/sys/user")
public class SysUserController extends BaseController<SysUserService, SysUser> {
    /**
     * 重置用户登录密码
     * @param sysUser 用户信息
     * @return ResponseBody
     */
    @PostMapping(value = "/resetPassword")
    public AjaxResponse resetPassword(@RequestBody SysUser sysUser){
        baseService.resetPassword(sysUser);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }



    @PostMapping
    @ResponseBody
    @Override
    public AjaxResponse add(@RequestBody SysUser entity) {
        return baseService.insertEntity(entity);
    }

    @PutMapping("/{id}")
    @ResponseBody
    @Override
    public AjaxResponse update(@RequestBody SysUser entity) {

        return baseService.updateEntity(entity);
    }


    /**
     * 修改用户密码
     * @param params 用户信息
     * @return AjaxResponse
     */
    @PostMapping("changePassword")
    public AjaxResponse changePassword(@RequestBody Map<String,String> params) {
        String userName = BaseContextHandler.getUsername();
        String oldPassword = params.get("oldPassword");
        String newPassword = params.get("newPassword");
        if (StrUtil.isEmpty(oldPassword)) {
            return AjaxResponse.of(20000, "原密码不能为空");
        }
        if (StrUtil.isEmpty(newPassword)) {
            return AjaxResponse.of(20000, "新密码不能为空");
        }
        if (StrUtil.equals(oldPassword, newPassword)) {
            return AjaxResponse.of(20000, "新密码不能与原密码相同");
        }

        if (baseService.checkPassword(userName, oldPassword)) {
            baseService.changePassword(newPassword);
            CacheUtils.delete(BaseContextHandler.getToken());
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }else {
            return AjaxResponse.of(20000, "原密码输入错误");
        }
    }


    /**
     * 用户启用/禁用
     * @param sysUser 用户信息
     * @return ResponseBody
     */
    @PostMapping(value = "/updateStatus")
    public AjaxResponse updateStatus(@RequestBody SysUser sysUser){
        baseService.updateStatus(sysUser);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 根据用户名判断用户是否重复
     * @param loginName 登录名
     * @return  AjaxResponse
     */
    @GetMapping("/checkName")
    public AjaxResponse checkName(String loginName) {
        return AjaxResponse.of(baseService.checkName(loginName));
    }

    /**
     * 获取当前登录人信息
     * @return
     */
    @GetMapping("/getCurrentUser")
    @ResponseBody
    public AjaxResponse getCurrentUser(){
        return AjaxResponse.of(baseService.getCurrentUser());
    }

    /**
     * 首页修改用户
     * @param entity
     * @return
     */
    @PostMapping("/updateUser")
    @ResponseBody
    public AjaxResponse updateUser(@RequestBody SysUser entity) {
        return baseService.updateUser(entity);
    }
}
