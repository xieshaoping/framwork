package com.isimpo.tech.framework.admin.auto.mapper.content.order;

import com.isimpo.tech.framework.admin.auto.entity.content.order.CsrOrder;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface CsrOrderMapper extends Mapper<CsrOrder> {
    List<CsrOrder> findList(Query query);

    CsrOrder selectById(Object id);

    List<WayMng> getRouteList();

    List<CsrOrder> getCsrOrderList();

    int orderChange(List<CsrOrder> list);

    int wayMngChange(List<WayMng> list);
}