/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.entity.travel;

import com.isimpo.tech.framework.common.entity.BaseVo;

/**
 * 管家与领队对象，供行程管理基本信息的管家与领队的下拉选使用
 * @author Tank
 * @version V1.0
 * @since 2019/2/1
 *
 */
public class KeeperVo extends BaseVo {
    /** 管家/领队id*/
    private String id;
    /** 管家/领队名称*/
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
