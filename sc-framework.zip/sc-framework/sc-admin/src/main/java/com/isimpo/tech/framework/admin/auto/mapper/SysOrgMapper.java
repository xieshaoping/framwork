package com.isimpo.tech.framework.admin.auto.mapper;

import java.util.List;
import java.util.Map;

import com.isimpo.tech.framework.admin.auto.entity.SysArea;
import com.isimpo.tech.framework.admin.auto.entity.SysOrg;

import tk.mybatis.mapper.common.Mapper;

public interface SysOrgMapper extends Mapper<SysOrg> {


    /**
     * 根据id查询地区名称
     *
     * @param areaIds 地区ids
     * @return 地区list
     */
    List<SysArea> selectAreas(String... areaIds);


    List<SysOrg> selectListAll(Map<String, Object> params);
}