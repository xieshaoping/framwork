package com.isimpo.tech.framework.admin.contorller.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraEvaluate;
import com.isimpo.tech.framework.admin.service.travel.TraEvaluateService;
import com.isimpo.tech.framework.common.controller.BaseController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 行程评价
 * @Author wangxinhai
 * @date 2019年5月23日
 */
@RestController
@RequestMapping("/travel/traEvaluate")
public class TraEvaluateController extends BaseController<TraEvaluateService, TraEvaluate> {

}
