package com.isimpo.tech.framework.admin.sequence;

/**
 * 编码类型
 * （生成编码的默认格式：前缀名+yyyyMMdd+固定长度序号）
 *
 * @author wgq
 * @version 1.0
 * @since 2018-01-07
 */
public enum SeqType {

    /**
     * 前台会员userNo
     */
    USER_NO("M", 9, false),
    /**
     * 采购管理编号
     */
    CGQD_NO("CGQD", 4, true),
    /**
     * 出库管理编号
     */
    CKQD_NO("CKQD", 4, true),
    /**
     * 入库管理编号
     */
    RKQD_NO("RKQD", 4, true),

    /**
     * 课程类别编号
     */
    SYS_COURSE_TYPE("SCT", 4, true),

    /**
     * 报名记录code
     */
    ENROLL_RECORD("ER",5,true),

    /**
     * 报名明细code
     */
    ENROLL_DETAIL("ED",5,true),

    /**
     * 课程编号
     */
    SYS_COURSE("COU",4,true),

    /**
     * 学生编号
     */
    CYS_NO("XS", 4, true),


    /**
     * 教室编号
     */
    CLASSROOM_NO("JS", 4, true),

    /**
     * 校区编号
     */
    CAMPUS_NO("XQ", 4, true),

    /**
     * 咨询沟通编号
     */
    COMM_NO("GT", 4, true),

    /**
     * 班级编号
     */
    CLASS_NO("CL", 4, true),
    /**
     * 试听编号
     */
    AUDITION_NO("AU", 4, true),
    /**
     * 排课编号
     */
    SCHEDULE_NO("SC", 4, true),
    /**
     * 试听活动编号
     */
    AUDITION_ACTIVITY_NO("AC", 4, true),

    /**
     * 账户编号
     */
    ACCOUNT_NO("ZH", 4, true),


    /**
     * 收支项目分类编号
     */
    CLASSIFY_NO("SZ", 4, true),

    /**
     * 咨询编号
     */
    CONSULT_NO("ZX", 4, true),
    /**
     * 订单编号
     */
    ORDER_NO("OR", 4, true),
    /**
     * 收支明细编号
     */
    FLOW_NO("FW", 4, true),
    /**
     * 收支账户编号
     */
    FLOW_ACCOUNT_NO("FA", 4, true),
    /**
     * 退费编号
     */
    REFUND_NO("RE", 4, true),
    /**
     * 停课编号
     */
    CLOSURE_NO("CO", 4, true),
    /**
     * 复课编号
     */
    RESUME_NO("RS", 4, true),
    /**
     * 调课编号
     */
    EXCHANGE_NO("EX", 4, true),
    /**
     * 考勤记录编号
     */
    ATTEND_NO("AN", 4, true),
    /**
     * 考勤明细记录编号
     */
    ATTEND_DETAIL_NO("AD", 4, true);
    /**
     * 前缀名
     */
    private String prefix;

    /**
     * 序号长度
     */
    private int serialLen;

    /**
     * 是否带有yyyyMMdd格式
     */
    private boolean hasYMD;

    /**
     * 构造函数 （生成编码的格式，根据 {@code hasYMD}值决定，true：前缀名+yyyyMMdd+固定长度序号；false：前缀+固定长度序号）
     *
     * @param prefix    前缀
     * @param serialLen 序号长度
     * @param hasYMD    是否带有yyyyMMdd格式，true:带有，false：前缀+固定长度序号
     */
    SeqType(String prefix, int serialLen, boolean hasYMD) {
        this.prefix = prefix;
        this.serialLen = serialLen;
        this.hasYMD = hasYMD;
    }

    /**
     * 构造函数 （生成默认编码的格式，{@code hasYMD}值为true：前缀名+yyyyMMdd+固定长度序号）
     *
     * @param prefix    前缀
     * @param serialLen 序号长度
     */
    SeqType(String prefix, int serialLen) {
        this(prefix, serialLen, true);
    }

    public boolean isHasYMD() {
        return hasYMD;
    }

    public String getPrefix() {
        return prefix;
    }

    public int getSerialLen() {
        return serialLen;
    }

}
