package com.isimpo.tech.framework.admin;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.ace.cache.EnableAceCache;

/**
 * admin工程启动入口
 *
 * @author guohui
 * @version v1.0.0
 */
@EnableEurekaClient
@EnableCircuitBreaker
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class,scanBasePackages = "com.isimpo.tech.framework")
@EnableScheduling
@EnableAceCache
@EnableTransactionManagement
public class AdminBootstrap {
	public static void main(String[] args) {
		new SpringApplicationBuilder(AdminBootstrap.class).web(true).run(args);
	}
}
