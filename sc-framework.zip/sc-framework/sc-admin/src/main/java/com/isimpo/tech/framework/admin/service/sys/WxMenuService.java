/*
 * @(#) WxMenuService.java 2019年02月27日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.service.sys;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.*;
import com.isimpo.tech.framework.admin.auto.mapper.WxMenuMapper;
import com.isimpo.tech.framework.admin.utils.WeinXinUtil;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.menu.WechatMenuUtil;
import com.isimpo.tech.wechat.pojo.menu.*;
import com.isimpo.tech.wechat.pojo.menu.WechatButton;
import com.isimpo.tech.wechat.pojo.menu.WechatClickButton;
import com.isimpo.tech.wechat.pojo.menu.WechatComplexButton;
import com.isimpo.tech.wechat.pojo.menu.WechatMenu;
import com.isimpo.tech.wechat.pojo.menu.WechatViewButton;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月27日
 */
@Service
public class WxMenuService extends BaseService<WxMenuMapper, WxMenu> {

    @Value("${wx.appid}")
    String appid;

    @Value("${wx.secret}")
    String secret;

    /**
     * 查询微信菜单列表
     *
     * @param query 查询参数
     * @return TableResultResponse<StoreType>
     */
    @Override
    public TableResultResponse<WxMenu> selectByQuery(Query query) {
        query.put("title", EntityUtils.replaceSQLSpecial((String) query.get("name")));
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<WxMenu> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }


    /**
     * 查询一级菜单列表
     *
     * @return
     */
    public AjaxResponse getPWXMenu(String id) {
        //id 为空查询的是所有菜单列表
        //        if (StringUtils.isNotEmpty(id)) {
        //            WxMenu wxMenu = mapper.getDetail(id);
        //            if (wxMenu.getCode().length() > 2) {
        //                id = wxMenu.getCode().substring(0, 2);
        //            }
        //        }
        return AjaxResponse.of(mapper.getPWXMenu(id));
    }

    /**
     * 查询当前实体
     *
     * @param id
     * @return
     */
    public AjaxResponse getDetail(String id) {
        WxMenu wxMenu = mapper.getDetail(id);
        wxMenu.setUpOk("1");
        if (wxMenu.getCode().length() > 2) {
            wxMenu.setpCode(wxMenu.getCode().substring(0, 2));
        } else {
            //查询当前的这个一级菜单有没有下级
            Integer i = mapper.getMenuNum(wxMenu.getCode());
            wxMenu.setpCode("");
            //没有下级
            if (i == 0) {
                wxMenu.setUpOk("0");
            }
        }
        return AjaxResponse.of(wxMenu);
    }

    /**
     * 保存和更新
     *
     * @param wxMenu
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse save(WxMenu wxMenu) {
        if (StringUtils.isEmpty(wxMenu.getType())) {
            wxMenu.setMenuKey("");
            wxMenu.setUrl("");
        } else if ("view".equals(wxMenu.getType())) {
            wxMenu.setMenuKey("");
        } else {
            wxMenu.setUrl("");
        }

        String newCode = null;
        if (StringUtils.isEmpty(wxMenu.getpCode())) {
            //没有选择上级菜单，拿自己就是一级菜单, code格式为 ‘00’
            if (StringUtils.isEmpty(wxMenu.getCode()) || wxMenu.getCode().length() > 2) {
                // 没有选择上级菜单，拿自己就是一级菜单, code格式为 ‘00’
                Integer pMenuNum = mapper.getPMenuNum();
                if (pMenuNum >= 3) {
                    return AjaxResponse.of(20000, "最多存在三个一级菜单");
                }
                if (pMenuNum > 9) {
                    newCode = (pMenuNum + 1) + "";
                } else {
                    //                    newCode = "0" + (pMenuNum + 1);
                    //查询到所有的一级菜单
                    List<String> list = mapper.getPMenuCode();
                    if (list.size() == 0) {
                        newCode = "0" + (pMenuNum + 1);
                    } else {
                        List<String> allCode = new ArrayList<>();
                        allCode.add("01");
                        allCode.add("02");
                        allCode.add("03");
                        for (int i = 0; i < list.size(); i++) {
                            for (int j = 0; j < allCode.size(); j++) {
                                if (allCode.get(j).equals(list.get(i))) {
                                    allCode.remove(j);
                                }
                            }
                        }
                        newCode = allCode.get(0);
                    }
                }
            } else {
                newCode = wxMenu.getCode();
            }
        } else {
            //二级菜单 格式为 '0101'
            int menuNum = mapper.getMenuNum(wxMenu.getpCode());
            if (menuNum >= 5) {
                return AjaxResponse.of(20000, "每个一级菜单下最多存在五个二级菜单");
            }
            if (menuNum > 9) {
                newCode = wxMenu.getpCode() + (menuNum + 1) + "";
            } else {
                //查询到所有的二级菜单
                List<String> list = mapper.getCMenuCode(wxMenu.getpCode());
                if (list.size() == 0) {
                    newCode = wxMenu.getpCode() + "0" + (menuNum + 1);
                } else {
                    List<String> allCode = new ArrayList<>();
                    allCode.add(wxMenu.getpCode() + "01");
                    allCode.add(wxMenu.getpCode() + "02");
                    allCode.add(wxMenu.getpCode() + "03");
                    allCode.add(wxMenu.getpCode() + "04");
                    allCode.add(wxMenu.getpCode() + "05");
                    for (int i = 0; i < list.size(); i++) {
                        for (int j = 0; j < allCode.size(); j++) {
                            if (allCode.get(j).equals(list.get(i))) {
                                allCode.remove(j);
                            }
                        }
                    }
                    newCode = allCode.get(0);
                }
            }
        }
        wxMenu.setCode(newCode);
        if (StringUtils.isEmpty(wxMenu.getId())) {
            //添加
            EntityUtils.setCreatAndUpdatInfo(wxMenu);
            if (mapper.save(wxMenu) > 0) {
//                LogUtil.handlerLogs("系统管理-微信菜单管理-保存", "成功", wxMenu.toString());
                return AjaxResponse.of(ResponseCode.SUCCESS);
            }
        } else {
            //修改
            EntityUtils.setUpdatedInfo(wxMenu);
            if (mapper.update(wxMenu) > 0) {
//                LogUtil.handlerLogs("系统管理-微信菜单管理-更新", "成功", wxMenu.toString());
                return AjaxResponse.of(ResponseCode.SUCCESS);
            }
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 删除
     *
     * @param ids
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse del(List<String> ids) {
        if (ids.size() == 0) {
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        for (String id : ids) {
            //首先判断是不是一级菜单
            WxMenu wxMenu = mapper.getDetail(id);
            //有可能在删除父集的时候把子集也删除了
            if (wxMenu != null) {
                //证明是一级菜单
                if (wxMenu.getCode().length() == 2) {
                    //所以连同子菜单一起干掉
                    mapper.del(wxMenu.getCode());
                }
                //证明这个菜单是二级菜单
                if (wxMenu.getCode().length() > 2) {
                    //那就只删除他自己
                    mapper.delTwo(wxMenu.getCode());
                }
            }
        }
//        LogUtil.handlerLogs("系统管理-微信菜单管理-删除", "成功", ids.toString());
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }


    /**
     * 同步微信菜单
     *
     * @return 0:删除 失败 1：添加失败 2:添加成功
     */
    public AjaxResponse synMenuToWechat() {
        //获取一级菜单
        List<WxMenu> wxMenuVos = mapper.searchWxMenu("1");
        if (wxMenuVos.size() == 0) {
            return AjaxResponse.of(20000, "请先添加菜单");
        }
        WechatMenu menu = new WechatMenu();
        WechatButton[] btns = new WechatButton[wxMenuVos.size()];
        for (int i = 0; i < wxMenuVos.size(); i++) {
            WxMenu wxMenuVo = wxMenuVos.get(i);
            int childCount = mapper.getMenuNum(wxMenuVo.getCode());
            if (childCount > 0) {
                WechatComplexButton complexButton = new WechatComplexButton(); // 组合框
                complexButton.setName(wxMenuVo.getName());
                WechatButton[] subBtns = new WechatButton[childCount];
                List<WxMenu> subWxMenuVos = mapper.searchChildWxMenu(wxMenuVo.getCode());
                for (int j = 0; j < subWxMenuVos.size(); j++) {
                    WxMenu subWxMenuVo = subWxMenuVos.get(j);
                    if (subWxMenuVo.getType().equalsIgnoreCase("click")) {
                        WechatClickButton clickBtn = new WechatClickButton();
                        clickBtn.setName(subWxMenuVo.getName());
                        clickBtn.setType("click");
                        clickBtn.setKey(subWxMenuVo.getMenuKey());
                        subBtns[j] = clickBtn;
                    }
                    if (subWxMenuVo.getType().equalsIgnoreCase("view")) {
                        WechatViewButton vwBtn = new WechatViewButton();
                        vwBtn.setName(subWxMenuVo.getName());
                        vwBtn.setType("view");
                        vwBtn.setUrl(StringEscapeUtils.unescapeHtml(subWxMenuVo.getUrl()));
                        subBtns[j] = vwBtn;
                    }
                }
                complexButton.setSub_button(subBtns);
                btns[i] = complexButton;
            } else {
                if (wxMenuVo.getType().equalsIgnoreCase("click")) {
                    WechatClickButton clickBtn = new WechatClickButton();
                    clickBtn.setName(wxMenuVo.getName());
                    clickBtn.setType("click");
                    clickBtn.setKey(wxMenuVo.getMenuKey());
                    btns[i] = clickBtn;
                } else {
                    WechatViewButton vwBtn = new WechatViewButton();
                    vwBtn.setName(wxMenuVo.getName());
                    vwBtn.setType("view");
                    vwBtn.setUrl(StringEscapeUtils.unescapeHtml(wxMenuVo.getUrl()));
                    btns[i] = vwBtn;
                }
            }
        }
        menu.setButton(btns);
        // 调用接口获取凭证
        String token = WechatApi.getToken();
        if (org.apache.commons.lang3.StringUtils.isNotEmpty(token)) {
            // 获取appid和 secret
            // 加载微信配置信息

            // 创建菜单
            boolean result = WechatMenuUtil.deleteMenu(token, appid, secret);
            // 判断菜单创建结果
            if (result) { // 删除成功
                token = WechatApi.getToken();
                result = WechatMenuUtil.createMenu(menu, token, appid, secret);
                if (result) {
                    return AjaxResponse.of(ResponseCode.SUCCESS);
                } else {
                    return AjaxResponse.of(20000, "菜单创建不正确");
                }
            } else {
                return AjaxResponse.of(20000, "删除原有菜单失败");
            }
        }
        return AjaxResponse.of(20000, "token获取失败");
    }
}
