/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.service.business;

import java.lang.reflect.Field;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraMember;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.util.CacheUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.alibaba.druid.util.StringUtils;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.auto.mapper.business.MemberMapper;
import com.isimpo.tech.framework.admin.utils.DateUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

/**
 * @author LuoCheng
 * @version 1.0
 * @since 2019年01月26日
 */
@Service
public class MemberService extends BaseService<MemberMapper, Member> {

    //手机号 /^1[34578]\d{9}$/
    public static final String REGEX_MOBILE = "^1[23456789]\\d{9}$";//"^((17[0-9])|(14[0-9])|(13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$";
    //身份证
    public static final String REGEX_IDCARD = "(^\\d{18}$)|(^\\d{15}$)";
    //台胞证
    public static final String REGEX_TBCARD = "/^\\d{8}|^[a-zA-Z0-9]{10}|^\\d{18}$/";
    //护照
    public static final String REGEX_PASSPORT = "/^([a-zA-z]|[0-9]){5,17}$/";


    @Override
    public TableResultResponse<Member> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<Member> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse update(Member member) {
        try {
            Member m = mapper.getMemberById(member.getId());
            EntityUtils.setUpdatedInfo(member);
            member.setTalentFlag(m.getTalentFlag());
            filter(member);
            mapper.update(member);
            return AjaxResponse.of(ResponseCode.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResponse.of(ResponseCode.FAIL);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse insertList(List<Member> list) throws Exception{
        List<Member> newList = new ArrayList<Member>();
        //处理空的obj
        for(Member member : list){
            if(!isAllFieldNull(member)){
                // 设置默认达人标识为 0：否
                if (member.getTalentFlag() == null) {
                    member.setTalentFlag("0");
                }
                newList.add(member);
            }

        }
        Query query = new Query(new HashMap<>());
        List<Member> alllist = mapper.findByParm(query);
        List<String> idNumList =alllist.stream().map(Member::getIdNum).collect(Collectors.toList());
        List<String> phoneList = alllist.stream().map(Member::getPhone).collect(Collectors.toList());
        StringBuilder str = new StringBuilder();
        boolean flag = false;
        //校验
        for(int i = 0;i < newList.size();i++){
            Member member = newList.get(i);
            EntityUtils.setCreateInfo(member);
            filter(member);
            if(StringUtils.isEmpty((member.getName()))){
                str.append("第" + (i + 1) + "条数据姓名不能为空,");
                flag = true;
            }
            if(StringUtils.isEmpty((member.getGender()))){
                str.append("第" + (i + 1) + "条数据性别不能为空,");
                flag = true;
            }else{
                if("女".equals(member.getGender())){
                    member.setGender("0");
                }else if("男".equals(member.getGender())){
                    member.setGender("1");
                }else{
                    str.append("第" + (i + 1) + "条数据性别不存在,");
                    flag = true;
                }
            }
            if(StringUtils.isEmpty((member.getPhone()))){
                str.append("第" + (i + 1) + "条数据手机号码不能为空,");
                flag = true;
            }else{
                if(!isMobile(member.getPhone())){
                    str.append("第" + (i + 1) + "条手机号码格式不正确,");
                    flag = true;
                }
                if(phoneList.contains(member.getPhone())){
                    str.append("第" + (i + 1) + "条手机号码重复,");
                    flag = true;
                }else{
                    phoneList.add(member.getPhone());
                }
            }
            if(StringUtils.isEmpty((member.getIdTypeName()))){
                str.append("第" + (i + 1) + "条数据证件类型不能为空,");
                flag = true;
            }
            if(StringUtils.isEmpty((member.getIdNum()))){
                str.append("第" + (i + 1) + "条数据证件号码不能为空,");
                flag = true;
            }else{
                if(idNumList.contains(member.getIdNum())){
                    str.append("第" + (i + 1) + "条证件号码重复,");
                    flag = true;
                }else{
                    idNumList.add(member.getIdNum());
                }
                if("身份证".equals(member.getIdTypeName())){
                    member.setIdType("0");
                    /*if(!isIdCard(member.getIdNum())){
                        str.append("第" + (i + 1) + "条数据身份证格式不正确,");
                        flag = true;
                    }*/
                }else if("护照".equals(member.getIdTypeName())){
                    member.setIdType("1");
                    /*if(!isPassPort(member.getIdNum())){
                        str.append("第" + (i + 1) + "条数据护照格式不正确,");
                        flag = true;
                    }*/
                }else if("台胞证".equals(member.getIdTypeName())){
                    member.setIdType("2");
                    /*if(!isTbCard(member.getIdNum())){
                        str.append("第" + (i + 1) + "条数据台胞证不正确,");
                        flag = true;
                    }*/
                }else{
                    str.append("第" + (i + 1) + "条数据证件类型不存在,");
                    flag = true;
                }
            }
        }
        if (flag) {
            String s = str.substring(0, str.length() - 1);
            return AjaxResponse.of(200001, "导入失败," + s);
        }
        mapper.insertList(newList);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    private AjaxResponse checked(List<Member> list){
        for(Member member:list){
            if(StringUtils.isEmpty(member.getGender())){
                return AjaxResponse.of(ResponseCode.FAIL,"性别不能空");
            }
            if(StringUtils.isEmpty(member.getName())){
                return AjaxResponse.of(ResponseCode.FAIL,"姓名不能空");
            }
            if(StringUtils.isEmpty(member.getPhone())){
                return AjaxResponse.of(ResponseCode.FAIL,"手机号不能空");
            }
            if(StringUtils.isEmpty(member.getIdNum())){
                return AjaxResponse.of(ResponseCode.FAIL,"证件号不能空");
            }
        }
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    public List<Member> queryAllMember(Query query){
        List<Member> list = mapper.findList(query).stream().peek(e->{
            String gender = e.getGender();
            if(StringUtils.equals("0",gender)){
                e.setGender("女");
            }else{
                e.setGender("男");
            }
            String idType = e.getIdType();
            if(StringUtils.equals("1",idType)){
                e.setIdTypeName("护照");
            }else if(StringUtils.equals("0",idType)){
                e.setIdTypeName("身份证");
            }else if(StringUtils.equals("2",idType)){
                e.setIdTypeName("台胞证");
            }
            Date date = e.getBirthday();
            if(null != date){
                String birthday = DateUtils.date2Str(date,"yyyy-MM-dd");
                e.setSbirthday(birthday);
            }
        }).collect(Collectors.toList());

        return list;
    }

    public AjaxResponse checkIdNum(Map<String,Object> params){
            Query query = new Query(params);
        List<Member> list = mapper.findByParm(query);
        if(CollectionUtils.isEmpty(list)){
            return AjaxResponse.of(10000,"");
        }else {
            return AjaxResponse.of(10000,"证件号码已存在");
        }
    }

    public AjaxResponse checkPhone(Map<String,Object> params){
        Query query = new Query(params);
        List<Member> list = mapper.findByParm(query);
        if(CollectionUtils.isEmpty(list)){
            return AjaxResponse.of(10000,"");
        }else {
            return AjaxResponse.of(10000,"手机号已存在");
        }
    }

    public AjaxResponse checkHkPhone(Map<String,Object> params){
        Query query = new Query(params);
        List<Member> list = mapper.findHkByParm(query);
        if(CollectionUtils.isEmpty(list)){
            return AjaxResponse.of(10000,"");
        }else {
            return AjaxResponse.of(10000,"管家手机号已存在");
        }
    }

    // 领队列表
    public TableResultResponse<Member> findTourLeaderList(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<Member> list = mapper.findTourLeaderList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    public AjaxResponse checkTourLeaderPhone(Map<String,Object> params){
        Query query = new Query(params);
        List<Member> list = mapper.checkTourLeaderPhone(query);
        if(CollectionUtils.isEmpty(list)){
            return AjaxResponse.of(10000,"");
        }else {
            return AjaxResponse.of(10000,"领队手机号已存在");
        }
    }

    /**
     * 根据id获取会员信息
     * @author wangxinhai
     * @param id
     * @return
     */
    @Override
    public Member selectById(Object id) {
        return mapper.getMemberById(id.toString());
    }


    /**
     * excel导入 会员信息表 行程会员表
     * @author wangxinhai
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse insertTraAndCsrList(List<Member> list) throws Exception{
        List<Member> newList = new ArrayList<Member>();
        //处理空的obj
        for(Member member : list){
            if(!isAllFieldNull(member)){
                member.setTalentFlag("0");
                newList.add(member);
            }

        }
        String phoneErro = "";
        String idNumErro = "";
        Query query = new Query(new HashMap<>());
        List<Member> alllist = mapper.findByParm(query);
        List<String> idNumList =alllist.stream().map(Member::getIdNum).collect(Collectors.toList());
        List<String> phoneList = alllist.stream().map(Member::getPhone).collect(Collectors.toList());
        StringBuilder str = new StringBuilder();
        boolean flag = false;
        List<TraMember> traList = new ArrayList<>();
        //校验
        for(int i = 0;i < newList.size();i++){
            Member member = newList.get(i);
            filter(member);
            EntityUtils.setCreateInfo(member);
            TraMember traMember = new TraMember();
            traMember.setMemId(member.getId());
            traMember.setTraId(CacheUtils.getString("traId"));
            traMember.setLeaderFlag("0");
            EntityUtils.setCreatAndUpdatInfo(traMember);
            traList.add(traMember);
            if(StringUtils.isEmpty((member.getName()))){
                str.append("第" + (i + 1) + "条数据姓名不能为空,");
                flag = true;
            }
            if(StringUtils.isEmpty((member.getGender()))){
                str.append("第" + (i + 1) + "条数据性别不能为空,");
                flag = true;
            }else{
                if("女".equals(member.getGender())){
                    member.setGender("0");
                }else if("男".equals(member.getGender())){
                    member.setGender("1");
                }else{
                    str.append("第" + (i + 1) + "条数据性别不存在,");
                    flag = true;
                }
            }
            if(StringUtils.isEmpty((member.getPhone()))){
                str.append("第" + (i + 1) + "条数据手机号码不能为空,");
                flag = true;
            }else{
                if(!isMobile(member.getPhone())){
                    str.append("第" + (i + 1) + "条手机号码格式不正确,");
                    flag = true;
                }
                if(phoneList.contains(member.getPhone())){
                    str.append("第" + (i + 1) + "条手机号码重复,");
                    flag = true;
                }else{
                    phoneList.add(member.getPhone());
                }
            }
            if(StringUtils.isEmpty((member.getIdTypeName()))){
                str.append("第" + (i + 1) + "条数据证件类型不能为空,");
                flag = true;
            }
            if(StringUtils.isEmpty((member.getIdNum()))){
                str.append("第" + (i + 1) + "条数据证件号码不能为空,");
                flag = true;
            }else{
                if(idNumList.contains(member.getIdNum())){
                    str.append("第" + (i + 1) + "条证件号码重复,");
                    flag = true;
                }else{
                    idNumList.add(member.getIdNum());
                }
                if("身份证".equals(member.getIdTypeName())){
                    member.setIdType("0");
                    /*if(!isIdCard(member.getIdNum())){
                        str.append("第" + (i + 1) + "条数据身份证格式不正确,");
                        flag = true;
                    }*/
                }else if("护照".equals(member.getIdTypeName())){
                    member.setIdType("1");
                    /*if(!isPassPort(member.getIdNum())){
                        str.append("第" + (i + 1) + "条数据护照格式不正确,");
                        flag = true;
                    }*/
                }else if("台胞证".equals(member.getIdTypeName())){
                    member.setIdType("2");
                    /*if(!isTbCard(member.getIdNum())){
                        str.append("第" + (i + 1) + "条数据台胞证不正确,");
                        flag = true;
                    }*/
                }else{
                    str.append("第" + (i + 1) + "条数据证件类型不存在,");
                    flag = true;
                }
            }
        }
        if (flag) {
            String s = str.substring(0, str.length() - 1);
            return AjaxResponse.of(200001, "导入失败," + s);
        }
        try {
            mapper.insertList(newList);
            mapper.insertTraList(traList);
            return AjaxResponse.of(ResponseCode.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResponse.of(ResponseCode.FAIL,"导入失败");
        }
    }

    public static boolean isMobile(String mobile) {
        return Pattern.matches(REGEX_MOBILE, mobile);
    }

    public static boolean isIdCard(String idCard) {
        return Pattern.matches(REGEX_IDCARD, idCard);
    }

    public static boolean isTbCard(String tbCard) {
        return Pattern.matches(REGEX_TBCARD, tbCard);
    }

    public static boolean isPassPort(String passPort) {
        return Pattern.matches(REGEX_PASSPORT, passPort);
    }

    //判断该对象是否: 返回ture表示所有属性为null  返回false表示不是所有属性都是null
    private boolean isAllFieldNull(Object obj) throws Exception{
        Class stuCla = (Class) obj.getClass();// 得到类对象
        Field[] fs = stuCla.getDeclaredFields();//得到属性集合
        boolean flag = true;
        for (Field f : fs) {//遍历属性
            f.setAccessible(true); // 设置属性是可以访问的(私有的也可以)
            Object val = f.get(obj);// 得到此属性的值
            if(val!=null) {//只要有1个属性不为空,那么就不是所有的属性值都为空
                flag = false;
                break;
            }
        }
        return flag;
    }

    // 敏感词过滤
    private void filter(Member member) {
        member.setName(SensitiveWordUtils.filterStr(member.getName()));
        member.setNote(SensitiveWordUtils.filterStr(member.getNote()));
        member.setSource(SensitiveWordUtils.filterStr(member.getSource()));
    }

    /**
     * 删除会员
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse delMember(String id) {
        Member member = new Member();
        member.setId(id);
        member.setDelFlag("1");
        EntityUtils.setUpdatedInfo(member);
        mapper.delMember(member);
        mapper.delMemberWechar(id);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }
}
