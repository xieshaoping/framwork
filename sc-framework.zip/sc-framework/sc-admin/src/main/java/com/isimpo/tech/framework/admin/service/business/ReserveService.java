package com.isimpo.tech.framework.admin.service.business;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.SysCust;
import com.isimpo.tech.framework.admin.auto.entity.SysHousekeeper;
import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.admin.auto.entity.SysUserRole;
import com.isimpo.tech.framework.admin.auto.entity.business.Reserve;
import com.isimpo.tech.framework.admin.auto.mapper.business.ReserveMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.xiaoleilu.hutool.util.StrUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 系统用户Service
 *
 * @author guohui
 * @version v1.0.0
 */
@Service
public class ReserveService extends BaseService<ReserveMapper, Reserve> {

    /**
     * 查询用户分页列表
     *
     * @param query 分页信息
     * @return TableResultResponse<SysUser> 用户分页列表
     */
    @Override
    public TableResultResponse<Reserve> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<Reserve> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 处理
     *
     * @param reserve 分页信息
     * @return TableResultResponse<SysUser> 用户分页列表
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse handle(Reserve reserve) {
        reserve.setUpdUserId(BaseContextHandler.getUserID());
        reserve.setNote(SensitiveWordUtils.filterStr(reserve.getNote()));
        int result=mapper.handle(reserve);
        if(result==1){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


}
