package com.isimpo.tech.framework.admin.contorller.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.NewsVo;
import com.isimpo.tech.framework.admin.service.travel.NewsService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
@RestController
@RequestMapping("/news")
public class NewsController extends BaseController<NewsService, NewsVo> {

    /**
     * 获取可乐消息详情
     * @param news
     * @return
     */
    @GetMapping("detail")
    public AjaxResponse getNewsDetail(NewsVo news) {
        return baseService.getNewsDetail(news);
    }
    /**
     * 删除可乐消息
     * @param news
     * @return
     */
    @GetMapping("/del")
    public AjaxResponse delNews(NewsVo news) {
        return baseService.delNews(news);
    }

    /**
     * 添加可乐消息
     * @param news
     * @return
     */
    @PostMapping("/add")
    public AjaxResponse addNews(@RequestBody NewsVo news) {
        return baseService.addNews(news);
    }

    /**
     * 查询行程列表
     * @return
     */
    @GetMapping("/listTra")
    public AjaxResponse getTravelList() {
        return baseService.getTravelList();
    }
}
