package com.isimpo.tech.framework.admin.contorller.travel;

import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.*;

import com.isimpo.tech.framework.admin.auto.entity.travel.MemberVo;
import com.isimpo.tech.framework.admin.service.travel.TraMemberService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;

import java.util.Map;


/**
 *
 * 成员信息
 * @author Tank
 * @version V1.0
 * @since 2019/2/11
 *
 */
@RestController
@RequestMapping("/travel_member")
public class TraMemberController extends BaseController<TraMemberService, MemberVo> {


    /**
     * 成员信息
     * @param params 根据行程的id查找成员
     */
    @GetMapping("/member")
    public AjaxResponse memberList(@RequestParam Map<String, Object> params) {//@RequestParam Map<String, Object> params
        Query query = new Query(params);
        return AjaxResponse.of(baseService.getList(query));
    }

    /**
     * 删除成员
     * @param id 成员的id
     */
    @GetMapping("/remove")
    public AjaxResponse removeMember(String id, String traId) {
        return baseService.removeMember(id, traId);
    }

    /**
     * 转换身份
     * @param id 成员的id
     */
    @GetMapping("/leader")
    public AjaxResponse switchLeader(String id, String traId) {
        return baseService.leader(id, traId);
    }


    /**
     * 行程管理 -添加 -成员信息 -成员添加
     * @author wangxinhai
     * @param entity
     * @return
     */
    @PostMapping("/traMemberAdd")
    @ResponseBody
    public AjaxResponse traMemberAdd(@RequestBody MemberVo entity) {
        baseService.traMemberAdd(entity);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 成员选择加入 行程会员表
     * @param member
     * @return
     */
    @PostMapping("/memberListChoo")
    public AjaxResponse memberListChoo(@RequestBody Member member){
        baseService.memberListChoo(member);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

}
