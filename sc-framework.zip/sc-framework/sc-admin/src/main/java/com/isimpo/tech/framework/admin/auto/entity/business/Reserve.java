package com.isimpo.tech.framework.admin.auto.entity.business;

import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @Author: xiesp
 * @Despriction: 预定报名表
 * @Date:Created in 11:36 2019/1/28
 * @Modify By:
 */
@Table(name = "csr_reserve")
public class Reserve extends BaseVo {
    @Id
    private String id;
    private String title;
    private String phone;
    private String place;
    private String state;
    @Column(name = "housekeeper_id")

    private String housekeeperId;
    private String note;
    @Column(name = "handle_time")
    private Date handleIime;

    @Column(name = "ysnc_state")
    private String ysncState;

    @Column(name = "mem_id")
    private String memId;
    /*
     * 管家姓名
     * */
    private String hkName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHkName() {
        return hkName;
    }

    public void setHkName(String hkName) {
        this.hkName = hkName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getHousekeeperId() {
        return housekeeperId;
    }

    public void setHousekeeperId(String housekeeperId) {
        this.housekeeperId = housekeeperId;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Date getHandleIime() {
        return handleIime;
    }

    public void setHandleIime(Date handleIime) {
        this.handleIime = handleIime;
    }

    public String getYsncState() {
        return ysncState;
    }

    public void setYsncState(String ysncState) {
        this.ysncState = ysncState;
    }

    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }
}
