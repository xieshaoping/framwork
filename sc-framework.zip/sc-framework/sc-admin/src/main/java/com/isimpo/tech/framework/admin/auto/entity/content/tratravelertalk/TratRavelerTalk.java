package com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.admin.auto.entity.Common;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;

/**
 * @Author: xyh
 * @Despriction: 旅咖说
 */
@Table(name = "tra_traveler_talk")
public class TratRavelerTalk  {
    //会员id
    @Column(name = "mem_id")
    private String memId;

    //标题
    @Column(name = "title")
    private String title;

    //摘要
    @Column(name = "digest")
    private String digest;

    //封面
    @Column(name = "cover")
    private String cover;

    //显示状态（0：隐藏，1：显示）
    @Column(name = "state")
    private String state;

    //视频地址
    @Column(name = "video_path")
    private String videoPath;

    @Column(name = "screenshot")
    private String screenshot;

    //备注
    @Column(name = "note")
    private String note;

    //类型（1：平台，2：会员）
    @Column(name = "type")
    private String type;

    @Transient
    private String fileName;

    @Transient
    //昵称
    private String name;

    @Id
    private String id;

    @Column(name = "del_flag")
    private String delFlag;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm")
    @Column(name = "add_time")
    private Date addTime;

    @Column(name = "add_user_id")
    private String addUserId;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm")
    @Column(name = "upd_time")
    private Date updTime;

    @Column(name = "upd_user_id")
    private String updUserId;

    public String getScreenshot() {
        return screenshot;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public Date getAddTime() {
        return addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public String getAddUserId() {
        return addUserId;
    }

    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdUserId() {
        return updUserId;
    }

    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    public void setScreenshot(String screenshot) {
        this.screenshot = screenshot;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDigest() {
        return digest;
    }

    public void setDigest(String digest) {
        this.digest = digest;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getVideoPath() {
        return videoPath;
    }

    public void setVideoPath(String videoPath) {
        this.videoPath = videoPath;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
