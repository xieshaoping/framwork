package com.isimpo.tech.framework.admin.auto.mapper.systemmanage;

import com.isimpo.tech.framework.admin.auto.entity.systemmanage.CommentVo;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/1/29
 */
public interface CommentMapper extends Mapper<CommentVo> {

    /**
     * 获取评论列表
     * @param query
     * @return
     */
    List<CommentVo> listComments(Query query);

    /**
     * 逻辑删除评论
     * @param commentVo
     * @return
     */
    int delComment(CommentVo commentVo);
}
