package com.isimpo.tech.framework.admin.service.content.order;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.content.order.CsrOrder;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import com.isimpo.tech.framework.admin.auto.mapper.content.order.CsrOrderMapper;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * 订单管理
 * @author wangxinhai
 * @since 2019/4/18
 */
@Service
public class CsrOrderService extends BaseService<CsrOrderMapper, CsrOrder> {

    /**
     * 查询订单列表
     * @param query 分页信息
     * @return TableResultResponse<> 会员祝福列表
     */
    @Override
    public TableResultResponse<CsrOrder> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<CsrOrder> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 查看订单
     * @param id
     * @return
     */
    @Override
    public CsrOrder selectById(Object id) {
        return mapper.selectById(id);
    }

    /**
     * 获取路线列表
     * @return
     */
    public List<WayMng> getRouteList(){
        return mapper.getRouteList();
    }

    public List<CsrOrder> getCsrOrderList() {
        return mapper.getCsrOrderList();
    }

    @Transactional(rollbackFor = Exception.class)
    public void orderRouteChange(List<CsrOrder> list){
        List<WayMng> routeList = new ArrayList<>();
        WayMng wayMng = null;
        for (int i = 0;i < list.size(); i++) {
            CsrOrder csrOrder = list.get(i);
            wayMng = new WayMng();
            wayMng.setId(csrOrder.getRouteId());
            wayMng.setRecruitState(csrOrder.getRecruitState());
            routeList.add(wayMng);
        }
        mapper.orderChange(list);
        mapper.wayMngChange(routeList);
    }
}
