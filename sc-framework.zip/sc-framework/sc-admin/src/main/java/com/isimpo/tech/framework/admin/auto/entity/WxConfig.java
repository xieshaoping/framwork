package com.isimpo.tech.framework.admin.auto.entity;

import java.util.Date;
import javax.persistence.*;

@Table(name = "wx_config")
public class WxConfig {
    /**
     * 编号
     */
    @Id
    private String id;

    /**
     * 微信公众号原始ID
     */
    @Column(name = "org_id")
    private String orgId;

    /**
     * Token
     */
    private String token;

    /**
     * AppID
     */
    @Column(name = "app_id")
    private String appId;

    /**
     * EncodingAESKey
     */
    @Column(name = "encoding_aes_key")
    private String encodingAesKey;

    /**
     * 用户名
     */
    @Column(name = "user_name")
    private String userName;

    /**
     * 密码
     */
    private String password;

    /**
     * access_token
     */
    @Column(name = "access_token")
    private String accessToken;

    /**
     * 状态(0未起用1起用)
     */
    private String status;

    @Column(name = "app_secret")
    private String appSecret;

    /**
     * 删除标识(1:有效,0:删除)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新页面ID
     */
    @Column(name = "upd_mark")
    private String updMark;

    @Column(name = "mch_id")
    private String mchId;

    @Column(name = "welcome_news_id")
    private String welcomeNewsId;

    @Column(name = "api_key")
    private String apiKey;

    /**
     * 存放活动id
     */
    @Column(name = "welcome_active_id")
    private String welcomeActiveId;

    /**
     * 获取编号
     *
     * @return id - 编号
     */
    public String getId() {
        return id;
    }

    /**
     * 设置编号
     *
     * @param id 编号
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取微信公众号原始ID
     *
     * @return org_id - 微信公众号原始ID
     */
    public String getOrgId() {
        return orgId;
    }

    /**
     * 设置微信公众号原始ID
     *
     * @param orgId 微信公众号原始ID
     */
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    /**
     * 获取Token
     *
     * @return token - Token
     */
    public String getToken() {
        return token;
    }

    /**
     * 设置Token
     *
     * @param token Token
     */
    public void setToken(String token) {
        this.token = token;
    }

    /**
     * 获取AppID
     *
     * @return app_id - AppID
     */
    public String getAppId() {
        return appId;
    }

    /**
     * 设置AppID
     *
     * @param appId AppID
     */
    public void setAppId(String appId) {
        this.appId = appId;
    }

    /**
     * 获取EncodingAESKey
     *
     * @return encoding_aes_key - EncodingAESKey
     */
    public String getEncodingAesKey() {
        return encodingAesKey;
    }

    /**
     * 设置EncodingAESKey
     *
     * @param encodingAesKey EncodingAESKey
     */
    public void setEncodingAesKey(String encodingAesKey) {
        this.encodingAesKey = encodingAesKey;
    }

    /**
     * 获取用户名
     *
     * @return user_name - 用户名
     */
    public String getUserName() {
        return userName;
    }

    /**
     * 设置用户名
     *
     * @param userName 用户名
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * 获取密码
     *
     * @return password - 密码
     */
    public String getPassword() {
        return password;
    }

    /**
     * 设置密码
     *
     * @param password 密码
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * 获取access_token
     *
     * @return access_token - access_token
     */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * 设置access_token
     *
     * @param accessToken access_token
     */
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    /**
     * 获取状态(0未起用1起用)
     *
     * @return status - 状态(0未起用1起用)
     */
    public String getStatus() {
        return status;
    }

    /**
     * 设置状态(0未起用1起用)
     *
     * @param status 状态(0未起用1起用)
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return app_secret
     */
    public String getAppSecret() {
        return appSecret;
    }

    /**
     * @param appSecret
     */
    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    /**
     * 获取删除标识(1:有效,0:删除)
     *
     * @return del_flag - 删除标识(1:有效,0:删除)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:有效,0:删除)
     *
     * @param delFlag 删除标识(1:有效,0:删除)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * @return add_mark
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * @param addMark
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新页面ID
     *
     * @return upd_mark - 更新页面ID
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新页面ID
     *
     * @param updMark 更新页面ID
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    /**
     * @return mch_id
     */
    public String getMchId() {
        return mchId;
    }

    /**
     * @param mchId
     */
    public void setMchId(String mchId) {
        this.mchId = mchId;
    }

    /**
     * @return welcome_news_id
     */
    public String getWelcomeNewsId() {
        return welcomeNewsId;
    }

    /**
     * @param welcomeNewsId
     */
    public void setWelcomeNewsId(String welcomeNewsId) {
        this.welcomeNewsId = welcomeNewsId;
    }

    /**
     * @return api_key
     */
    public String getApiKey() {
        return apiKey;
    }

    /**
     * @param apiKey
     */
    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * 获取存放活动id
     *
     * @return welcome_active_id - 存放活动id
     */
    public String getWelcomeActiveId() {
        return welcomeActiveId;
    }

    /**
     * 设置存放活动id
     *
     * @param welcomeActiveId 存放活动id
     */
    public void setWelcomeActiveId(String welcomeActiveId) {
        this.welcomeActiveId = welcomeActiveId;
    }
}