package com.isimpo.tech.framework.admin.contorller.content.order;

import com.isimpo.tech.framework.admin.auto.entity.content.order.CsrOrder;
import com.isimpo.tech.framework.admin.service.content.order.CsrOrderService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

/**
 * 订单管理
 * @author wangxinhai
 * @since 2019/4/18
 */
@RestController
@RequestMapping("/content/csrOrder")
public class CsrOrderController extends BaseController<CsrOrderService, CsrOrder> {

    /**
     * 获取路线列表
     * @return
     */
    @GetMapping("/getRouteList")
    @ResponseBody
    public AjaxResponse getRouteList(){
        return AjaxResponse.of(baseService.getRouteList());
    }
}
