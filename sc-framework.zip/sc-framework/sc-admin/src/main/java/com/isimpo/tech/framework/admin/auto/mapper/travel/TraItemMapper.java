package com.isimpo.tech.framework.admin.auto.mapper.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraCalendar;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraItem;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraSupp;
import tk.mybatis.mapper.common.Mapper;

import java.util.Calendar;

public interface TraItemMapper extends Mapper<TraItem> {

    TraCalendar getCalendar(String id);

    int insertTraSupp(TraSupp traSupp);

    int updateTraSupp(TraSupp traSupp);

    int delTraSupp(TraSupp traSupp);

    TraSupp getTraSupp(String id);
}