package com.isimpo.tech.framework.admin.contorller.sys;

import com.isimpo.tech.framework.admin.auto.entity.systemmanage.CommentVo;
import com.isimpo.tech.framework.admin.service.sys.CommentManageService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @author zhuyilong
 * @since 2019/1/29
 */
@RestController
@RequestMapping("/commentmanage")
public class CommentManageController extends BaseController<CommentManageService, CommentVo> {

    /**
     * 分页获取评论列表
     *
     * @param params
     * @return
     */
    @GetMapping("/list")
    public AjaxResponse getCommentList(@RequestParam Map<String, Object> params) {
        return baseService.getComments(new Query(params));
    }
    /**
     * 分页获取评论列表
     *
     * @param params
     * @return
     */
    @PostMapping("/list")
    public AjaxResponse getCommentListUsePost(@RequestBody Map<String, Object> params) {
        return baseService.getComments(new Query(params));
    }
    /**
     * 逻辑删除评论
     * @param comment
     * @return
     */
    @GetMapping("/del")
    public AjaxResponse delComment(CommentVo comment) {
        return baseService.delComment(comment);
    }
}
