package com.isimpo.tech.framework.admin.service.travel;

import java.util.List;

import org.springframework.stereotype.Service;

import com.isimpo.tech.framework.admin.auto.entity.travel.CustomerVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.KeeperVo;
import com.isimpo.tech.framework.admin.auto.mapper.travel.CustomerMapper;
import com.isimpo.tech.framework.admin.auto.mapper.travel.KeeperMapper;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/1
 *
 */
@Service
public class KeeperService extends BaseService<KeeperMapper, KeeperVo> {

    /**
     * 管家
     * @return 返回数据
     */
    public AjaxResponse getKeepers() {
        List<KeeperVo> list = mapper.getKeepersAll();
        return  AjaxResponse.of(list);
    }

    /**
     * 领队
     * @return 返回数据
     */
    public AjaxResponse getGuide() {
        List<KeeperVo> list = mapper.getGuideAll();
        return  AjaxResponse.of(list);
    }

}
