/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.contorller.sys;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.admin.auto.entity.SysSensitive;
import com.isimpo.tech.framework.admin.service.sys.SysSensitiveService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;

/**
 * 敏感词管理
 * @author LuoCheng
 * @version 1.0
 * @since 2019年01月25日
 */

@RestController
@RequestMapping("/sys/sensitive")
public class SysSensitiveController extends BaseController<SysSensitiveService,SysSensitive> {

    @GetMapping("/page")
    @Override
    public AjaxResponse list(@RequestParam Map<String, Object> params) {
        Map<String, String> orderByMap = new HashMap<>();
        orderByMap.put("addTime", CommonConstants.ORDER_BY_DESC);
        params.put(CommonConstants.ORDER_BY_PARAM, orderByMap);
        return super.list(params);
    }
}
