package com.isimpo.tech.framework.admin.contorller.sys;

import com.github.pagehelper.Page;
import com.isimpo.tech.framework.admin.auto.entity.SysCust;
import com.isimpo.tech.framework.admin.auto.entity.SysDict;
import com.isimpo.tech.framework.admin.service.sys.SysCustService;
import com.isimpo.tech.framework.admin.service.sys.SysDictService;
import com.isimpo.tech.framework.admin.service.sys.SysUserService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 15:52 2019/1/25
 * @Modify By:
 */
@RestController
@RequestMapping("/sys/cust")
public class SysCustController extends BaseController<SysCustService, SysCust> {


    /*
     * 查询全部客户,分页，每页10条
     * */
    /*@Override
    @GetMapping("/page")
    public AjaxResponse list(@RequestParam Map<String, Object> params) {
        Query query = new Query(params);
        return baseService.custList(query);
    }*/
    /*
     *//*
     * 添加客户
     * *//*
    @GetMapping("/save")
    public AjaxResponse save(@RequestParam Map<String, Object> params) {
        String  id = BaseContextHandler.getUserID();
        return baseService.custList(query);
    }*/

    @GetMapping("/save")
    public AjaxResponse save(@ModelAttribute SysCust sysCust) {
        return baseService.save(sysCust);
    }

    //修改前，显示信息
    @GetMapping("/getOne")
    public AjaxResponse getOne(@RequestParam Map<String, String> params) {
        return baseService.getOne(params);
    }

    //查询一个客户信息
    @GetMapping("/searchOne")
    public AjaxResponse searchOne(@RequestParam Map<String, String> params) {
        return baseService.searchOne(params);
    }


//    //更新客户信息
//    @Override
//    @GetMapping("/update")
//    public AjaxResponse update(@ModelAttribute SysCust sysCust) {
//        return baseService.update(sysCust);
//    }

    @PostMapping("/updateSysCust")
    @ResponseBody
    public AjaxResponse updateSysCust(@RequestBody SysCust entity) {
        return baseService.updateSysCust(entity);
    }



    //    增加
    @Override
    @PostMapping
    @ResponseBody
    public AjaxResponse add(@RequestBody SysCust entity) {
        return AjaxResponse.of( baseService.insertSysCust(entity));
    }

    //  逻辑删除用户
    @Override
    @DeleteMapping("/{id}")
    @ResponseBody
    public AjaxResponse remove(@PathVariable String id) {
        return  baseService.deleteCust(id);
    }
}
