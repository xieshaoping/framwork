package com.isimpo.tech.framework.admin.auto.mapper.content.strategy;

import com.isimpo.tech.framework.admin.auto.entity.content.strategy.StrategyVo;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface StrategyMapper extends Mapper<StrategyVo> {
    /**
     * 查询攻略列表
     * @param query
     * @return
     */
    List<StrategyVo> listStrategy(Query query);
}