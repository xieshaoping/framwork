package com.isimpo.tech.framework.admin.auto.mapper.travel;


import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.auto.entity.content.LibItem;
import com.isimpo.tech.framework.admin.auto.entity.content.LibPlace;
import com.isimpo.tech.framework.admin.auto.entity.content.LibSupp;
import com.isimpo.tech.framework.admin.auto.entity.travel.*;
import com.isimpo.tech.framework.common.util.Query;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

/**
 * 行程管理列表
 * @author Tank
 * @version V1.0
 * @since 2019/1/29
 *
 */

public interface TraManageMapper extends Mapper<TraManageVo> {


    /**
     * 老师列表
     * @param query 参数
     * @return 返回数据
     */
    List<TraManageVo> getList(Query query);


    /**
     * 根据id查找行程
     * @param  id 参数
     * @return 行程对象
     */
    TraManageVo findTravelById(String id);

    /**
     * 删除行程-逻辑删除
     * @param  vo 参数
     * @return 行数
     */
    int removeTravel(TraManageVo vo);

    /**
     * 取消行程-设置状态值为7
     * @param  vo 参数
     * @return 行数
     */
    int cancelTravel(TraManageVo vo);

    /**
     * 行程修改
     *
     */
    int editTravel(TraManageVo vo);


    /**
     * 查询制定中和旅行中的行程
     */
    List<TraManageVo> queryForState();


    void updateState(List<TraManageVo> list);

    List<TraCalendar> getTraCalendarByTraId(String id);

    List<TraCalendar> getTraCalendarByTraIdAndDate(@Param("traId") String traId, @Param("date") Date date);

    int addTraCalendar(TraCalendar traCalendar);

    int updateTraCalendar(TraCalendar traCalendar);

    int delTraCalendar(TraCalendar traCalendar);

    TraCalendar getTraCalendar(String id);

    List<TraPlaceTraItem> getPlaceTraItemList(TraPlace traPlace);

    int getTraPlaceMaxSort(TraPlace traPlace);

    int insertTraPlace(TraPlace traPlace);

    TraPlace getTraPlaceById(String id);

    int updatePlace(TraPlace traPlace);

    int updateTraPlace(TraPlace traPlace);

    int delTraPlace(TraPlace traPlace);

    int updOverView(TraManageVo traManageVo);

    List<Member> findByParm(Query query);

    List<TraCalendar> findCalendarAll();

    void insertMemberList(List<Member> list);
    void insertTraMemberList(List<TraMember> list);
    void insertCalendarList(List<TraCalendar> list);
    void insertPlaceList(List<TraPlace> list);
    void insertTraItemList(List<TraItem> list);

    Member getMemberByName(@Param("name") String name, @Param("type") String type);

    int insertTraHk(List<TraHk> list);

    int deleteTraHk(String traId);

    /**
     * 地区信息库新增
     */
    int insertLibPlace(LibPlace libPlace);

    /**
     * 查询行程事项
     * @param placeId 行程地点id
     */
    List<LibItem> getLibItem(String placeId);

    /**
     * 插入地区介绍
     * @param itemList 行程事项
     */
    int insertLibItem(@Param("itemList") List<LibItem> itemList);

    /**
     * 查询事项补充
     * @param itemList 行程事项
     */
    List<LibSupp> getLibSupp(@Param("itemList") List<LibItem> itemList);

    /**
     * 插入介绍补充
     * @param suppList 介绍补充
     */
    int insertLibSupp(@Param("suppList") List<LibSupp> suppList);
}