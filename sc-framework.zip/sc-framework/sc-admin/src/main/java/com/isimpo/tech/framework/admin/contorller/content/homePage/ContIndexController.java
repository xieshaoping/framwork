package com.isimpo.tech.framework.admin.contorller.content.homePage;

import com.isimpo.tech.framework.admin.auto.entity.content.homePage.ContIndex;
import com.isimpo.tech.framework.admin.auto.entity.content.homePage.IndexPic;
import com.isimpo.tech.framework.admin.service.content.homePage.ContIndexService;
import com.isimpo.tech.framework.admin.service.content.homePage.IndexPicService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 12:37 2019/2/12
 * @Modify By:
 */
@RestController
@RequestMapping("/content/homePage/contIndex")
public class ContIndexController extends BaseController<ContIndexService, ContIndex> {


    @PostMapping
    @ResponseBody
    @Override
    public AjaxResponse add(@RequestBody ContIndex entity) {
        return   baseService.insertContIndex(entity);
    }


    // 管家列表
    @GetMapping("/indeHkpage")
    @ResponseBody
    public AjaxResponse getIndexHkList(@RequestParam Map<String, Object> params) {
        Query query = new Query(params);
        return AjaxResponse.of(baseService.getIndexHkList(query));
    }


    // 路线列表
    @GetMapping("/indexRoutepage")
    @ResponseBody
    public AjaxResponse getIndexRouteList() {
        return AjaxResponse.of(baseService.getIndexRouteList());
    }

    /**
     * 获取带推荐攻略列表
     * @param params
     * @return
     */
    @GetMapping("/indexStrategyPage")
    public AjaxResponse getStrategyList(@RequestParam Map<String, Object> params) {
        return baseService.getStrategyList(new Query(params));
    }

    // 列表,通用
    @GetMapping("/indexPage")
    @ResponseBody
    public AjaxResponse indexPage(String type) {
        return AjaxResponse.of(baseService.indexPage(type));
    }

    //  逻辑删除
    @Override
    @DeleteMapping("/{id}")
    @ResponseBody
    public AjaxResponse remove(@PathVariable String id) {
        return  baseService.deleteIndexHk(id);
    }

}
