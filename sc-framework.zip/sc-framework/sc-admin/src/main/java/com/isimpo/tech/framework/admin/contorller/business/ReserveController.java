package com.isimpo.tech.framework.admin.contorller.business;

import com.isimpo.tech.framework.admin.auto.entity.business.Reserve;
import com.isimpo.tech.framework.admin.service.business.ReserveService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 11:46 2019/1/28
 * @Modify By:
 */
@RestController
@RequestMapping("/business/reserve")
public class ReserveController extends BaseController<ReserveService, Reserve> {


    /*
     * 获取所有管家信息id,name
     * */
    @GetMapping("/handle")
    public AjaxResponse handle(@ModelAttribute Reserve reserve) {
        return baseService.handle(reserve);
    }

}
