package com.isimpo.tech.framework.admin.service.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TimeCapsuleVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TravelRecordVo;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
@Service
public class TimeCapsuleService{
    @Autowired
    private TravelRecordService travelRecordService;

    /**
     * 获取时光胶囊列表
     * @param query
     * @return
     */
    public AjaxResponse getTimeCapsules(Query query) {
        return travelRecordService.getTravelRecords(query);
    }

    /**
     * 逻辑删除时光胶囊
     * @param timeCapsule
     * @return
     */
    public AjaxResponse delTimeCapsules(TimeCapsuleVo timeCapsule) {
        return travelRecordService.delTravelRecord(timeCapsule);
    }

    /**
     * 获取时光胶囊详情
     * @param timeCapsule
     * @return
     */
    public AjaxResponse getTimeCapsuleDetail(TimeCapsuleVo timeCapsule) {
        return travelRecordService.getTravelRecordDetail(timeCapsule);
    }
}
