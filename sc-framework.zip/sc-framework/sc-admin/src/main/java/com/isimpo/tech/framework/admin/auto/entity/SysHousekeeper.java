package com.isimpo.tech.framework.admin.auto.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;

/**
 * @Author: xiesp
 * @Despriction: 管家实体类
 * @Date:Created in 9:13 2019/1/26
 * @Modify By:
 */

@Table(name = "csr_housekeeper")
public class SysHousekeeper extends BaseVo {
    @Id
    private String id;
    @Column(name = "mem_id")
    private String memId;
    @Column(name = "user_id")
    private String userId;
    private String cover;
    private String content;

    //    额外属性
    private String name;
    private String phone;
    private String gender;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date birthday;
    private String source;
    private String note;

    private String message;

    /*证件类型（关联字典表信息）*/
    private String idType;


    /*证件号码（关联字典表信息）*/
    private String idNum;

    /*登陆名*/
    private String loginName;

    private String realName;

    @Column(name = "all_flag")
    private String allFlag;

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }


    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAllFlag() {
        return allFlag;
    }

    public void setAllFlag(String allFlag) {
        this.allFlag = allFlag;
    }
}
