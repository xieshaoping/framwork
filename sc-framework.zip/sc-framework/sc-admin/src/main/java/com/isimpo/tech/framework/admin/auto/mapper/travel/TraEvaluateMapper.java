package com.isimpo.tech.framework.admin.auto.mapper.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraEvaluate;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraStaffEvaluate;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface TraEvaluateMapper extends Mapper<TraEvaluate> {

    List<TraEvaluate> findList(Query query);

    TraEvaluate selectById(Object id);

    List<TraStaffEvaluate> findGuideEva(String traId);
}