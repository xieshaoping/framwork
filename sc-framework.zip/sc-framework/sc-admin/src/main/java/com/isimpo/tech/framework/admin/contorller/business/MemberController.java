/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.contorller.business;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.github.crab2died.handler.ExcelTemplate;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.service.business.MemberService;
import com.isimpo.tech.framework.admin.utils.ExcelUtils;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;

/**
 * 会员管理
 * @author LuoCheng
 * @version 1.0
 * @since 2019年01月26日
 */
@RestController
@RequestMapping("/business/member")
public class MemberController extends BaseController<MemberService, Member> {


    @PutMapping("/{id}")
    @Override
    public AjaxResponse update(@RequestBody Member entity) {
        return baseService.update(entity);
    }

    /**
     * 导出excel模版
     */
    @RequestMapping("/exportExcelModel")
    public void exportExcelModel(HttpServletResponse response,HttpServletRequest
            request) throws Exception {
        List<Member> list = new ArrayList<>();
        String tempPath = "/excelModal/memberInfoModal.xlsx";
        Map<String, String> data = new HashMap<>();
        ExcelTemplate excelTemplate = ExcelUtils.getInstance().exportExcelByModuleHandler(tempPath, 0, list, data, Member.class, false);
        OutputStream outputStream = response.getOutputStream();
        response.reset();
        response.setContentType("application/vnd.ms-excel;charset=utf-8");
        String fileName = URLEncoder.encode("会员信息导入模版.xlsx", "UTF-8");
        if ("FF".equals(getBrowser(request))) { //火狐浏览器
            fileName = new String("会员信息导入模版.xlsx".getBytes("UTF-8"), "iso-8859-1");
        }
        response.setHeader("content-disposition", "attachment;filename=" + fileName);
        excelTemplate.write2Stream(outputStream);
        outputStream.close();
    }

    @RequestMapping("/exportExcel")
    public void exportExcel(HttpServletResponse response, @RequestParam Map<String,Object> params, HttpServletRequest
            request) throws Exception {
        Query query = new Query(params);
        List<Member> list = baseService.queryAllMember(query);
        ExcelUtils.downloadExcel(list,Member.class,"会员信息.xlsx",response,request);
    }

    /**
     * excel导入
     */
    @PostMapping("/importExcel")
    public AjaxResponse importExcel(MultipartFile file) throws Exception {
        List<Member> list = null;
        try {
            list = ExcelUtils.getInstance().readExcel2Objects(file.getInputStream(), Member.class);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return baseService.insertList(list);
    }

    /**
     * 校验身份证
     */
    @GetMapping("/checkIdNum")
    public AjaxResponse checkIdNum(@RequestParam Map<String,Object> params){
        return baseService.checkIdNum(params);
    }

    /**
     * 校验手机号
     */
    @GetMapping("/checkPhone")
    public AjaxResponse checkPhone(@RequestParam Map<String,Object> params){
        return baseService.checkPhone(params);
    }

    /**
     * 校验管家手机号
     */
    @GetMapping("/checkHkPhone")
    public AjaxResponse checkHPhone(@RequestParam Map<String,Object> params){
        return baseService.checkHkPhone(params);
    }


    //  列队页
    @GetMapping("/tourLeaderPage")
    public AjaxResponse findTourLeaderList(@RequestParam Map<String, Object> params) {
        for (String in : params.keySet()) {
            if (!in.equals(CommonConstants.ORDER_BY_PARAM)) {
                //map.keySet()返回的是所有key的值
                String str = (String) params.get(in);//得到每个key多对用value的值
                str = str.replace("%", "%\\");
                str = str.replace("?", "?\\");
                str = str.replace("_", "_\\");
                params.put(in, str);
            }
        }
        Query query = new Query(params);
        return AjaxResponse.of(baseService.findTourLeaderList(query));
    }

    /**
     * 校验领队的手机号
     */
    @GetMapping("/checkTourLeaderPhone")
    public AjaxResponse checkTourLeaderPhone(@RequestParam Map<String,Object> params){
        return baseService.checkTourLeaderPhone(params);
    }


    /**
     * 成员添加 获取会员 分页列表
     * @author wangxinhai
     * @param map
     * @return
     */
    @PostMapping("/getMemberList")
    public AjaxResponse getMemberList(@RequestBody Map map) {
        Query query = new Query(map);
        return AjaxResponse.of(baseService.selectByQuery(query));
    }


    /**
     * excel导入 会员信息表 行程会员表
     * @author wangxinhai
     * @param file
     * @return
     * @throws Exception
     */
    @PostMapping("/importExcelTraAndCsr")
    public AjaxResponse importExcelTraAndCsr(MultipartFile file) throws Exception {
        List<Member> list = null;
        try {
            list = ExcelUtils.getInstance().readExcel2Objects(file.getInputStream(), Member.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return baseService.insertTraAndCsrList(list);
    }

    /**
     * 删除会员
     * @param id
     * @return
     */
    @GetMapping("/delMember")
    @ResponseBody
    public AjaxResponse delMember(String id) {
        return baseService.delMember(id);
    }

    /**
     * 判断浏览器
     *
     * @param request
     * @return
     */
    public String getBrowser(HttpServletRequest request) {
        String UserAgent = request.getHeader("USER-AGENT").toLowerCase();
        if (UserAgent != null) {
            if (UserAgent.indexOf("msie") >= 0)
                return "IE";
            if (UserAgent.indexOf("firefox") >= 0)
                return "FF";
            if (UserAgent.indexOf("safari") >= 0)
                return "SF";
        }
        return null;
    }



}
