package com.isimpo.tech.framework.admin.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.github.pagehelper.PageInterceptor;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Properties;

/**
 * mybatis 配置数据源类
 *
 * @author guohui
 * @version v1.0.0
 */
@Configuration
@EnableConfigurationProperties({DruidDataSourceProperties.class, MybatisProperties.class})
@EnableTransactionManagement
public class MybatisConfiguration {

    private final DruidDataSourceProperties properties;

    private final MybatisProperties mybatisProperties;

    @Autowired
    public MybatisConfiguration(DruidDataSourceProperties properties, MybatisProperties mybatisProperties) {
        this.properties = properties;
        this.mybatisProperties = mybatisProperties;
    }
    //////////////////////////////////////////////////////////////////////////

    @Bean
    public DataSource druidDataSource() throws SQLException {
        @SuppressWarnings("squid:S2095")
        DruidDataSource druidDataSource = new DruidDataSource();
        druidDataSource.setUrl(properties.getUrl());
        druidDataSource.setUsername(properties.getUserName());
        druidDataSource.setPassword(properties.getPassword());
        druidDataSource.setDriverClassName(properties.getDriverClassName());
        druidDataSource.setMaxActive(properties.getMaxActive());
        druidDataSource.setInitialSize(properties.getInitialSize());
        druidDataSource.setMaxWait(properties.getMaxWait());
        druidDataSource.setMinIdle(properties.getMinIdle());
        druidDataSource.setTimeBetweenEvictionRunsMillis(properties.getTimeBetweenEvictionRunsMillis());
        druidDataSource.setMinEvictableIdleTimeMillis(properties.getMinEvictableIdleTimeMillis());
        druidDataSource.setValidationQuery(properties.getValidationQuery());
        druidDataSource.setTestWhileIdle(properties.isTestWhileIdle());
        druidDataSource.setTestOnBorrow(properties.isTestOnBorrow());
        druidDataSource.setTestOnReturn(properties.isTestOnReturn());
        druidDataSource.setPoolPreparedStatements(properties.isPoolPreparedStatements());
        druidDataSource.setMaxOpenPreparedStatements(properties.getMaxOpenPreparedStatements());
        druidDataSource.setFilters(properties.getFilters());

        return druidDataSource;
    }

    @Bean(name = "sqlSessionFactory")
    public SqlSessionFactory sqlSessionFactoryBean(DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        if (StringUtils.isNotBlank(mybatisProperties.getTypeAliasesPackage())) {
            bean.setTypeAliasesPackage(mybatisProperties.getTypeAliasesPackage());
        }
        // 分页插件
        PageInterceptor pageInterceptor = new PageInterceptor();
        Properties interceptorProps = new Properties();
        interceptorProps.setProperty("reasonable", "true");
        interceptorProps.setProperty("supportMethodsArguments", "true");
        interceptorProps.setProperty("returnPageInfo", "check");
        interceptorProps.setProperty("params", "count=countSql");
        pageInterceptor.setProperties(interceptorProps);
        // 添加XML目录
        Interceptor[] plugins = new Interceptor[] {pageInterceptor};
        bean.setPlugins(plugins);

        bean.setMapperLocations(mybatisProperties.getXmlLocation());
        return bean.getObject();
    }

    @Bean
    public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean
    public DataSourceTransactionManager transactionManager(DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

}
