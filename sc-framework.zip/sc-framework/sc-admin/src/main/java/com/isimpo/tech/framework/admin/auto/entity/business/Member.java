/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.entity.business;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.alibaba.druid.util.StringUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.crab2died.annotation.ExcelField;
import com.isimpo.tech.framework.admin.utils.DateUtils;

/**
 * 会员
 *
 * @author LuoCheng
 * @version 1.0
 * @since 2019年01月26日
 */

@Table(name = "csr_member")
public class Member {

    private String id;

    /**role
     * 姓名
     */
    @ExcelField(title = "姓名", order = 1)
    private String name;


    /**
     * 性别
     */
    @ExcelField(title = "性别", order = 2)
    private String gender;

    /**
     * 手机
     */
    @ExcelField(title = "手机号码", order = 4)
    private String phone;

    @JsonFormat(pattern="yyyy-MM-dd")
    private Date birthday;

    /**
     * 证件类型
     */
    @Column(name = "id_type")
    private String idType;

    /**
     * 达人标识 0.否 1.是
     */
    @Column(name = "talent_flag")
    private String talentFlag;


    /**
     * 类型（1：会员，2：管家）
     */
    private  String type;
    /**
     * 证件号码
     */
    @ExcelField(title = "证件号码", order = 6)
    @Column(name = "id_num")
    private String idNum;

    /**
     * 联系地址
     */
    @ExcelField(title = "联系地址", order = 7)
    private String source;

    /**
     * 备注
     */
    @ExcelField(title = "备注", order = 8)
    private String note;

    /**
     * 查看全部行程（0：否，1是）
     */
    @Column(name = "all_flag")
    private String allFlag;

    //头像
    @Transient
    private String photo;

    // -- 1:管家，2：领队，3：团长，4：普通会员
    @Transient
    private String role;

    //openId
    @Transient
    private String openId;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;



    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 关注时间
     */
    @Transient
    private Date followDate;

    /**
     * 昵称
     */
    @Transient
    private String nickName;

    @Transient
    @ExcelField(title = "生日", order = 3)
    private String sbirthday;

    @ExcelField(title = "证件类型", order = 5)
    @Transient
    private String idTypeName;

    //成员id
    @Transient
    private List<String> memberId;

    //行程id
    @Transient
    private String traId;

    public String getSbirthday() {
        return sbirthday;
    }

    public void setSbirthday(String sbirthday) {

        if (!StringUtils.isEmpty(sbirthday)) {
            if (isInteger(sbirthday)) {
                this.birthday = org.apache.poi.ss.usermodel.DateUtil.getJavaDate(Double.valueOf(sbirthday));
            } else {
                if (sbirthday.contains("/")) {
                    sbirthday = sbirthday.replace('/', '-');
                }
                this.birthday = DateUtils.str2Date(sbirthday, "yyyy-MM-dd");
                this.sbirthday=sbirthday;
            }
        }
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getFollowDate() {
        return followDate;
    }

    public void setFollowDate(Date followDate) {
        this.followDate = followDate;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public Date getAddTime() {
        return addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public String getAddUserId() {
        return addUserId;
    }

    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdUserId() {
        return updUserId;
    }

    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    public String getIdTypeName() {
        return idTypeName;
    }

    public void setIdTypeName(String idTypeName) {
        this.idTypeName = idTypeName;
    }

    private boolean isInteger(String str) {
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        return pattern.matcher(str).matches();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    public List<String> getMemberId() {
        return memberId;
    }

    public void setMemberId(List<String> memberId) {
        this.memberId = memberId;
    }

    public String getTalentFlag() {
        return talentFlag;
    }

    public void setTalentFlag(String talentFlag) {
        this.talentFlag = talentFlag;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getAllFlag() {
        return allFlag;
    }

    public void setAllFlag(String allFlag) {
        this.allFlag = allFlag;
    }
}
