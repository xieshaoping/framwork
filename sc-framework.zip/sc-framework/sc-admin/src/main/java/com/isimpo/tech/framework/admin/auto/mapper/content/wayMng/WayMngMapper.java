package com.isimpo.tech.framework.admin.auto.mapper.content.wayMng;


import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.RouteCust;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import tk.mybatis.mapper.common.Mapper;
import com.isimpo.tech.framework.common.util.Query;

import java.util.List;

public interface WayMngMapper extends Mapper<WayMng> {

    List<WayMng> findList(Query query);

    int  insertRouteCust(RouteCust RouteCust);

    List<WayMng> selectList(Query query);

    int  removeDict(WayMng entity);

    int  getTotal(Query query);

    int  getAllTotal(Query query);

    int startWayMng(String id);
}
