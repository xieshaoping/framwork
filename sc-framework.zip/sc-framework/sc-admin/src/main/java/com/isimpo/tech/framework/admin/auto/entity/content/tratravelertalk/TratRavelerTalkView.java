package com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk;

public class TratRavelerTalkView extends TratRavelerTalk {
    //用户头像
    private String pic;
    //日期标识
    private String dateFlag;
    //内容
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getDateFlag() {
        return dateFlag;
    }

    public void setDateFlag(String dateFlag) {
        this.dateFlag = dateFlag;
    }
}
