package com.isimpo.tech.framework.admin.service.travel.complain;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.travel.NewsVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.complain.ComplainVo;
import com.isimpo.tech.framework.admin.auto.mapper.travel.complain.ComplainMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/2/26
 */
@Service
public class ComplainService extends BaseService<ComplainMapper, ComplainVo> {

    /**
     * 分页查询投诉列表
     * @param query
     * @return
     */
    @Override
    public TableResultResponse<ComplainVo> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<ComplainVo> list = mapper.listComplain(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    @Override
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void updateSelectiveById(ComplainVo entity) {
        // 敏感词过滤
        entity.setNote(SensitiveWordUtils.filterStr(entity.getNote()));
        super.updateSelectiveById(entity);
    }
}
