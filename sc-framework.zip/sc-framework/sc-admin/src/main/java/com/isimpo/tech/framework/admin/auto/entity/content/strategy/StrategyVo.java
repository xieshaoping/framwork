package com.isimpo.tech.framework.admin.auto.entity.content.strategy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;

@Table(name = "cont_strategy")
public class StrategyVo extends BaseVo {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 标题
     */
    private String title;

    /**
     * 封面
     */
    private String cover;

    /**
     * 显示状态（0：隐藏，1：显示）
     */
    private String state;

    /**
     * 出发时间
     */
    @Column(name = "set_out")
    @JsonFormat(pattern = "yyyy-MM-dd HH:ss")
    private Date setOut;

    /**
     * 行程天数
     */
    private Integer days;

    /**
     * 人均花费
     */
    private BigDecimal cost;

    /**
     * 和谁出行
     */
    private String companion;

    /**
     * 摘要
     */
    private String summary;

    /**
     * 来源（1：平台，2：达人）
     */
    private String source;

    /**
     * 作者id
     */
    private String author;

    // 作者名称
    @Transient
    private String authorName;

    /**
     * 详细介绍
     */
    private String content;

    /**
     * 置顶标识（0：否，1：是）
     */
    @Column(name = "top_flag")
    private String topFlag;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取封面
     *
     * @return cover - 封面
     */
    public String getCover() {
        return cover;
    }

    /**
     * 设置封面
     *
     * @param cover 封面
     */
    public void setCover(String cover) {
        this.cover = cover;
    }

    /**
     * 获取显示状态（0：隐藏，1：显示）
     *
     * @return state - 显示状态（0：隐藏，1：显示）
     */
    public String getState() {
        return state;
    }

    /**
     * 设置显示状态（0：隐藏，1：显示）
     *
     * @param state 显示状态（0：隐藏，1：显示）
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * 获取出发时间
     *
     * @return set_out - 出发时间
     */
    public Date getSetOut() {
        return setOut;
    }

    /**
     * 设置出发时间
     *
     * @param setOut 出发时间
     */
    public void setSetOut(Date setOut) {
        this.setOut = setOut;
    }

    /**
     * 获取行程天数
     *
     * @return days - 行程天数
     */
    public Integer getDays() {
        return days;
    }

    /**
     * 设置行程天数
     *
     * @param days 行程天数
     */
    public void setDays(Integer days) {
        this.days = days;
    }

    /**
     * 获取人均花费
     *
     * @return cost - 人均花费
     */
    public BigDecimal getCost() {
        return cost;
    }

    /**
     * 设置人均花费
     *
     * @param cost 人均花费
     */
    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    /**
     * 获取和谁出行
     *
     * @return companion - 和谁出行
     */
    public String getCompanion() {
        return companion;
    }

    /**
     * 设置和谁出行
     *
     * @param companion 和谁出行
     */
    public void setCompanion(String companion) {
        this.companion = companion;
    }

    /**
     * 获取摘要
     *
     * @return summary - 摘要
     */
    public String getSummary() {
        return summary;
    }

    /**
     * 设置摘要
     *
     * @param summary 摘要
     */
    public void setSummary(String summary) {
        this.summary = summary;
    }

    /**
     * 获取来源（1：平台，2：达人）
     *
     * @return source - 来源（1：平台，2：达人）
     */
    public String getSource() {
        return source;
    }

    /**
     * 设置来源（1：平台，2：达人）
     *
     * @param source 来源（1：平台，2：达人）
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * 获取作者
     *
     * @return author - 作者
     */
    public String getAuthor() {
        return author;
    }

    /**
     * 设置作者
     *
     * @param author 作者
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * 获取详细介绍
     *
     * @return content - 详细介绍
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置详细介绍
     *
     * @param content 详细介绍
     */
    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getAddTime() {
        return super.getAddTime();
    }

    public String getTopFlag() {
        return topFlag;
    }

    public void setTopFlag(String topFlag) {
        this.topFlag = topFlag;
    }
}
