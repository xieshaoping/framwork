package com.isimpo.tech.framework.admin.service.content.libPlace;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.SysArea;
import com.isimpo.tech.framework.admin.auto.entity.content.*;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraItem;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraPlace;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraSupp;
import com.isimpo.tech.framework.admin.auto.mapper.content.LibPlaceMapper;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraManageMapper;
import com.isimpo.tech.framework.admin.utils.BaseUtil;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.xiaoleilu.hutool.util.StrUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class LibPlaceService extends BaseService<LibPlaceMapper, LibPlace> {

    @Autowired
    private TraManageMapper traManageMapper;

    /**
     * 分页列表
     * @param query
     * @return
     */
    @Override
    public TableResultResponse<LibPlace> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<LibPlace> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 校验地点名称是否重复
     * @param name
     * @return
     */
    public AjaxResponse checkName(String name) {
        List<LibPlace> libPlaceList = mapper.getListByName(name);
        if (libPlaceList.size() > 0) {
            return AjaxResponse.of(10000,"改地点名称已存在!");
        } else {
            return AjaxResponse.of(10000,"");
        }
    }

    /**
     * 获取地点事项补充列表
     * @param id
     * @return
     */
    public LibPlaceItemSupp findLibPlaceItemSuppList(String id) {
        return mapper.findLibPlaceItemSuppList(id);
    }

    /**
     * 查询区域
     * @return
     */
    public List<LibArea> findAreaList() {
        List<LibArea> libAreas = mapper.findAreaList();
        List<LibArea> newAreas = new ArrayList<>();
        if (!libAreas.isEmpty()) {
            String type = libAreas.get(0).getType();
            for (LibArea libArea : libAreas) {
                if (type.equals(libArea.getType())) {
                    newAreas.add(libArea);
                } else {
                    getChildren(newAreas, libArea);
                }
            }
        }
        return newAreas;
    }

    /**
     * 递归区域
     * @param newAreas 新的区域集合
     * @param area 区域
     */
    private static void getChildren(List<LibArea> newAreas, LibArea area) {
        for (LibArea libArea : newAreas) {
            if (StrUtil.equals(libArea.getId(), area.getParentId())) {
                List<LibArea> childList = new ArrayList<>();
                if (null != libArea.getChildren()) {
                    childList = libArea.getChildren();
                }
                childList.add(area);
                libArea.setChildren(childList);
            } else if (null != libArea.getChildren()) {
                getChildren(libArea.getChildren(), area);
            }
        }
    }

    /**
     * 逻辑删除
     * @param id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Object id) {
        LibPlace libPlace = new LibPlace();
        libPlace.setId(id.toString());
        libPlace.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        EntityUtils.setUpdatedInfo(libPlace);
        super.updateSelectiveById(libPlace);
    }

    /**
     * 成员选择加入 行程会员表
     * @author wangxinhai
     * @param libPlace
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse placeListChoo(LibPlace libPlace) throws ParseException {
        List<String> placeIds = libPlace.getPlaceId();
        List<TraPlace> traPlaceList = new ArrayList<>();
        List<TraItem> traItemList = new ArrayList<>();
        List<TraSupp> traSuppList = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

        TraPlace traPlace = null;
        for (String s : placeIds) {
            traPlace = new TraPlace();
            LibPlace libP = mapper.selectByPrimaryKey(s);
            //将LibPlace复制给TraPlace
            BeanUtils.copyProperties(libP,traPlace);
            traPlace.setTraId(libPlace.getTraId());
            traPlace.setCalendarId(libPlace.getCalendarId());
            int num = traManageMapper.getTraPlaceMaxSort(traPlace);
            traPlace.setSort(++num);
            EntityUtils.setCreatAndUpdatInfo(traPlace);
            traPlace.setAddTime(new Date());
            traPlaceList.add(traPlace);
            List<LibItem> libItemList = mapper.findItemListByPlaceId(s);

            String startTime = "01:00";
            String endTime = "01:10";
            Date sTime = sdf.parse(startTime);
            Date eTime = sdf.parse(endTime);
            for(int i = 0; i < libItemList.size(); i++) {
                LibItem lb = libItemList.get(i);

                //事项
                List<LibSupp> libSuppList = mapper.findSuppListByItemId(lb.getId());
                EntityUtils.setCreatAndUpdatInfo(lb);
                libSuppList.stream().forEach(item -> {EntityUtils.setCreatAndUpdatInfo(item);item.setItemId(lb.getId());});
                traSuppList.addAll(BaseUtil.mapList(libSuppList,TraSupp.class));

                lb.setStartTime(sTime);
                lb.setEndTime(eTime);
                lb.setPlaceId(traPlace.getId());
                sTime = addDateMinut(sTime,10);
                eTime = addDateMinut(eTime,10);

            }
            traItemList.addAll(BaseUtil.mapList(libItemList,TraItem.class));
        }
        if (traPlaceList.size() > 0) {
            traManageMapper.insertPlaceList(traPlaceList);
        }
        if (traItemList.size() > 0) {
            traManageMapper.insertTraItemList(traItemList);
        }
        if (traSuppList.size() > 0) {
            mapper.insertTraSupp(traSuppList);
        }

        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 给某个时间增加n分钟
     * @param date
     * @param minutes
     * @return
     */
    public static Date addDateMinut(Date date, int minutes){
        if (date == null)
            return date;
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MINUTE, minutes);// 分钟
        date = cal.getTime();
        return date;
    }

}
