package com.isimpo.tech.framework.admin.quartz;

import com.isimpo.tech.framework.admin.auto.entity.WxConfig;
import com.isimpo.tech.framework.admin.service.wechat.WxConfigService;
import com.isimpo.tech.wechat.WeChatConfigUtil;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.WechatConstants;
import com.isimpo.tech.wechat.WechatJSUtils;
import com.isimpo.tech.wechat.pojo.WechatConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 微信token获取定时任务
 *
 * @author abator
 * @version 1.0
 * @since 2018年01月30日
 */
@Component
public class WechatTokenScheduler {

    private static final Logger logger = LoggerFactory.getLogger(WechatTokenScheduler.class);

    @Autowired
    private WxConfigService wxConfigService;


    /**
     * 一小时执行一次
     */
    //@Scheduled(fixedRate = WechatConstants.TOKEN_REFRESH_INTERVAL * 1000L)
    //@Scheduled(cron = "0 */1 * * * ?")
    public void refreshAccessToken() {
        WechatConfig wechatConfig = WeChatConfigUtil.getWechatConfig();
        if (wechatConfig == null) {
            logger.info("定时任务，获取微信配置");
            // 加载微信配置信息
            WxConfig wxConfig = wxConfigService.getWxConfig();
            if (wxConfig != null) {
                wechatConfig = new WechatConfig();
                wechatConfig.setAppId(wxConfig.getAppId());
                wechatConfig.setSecret(wxConfig.getAppSecret());
                wechatConfig.setToken(wxConfig.getAccessToken());
                wechatConfig.setMch_id(wxConfig.getMchId());
                wechatConfig.setPaySecretId(wxConfig.getApiKey());
                WeChatConfigUtil.load(wechatConfig);
            }
        }
        logger.info("定时任务，刷新微信Token开始");
        WechatApi.refreshAccessToken();
        WechatJSUtils.refreshJsApiToken();
        logger.info("定时任务，刷新微信Token结束");
    }
}
