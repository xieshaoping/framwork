package com.isimpo.tech.framework.admin.auto.mapper.content;

import com.isimpo.tech.framework.admin.auto.entity.content.*;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraItem;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraPlace;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraSupp;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface LibPlaceMapper extends Mapper<LibPlace> {

    List<LibPlace> findList(Query query);

    List<LibPlace> getListByName(String name);

    List<LibArea> findAreaList();

    LibPlaceItemSupp findLibPlaceItemSuppList(String id);

    List<LibItem> findItemListByPlaceId(String placeId);

    List<LibSupp> findSuppListByItemId(String itemId);

    void insertTraSupp(List<TraSupp> list);

}