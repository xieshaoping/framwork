package com.isimpo.tech.framework.admin.auto.mapper.travel;


import java.util.List;

import com.isimpo.tech.framework.admin.auto.entity.travel.CustomerVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.KeeperVo;

import tk.mybatis.mapper.common.Mapper;

/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/1
 *
 */

public interface KeeperMapper extends Mapper<KeeperVo> {


    /**
     * 查询所有管家(id-name)
     * @return 返回数据
     */
    List<KeeperVo> getKeepersAll();

    /**
     * 查询所有领队(id-name)  2019-05-06改 领队 = 领队+管家
     * @return 返回数据
     */
    List<KeeperVo> getGuideAll();


}