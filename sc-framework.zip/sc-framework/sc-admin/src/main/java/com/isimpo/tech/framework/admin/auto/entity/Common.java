package com.isimpo.tech.framework.admin.auto.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.Date;

/**
 * @Author: xiesp
 * @Despriction: 公共实体，通用的6个属性
 * @Date:Created in 15:35 2019/1/26
 * @Modify By:
 */
public class Common {
    @Id
    private String id;

    @Column(name = "del_flag")
    private String delFlag;

    @Column(name = "add_time")
    private Date addTime;

    @Column(name = "add_user_id")
    private String addUserId;

    @Column(name = "upd_time")
    private Date updTime;

    @Column(name = "upd_user_id")
    private String updUserId;

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public Date getAddTime() {
        return addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public String getAddUserId() {
        return addUserId;
    }

    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdUserId() {
        return updUserId;
    }

    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
