package com.isimpo.tech.framework.admin.contorller.sys;

import com.isimpo.tech.framework.admin.auto.entity.SysMenu;
import com.isimpo.tech.framework.admin.service.sys.SysMenuService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 菜单管理controller
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/26
 */
@RestController
@RequestMapping("/sys/menu")
public class SysMenuController extends BaseController<SysMenuService, SysMenu> {

    @GetMapping("/all")
    @Override
    public AjaxResponse all(@RequestParam Map<String, Object> params) {
        Map<String, String> orderByMap = new HashMap<>();
        orderByMap.put("level", CommonConstants.ORDER_BY_ASC);
        orderByMap.put("sort", CommonConstants.ORDER_BY_ASC);
        params.put(CommonConstants.ORDER_BY_PARAM, orderByMap);
        return AjaxResponse.of(baseService.selectListAll(params));
    }
}
