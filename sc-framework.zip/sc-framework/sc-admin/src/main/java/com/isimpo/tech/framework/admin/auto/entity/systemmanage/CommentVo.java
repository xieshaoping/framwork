package com.isimpo.tech.framework.admin.auto.entity.systemmanage;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author zhuyilong
 * @since 2019/1/29
 */

/**
 * 评论管理VO
 */
public class CommentVo extends BaseVo {
    // 评论id
    private String id;

    // 评论人名称
    private String name;

    // 用户头像
    private String photo;

    // 评论人微信昵称
    private String nickName;

    // 被评论人微信昵称
    private String replyNickName;

    // 评论内容
    private String content;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getReplyNickName() {
        return replyNickName;
    }

    public void setReplyNickName(String replyNickName) {
        this.replyNickName = replyNickName;
    }

    @Override
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    public Date getAddTime() {
        return super.getAddTime();
    }
}
