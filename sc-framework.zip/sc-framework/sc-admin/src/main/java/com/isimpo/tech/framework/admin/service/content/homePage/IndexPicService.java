package com.isimpo.tech.framework.admin.service.content.homePage;

import com.isimpo.tech.framework.admin.auto.entity.content.formerlyarticles.FormerlyArticles;
import com.isimpo.tech.framework.admin.auto.entity.content.homePage.IndexPic;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import com.isimpo.tech.framework.admin.auto.mapper.content.formerlyarticles.FormerlyArticlesMapper;
import com.isimpo.tech.framework.admin.auto.mapper.content.homePage.IndexPicMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 12:39 2019/2/12
 * @Modify By:
 */
@Service
public class IndexPicService extends BaseService<IndexPicMapper, IndexPic> {

    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public void insertIndexPic(IndexPic entity) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        mapper.insertSelective(entity);
    }

    /*逻辑删除*/
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse deleteIndexPic(String id) {
        IndexPic indexPic = new IndexPic();
        indexPic.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        indexPic.setId(id);
        EntityUtils.setUpdatedInfo(indexPic);
        int result = mapper.updateByPrimaryKeySelective(indexPic);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }
}
