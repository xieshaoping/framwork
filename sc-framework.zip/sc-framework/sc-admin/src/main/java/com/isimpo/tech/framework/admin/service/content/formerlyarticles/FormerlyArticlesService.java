package com.isimpo.tech.framework.admin.service.content.formerlyarticles;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.isimpo.tech.framework.admin.auto.entity.content.formerlyarticles.FormerlyArticles;
import com.isimpo.tech.framework.admin.auto.mapper.content.formerlyarticles.FormerlyArticlesMapper;
import com.isimpo.tech.framework.admin.utils.WechatXCXUtils;
import com.isimpo.tech.framework.admin.utils.vo.Material;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;

@Service
public class FormerlyArticlesService extends BaseService<FormerlyArticlesMapper, FormerlyArticles> {

    /**
     * 查询往日文章分页列表
     * @param query 分页信息
     * @return TableResultResponse<SysUser> 用户分页列表
     */
    @Override
    public TableResultResponse<FormerlyArticles> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<FormerlyArticles> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse syncArticles() {
        try {
            //获取所有已同步的文章
            List<String> stringList =
                    super.selectListAll(new HashMap<>()).stream().map(FormerlyArticles::getThumbMediaId)
                            .collect(Collectors.toList());
            List<Material> materials = WechatXCXUtils.getArticleList("news");
            List<FormerlyArticles> articles = materials.stream().filter(e -> !stringList.contains(e.getThumbMediaId()))
                    .map(this::getFormerlyArticle).collect(Collectors.toList());
            if(!CollectionUtils.isEmpty(articles)){
                 mapper.insertList(articles);
            }
            List<FormerlyArticles> articlesList = materials.stream().filter(e -> stringList.contains(e.getThumbMediaId()))
                    .map(this::getFormerlyArticles).collect(Collectors.toList());
            if(!CollectionUtils.isEmpty(articlesList)){
                mapper.updateList(articlesList);
            }
            return AjaxResponse.of(ResponseCode.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResponse.of(ResponseCode.FAIL);
        }
    }

    private FormerlyArticles getFormerlyArticles(Material material) {
        FormerlyArticles articles = new FormerlyArticles();
        EntityUtils.setCreateInfo(articles);
        articles.setTitle(material.getTitle());
        articles.setDigest(material.getDigest());
        articles.setCover(material.getThumbUrl());
        articles.setState("1");
        articles.setContent(material.getContent());
        articles.setAuthor(material.getAuthor());
        articles.setThumbMediaId(material.getThumbMediaId());
        articles.setContentSourceUrl(material.getContentSourceUrl());
        articles.setUpdateTime(material.getUpdateTime());
        articles.setUrl(material.getUrl());
        return articles;
    }

    private FormerlyArticles getFormerlyArticle(Material material) {
        FormerlyArticles articles = new FormerlyArticles();
        EntityUtils.setCreateInfo(articles);
        articles.setTitle(material.getTitle());
        articles.setDigest(material.getDigest());
        articles.setCover(material.getThumbUrl());
        articles.setState("0");
        articles.setContent(material.getContent());
        articles.setAuthor(material.getAuthor());
        articles.setThumbMediaId(material.getThumbMediaId());
        articles.setContentSourceUrl(material.getContentSourceUrl());
        articles.setUpdateTime(material.getUpdateTime());
        articles.setUrl(material.getUrl());
        return articles;
    }

    public TableResultResponse<FormerlyArticles> indexArticleList(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<FormerlyArticles> list = mapper.indexArticleList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }


    public FormerlyArticles getArticles(String id){
        return mapper.getArticles(id);
    }
}
