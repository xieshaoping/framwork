package com.isimpo.tech.framework.admin.auto.mapper;

import java.util.List;

import com.isimpo.tech.framework.admin.auto.entity.SysArea;
import com.isimpo.tech.framework.common.util.Query;

import tk.mybatis.mapper.common.Mapper;

public interface SysAreaMapper extends Mapper<SysArea> {

    /**
     * 按type排序查询所有的地区
     *
     * @param query 查询条件
     * @return List<SysArea> 区域list
     */
     List<SysArea> findList(Query query);

    /**
     * 根据id删除地区及下属地区
     * @param area 地区id
     */
    void deleteSelfAndChildren(SysArea area);

    /**
     * 更新地区信息
     * @param area 地区
     */
    void updateSelfAndChildren(SysArea area);

    /**
     * 根据code查询区域数量
     * @param code 区域编码
     * @return 数量
     */
    int checkCode(String code);


    /**
     * 根据id查询此地域有没有子集
     * @param id
     * @return
     */
    int findCount(String id);

    /**
     * 根据条件查询区域信息
     * @param query 查寻条件
     * @return
     */
    List<SysArea> searchList(Query query);


    List<SysArea> findChildList(String id);

    SysArea findSysArea(String id);
}