/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.entity.travel;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;
import java.util.List;

/**
 * 行程领队
 * @author wangxinhai
 * @version V1.0
 * @since 2019/5/6
 *
 */
@Table(name = "tra_hk")
public class TraHk extends BaseVo {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 行程id
     */
    @Column(name = "tra_id")
    private String traId;

    /**
     * 领队id
     */
    @Column(name = "hk_id")
    private String hkId;

    /**
     * 删除标识(1:已删除,0:正常)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 创建备注
     */
    @Column(name = "add_mark")
    private String addMark;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新备注
     */
    @Column(name = "upd_mark")
    private String updMark;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTraId() {
        return traId;
    }

    public void setTraId(String traId) {
        this.traId = traId;
    }

    public String getHkId() {
        return hkId;
    }

    public void setHkId(String hkId) {
        this.hkId = hkId;
    }

    @Override
    public String getDelFlag() {
        return delFlag;
    }

    @Override
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public Date getAddTime() {
        return addTime;
    }

    @Override
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    @Override
    public String getAddUserId() {
        return addUserId;
    }

    @Override
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    @Override
    public String getAddMark() {
        return addMark;
    }

    @Override
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }

    @Override
    public Date getUpdTime() {
        return updTime;
    }

    @Override
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    @Override
    public String getUpdUserId() {
        return updUserId;
    }

    @Override
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    @Override
    public String getUpdMark() {
        return updMark;
    }

    @Override
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }
}
