package com.isimpo.tech.framework.admin.utils;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;
import org.dozer.DozerBeanMapper;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 一些常用工具类
 * @author : qin dong on 2019/4/11 9:39
 */
public class BaseUtil {
    /**
     * 格式化格式 yyyy-MM-dd
     */
    public final static String DAY_FORMAT = "yyyy-MM-dd";

    /**
     * 格式化格式 yyyy-MM-dd HH:mm:ss
     */
    public final static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    /**
     * 获取uuid
     * @return
     */
    public static String getId(){
        return UUID.randomUUID().toString().replaceAll("\\-", "");
    }

    /**
     * 对象之间转换 Obj A --> Obj B
     * @param source            源Obj
     * @param destinationClass  目标Obj
     * @param <T>               泛型
     * @return  目标对象Obj
     */
    public static <T> T map(Object source, Class<T> destinationClass) {
        DozerBeanMapper mapper = new DozerBeanMapper();
        if (source == null) {
            return null;
        }
        return mapper.map(source, destinationClass);
    }

    /**
     * 对象list之间转换 List A --> List B
     * @param sourceList          源List
     * @param destinationClass    目标List
     * @param <T>                 泛型
     * @return 目标List
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static <T> List<T> mapList(Collection sourceList, Class<T> destinationClass) {
        DozerBeanMapper mapper = new DozerBeanMapper();
        List<T> destinationList = new ArrayList();
        if (sourceList == null) {
            return destinationList;
        }
        for (Object sourceObject : sourceList) {
            if (sourceObject != null) {
                T destinationObject = mapper.map(sourceObject, destinationClass);
                destinationList.add(destinationObject);
            }
        }
        return destinationList;
    }

    /**
     * md5加密
     * @param paramArrayOfByte
     * @return
     */
    public static String getMD5(byte[] paramArrayOfByte)
    {
        String str = null;
        char[] arrayOfChar1 = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
        try
        {
            MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
            localMessageDigest.update(paramArrayOfByte);
            byte[] arrayOfByte = localMessageDigest.digest();
            char[] arrayOfChar2 = new char[32];
            int i = 0;
            for (int j = 0; j < 16; j++)
            {
                int k = arrayOfByte[j];
                arrayOfChar2[(i++)] = arrayOfChar1[(k >>> 4 & 0xF)];
                arrayOfChar2[(i++)] = arrayOfChar1[(k & 0xF)];
            }
            str = new String(arrayOfChar2);
        }
        catch (Exception localException)
        {
            localException.printStackTrace();
        }
        return str;
    }

    /**
     * 汉字转为拼音
     * @param chinese
     * @return
     */
    public static String toPinyin(String chinese){
        StringBuilder pinyinStr = new StringBuilder();
        char[] newChar = chinese.toCharArray();
        HanyuPinyinOutputFormat defaultFormat = new HanyuPinyinOutputFormat();
        defaultFormat.setCaseType(HanyuPinyinCaseType.LOWERCASE);
        defaultFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        for (char c : newChar) {
            if (c > 128) {
                try {
                    pinyinStr.append(PinyinHelper.toHanyuPinyinStringArray(c, defaultFormat)[0]);
                } catch (BadHanyuPinyinOutputFormatCombination e) {
                    e.printStackTrace();
                }
            } else {
                pinyinStr.append(c);
            }
        }
        return pinyinStr.toString();
    }

    /**
     * 比较两个时间的大小
     *
     * @param date1 日期1 yyyy-MM-dd HH:mm
     * @param date2 日期2 yyyy-MM-dd HH:mm
     * @return true:date1在date2前  false:date1在date2后 (前后判断以二维时间轴为准)
     */
    public static boolean compareDate(String date1, String date2) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            Date dt1 = sdf.parse(date1);
            Date dt2 = sdf.parse(date2);
            return dt1.getTime() >= dt2.getTime();
//            if (dt1.getTime() > dt2.getTime()) {
            //System.out.println("dt1 在dt2前");
//                flag = true;
//            } else if (dt1.getTime() < dt2.getTime()) {
            //System.out.println("dt1在dt2后");
//                flag = false;
//            }else{
//                System.out.println("两个时间相等");
//                flag = true;
//            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }

    //根据当前日期获得所在周的日期区间（周一和周日日期）
    public static String getTimeInterval(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(DAY_FORMAT);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        // 判断要计算的日期是否是周日，如果是则减一天计算周六的，否则会出问题，计算到下一周去了
        int dayWeek = cal.get(Calendar.DAY_OF_WEEK);// 获得当前日期是一个星期的第几天
        if (1 == dayWeek) {
            cal.add(Calendar.DAY_OF_MONTH, -1);
        }
        // System.out.println("要计算日期为:" + sdf.format(cal.getTime())); // 输出要计算日期
        // 设置一个星期的第一天，按中国的习惯一个星期的第一天是星期一
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        // 获得当前日期是一个星期的第几天
        int day = cal.get(Calendar.DAY_OF_WEEK);
        // 根据日历的规则，给当前日期减去星期几与一个星期第一天的差值
        cal.add(Calendar.DATE, cal.getFirstDayOfWeek() - day);
        String imptimeBegin = sdf.format(cal.getTime());
        // System.out.println("所在周星期一的日期：" + imptimeBegin);
        cal.add(Calendar.DATE, 6);
        String imptimeEnd = sdf.format(cal.getTime());
        // System.out.println("所在周星期日的日期：" + imptimeEnd);
        return imptimeBegin + "," + imptimeEnd;
    }

    //获取一周开始到结束的list集合
    public static List<Date> findDates(Date dBegin, Date dEnd)
    {
        List lDate = new ArrayList();
        lDate.add(dBegin);
        Calendar calBegin = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calBegin.setTime(dBegin);
        Calendar calEnd = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calEnd.setTime(dEnd);
        // 测试此日期是否在指定日期之后
        while (dEnd.after(calBegin.getTime()))
        {
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量
            calBegin.add(Calendar.DAY_OF_MONTH, 1);
            lDate.add(calBegin.getTime());
        }
        return lDate;
    }

    //获取当前一周所有的日期合集
    public static List<String> weekendDate() {
        List<String> weekendDates = new ArrayList<>();
        String yz_time=BaseUtil.getTimeInterval(new Date());//获取本周时间
        String array[]=yz_time.split(",");
        String start_time=array[0];//本周第一天
        String end_time=array[1];  //本周最后一天
        //格式化日期
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try{
            Date dBegin = sdf.parse(start_time);
            Date dEnd = sdf.parse(end_time);
            List<Date> lDate = findDates(dBegin, dEnd);//获取这周所有date
            for (Date date : lDate)
            {
                weekendDates.add(sdf.format(date));
            }
            return weekendDates;
        }catch (Exception e){
            return weekendDates;
        }
    }

    /**
     *  java 获取 获取某年某月 所有日期（yyyy-mm-dd格式字符串）
     * @param year
     * @param month
     * @return
     */
    public static List<String> getMonthFullDay(int year , int month){
        SimpleDateFormat dateFormatYYYYMMDD = new SimpleDateFormat("yyyy-MM-dd");
        List<String> fullDayList = new ArrayList<>();
        // 获得当前日期对象
        Calendar cal = Calendar.getInstance();
        cal.clear();// 清除信息
        cal.set(Calendar.YEAR, year);
        // 1月从0开始
        cal.set(Calendar.MONTH, month-1 );
        // 当月1号
        cal.set(Calendar.DAY_OF_MONTH,1);
        int count = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int j = 1; j <= count ; j++) {
            fullDayList.add(dateFormatYYYYMMDD.format(cal.getTime()));
            cal.add(Calendar.DAY_OF_MONTH,1);
        }
        return fullDayList;
    }
}
