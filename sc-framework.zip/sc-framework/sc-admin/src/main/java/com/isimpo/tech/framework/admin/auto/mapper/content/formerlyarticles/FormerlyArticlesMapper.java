package com.isimpo.tech.framework.admin.auto.mapper.content.formerlyarticles;

import java.util.List;

import com.isimpo.tech.framework.admin.auto.entity.content.formerlyarticles.FormerlyArticles;

import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

public interface FormerlyArticlesMapper extends Mapper<FormerlyArticles> {

    void insertList(List<FormerlyArticles> list);

    void updateList(List<FormerlyArticles> list);

    List<FormerlyArticles> findList(Query query);

    List<FormerlyArticles> indexArticleList(Query query);

    FormerlyArticles getArticles(String id);
}
