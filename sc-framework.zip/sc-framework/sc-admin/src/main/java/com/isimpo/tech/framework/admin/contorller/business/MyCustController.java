package com.isimpo.tech.framework.admin.contorller.business;

import com.isimpo.tech.framework.admin.auto.entity.SysCust;
import com.isimpo.tech.framework.admin.auto.entity.business.Reserve;
import com.isimpo.tech.framework.admin.service.business.MyCustService;
import com.isimpo.tech.framework.admin.service.business.ReserveService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 15:32 2019/1/31
 * @Modify By:
 */
@RestController
@RequestMapping("/business/myCust")
public class MyCustController extends BaseController<MyCustService, SysCust> {


    //查看自己是否是管家，并返回mem_id
    @GetMapping("/checkMyId")
    @ResponseBody
    public AjaxResponse checkMyId() {
        return AjaxResponse.of(baseService.checkMyId());
    }

    @Override
    @PutMapping("/{id}")
    @ResponseBody
    public AjaxResponse update(@RequestBody SysCust entity) {
        return AjaxResponse.of(baseService.updateMyCustById(entity));
    }



}
