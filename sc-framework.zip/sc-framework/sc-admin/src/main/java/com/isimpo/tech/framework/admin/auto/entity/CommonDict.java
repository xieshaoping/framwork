/*
* Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
* SIMPO Technology. CONFIDENTIAL
*/
package com.isimpo.tech.framework.admin.auto.entity;

import java.util.List;

/**字典前台共通
 * @author xieanan
 * @version 1.0
 * @since 2018/1/15
 */
public class CommonDict {

    private String key;
    private List<SysDict> value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public List<SysDict> getValue() {
        return value;
    }

    public void setValue(List<SysDict> value) {
        this.value = value;
    }
}
