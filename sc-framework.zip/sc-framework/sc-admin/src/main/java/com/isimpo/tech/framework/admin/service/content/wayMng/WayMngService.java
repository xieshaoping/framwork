package com.isimpo.tech.framework.admin.service.content.wayMng;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.RouteCust;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import com.isimpo.tech.framework.admin.auto.mapper.content.wayMng.WayMngMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class WayMngService extends BaseService<WayMngMapper, WayMng> {

    /*
    * 查询所有路线集合
    * */
    @Override
    public TableResultResponse<WayMng> selectByQuery(Query query) {
        /*int limit = query.getLimit();
        int offset = (query.getPage() - 1) * limit;
        query.put("offset", offset);
        query.put("limit", limit);

        // 获得总条数
        int total = mapper.getAllTotal(query);*/

        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<WayMng> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse insertWayMng(WayMng entity) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        filter(entity);
        List<RouteCust> routeCustList = entity.getCustomize();
        for (RouteCust r : routeCustList) {
            r.setRouteId(entity.getId());
            EntityUtils.setCreatAndUpdatInfo(r);
            mapper.insertRouteCust(r);
        }
        int resultW = mapper.insertSelective(entity);
        if (resultW == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse updateWayMng(WayMng entity) {
        EntityUtils.setUpdatedInfo(entity);
        filter(entity);
        int result = mapper.updateByPrimaryKeySelective(entity);
        List<RouteCust> customize = entity.getCustomize();
        // 先删除
        int resultD = mapper.removeDict(entity);
        // 添加
        for (RouteCust r : customize) {
            r.setRouteId(entity.getId());
            EntityUtils.setCreatAndUpdatInfo(r);
            mapper.insertRouteCust(r);
        }
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse deleteWayMng(Object id) {
        int result = mapper.deleteByPrimaryKey(id);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 根据userId逻辑删除用户信息
     *
     * @param id 用户id
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse deleteWayMng(String id) {
        WayMng wayMng = new WayMng();
        wayMng.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        wayMng.setId(id);
        EntityUtils.setUpdatedInfo(wayMng);
        int result = mapper.updateByPrimaryKeySelective(wayMng);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    public TableResultResponse<WayMng> selectRouteList(Query query) {
        int limit = query.getLimit();
        int offset = (query.getPage() - 1) * limit;
        query.put("offset", offset);
        query.put("limit", limit);

        // 获得总条数
        int total = mapper.getTotal(query);
//        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<WayMng> list = mapper.selectList(query);
        return new TableResultResponse<>(total, list);
    }

    // 敏感词过滤
    private void filter(WayMng wayMng) {
        wayMng.setTitle(SensitiveWordUtils.filterStr(wayMng.getTitle()));
        wayMng.setChara(SensitiveWordUtils.filterStr(wayMng.getChara()));
        wayMng.setContent(SensitiveWordUtils.filterStr(wayMng.getContent()));
        wayMng.setSummary(SensitiveWordUtils.filterStr(wayMng.getSummary()));
    }

    /**
     * 启动路线
     * @param id
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse startWayMng(String id){
        int num = mapper.startWayMng(id);
        if(num > 0){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }
}

