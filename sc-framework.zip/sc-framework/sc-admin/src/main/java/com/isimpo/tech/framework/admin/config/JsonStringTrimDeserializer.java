package com.isimpo.tech.framework.admin.config;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import org.apache.commons.lang.StringUtils;
import org.springframework.boot.jackson.JsonComponent;

import java.io.IOException;

/**
 * @author abator
 * @version 1.0
 * @since 2018年06月28日
 */
@JsonComponent
public class JsonStringTrimDeserializer extends JsonDeserializer<String>{

    @Override
    public String deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        return StringUtils.trim(p.getValueAsString());
    }
}
