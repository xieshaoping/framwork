package com.isimpo.tech.framework.admin.service.sys;

import com.isimpo.tech.framework.admin.auto.entity.CommonDict;
import com.isimpo.tech.framework.admin.auto.entity.SysDict;
import com.isimpo.tech.framework.admin.auto.mapper.SysDictMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;

/**
 * 字典管理service
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/28
 */
@Service
public class SysDictService extends BaseService<SysDictMapper, SysDict> {


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Object id) {
        SysDict dict = new SysDict();
        dict.setId(String.valueOf(id));
        dict.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        EntityUtils.setUpdatedInfo(dict);
        super.updateSelectiveById(dict);
    }

    /**
     * 字典type列表接口
     *
     * @return 字典type列表
     */
    public List<String> listType() {
        return mapper.listType();
    }


    /**
     * 查询字典根据type分组
     *
     * @return 分组后的字典
     */
    public List<CommonDict> getAll() {
        List<CommonDict> list = new ArrayList<>();
        List<SysDict> sysDicts = mapper.findAll();

        Map<String, List<SysDict>> group = sysDicts.stream().collect(Collectors.groupingBy(SysDict::getType));
        for (Map.Entry<String, List<SysDict>> entry : group.entrySet()) {
            CommonDict commonDict = new CommonDict();
            commonDict.setKey(entry.getKey());
            commonDict.setValue(entry.getValue());
            list.add(commonDict);
        }
        return list;
    }

    /**
     * 根据type获取字典合集
     *
     * @return 字典合集
     * @Author ZLF
     */
    public List<SysDict> getAllByType(String type) {
        if (StringUtils.isEmpty(type)) {
            return Collections.emptyList();
        } else {
            return mapper.findAll().stream().
                    filter(item -> type.equals(item.getType())).
                    sorted(comparing(SysDict::getType))
                    .collect(Collectors.toList());
        }
    }
}
