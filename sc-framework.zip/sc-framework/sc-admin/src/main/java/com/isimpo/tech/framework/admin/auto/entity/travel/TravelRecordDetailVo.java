package com.isimpo.tech.framework.admin.auto.entity.travel;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.admin.auto.entity.systemmanage.CommentVo;
import com.isimpo.tech.framework.common.entity.BaseVo;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
public class TravelRecordDetailVo extends TravelRecordVo {

    // 发布人昵称
    private String nickName;

    // 发布人微信头像
    private String photo;

    // 行程起始时间
    private Date startTime;

    // 行程结束时间
    private Date endTime;

    // 文件地址
    private String filePath;

    // 地点名称
    private String location;

    // 地点经度
    private String longitude;

    // 地点纬度
    private String latitude;

    // 行程事项名
    private String itemName;

    private String dateFlag;

    // 游记下的评论列表
    private List<CommentVo> comments;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    @JsonFormat(pattern = "HH:mm")
    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    @JsonFormat(pattern = "HH:mm")
    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public List<CommentVo> getComments() {
        return comments;
    }

    public void setComments(List<CommentVo> comments) {
        this.comments = comments;
    }

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm")
    @Override
    public Date getAddTime() {
        return super.getAddTime();
    }

    public String getDateFlag() {
        return dateFlag;
    }

    public void setDateFlag(String dateFlag) {
        this.dateFlag = dateFlag;
    }
}







