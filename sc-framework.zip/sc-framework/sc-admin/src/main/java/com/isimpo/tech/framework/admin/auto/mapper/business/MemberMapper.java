/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.auto.mapper.business;

import java.util.List;

import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraMember;
import com.isimpo.tech.framework.common.util.Query;

import tk.mybatis.mapper.common.Mapper;

/**
 * @author LuoCheng
 * @version 1.0
 * @since 2019年01月26日
 */
public interface MemberMapper extends Mapper<Member> {

    List<Member> findList(Query query);

    void update(Member member);

    void insertList(List<Member> list);

    List<Member> findByParm(Query query);

    List<Member> findHkByParm(Query query);

    List<Member> checkTourLeaderPhone(Query query);

    List<Member> findTourLeaderList(Query query);


    Member getMemberById(String id);

    void insertTraList(List<TraMember> list);

    List<Member> getMemberListByTraId(String traId);

    int delMember(Member member);

    int delMemberWechar(String memberId);
}
