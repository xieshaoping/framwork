package com.isimpo.tech.framework.admin.auto.mapper;

import com.isimpo.tech.framework.admin.auto.entity.WxAutoReply;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface WxMessageMapper extends Mapper<WxAutoReply> {


    /**
     * 根据flag获取相应的消息
     *
     * @param flag 标示
     * @return 自动回复消息实体
     */
    WxAutoReply findWxMessage(@Param("flag") String flag);

    /**
     * 根据查询id消息下的实体关键字
     *
     * @param id 参数实体id
     * @return 自动回复消息实体
     */
    List<WxAutoReply> searchKeyWordMessage(@Param("id") String id);
}