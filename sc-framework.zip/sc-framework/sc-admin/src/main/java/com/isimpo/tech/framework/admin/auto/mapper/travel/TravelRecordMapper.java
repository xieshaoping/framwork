package com.isimpo.tech.framework.admin.auto.mapper.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TravelRecordDetailVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TravelRecordVo;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
public interface TravelRecordMapper extends Mapper<TravelRecordVo> {

    /**
     * 查询行程游记列表
     * @param query
     * @return
     */
    List<TravelRecordVo> listTravelRecord(Query query);

    /**
     * 逻辑删除行程游记
     *
     * @param travelRecord
     * @return
     */
    int delTravelRecord(TravelRecordVo travelRecord);

    /**
     * 查询行程游记详情
     * @param travelRecord
     * @return
     */
    TravelRecordDetailVo getTravelRecordDetail(TravelRecordVo travelRecord);
}
