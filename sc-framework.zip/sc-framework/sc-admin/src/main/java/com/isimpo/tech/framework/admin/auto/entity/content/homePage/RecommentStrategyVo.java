package com.isimpo.tech.framework.admin.auto.entity.content.homePage;

import com.isimpo.tech.framework.admin.auto.entity.content.strategy.StrategyVo;

/**
 * @author zhuyilong
 * @since 2019/2/28
 */

/**
 * 推荐攻略VO
 */
public class RecommentStrategyVo extends StrategyVo {
    // 首页配置表id
    private String cId;

    // 首页配置表类型  （1：管家，2：路线，3：文章，4：旅咖说，5：攻略）
    private String type;

    public String getcId() {
        return cId;
    }

    public void setcId(String cId) {
        this.cId = cId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
