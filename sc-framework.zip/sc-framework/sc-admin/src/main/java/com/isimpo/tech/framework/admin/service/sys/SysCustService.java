package com.isimpo.tech.framework.admin.service.sys;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.CommonDict;
import com.isimpo.tech.framework.admin.auto.entity.SysCust;
import com.isimpo.tech.framework.admin.auto.entity.SysDict;
import com.isimpo.tech.framework.admin.auto.entity.content.homePage.IndexPic;
import com.isimpo.tech.framework.admin.auto.mapper.SysCustMapper;
import com.isimpo.tech.framework.admin.auto.mapper.SysDictMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.xiaoleilu.hutool.util.RandomUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.lang.reflect.ParameterizedType;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;

/**
 * 字典管理service
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/28
 */
@Service
public class SysCustService extends BaseService<SysCustMapper, SysCust> {

    /*public AjaxResponse custList(Query query) {

        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());

        List<SysCust> list = mapper.custList(query);
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }*/

    @Override
    public TableResultResponse<SysCust> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<SysCust> list = mapper.custList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }



    //    添加用户
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse save(SysCust entity) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        // 敏感词过滤
        filter(entity);
        int result = mapper.insertSelective(entity);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

//    修改
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse updateSysCust(SysCust entity) {
        EntityUtils.setUpdatedInfo(entity);
        int result =  mapper.updateByPrimaryKeySelective(entity);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


   //    获取一个客户
    public AjaxResponse getOne(Map<String, String> params) {
        String id=params.get("id");
        return AjaxResponse.of( mapper.getOne(id));
    }


    //    获取一个客户
    public AjaxResponse searchOne(Map<String, String> params) {
        String id=params.get("id");
        SysCust cust=mapper.searchOne(id);
        cust.setTravels(mapper.searchTra(id));
        return AjaxResponse.of(cust);
    }




    //    修改客户
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse update(SysCust sysCust) {
        String id = BaseContextHandler.getUserID();
        sysCust.setUpdUserId(id);
        // 敏感词过滤
        filter(sysCust);
        int result=mapper.update(sysCust);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);

    }



  // 添加
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse insertSysCust(SysCust entity) {
        String reId=entity.getId();
        EntityUtils.setCreatAndUpdatInfo(entity);
        entity.setHkName(null);
        entity.setName(entity.getTitle());
        entity.setTitle(null);
        filter(entity);
        int result= mapper.insertSelective(entity);
        if (result == 1) {
            // 添加完后改变状态
            result=mapper.changeState(reId);
            if (result==1){
                return AjaxResponse.of(ResponseCode.SUCCESS);
            }
            return AjaxResponse.of(ResponseCode.FAIL);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    // 逻辑删除用户
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse deleteCust(String id) {
        SysCust sysCust = new SysCust();
        sysCust.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        sysCust.setId(id);
        EntityUtils.setUpdatedInfo(sysCust);
        int result = mapper.updateByPrimaryKeySelective(sysCust);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    public static void filter(SysCust sysCust) {
        // 敏感词过滤
        sysCust.setName(SensitiveWordUtils.filterStr(sysCust.getName()));
        sysCust.setContact(SensitiveWordUtils.filterStr(sysCust.getContact()));
        sysCust.setAddress(SensitiveWordUtils.filterStr(sysCust.getAddress()));
        sysCust.setNote(SensitiveWordUtils.filterStr(sysCust.getNote()));
    }
}


