/*
 * @(#) WxMenuController.java 2019年02月27日
 *
 * Copyright (c) 2015, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.contorller.sys;

import com.isimpo.tech.framework.admin.auto.entity.WxMenu;
import com.isimpo.tech.framework.admin.service.sys.WxMenuService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author ding.haiyan
 * @version 1.0
 * @since 2019年02月27日
 */
@RestController
@RequestMapping("/system/wxMenu")
public class WxMenuController extends BaseController<WxMenuService, WxMenu> {

    /**
     * 获取所有一级菜单
     *
     * @return
     */
    @GetMapping("/getPWXMenu")
    public AjaxResponse getPWXMenu(String id) {
        return baseService.getPWXMenu(id);
    }

    /**
     * 获取菜单实体
     *
     * @param id
     * @return
     */
    @GetMapping("/getDetail")
    public AjaxResponse getDetail(String id) {
        return baseService.getDetail(id);
    }

    /**
     * 保存菜单
     *
     * @param wxMenu
     * @return
     */
    @PostMapping("/save")
    public AjaxResponse save(@RequestBody WxMenu wxMenu) {
        return baseService.save(wxMenu);
    }

    /**
     * 删除菜单
     *
     * @param ids
     * @return
     */
    @PostMapping("/del")
    public AjaxResponse del(@RequestBody List<String> ids) {
        return baseService.del(ids);
    }


    /**
     * 同步微信菜单
     *
     * @return 0:删除失败 1：添加失败 2:添加成功
     */
    @GetMapping("/synMenuToWechat")
    public AjaxResponse synMenuToWechat() {
        return baseService.synMenuToWechat();
    }
}
