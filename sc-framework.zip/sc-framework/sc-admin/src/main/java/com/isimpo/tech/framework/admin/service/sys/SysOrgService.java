package com.isimpo.tech.framework.admin.service.sys;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isimpo.tech.framework.admin.auto.entity.SysArea;
import com.isimpo.tech.framework.admin.auto.entity.SysOrg;
import com.isimpo.tech.framework.admin.auto.mapper.SysOrgMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.service.BaseService;

/**
 * 组织机构service
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/26
 */
@Service
public class SysOrgService extends BaseService<SysOrgMapper, SysOrg> {


    @Override
    public List<SysOrg> selectListAll(Map<String, Object> params) {
        params.put("delFlag", DBConstants.DEL_FLAG_EXISTED);
        List<SysOrg> orgs = mapper.selectListAll(params);
        orgs.forEach(it -> {
            List<SysArea> areas = mapper.selectAreas(it.getProvince(), it.getCity(), it.getCounty());
            it.setAreas(areas);
        });
        return orgs;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertSelective(SysOrg org) {
        List<SysArea> area = org.getAreas();
        if(area != null){
            Optional.ofNullable(area.get(0)).ifPresent(it -> org.setProvince(it.getId()));
            Optional.ofNullable(area.get(1)).ifPresent(it -> org.setCity(it.getId()));
            Optional.ofNullable(area.get(2)).ifPresent(it -> org.setCounty(it.getId()));
        }
        super.insertSelective(org);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateSelectiveById(SysOrg org) {
        List<SysArea> area = org.getAreas();
        if(area != null){
            Optional.ofNullable(area.get(0)).ifPresent(it -> org.setProvince(it.getId()));
            Optional.ofNullable(area.get(1)).ifPresent(it -> org.setCity(it.getId()));
            Optional.ofNullable(area.get(2)).ifPresent(it -> org.setCounty(it.getId()));
        }
        super.updateSelectiveById(org);
    }

}


