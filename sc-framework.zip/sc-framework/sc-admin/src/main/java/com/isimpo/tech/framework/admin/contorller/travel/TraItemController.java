package com.isimpo.tech.framework.admin.contorller.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.*;
import com.isimpo.tech.framework.admin.service.travel.TraItemService;
import com.isimpo.tech.framework.admin.service.travel.TraManageService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


/**
 * 行程事项
 * @author wangxinhai
 * @version V1.0
 * @since 2019/2/18
 */
@RestController
@RequestMapping("/travel/traItem")
public class TraItemController extends BaseController<TraItemService, TraItem> {


    /**
     * 增加
     * @param entity
     * @return
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResponse add(@RequestBody TraItem entity) {
        baseService.insertSelective(entity);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    @Override
    @DeleteMapping("/{id}")
    @ResponseBody
    public AjaxResponse remove(@PathVariable String id) {
        baseService.deleteById(id);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 行程补充添加
     * @param traSupp
     * @return
     */
    @ResponseBody
    @PostMapping("/addTraSupp")
    public AjaxResponse addTraSupp(@RequestBody TraSupp traSupp){
        return baseService.addTraSupp(traSupp);
    }

    /**
     * 行程补充修改
     * @param traSupp
     * @return
     */
    @ResponseBody
    @PostMapping("/updateTraSupp")
    public AjaxResponse updateTraSupp(@RequestBody TraSupp traSupp){
        return baseService.updateTraSupp(traSupp);
    }

    /**
     * 行程补充删除
     * @param id
     * @return
     */
    @ResponseBody
    @GetMapping("/delTraSupp")
    public AjaxResponse delTraSupp(String id){
        return baseService.delTraSupp(id);
    }

    /**
     * 行程补充详情
     * @param id
     * @return
     */
    @GetMapping("/getTraSupp")
    public AjaxResponse getTraSupp(String id){
        return AjaxResponse.of(baseService.getTraSupp(id));
    }
}
