package com.isimpo.tech.framework.admin.service.travel;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.systemmanage.CommentVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TravelRecordDetailVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TravelRecordVo;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TravelRecordMapper;
import com.isimpo.tech.framework.admin.service.sys.CommentManageService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.aspectj.weaver.loadtime.Aj;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
@Service
public class TravelRecordService extends BaseService<TravelRecordMapper, TravelRecordVo> {

    /**
     * 获取行程记录列表
     * @param query
     * @return
     */
    public AjaxResponse getTravelRecords(Query query) {
        CommentManageService.resoveSpecialChar(query, new String[] {"name", "traName", "content"});
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<TravelRecordVo> list = mapper.listTravelRecord(query);
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }

    /**
     * 删除行程记录
     * @param travelRecord
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delTravelRecord(TravelRecordVo travelRecord) {
        EntityUtils.setUpdatedInfo(travelRecord);
        int count = mapper.delTravelRecord(travelRecord);
        if (count > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 获取行程游记详情
     * @param travelRecord
     * @return
     */
    public AjaxResponse getTravelRecordDetail(TravelRecordVo travelRecord) {
        TravelRecordDetailVo travelRecordDetailVo = mapper.getTravelRecordDetail(travelRecord);
        return AjaxResponse.of(travelRecordDetailVo);
    }
}
