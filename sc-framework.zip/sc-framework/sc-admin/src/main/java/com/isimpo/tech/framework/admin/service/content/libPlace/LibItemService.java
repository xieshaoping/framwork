package com.isimpo.tech.framework.admin.service.content.libPlace;

import com.isimpo.tech.framework.admin.auto.entity.content.LibItem;
import com.isimpo.tech.framework.admin.auto.entity.content.LibSupp;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraCalendar;
import com.isimpo.tech.framework.admin.auto.mapper.content.LibItemMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.text.SimpleDateFormat;

/**
 * 行程事项
 * @author wangxinhai
 * @version V1.0
 * @since 2019/2/18
 */
@Service
public class LibItemService extends BaseService<LibItemMapper, LibItem> {

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Object id) {
        LibItem traItem = new LibItem();
        traItem.setId(id.toString());
        traItem.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        EntityUtils.setUpdatedInfo(traItem);
        super.updateSelectiveById(traItem);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertSelective(LibItem entity) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfh = new SimpleDateFormat("HH:mm:ss");
        TraCalendar traCalendar = null;
        /*if(entity.getCalendarId() != null){
            traCalendar = mapper.getCalendar(entity.getCalendarId());
        }
        String sd = sdf.format(traCalendar.getTraDate()) + " " + sdfh.format(entity.getStartTime());
        String ed = sdf.format(traCalendar.getTraDate()) + " " + sdfh.format(entity.getEndTime());
        Date sdd = null;
        Date edd = null;
        try {
            sdd = sdfs.parse(sd);
            edd = sdfs.parse(ed);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        entity.setStartTime(sdd);
        entity.setEndTime(edd);*/
        EntityUtils.setCreatAndUpdatInfo(entity);
        // 敏感词过滤
        entity.setName(SensitiveWordUtils.filterStr(entity.getName()));
        entity.setEnName(SensitiveWordUtils.filterStr(entity.getEnName()));
        entity.setOverview(SensitiveWordUtils.filterStr(entity.getOverview()));
        entity.setTips(SensitiveWordUtils.filterStr(entity.getTips()));
        entity.setContent(SensitiveWordUtils.filterStr(entity.getContent()));
        mapper.insertSelective(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateSelectiveById(LibItem entity) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdfh = new SimpleDateFormat("HH:mm:ss");
        TraCalendar traCalendar = null;
        /*if(entity.getCalendarId() != null){
            traCalendar = mapper.getCalendar(entity.getCalendarId());
        }
        String sd = sdf.format(traCalendar.getTraDate()) + " " + sdfh.format(entity.getStartTime());
        String ed = sdf.format(traCalendar.getTraDate()) + " " + sdfh.format(entity.getEndTime());
        Date sdd = null;
        Date edd = null;
        try {
            sdd = sdfs.parse(sd);
            edd = sdfs.parse(ed);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        entity.setStartTime(sdd);
        entity.setEndTime(edd);*/
        EntityUtils.setUpdatedInfo(entity);
        mapper.updateByPrimaryKeySelective(entity);
    }

    /**
     * 行程补充添加
     * @param libSupp
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse addTraSupp(LibSupp libSupp){
        EntityUtils.setCreatAndUpdatInfo(libSupp);
        // 敏感词过滤
        libSupp.setName(SensitiveWordUtils.filterStr(libSupp.getName()));
        libSupp.setEnName(SensitiveWordUtils.filterStr(libSupp.getEnName()));
        libSupp.setOverview(SensitiveWordUtils.filterStr(libSupp.getOverview()));
        libSupp.setTips(SensitiveWordUtils.filterStr(libSupp.getTips()));
        libSupp.setContent(SensitiveWordUtils.filterStr(libSupp.getContent()));
        int num = mapper.insertLibSupp(libSupp);
        if (num > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 行程补充修改
     * @param libSupp
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updateTraSupp(LibSupp libSupp){
        EntityUtils.setUpdatedInfo(libSupp);
        // 敏感词过滤
        libSupp.setName(SensitiveWordUtils.filterStr(libSupp.getName()));
        libSupp.setEnName(SensitiveWordUtils.filterStr(libSupp.getEnName()));
        libSupp.setOverview(SensitiveWordUtils.filterStr(libSupp.getOverview()));
        libSupp.setTips(SensitiveWordUtils.filterStr(libSupp.getTips()));
        libSupp.setContent(SensitiveWordUtils.filterStr(libSupp.getContent()));
        int num = mapper.updateLibSupp(libSupp);
        if (num > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 行程补充删除
     * @param id
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse delTraSupp(String id){
        LibSupp libSupp = new LibSupp();
        libSupp.setId(id);
        EntityUtils.setUpdatedInfo(libSupp);
        int num = mapper.delLibSupp(libSupp);
        if (num > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 行程补充详情
     * @param id
     * @return
     */
    public LibSupp getLibSupp(String id){
        return mapper.getLibSupp(id);
    }
}
