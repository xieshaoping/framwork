package com.isimpo.tech.framework.admin.service.sys;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;

import com.isimpo.tech.framework.admin.auto.entity.SysCust;

import com.isimpo.tech.framework.admin.auto.entity.SysHousekeeper;

import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.admin.auto.mapper.SysHkMapper;

import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;

import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;

import com.xiaoleilu.hutool.util.RandomUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

import static com.isimpo.tech.framework.common.util.EntityUtils.setUpdatedInfo;
/**
 * 管家service
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/28
 */
@Service
public class SysHkService extends BaseService<SysHkMapper, SysHousekeeper> {

    public AjaxResponse custList(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<SysCust> list = mapper.custList(query);
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }

    public AjaxResponse getHousekeeper() {
        return AjaxResponse.of(mapper.getHousekeeper());
    }


    /**
     * 查询管家分页列表
     *
     * @param query 分页信息
     * @return TableResultResponse<> 用户分页列表
     */
    @Override
    public TableResultResponse<SysHousekeeper> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<SysHousekeeper> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }


    /*
     * 从数据字典中获取证件类型，certificates_type，id，value，lable
     * */
    public AjaxResponse queryCerTypeList() {
        return AjaxResponse.of(mapper.queryCerTypeList());
    }


    // 添加管理员
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addHouseKeeper(SysHousekeeper hk) {
        EntityUtils.setCreatAndUpdatInfo(hk);
        String memId = RandomUtil.simpleUUID();
        hk.setMemId(memId);

        int result = mapper.addMember(hk);
        if (result == 1) {
            result = mapper.addHouseKeeper(hk);
        }
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }

        return AjaxResponse.of(ResponseCode.FAIL);
    }

    // 添加管理员
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse updateHousekeeper(SysHousekeeper hk) {
//        EntityUtils.setCreatAndUpdatInfo(hk);
        setUpdatedInfo(hk);
        int resultM = mapper.updMember(hk);
        int resultH = mapper.updHousekeeper(hk);
        if (resultM == 1 && resultH == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    // 删除管理员
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delHousekeeper(SysHousekeeper hk) {
        setUpdatedInfo(hk);
//        int resultM = mapper.delMember(hk);
        int resultH = mapper.delHousekeeper(hk);
        int num = mapper.delMemWechar(hk);
//        if (resultM==1&&resultH==1){
        if (resultH == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    // 待选推荐管家，过滤掉已经选择的
    public TableResultResponse<SysHousekeeper> selectHk(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<SysHousekeeper> list = mapper.selectList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    // 可选择的用户
    public TableResultResponse<SysHousekeeper> selectUser(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<SysHousekeeper> list = mapper.selectUser(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }


    public AjaxResponse selectOneHk(String id) {
        return AjaxResponse.of(mapper.selectOneHk(id));
    }
}
