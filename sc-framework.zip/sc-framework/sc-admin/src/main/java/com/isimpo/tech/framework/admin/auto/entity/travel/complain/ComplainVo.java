package com.isimpo.tech.framework.admin.auto.entity.travel.complain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isimpo.tech.framework.common.entity.BaseVo;
import javax.persistence.*;
import java.util.Date;

@Table(name = "tra_complain")
public class ComplainVo extends BaseVo {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 会员Id
     */
    @Column(name = "mem_id")
    private String memId;

    // 姓名
    @Transient
    private String name;

    /**
     * 行程id
     */
    @Column(name = "range_id")
    private String rangeId;

    // 行程名称
    @Transient
    private String traName;

    /**
     * 处理状态（0：未处理，1：已处理）
     */
    private String state;

    /**
     * 投诉内容
     */
    private String content;

    /**
     * 处理说明
     */
    private String note;

    // 昵称
    @Transient
    private String nickName;

    // 性别 0.女 1.男
    @Transient
    private String gender;

    // 生日
    @Transient
    private Date birthday;

    // 电话号码
    @Transient
    private String phone;

    // 证件类型
    @Transient
    private String idType;

    // 证件号码
    @Transient
    private String idNum;

    // 联系地址
    @Transient
    private String source;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取会员Id
     *
     * @return mem_id - 会员Id
     */
    public String getMemId() {
        return memId;
    }

    /**
     * 设置会员Id
     *
     * @param memId 会员Id
     */
    public void setMemId(String memId) {
        this.memId = memId;
    }

    /**
     * 获取行程id
     *
     * @return range_id - 行程id
     */
    public String getRangeId() {
        return rangeId;
    }

    /**
     * 设置行程id
     *
     * @param rangeId 行程id
     */
    public void setRangeId(String rangeId) {
        this.rangeId = rangeId;
    }

    /**
     * 获取处理状态（0：未处理，1：已处理）
     *
     * @return state - 处理状态（0：未处理，1：已处理）
     */
    public String getState() {
        return state;
    }

    /**
     * 设置处理状态（0：未处理，1：已处理）
     *
     * @param state 处理状态（0：未处理，1：已处理）
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * 获取投诉内容
     *
     * @return content - 投诉内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置投诉内容
     *
     * @param content 投诉内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取处理说明
     *
     * @return note - 处理说明
     */
    public String getNote() {
        return note;
    }

    /**
     * 设置处理说明
     *
     * @param note 处理说明
     */
    public void setNote(String note) {
        this.note = note;
    }

    @Override
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    public Date getAddTime() {
        return super.getAddTime();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTraName() {
        return traName;
    }

    public void setTraName(String traName) {
        this.traName = traName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonFormat(pattern = "yyyy-MM-dd")
    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}