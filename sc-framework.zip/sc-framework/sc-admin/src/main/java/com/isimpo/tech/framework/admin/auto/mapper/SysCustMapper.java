package com.isimpo.tech.framework.admin.auto.mapper;

import com.isimpo.tech.framework.admin.auto.entity.SysCust;
import com.isimpo.tech.framework.admin.auto.entity.SysTra;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface SysCustMapper extends Mapper<SysCust> {

/*    List<String> listType();
    List<SysDict> findAll();*/

    List<SysCust> custList(Query query);


    int save(@Param("sysCust")SysCust sysCust);

    SysCust getOne(String id);

    SysCust searchOne(String id);

    List<SysTra> searchTra(String id);

    int update(@Param("sysCust")SysCust sysCust);

    int changeState(@Param("reId")String reId);
}
