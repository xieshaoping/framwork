package com.isimpo.tech.framework.admin.auto.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.isimpo.tech.framework.admin.auto.entity.SysRole;
import com.isimpo.tech.framework.admin.auto.entity.SysRoleMenu;

import tk.mybatis.mapper.common.Mapper;

public interface SysRoleMapper extends Mapper<SysRole> {
    /**
     * 根据角色id查询菜单list排除父节点
     *
     * @param roleId 角色id
     * @return 菜单list
     */
    List<String> selectMenuListByRoleIdExcludeParent(String roleId);
    /**
     * 根据角色id查询菜单list
     *
     * @param roleId 角色id
     * @return 菜单list
     */
    List<String> selectMenuListByRoleId(String roleId);


    /**
     * 根据角色id删除菜单
     *
     * @param role 角色信息
     */
    void deleteMenusById(SysRole role);

    /**
     * 删除菜单
     *
     * @param roleMenu 删除信息
     * @param deleteIds 删除list
     */
    void deleteMenus(@Param("roleMenu") SysRoleMenu roleMenu,@Param("deleteIds") List<String> deleteIds);

    /**
     * 插入角色菜单
     *
     * @param checkedMenus 角色菜单
     */
    void insertRoleMenus(List<SysRoleMenu> checkedMenus);

    /**
     * 通过角色名称查询角色
     *
     * @param name 角色名称
     * @param id 角色id
     * @return SysRole 角色
     */
    int getRoleByName(@Param("name") String name,@Param("id")String id);
}