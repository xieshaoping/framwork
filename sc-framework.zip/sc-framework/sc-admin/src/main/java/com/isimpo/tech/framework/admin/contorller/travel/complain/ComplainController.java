package com.isimpo.tech.framework.admin.contorller.travel.complain;

import com.isimpo.tech.framework.admin.auto.entity.travel.complain.ComplainVo;
import com.isimpo.tech.framework.admin.service.travel.complain.ComplainService;
import com.isimpo.tech.framework.common.controller.BaseController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhuyilong
 * @since 2019/2/26
 */
@RestController
@RequestMapping("/complain")
public class ComplainController extends BaseController<ComplainService, ComplainVo> {

}
