package com.isimpo.tech.framework.admin.contorller.content.tratravelertalk;

import com.isimpo.tech.framework.admin.auto.entity.content.tratravelertalk.TratRavelerTalk;
import com.isimpo.tech.framework.admin.service.content.tratravelertalk.TratRavelerTalkService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 旅咖说Controller
 *
 * @Witer xyh
 * @Date 2019/1/29
 */
@RestController
@RequestMapping("/content/tratRavelerTalk")
public class TratRavelerTalkController extends BaseController<TratRavelerTalkService, TratRavelerTalk> {

    @Autowired
    private TratRavelerTalkService tratRavelerTalkService;

    /**
     * 保存（修改）旅咖说
     *
     * @param tratRavelerTalk
     * @return
     */
    @RequestMapping("/saveTratRavelerTalkItem")
    public AjaxResponse saveTratRavelerTalkItem(@RequestBody TratRavelerTalk tratRavelerTalk) {
        return tratRavelerTalkService.saveTratRavelerTalkItem(tratRavelerTalk);
    }


    /**
     * 获取单个旅咖说实体
     *
     * @param tratRavelerTalk
     * @return
     */
    @RequestMapping("/getTratRavelerTalkItem")
    public AjaxResponse getTratRavelerTalkItem(TratRavelerTalk tratRavelerTalk) {
        return tratRavelerTalkService.getTratRavelerTalkItem(tratRavelerTalk);
    }

    /**
     * 删除旅咖说
     *
     * @param tratRavelerTalk
     * @return
     */
    @RequestMapping("/delTratRavelerTalk")
    public AjaxResponse delTratRavelerTalk(TratRavelerTalk tratRavelerTalk) {
        return tratRavelerTalkService.delTratRavelerTalk(tratRavelerTalk);
    }

    /**
     * 获取查看旅咖说数据
     * @param tratRavelerTalk
     * @return
     */
    @RequestMapping("/getTratRavelerTalkView")
    public AjaxResponse getTratRavelerTalkView(TratRavelerTalk tratRavelerTalk) {
        return tratRavelerTalkService.getTratRavelerTalkView(tratRavelerTalk);
    }

    /**
     * 删除某条评论
     * @param id
     * @return
     */
    @RequestMapping("/delTalk")
    public AjaxResponse delTalk(String id){
        return tratRavelerTalkService.delTalk(id);
    }

    /**
     * 首页管理，查询用户分页列表,过滤了已经是首页展示的
     *
     * @param params 分页信息
     * @return TableResultResponse<SysUser> 用户分页列表
     */
    @GetMapping("/indexTalkList")
    @ResponseBody
    public AjaxResponse indexTalkList(@RequestParam Map<String, Object> params) {
        // 查询列表数据
        System.out.println(params);
        for (String in : params.keySet()) {
            if (!in.equals(CommonConstants.ORDER_BY_PARAM)) {
                //map.keySet()返回的是所有key的值
                String str = (String) params.get(in);//得到每个key多对用value的值
                str = str.replace("%", "%\\");
                str = str.replace("?", "?\\");
                str = str.replace("_", "_\\");
                params.put(in, str);
            }
        }
        Query query = new Query(params);
        return AjaxResponse.of(baseService.selectTalk(query));
    }
}
