package com.isimpo.tech.framework.admin.service.business;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.SysCust;
import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.auto.entity.business.Reserve;
import com.isimpo.tech.framework.admin.auto.mapper.business.MyCustMapper;
import com.isimpo.tech.framework.admin.auto.mapper.business.ReserveMapper;
import com.isimpo.tech.framework.admin.service.sys.SysCustService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 15:33 2019/1/31
 * @Modify By:
 */
@Service
public class MyCustService extends BaseService<MyCustMapper, SysCust> {


    /**
     * 查询用户分页列表
     *
     * @param query 分页信息
     * @return TableResultResponse<SysUser> 用户分页列表
     */
    @Override
    public TableResultResponse<SysCust> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        String myId = BaseContextHandler.getUserID();
        // 當前登錄人会员Id（前提，当前登录人是管家）
        query.put("myId", myId);
        List<SysCust> list = mapper.findList(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    // 增加
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertSelective(SysCust entity) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        SysCustService.filter(entity);
        mapper.insertSelective(entity);
    }


    //    查询自己是否是管家,并返回csr_housekeeper表里的mem_id
    public AjaxResponse checkMyId() {
        String myId = BaseContextHandler.getUserID();
        String menId = mapper.checkMyId(myId);
        if (menId != null && menId!="") {
            return AjaxResponse.of(10000, menId);
        }
        return AjaxResponse.of(20000, "您不是管家");
    }

     //    根据id修改
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse updateMyCustById(SysCust entity) {
        EntityUtils.setUpdatedInfo(entity);
        SysCustService.filter(entity);
        int result =mapper.updateByPrimaryKeySelective(entity);
        if(result==1){
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }
}
