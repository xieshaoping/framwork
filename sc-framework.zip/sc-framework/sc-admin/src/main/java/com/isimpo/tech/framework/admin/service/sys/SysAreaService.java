/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.service.sys;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isimpo.tech.framework.admin.auto.entity.SysArea;
import com.isimpo.tech.framework.admin.auto.mapper.SysAreaMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.xiaoleilu.hutool.util.StrUtil;

/**
 * 系统区域管理service
 *
 * @author xieanan
 * @version 1.0
 * @since 2017/12/28
 */
@Service
public class SysAreaService extends BaseService<SysAreaMapper, SysArea> {


    /**
     * 按type排序查询所有的地区,没有处理数据
     *
     * @return List<SysArea> 地区list
     */
    @Override
    public List<SysArea> selectListAll(Map<String, Object> params) {
        Query query = new Query(params);
        return mapper.findList(query);
    }

    /**
     * 按type排序查询所有的地区 封装好数据
     *
     * @return List<SysArea> 地区list
     */
    public List<SysArea> findAll(Map<String, Object> params) {
        Query query = new Query(params);
        List<SysArea> sysAreas = mapper.findList(query);
        List<SysArea> newAreas = new ArrayList<>();
        if (!sysAreas.isEmpty()) {
            String type = sysAreas.get(0).getType();
            for (SysArea sysArea : sysAreas) {
                if (type.equals(sysArea.getType())) {
                    newAreas.add(sysArea);
                } else {
                    getChildren(newAreas, sysArea);
                }
            }
        }
        return newAreas;
    }


    /**
     * 按条件查询区域信息
     *
     * @return List<SysArea> 地区list
     */
    public List<SysArea> findList(Map<String, Object> params) {
        Query query = new Query(params);
        List<SysArea> sysAreas = mapper.searchList(query);
        for (SysArea sysArea : sysAreas) {
            if (mapper.findCount(sysArea.getId()) > 0) {
                sysArea.setChildren(new ArrayList<>());
            }
        }
        return sysAreas;
    }


    /**
     * 递归区域
     *
     * @param newAreas 新的区域集合
     * @param area 区域
     */
    private static void getChildren(List<SysArea> newAreas, SysArea area) {
        for (SysArea sysArea : newAreas) {
            if (StrUtil.equals(sysArea.getId(), area.getParentId())) {
                List<SysArea> childList = new ArrayList<>();
                if (null != sysArea.getChildren()) {
                    childList = sysArea.getChildren();
                }
                childList.add(area);
                sysArea.setChildren(childList);
            } else if (null != sysArea.getChildren()) {
                getChildren(sysArea.getChildren(), area);
            }
        }
    }


    /**
     * 根据id删除地区及下属地区
     *
     * @param id 地区id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Object id) {
        SysArea area = new SysArea();
        area.setId((String) id);
        EntityUtils.setUpdatedInfo(area);
        area.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        mapper.deleteSelfAndChildren(area);
    }

    /**
     * 更新地区及下属地区父节点信息
     *
     * @param area 地区
     */

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateSelectiveById(SysArea area) {
        EntityUtils.setUpdatedInfo(area);
        mapper.updateSelfAndChildren(area);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertSelective(SysArea entity) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        entity.setSort(Integer.parseInt(entity.getCode()));
        mapper.insertSelective(entity);
    }


    public List<SysArea> findChildList(String id) {
        List<SysArea> sysAreas = mapper.findChildList(id);
        for (SysArea sysArea : sysAreas) {
            if (mapper.findCount(sysArea.getId()) > 0) {
                sysArea.setChildren(new ArrayList<SysArea>());
            }
        }
        return  sysAreas;
    }

    @Override
    public SysArea selectById(Object id) {
        return mapper.findSysArea(id.toString());
    }
}
