package com.isimpo.tech.framework.admin.contorller.travel;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.admin.auto.entity.travel.CustomerVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.KeeperVo;
import com.isimpo.tech.framework.admin.service.travel.CustomerService;
import com.isimpo.tech.framework.admin.service.travel.KeeperService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;


/**
 *
 * @author Tank
 * @version V1.0
 * @since 2019/2/1
 *
 */
@RestController
@RequestMapping("/travel_keeper")
public class KeeperController extends BaseController<KeeperService, KeeperVo> {


    /**
     * 行程基本信息客户下拉选
     * @return 返回数据
     */
    @GetMapping("/keeper")
    public AjaxResponse getKeepers() {
       return baseService.getKeepers();
    }


    @GetMapping("/guide")
    public AjaxResponse getGuide() {
        return baseService.getGuide();
    }

}
