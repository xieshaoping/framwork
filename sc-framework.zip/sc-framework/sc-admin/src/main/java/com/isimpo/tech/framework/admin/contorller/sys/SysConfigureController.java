/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.contorller.sys;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.admin.auto.entity.SysConfigure;
import com.isimpo.tech.framework.admin.service.sys.SysConfigureService;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;

/**
 * 系统配置
 *
 * @author LuoCheng
 * @version 1.0
 * @since 2019年02月12日
 */

@RestController
@RequestMapping("/sys/configure")
public class SysConfigureController extends BaseController<SysConfigureService, SysConfigure> {

    @RequestMapping("/querySysConfigure")
    public AjaxResponse query() {
        return baseService.getSysConfigure();
    }

    @PostMapping("/updateSysConfigure")
    public AjaxResponse update(@RequestBody SysConfigure sysConfigure) {
        return baseService.updateSysConfigure(sysConfigure);
    }
}
