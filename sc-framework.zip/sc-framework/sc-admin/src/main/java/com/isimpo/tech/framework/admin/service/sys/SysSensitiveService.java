/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.service.sys;

import org.springframework.stereotype.Service;

import com.isimpo.tech.framework.admin.auto.entity.SysSensitive;
import com.isimpo.tech.framework.admin.auto.mapper.SysSensitiveMapper;
import com.isimpo.tech.framework.common.service.BaseService;

/**
 * @author LuoCheng
 * @version 1.0
 * @since 2019年01月25日
 */

@Service
public class SysSensitiveService extends BaseService<SysSensitiveMapper, SysSensitive> {

}
