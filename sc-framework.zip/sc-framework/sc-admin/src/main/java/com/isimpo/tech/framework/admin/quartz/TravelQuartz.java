/*
 * Copyright (c) 2019, SIMPO Technology. All Rights Reserved. SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.quartz;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.isimpo.tech.framework.admin.auto.entity.content.order.CsrOrder;
import com.isimpo.tech.framework.admin.service.content.order.CsrOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraManageVo;
import com.isimpo.tech.framework.admin.service.travel.TraManageService;

/**
 * 定时更新行程状态
 *
 * @author LuoCheng
 * @version 1.0
 * @since 2019年02月12日
 */

@Component
public class TravelQuartz {

    @Autowired
    private TraManageService traManageService;

    @Autowired
    private CsrOrderService csrOrderService;

    @Scheduled(cron = "0 0/30 * * * ?")
    public void travelQuartz() throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String snowDate = format.format(new Date());
        Date nowDate = format.parse(snowDate);
        List<TraManageVo> traManageVoList = traManageService.queryForState();
        if (!CollectionUtils.isEmpty(traManageVoList)) {
            traManageVoList = traManageVoList.stream().peek(traManageVo -> {
            Date startDate = traManageVo.getStartDate();
            Date endDate = traManageVo.getEndDate();
            //比较开始时间和结束时间
            int i = this.compareDate(nowDate,startDate);
            int j = this.compareDate(nowDate,endDate);
            //行程状态为旅行中
            if(i==0 || j ==0){
                traManageVo.setState("1");
            }
            if(i>0 && j<0){
                traManageVo.setState("1");
            }
            //行程状态为已结束
            if(j>0){
                traManageVo.setState("9");
            }
            }).collect(Collectors.toList());
            traManageService.updateState(traManageVoList);
        }
    }

    private int compareDate(Date date1,Date date2){
        return date1.compareTo(date2);
    }

    /**
     * 订单 路线 定时切换状态
     */
    @Scheduled(cron = "0 0 1 * * ?")
    public void orderRouteChange()throws Exception{
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String snowDate = format.format(new Date());
        Date nowDate = format.parse(snowDate);
        List<CsrOrder> csrOrderList = csrOrderService.getCsrOrderList();
        csrOrderList.stream().peek(csrOrder -> {
            if (csrOrder.getPlanAmount() == csrOrder.getRealAmount()) { //人齐
                if (compareDate(nowDate, csrOrder.getStartDate()) > 0) {
                    csrOrder.setState("9");//已完成
                    csrOrder.setRecruitState("9");//已截止
                }else{
                    csrOrder.setState("2");//待出行
                }
            } else { //人没齐
                if (compareDate(nowDate, csrOrder.getStartDate()) > 0) {
                    csrOrder.setState("5");//未成团
                    csrOrder.setRecruitState("9");//已截止
                }
            }
        }).collect(Collectors.toList());
        csrOrderService.orderRouteChange(csrOrderList);
    }

}
