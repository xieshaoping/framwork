package com.isimpo.tech.framework.admin.service.content.homePage;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.SysHousekeeper;
import com.isimpo.tech.framework.admin.auto.entity.content.formerlyarticles.FormerlyArticles;
import com.isimpo.tech.framework.admin.auto.entity.content.homePage.ContIndex;
import com.isimpo.tech.framework.admin.auto.entity.content.homePage.IndexPic;
import com.isimpo.tech.framework.admin.auto.entity.content.homePage.RecommentStrategyVo;
import com.isimpo.tech.framework.admin.auto.entity.content.wayMng.WayMng;
import com.isimpo.tech.framework.admin.auto.entity.travel.NewsVo;
import com.isimpo.tech.framework.admin.auto.mapper.content.formerlyarticles.FormerlyArticlesMapper;
import com.isimpo.tech.framework.admin.auto.mapper.content.homePage.ContIndexMapper;
import com.isimpo.tech.framework.admin.auto.mapper.content.homePage.IndexPicMapper;
import com.isimpo.tech.framework.common.constant.DBConstants;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @Author: xiesp
 * @Despriction:
 * @Date:Created in 12:39 2019/2/12
 * @Modify By:
 */
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class ContIndexService extends BaseService<ContIndexMapper, ContIndex> {

    /**
     * 新增页面展示
     *
     * @param
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse insertContIndex(ContIndex entity) {
        EntityUtils.setCreatAndUpdatInfo(entity);
        int result = mapper.insertSelective(entity);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }



    /**
     * 分页查询推荐管家列表
     * @param query
     * @return
     */
    public AjaxResponse getIndexHkList(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<SysHousekeeper> list = mapper.getIndexHkList(query);
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }


    /**
     * 分页查询推荐路线列表
     * @param
     * @return
     */
    public AjaxResponse getIndexRouteList() {
        return AjaxResponse.of(mapper.getIndexRouteList());
    }

    /**
     * 分页查询待推荐攻略列表
     * @param query
     * @return
     */
    public AjaxResponse getStrategyList(Query query) {
        convertSpecialChar(query);
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<RecommentStrategyVo> list = mapper.listStrategy(query);
        return AjaxResponse.of(new TableResultResponse<>(result.getTotal(), list));
    }

    /**
     * 通用获取已推荐列表
     * 类型（1：管家，2：路线，3：文章，4：旅咖说 5：攻略）
     * @param
     * @return
     */
    public AjaxResponse indexPage(String type) {
        if ( StringUtils.equals(type,"3")){
            return AjaxResponse.of(mapper.getIndexArticleList());
        }else if (StringUtils.equals(type,"4")){
            return AjaxResponse.of(mapper.getIndexTraverlerTalkList());
        }else if (StringUtils.equals(type, "5")) {
            return AjaxResponse.of(mapper.listRecommentedStrategy());
        }
        return AjaxResponse.of(mapper.getIndexRouteList());
    }




    /*逻辑删除*/
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse deleteIndexHk(String id) {
        ContIndex contIndex = new ContIndex();
        contIndex.setDelFlag(DBConstants.DEL_FLAG_DELETED);
        contIndex.setId(id);
        EntityUtils.setUpdatedInfo(contIndex);
        int result = mapper.updateByPrimaryKeySelective(contIndex);
        if (result == 1) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 转换特殊字符
     * @param map
     */
    private void convertSpecialChar(Map<String, Object> map) {
        for (String key : map.keySet()) {
            String value = (String) map.get(key);
            if (value != null) {
                value.replace("%", "\\%");
                map.put(key, value);
            }
        }
    }
}

