package com.isimpo.tech.framework.admin.contorller.travel;

import com.isimpo.tech.framework.admin.auto.entity.travel.TraStaffEvaluate;
import com.isimpo.tech.framework.admin.service.travel.TraStaffEvaluateService;
import com.isimpo.tech.framework.common.controller.BaseController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 行程员工评价
 * @Author wangxinhai
 * @date 2019年5月23日
 */
@RestController
@RequestMapping("/travel/traStaffEvaluate")
public class TraStaffEvaluateController extends BaseController<TraStaffEvaluateService, TraStaffEvaluate> {
}
