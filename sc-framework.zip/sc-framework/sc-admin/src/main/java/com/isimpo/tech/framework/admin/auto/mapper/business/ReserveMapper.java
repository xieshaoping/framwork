package com.isimpo.tech.framework.admin.auto.mapper.business;


import com.isimpo.tech.framework.admin.auto.entity.SysHousekeeper;
import com.isimpo.tech.framework.admin.auto.entity.business.Reserve;
import com.isimpo.tech.framework.common.util.Query;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface ReserveMapper extends Mapper<Reserve> {

    /**
     * 查询用户列表
     *
     * @param query 查询参数
     * @return  用户列表
     */
    List<Reserve> findList(Query query);

    /**
     * 查询用户列表
     *
     * @param reserve 查询参数
     * @return  用户列表
     */
    int handle(Reserve reserve);
}
