package com.isimpo.tech.framework.admin.auto.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;

@Table(name = "wx_menu")
public class WxMenu {
    /**
     * id
     */
    @Id
    private String id;

    /**
     * 编号(两位数一组，例：0203)
     */
    private String code;

    /**
     * 菜单Name
     */
    private String name;

    /**
     * 菜单Type
     */
    private String type;

    /**
     * 菜单Key
     */
    @Column(name = "menu_key")
    private String menuKey;

    /**
     * 菜单Url
     */
    private String url;

    /**
     * 微信公众号原始ID
     */
    @Column(name = "org_id")
    private String orgId;

    /**
     * 删除标识(1:有效,0:删除)
     */
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 创建时间
     */
    @Column(name = "add_time")
    private Date addTime;

    /**
     * 创建者
     */
    @Column(name = "add_user_id")
    private String addUserId;

    /**
     * 更新时间
     */
    @Column(name = "upd_time")
    private Date updTime;

    /**
     * 更新者
     */
    @Column(name = "upd_user_id")
    private String updUserId;

    /**
     * 更新页面ID
     */
    @Column(name = "upd_mark")
    private String updMark;

    private Integer sort;

    @Column(name = "add_mark")
    private String addMark;

    private String pCode;

    private String upOk;

    public String getUpOk() {
        return upOk;
    }

    public void setUpOk(String upOk) {
        this.upOk = upOk;
    }

    public String getpCode() {
        return pCode;
    }

    public void setpCode(String pCode) {
        this.pCode = pCode;
    }

    /**
     * 获取id
     *
     * @return id - id
     */
    public String getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取编号(两位数一组，例：0203)
     *
     * @return code - 编号(两位数一组，例：0203)
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置编号(两位数一组，例：0203)
     *
     * @param code 编号(两位数一组，例：0203)
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取菜单Name
     *
     * @return name - 菜单Name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置菜单Name
     *
     * @param name 菜单Name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取菜单Type
     *
     * @return type - 菜单Type
     */
    public String getType() {
        return type;
    }

    /**
     * 设置菜单Type
     *
     * @param type 菜单Type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 获取菜单Key
     *
     * @return menu_key - 菜单Key
     */
    public String getMenuKey() {
        return menuKey;
    }

    /**
     * 设置菜单Key
     *
     * @param menuKey 菜单Key
     */
    public void setMenuKey(String menuKey) {
        this.menuKey = menuKey;
    }

    /**
     * 获取菜单Url
     *
     * @return url - 菜单Url
     */
    public String getUrl() {
        return url;
    }

    /**
     * 设置菜单Url
     *
     * @param url 菜单Url
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * 获取微信公众号原始ID
     *
     * @return org_id - 微信公众号原始ID
     */
    public String getOrgId() {
        return orgId;
    }

    /**
     * 设置微信公众号原始ID
     *
     * @param orgId 微信公众号原始ID
     */
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    /**
     * 获取删除标识(1:有效,0:删除)
     *
     * @return del_flag - 删除标识(1:有效,0:删除)
     */
    public String getDelFlag() {
        return delFlag;
    }

    /**
     * 设置删除标识(1:有效,0:删除)
     *
     * @param delFlag 删除标识(1:有效,0:删除)
     */
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    /**
     * 获取创建时间
     *
     * @return add_time - 创建时间
     */
    public Date getAddTime() {
        return addTime;
    }

    /**
     * 设置创建时间
     *
     * @param addTime 创建时间
     */
    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    /**
     * 获取创建者
     *
     * @return add_user_id - 创建者
     */
    public String getAddUserId() {
        return addUserId;
    }

    /**
     * 设置创建者
     *
     * @param addUserId 创建者
     */
    public void setAddUserId(String addUserId) {
        this.addUserId = addUserId;
    }

    /**
     * 获取更新时间
     *
     * @return upd_time - 更新时间
     */
    public Date getUpdTime() {
        return updTime;
    }

    /**
     * 设置更新时间
     *
     * @param updTime 更新时间
     */
    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    /**
     * 获取更新者
     *
     * @return upd_user_id - 更新者
     */
    public String getUpdUserId() {
        return updUserId;
    }

    /**
     * 设置更新者
     *
     * @param updUserId 更新者
     */
    public void setUpdUserId(String updUserId) {
        this.updUserId = updUserId;
    }

    /**
     * 获取更新页面ID
     *
     * @return upd_mark - 更新页面ID
     */
    public String getUpdMark() {
        return updMark;
    }

    /**
     * 设置更新页面ID
     *
     * @param updMark 更新页面ID
     */
    public void setUpdMark(String updMark) {
        this.updMark = updMark;
    }

    /**
     * @return sort
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * @param sort
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }

    /**
     * @return add_mark
     */
    public String getAddMark() {
        return addMark;
    }

    /**
     * @param addMark
     */
    public void setAddMark(String addMark) {
        this.addMark = addMark;
    }
}
