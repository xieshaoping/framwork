package com.isimpo.tech.framework.admin.contorller.content.cocoCard;

import com.isimpo.tech.framework.admin.auto.entity.content.cocoCard.CocoCard;
import com.isimpo.tech.framework.admin.service.content.cocoCard.CocoCardService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;

/**
 * 可乐名片Controller
 *
 * @Witer xyh
 * @Date 2019/2/1
 */
@RestController
@ResponseBody
@RequestMapping("/content/cocoCard")
public class CocoCardController extends BaseController<CocoCardService, CocoCard> {

    /**
     * 获取可乐名片详细信息
     * @return
     */
    @GetMapping("/getCocoCard")
    public AjaxResponse getCocoCard(){
        return AjaxResponse.of(baseService.getCocoCard());
    }

    /**
     * 修改可乐名片信息
     * @param cocoCard
     * @return
     */
    @RequestMapping("/updateCocoCard")
    public AjaxResponse updateCocoCard(CocoCard cocoCard){
        return baseService.updateCocoCard(cocoCard);
    }

}
