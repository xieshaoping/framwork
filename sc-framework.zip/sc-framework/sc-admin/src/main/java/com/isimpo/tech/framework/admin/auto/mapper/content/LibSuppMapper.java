package com.isimpo.tech.framework.admin.auto.mapper.content;

import com.isimpo.tech.framework.admin.auto.entity.content.LibSupp;
import tk.mybatis.mapper.common.Mapper;

public interface LibSuppMapper extends Mapper<LibSupp> {
}