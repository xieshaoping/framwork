/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.service.sys;

import java.util.Date;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isimpo.tech.framework.admin.auto.entity.SysConfigure;
import com.isimpo.tech.framework.admin.auto.mapper.SysConfigureMapper;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;

/**
 * 系统区域管理service
 *
 * @author xieanan
 * @version 1.0
 * @since 2017/12/28
 */
@Service
public class SysConfigureService extends BaseService<SysConfigureMapper, SysConfigure> {

    public AjaxResponse getSysConfigure() {
        SysConfigure sysConfigure = mapper.querySysConfigure();
        return AjaxResponse.of(sysConfigure);
    }

    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updateSysConfigure(SysConfigure sysConfigure) {
        sysConfigure.setUpdTime(new Date());
        sysConfigure.setUpdUserId(BaseContextHandler.getUserID());
        try {
            mapper.updateSysConfigure(sysConfigure);
            return AjaxResponse.of(ResponseCode.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResponse.of(ResponseCode.FAIL);
        }
    }
}
