package com.isimpo.tech.framework.admin.auto.entity.content;


import java.util.List;

public class LibPlaceItemSupp {
    private String id;
    private String enName; //地点名称
    List<LibItem> libItemList; //行程列表
    List<LibSupp> libSuppList; //补充列表

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEnName() {
        return enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public List<LibItem> getLibItemList() {
        return libItemList;
    }

    public void setLibItemList(List<LibItem> libItemList) {
        this.libItemList = libItemList;
    }

    public List<LibSupp> getLibSuppList() {
        return libSuppList;
    }

    public void setLibSuppList(List<LibSupp> libSuppList) {
        this.libSuppList = libSuppList;
    }
}
