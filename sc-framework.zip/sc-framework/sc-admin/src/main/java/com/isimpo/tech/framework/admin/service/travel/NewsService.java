package com.isimpo.tech.framework.admin.service.travel;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.isimpo.tech.framework.admin.auto.entity.WechatTplMsgItemVo;
import com.isimpo.tech.framework.admin.auto.entity.WechatTplMsgVo;
import com.isimpo.tech.framework.admin.auto.entity.business.Member;
import com.isimpo.tech.framework.admin.auto.entity.travel.NewsVo;
import com.isimpo.tech.framework.admin.auto.entity.travel.TraManageVo;
import com.isimpo.tech.framework.admin.auto.mapper.business.MemberMapper;
import com.isimpo.tech.framework.admin.auto.mapper.travel.NewsMapper;
import com.isimpo.tech.framework.admin.auto.mapper.travel.TraManageMapper;
import com.isimpo.tech.framework.admin.utils.HttpClientUtils;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.admin.utils.WeinXinUtil;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.context.BaseContextHandler;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.response.TableResultResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import com.isimpo.tech.framework.common.util.Query;
import com.isimpo.tech.wechat.WeChatConfigUtil;
import com.isimpo.tech.wechat.WechatApi;
import com.isimpo.tech.wechat.WechatConstants;
import com.isimpo.tech.wechat.pojo.WechatConfig;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.validation.constraints.NotNull;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zhuyilong
 * @since 2019/1/30
 */
@Service
public class NewsService extends BaseService<NewsMapper, NewsVo> {
    private Logger logger = LoggerFactory.getLogger(NewsService.class);

    @NotNull
    @Value("${templateId}")
    private String templateId;

    @NotNull
    @Value("${h5Url}")
    private String h5Url;

    @Autowired
    private TraManageMapper traManageMapper;

    @Autowired
    private MemberMapper memberMapper;

    /**
     * 分页查询可乐消息列表
     * @param query
     * @return
     */
    @Override
    public TableResultResponse<NewsVo> selectByQuery(Query query) {
        Page<Object> result = PageHelper.startPage(query.getPage(), query.getLimit());
        List<NewsVo> list = mapper.listNews(query);
        return new TableResultResponse<>(result.getTotal(), list);
    }

    /**
     * 查询可乐消息详情
     * @param news
     * @return
     */
    public AjaxResponse getNewsDetail(NewsVo news) {
        return AjaxResponse.of(mapper.getNewsDetail(news));
    }
    /**
     * 删除可乐消息
     * @param news
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse delNews(NewsVo news) {
        EntityUtils.setUpdatedInfo(news);
        int count = mapper.delNews(news);
        if (count > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

    /**
     * 添加可乐消息
     * @param news
     * @return
     */
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public AjaxResponse addNews(NewsVo news) {
        EntityUtils.setCreatAndUpdatInfo(news);
        // 敏感词过滤
        news.setContent(SensitiveWordUtils.filterStr(news.getContent()));
        if (mapper.addNews(news) > 0) {
            setTemplantDate("可乐消息发布",news.getContent(),news.getTraId(),news.getId());
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }


    /**
     * 发送模板消息
     *
     * @param name
     * @param content
     * @param traId
     */
    public void setTemplantDate(String name, String content,String traId, String newsId) {
        //查询该行程所在的成员  openId
        List<String> authPeoples = memberMapper.getMemberListByTraId(traId).stream().map(Member::getOpenId).collect(Collectors.toList());
        List<Member> list = memberMapper.getMemberListByTraId(traId);
        TraManageVo traBase = traManageMapper.findTravelById(traId);
        for (int i = 0;i<list.size();i++) {
            //发送模板消息
            WechatTplMsgVo tplMsgVo = new WechatTplMsgVo();
            tplMsgVo.setTemplate_id(templateId);
            tplMsgVo.setUrl(h5Url + "static/page/onroad/news/newsDetail.html?newsId=" + newsId);
            Map<String, WechatTplMsgItemVo> map = new HashMap<>();
            map.put("first",new WechatTplMsgItemVo("尊敬的"+list.get(i).getName()+"，您好，可乐国旅温馨提醒。"));
            map.put("keyword1",new WechatTplMsgItemVo(traBase.getName()));
            map.put("keyword2",new WechatTplMsgItemVo("可乐消息"));
            map.put("keyword3",new WechatTplMsgItemVo(content));
            map.put("remark", new WechatTplMsgItemVo(""));
            tplMsgVo.setData(map);
            sendTplMsg(tplMsgVo, list.get(i).getOpenId());
        }

    }

    public boolean sendTplMsg(WechatTplMsgVo tplMsgVo, String openId){
        WechatConfig wechatConfig = WeChatConfigUtil.getWechatConfig();
        String accessToken = WechatApi.getToken();//WeinXinUtil.getAccessToken(wechatConfig.getAppId(),wechatConfig.getSecret());//WechatApi.getToken();
        Boolean success = false;
        if (StringUtils.isNotEmpty(openId) && StringUtils.isNotEmpty(accessToken)) {
            String requestUrl = WechatConstants.WECHAT_SEND_WECHAT_URL.replace("#ACCESS_TOKEN#", accessToken);
            tplMsgVo.setTouser(openId);
            String params = JSONObject.toJSONString(tplMsgVo);
            params = stringUncode(params);
            try {
                String result = HttpClientUtils.sendPostSSLRequest(requestUrl, params);
                if (StringUtils.isNotBlank(result)) {
                    JSONObject jsonObject = JSONObject.parseObject(result);
                    if (jsonObject.containsKey("errcode") && jsonObject.getIntValue("errcode") == 0) {
                        success = true;
                        logger.info("发送模版消息成功：token:{}：{}：{}", accessToken, params, result);
                    } else {
                        logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                    }
                } else {
                    logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                }
            } catch (Exception ex) {
                logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, ex);
            }
        } else {
            logger.error("发送模版消息失败：token:{} 或 没有审核人员", accessToken);
        }
        return success;
    }



    /**
     * 发送给模版消息
     *
     * @param tplMsgVo 消息内容
     * @param openids  用户openid集合
     * @return 是否有发送成功的
     */
    public boolean sendTplMsg(WechatTplMsgVo tplMsgVo, List<String> openids, int checkNum) {
        WechatConfig wechatConfig = WeChatConfigUtil.getWechatConfig();
        String accessToken = WechatApi.getToken();//WeinXinUtil.getAccessToken(wechatConfig.getAppId(),wechatConfig.getSecret());//WechatApi.getToken();
        Boolean success = false;
        if (!CollectionUtils.isEmpty(openids) && StringUtils.isNotEmpty(accessToken)) {
            String requestUrl = WechatConstants.WECHAT_SEND_WECHAT_URL.replace("#ACCESS_TOKEN#", accessToken);
            for (int i = 0; i < openids.size(); i++) {
                tplMsgVo.setTouser(openids.get(i));
                String params = JSONObject.toJSONString(tplMsgVo);
                params = stringUncode(params);
                try {
                    String result = HttpClientUtils.sendPostSSLRequest(requestUrl, params);
                    if (StringUtils.isNotBlank(result)) {
                        JSONObject jsonObject = JSONObject.parseObject(result);
                        if (jsonObject.containsKey("errcode") && jsonObject.getIntValue("errcode") == 0) {
                            success = true;
                            logger.info("发送模版消息成功：token:{}：{}：{}", accessToken, params, result);
                        } else {
                            logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                        }
                    } else {
                        logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, result);
                    }
                } catch (Exception ex) {
                    logger.error("发送模版消息失败：token:{}：{}：{}", accessToken, params, ex);
                }
            }
        } else {
            logger.error("发送模版消息失败：token:{} 或 没有审核人员", accessToken);
        }
        return success;
    }

    /**
     * 特殊字符转码
     *
     * @param param
     * @return
     */
    public static String stringUncode(String param) {
        if (param != null && !param.trim().equals("")) {
            try {
                param = URLEncoder.encode(param, "utf-8");//转码
                param = URLDecoder.decode(param, "UTF-8");//解码
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return param;
    }

    /**
     * 查询行程列表
     * @return
     */
    public AjaxResponse getTravelList() {
        List<TraManageVo> list = mapper.listTravel();
        return AjaxResponse.of(list);
    }
}
