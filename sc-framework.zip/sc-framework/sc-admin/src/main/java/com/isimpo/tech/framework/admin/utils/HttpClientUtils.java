/*
* Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
* SIMPO Technology. CONFIDENTIAL
*/
package com.isimpo.tech.framework.admin.utils;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author zx
 * @version 1.0
 * @since 2018/6/4
 */
public class HttpClientUtils {

	private HttpClientUtils(){}

	private static Logger logger = LoggerFactory.getLogger(HttpClientUtils.class);

	private static final String UTF8 = "UTF-8";
	/**
	 * post方式请求服务器(https协议)
	 *
	 * @param url 请求地址
	 * @param content 参数
	 * @param charset 编码
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 * @throws IOException
	 */
	public static byte[] post(String url, String content, String charset)
			throws NoSuchAlgorithmException, KeyManagementException, IOException {
		byte[] ret = null;
		HttpsURLConnection conn = null;
		DataOutputStream out = null;
		InputStream is = null;
		ByteArrayOutputStream outStream = null;
		try {
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, new TrustManager[] { new TrustAnyTrustManager() },
					new java.security.SecureRandom());

			URL console = new URL(url);
			conn = (HttpsURLConnection)console.openConnection();
			conn.setSSLSocketFactory(sc.getSocketFactory());
			conn.setHostnameVerifier(new TrustAnyHostnameVerifier());
			conn.setDoOutput(true);
			conn.connect();
			out = new DataOutputStream(conn.getOutputStream());
			out.write(content.getBytes(charset));
			// 刷新、关闭
			out.flush();
			is = conn.getInputStream();
			if (is != null) {
				outStream = new ByteArrayOutputStream();
				byte[] buffer = new byte[1024];
				int len = 0;
				while ((len = is.read(buffer)) != -1) {
					outStream.write(buffer, 0, len);
				}
				ret = outStream.toByteArray();
			}
		} catch (Exception ex) {
			logger.error("发送post 请求失败:" + ex.getMessage());
		} finally {
			// modify by ranphy 内存问题
			if (out != null) {
				out.close();
			}
			if (outStream != null) {
				outStream.close();
			}
			if (is != null) {
				is.close();
			}
			if (conn != null) {
				conn.disconnect();
			}
		}
		return ret;
	}

	/**
	 * 发送HTTP_GET请求 该方法会自动关闭连接,释放资源
	 *
	 * @param reqURL 请求地址(含参数)
	 * @param decodeCharset 解码字符集,解析响应数据时用之,其为null时默认采用UTF-8解码
	 * @return 远程主机响应正文
	 */
	public static String sendGetRequest(String reqURL, String decodeCharset) {
		long responseLength = 0; // 响应长度
		String responseContent = null; // 响应内容
		HttpClient httpClient = null;
		HttpGet httpGet = new HttpGet(reqURL); // 创建org.apache.http.client.methods.HttpGet
		try {
			httpClient= HttpClientBuilder.create().build(); // 创建默认的httpClient实例
			HttpResponse response = httpClient.execute(httpGet); // 执行GET请求
			HttpEntity entity = response.getEntity(); // 获取响应实体
			if (null != entity) {
				responseLength = entity.getContentLength();
				responseContent = EntityUtils.toString(entity, decodeCharset == null ? UTF8
						: decodeCharset);
				EntityUtils.consume(entity); // Consume response content
			}
		} catch (ClientProtocolException e) {
			logger.error(
					"该异常通常是协议错误导致,比如构造HttpGet对象时传入的协议不对(将'http'写成'htp')或者服务器端返回的内容不符合HTTP协议要求等,堆栈信息如下",
					e);
		} catch (ParseException e) {
			logger.error(e.getMessage(), e);
		} catch (IOException e) {
			logger.error("该异常通常是网络原因引起的,如HTTP服务器未启动等,堆栈信息如下", e);
		} finally {
			if(httpClient!=null){
				httpClient.getConnectionManager().shutdown(); // 关闭连接,释放资源
			}
		}
		return responseContent;
	}

	/**
	 * 发送HTTP_POST请求 该方法为 <code>sendPostRequest(String,String,boolean,String,String)</code>的简化方法 该方法在对请求数据的编码和响应数据的解码时,所采用的字符集均为UTF-8 当
	 * <code>isEncoder=true</code>时,其会自动对 <code>sendData</code>中的[中文][|][ ]等特殊字符进行 <code>URLEncoder.encode(string,"UTF-8")</code>
	 *
	 * @param isEncoder 用于指明请求数据是否需要UTF-8编码,true为需要
	 */
	public static String sendPostRequest(String reqURL, String sendData, boolean isEncoder) {
		return sendPostRequest(reqURL, sendData, isEncoder, null, null);
	}

	/**
	 * 发送post请求
	 *
	 * @param reqURL 请求地址
	 * @param decodeCharset 字符编码
	 * @return 响应字符串
	 */
	public static String sendPostRequestOne(String reqURL, String jsonStr, String decodeCharset) {
		CloseableHttpClient httpclient = HttpClients.createDefault(); // 创建httpclient实例
		HttpPost httpPost = new HttpPost(reqURL); //创建post方式请求对象
		//指定报文头【Content-type】、【User-Agent】
		httpPost.setHeader("Content-type", "application/json");
		httpPost.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:50.0) Gecko/20100101 Firefox/50.0"); // 设置请求头消息User-Agent
		CloseableHttpResponse response = null;
		String responseContent = "";
		try {
			//设置参数到请求对象中
			httpPost.setEntity(new StringEntity(jsonStr, decodeCharset == null ? "utf-8" : decodeCharset));
			response = httpclient.execute(httpPost); // 执行get请求
			HttpEntity entity = response.getEntity(); // 获取返回实体
			responseContent = EntityUtils.toString(entity, decodeCharset == null ? "utf-8" : decodeCharset);
			EntityUtils.consume(entity);
		} catch (IOException e) {
			logger.error("该异常通常是协议错误导致,比如构造HttpGet对象时传入的协议不对(将'http'写成'htp')或者服务器端返回的内容不符合HTTP协议要求等,堆栈信息如下", e);
		} finally {
			CloseableHttpResponseClose(response);
		}
		return responseContent;
	}

	/**
	 * 关闭流和释放系统资源
	 */
	private static void CloseableHttpResponseClose(CloseableHttpResponse response) {
		if (null != response) {
			try {
				response.close();
			} catch (IOException e) {
				logger.error("该异常通常是网络原因引起的,如HTTP服务器未启动等,堆栈信息如下", e);
			}
		}
	}

	/**
	 * 发送HTTP_POST请求 该方法会自动关闭连接,释放资源 当<code>isEncoder=true</code>时,其会自动对 <code>sendData</code> 中的[中文][|][ ]等特殊字符进行
	 * <code>URLEncoder.encode(string,encodeCharset)</code>
	 *
	 * @param reqURL 请求地址
	 * @param sendData 请求参数,若有多个参数则应拼接成param11=value11¶m22=value22¶m33=value33的形式后, 传入该参数中
	 * @param isEncoder 请求数据是否需要encodeCharset编码,true为需要
	 * @param encodeCharset 编码字符集,编码请求数据时用之,其为null时默认采用UTF-8解码
	 * @param decodeCharset 解码字符集,解析响应数据时用之,其为null时默认采用UTF-8解码
	 * @return 远程主机响应正文
	 */
	public static String sendPostRequest(String reqURL, String sendData, boolean isEncoder,
	                                     String encodeCharset, String decodeCharset) {
		String responseContent = null;
		CloseableHttpClient httpClient = null;

		HttpPost httpPost = new HttpPost(reqURL);
		httpPost.setHeader(HTTP.CONTENT_TYPE, "application/x-www-form-urlencoded");
		try {
			httpClient= HttpClientBuilder.create().build();
			if (isEncoder) {
				List<NameValuePair> formParams = new ArrayList<NameValuePair>();
				for (String str : sendData.split("&")) {
					formParams.add(new BasicNameValuePair(str.substring(0, str.indexOf('=')), str
							.substring(str.indexOf('=') + 1)));
				}
				httpPost.setEntity(new StringEntity(URLEncodedUtils.format(formParams,
						encodeCharset == null ? UTF8 : encodeCharset)));
			} else {
				httpPost.setEntity(new StringEntity(sendData));
			}

			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			if (null != entity) {
				responseContent = EntityUtils.toString(entity, decodeCharset == null ? UTF8
						: decodeCharset);
				EntityUtils.toByteArray(entity);
				EntityUtils.consume(entity);
			}
		} catch (Exception e) {
			logger.error("与[" + reqURL + "]通信过程中发生异常,堆栈信息如下", e);
		} finally {
			if(httpClient!=null){
				httpClient.getConnectionManager().shutdown();
			}
		}
		return responseContent;
	}

	/**
	 * 发送HTTP_POST请求 该方法会自动关闭连接,释放资源 该方法会自动对<code>params</code>中的[中文][|][ ]等特殊字符进行 <code>URLEncoder.encode(string,encodeCharset)</code>
	 *
	 * @param reqURL 请求地址
	 * @param params 请求参数
	 * @param encodeCharset 编码字符集,编码请求数据时用之,其为null时默认采用UTF-8解码
	 * @param decodeCharset 解码字符集,解析响应数据时用之,其为null时默认采用UTF-8解码
	 * @return 远程主机响应正文
	 */
	public static String sendPostRequest(String reqURL, Map<String, String> params,
	                                     String encodeCharset, String decodeCharset) {
		String responseContent = null;
		HttpClient httpClient = null;

		HttpPost httpPost = new HttpPost(reqURL);
		List<NameValuePair> formParams = new ArrayList<NameValuePair>(); // 创建参数队列
		for (Map.Entry<String, String> entry : params.entrySet()) {
			formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
		}
		try {
			httpClient=HttpClientBuilder.create().build();
			httpPost.setEntity(new UrlEncodedFormEntity(formParams, encodeCharset == null ? UTF8
					: encodeCharset));

			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			if (null != entity) {
				responseContent = EntityUtils.toString(entity, decodeCharset == null ? UTF8
						: decodeCharset);
				EntityUtils.consume(entity);
			}
		} catch (Exception e) {
			logger.error("与[" + reqURL + "]通信过程中发生异常,堆栈信息如下", e);
		} finally {
			if(httpClient!=null){
				httpClient.getConnectionManager().shutdown();
			}
		}
		return responseContent;
	}

	/**
	 * 发送HTTPS_POST，类型为JSON的请求 该方法会自动关闭连接,释放资源 该方法会自动对<code>params</code> 中的[中文][|][ ]等特殊字符进行
	 * <code>URLEncoder.encode(string,encodeCharset)</code>
	 *
	 * @param reqURL 请求地址
	 * @param params 请求参数
	 * @param encodeCharset 编码字符集,编码请求数据时用之,其为null时默认采用UTF-8解码
	 * @param decodeCharset 解码字符集,解析响应数据时用之,其为null时默认采用UTF-8解码
	 * @return 远程主机响应正文
	 */
	public static String sendPostRequest(String reqURL, String params, String encodeCharset, String decodeCharset) {
		String responseContent = "";
		HttpClient httpClient = null;
		try {
			httpClient = DefaultApacheHttpClientBuilder.get().build();
			HttpPost httpPost = new HttpPost(reqURL);
			httpPost.setEntity(new StringEntity(params, encodeCharset == null ? UTF8 : encodeCharset));
			httpPost.addHeader("content-type", "application/json");
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			if (null != entity) {
				responseContent = EntityUtils.toString(entity, decodeCharset == null ? UTF8 : decodeCharset);
			}
		} catch (Exception e) {
			logger.error("与[" + reqURL + "]通信过程中发生异常,堆栈信息为", e);
		} finally {
			org.apache.http.client.utils.HttpClientUtils.closeQuietly(httpClient);
		}
		return responseContent;
	}

	/**
	 * 发送HTTPS_POST请求 该方法为 <code>sendPostSSLRequest(String,Map<String,String>,String,String)</code> 方法的简化方法 该方法在对请求数据的编码和响应数据的解码时,所采用的字符集均为UTF-8
	 * 该方法会自动对<code>params</code> 中的[中文][|][ ]等特殊字符进行 <code>URLEncoder.encode(string,"UTF-8")</code>
	 */
	public static String sendPostSSLRequest(String reqURL, Map<String, String> params) {
		return sendPostSSLRequest(reqURL, params, null, null);
	}

	/**
	 * 发送HTTPS_POST请求 该方法会自动关闭连接,释放资源 该方法会自动对<code>params</code>中的[中文][|][ ]等特殊字符进行 <code>URLEncoder.encode(string,encodeCharset)</code>
	 *
	 * @param reqURL 请求地址
	 * @param params 请求参数
	 * @param encodeCharset 编码字符集,编码请求数据时用之,其为null时默认采用UTF-8解码
	 * @param decodeCharset 解码字符集,解析响应数据时用之,其为null时默认采用UTF-8解码
	 * @return 远程主机响应正文
	 */
	public static String sendPostSSLRequest(String reqURL, Map<String, String> params,
	                                        String encodeCharset, String decodeCharset) {
		String responseContent = "";
		HttpClient httpClient = null;
		X509TrustManager xtm = new X509TrustManager() {
			@Override
			public void checkClientTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				//规范调整
			}
			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				//规范调整
			}
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[1];
			}
		};
		try {
			SSLContext ctx = SSLContext.getInstance("TLS");
			ctx.init(null, new TrustManager[] { xtm }, null);
			httpClient=HttpClientBuilder.create().setSSLSocketFactory(new SSLConnectionSocketFactory(ctx,
					SSLConnectionSocketFactory.getDefaultHostnameVerifier())).build();
			HttpPost httpPost = new HttpPost(reqURL);
			List<NameValuePair> formParams = new ArrayList<NameValuePair>();
			for (Map.Entry<String, String> entry : params.entrySet()) {
				formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
			}
			httpPost.setEntity(new UrlEncodedFormEntity(formParams, encodeCharset == null ? UTF8
					: encodeCharset));

			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			if (null != entity) {
				responseContent = EntityUtils.toString(entity, decodeCharset == null ? UTF8
						: decodeCharset);
				EntityUtils.consume(entity);
			}
		} catch (Exception e) {
			logger.error("与[" + reqURL + "]通信过程中发生异常,堆栈信息为", e);
		} finally {
			if(httpClient!=null){
				httpClient.getConnectionManager().shutdown();
			}
		}
		return responseContent;
	}

	/**
	 * 发送HTTPS_POST,类型为JSON的请求 该方法为 <code>sendPostSSLRequest(String,String,String,String)</code> 方法的简化方法 该方法在对请求数据的编码和响应数据的解码时,所采用的字符集均为UTF-8
	 * 该方法会自动对<code>params</code>中的[中文][|][ ]等特殊字符进行 <code>URLEncoder.encode(string,"UTF-8")</code>
	 */
	public static String sendPostSSLRequest(String reqURL, String params) {
		return sendPostSSLRequest(reqURL, params, null, null);
	}

	/**
	 * 发送HTTPS_POST，类型为JSON的请求 该方法会自动关闭连接,释放资源 该方法会自动对<code>params</code> 中的[中文][|][ ]等特殊字符进行
	 * <code>URLEncoder.encode(string,encodeCharset)</code>
	 *
	 * @param reqURL 请求地址
	 * @param params 请求参数
	 * @param encodeCharset 编码字符集,编码请求数据时用之,其为null时默认采用UTF-8解码
	 * @param decodeCharset 解码字符集,解析响应数据时用之,其为null时默认采用UTF-8解码
	 * @return 远程主机响应正文
	 */
	public static String sendPostSSLRequest(String reqURL, String params, String encodeCharset,
	                                        String decodeCharset) {
		String responseContent = "";
		HttpClient httpClient = null;
		X509TrustManager xtm = new X509TrustManager() {
			@Override
			public void checkClientTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				//调整
			}
			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				//调整
			}
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[1];
			}
		};
		try {
			SSLContext ctx = SSLContext.getInstance("TLS");
			ctx.init(null, new TrustManager[] { xtm }, null);
			httpClient=HttpClientBuilder.create().setSSLSocketFactory(new SSLConnectionSocketFactory(ctx,
					SSLConnectionSocketFactory.getDefaultHostnameVerifier())).build();
			HttpPost httpPost = new HttpPost(reqURL);
			/*
			 * List<NameValuePair> formParams = new ArrayList<NameValuePair>(); for(Map.Entry<String,String> entry : params.entrySet()){
			 * formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue())); }
			 */
			httpPost.setEntity(new StringEntity(params, encodeCharset == null ? UTF8
					: encodeCharset));
			httpPost.addHeader("content-type", "application/json");
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			if (null != entity) {

				byte[] byteArray = EntityUtils.toByteArray(entity);
				responseContent = new String(byteArray, UTF8);
				EntityUtils.consume(entity);
			}
		} catch (Exception e) {
			logger.error("与[" + reqURL + "]通信过程中发生异常,堆栈信息为", e);
		} finally {
			if(httpClient!=null){
				httpClient.getConnectionManager().shutdown();
			}
		}
		return responseContent;
	}

	/**
	 * 上传微信媒体信息
	 *
	 * @author fanhy
	 * @since 2015年11月11日
	 * @param uploadMediaUrl
	 * @param mediaFileUrl
	 * @return
	 */
	/*public static String uploadMedia(String uploadMediaUrl, String mediaFileUrl) {
		String result = "";
		// 定义数据分隔符 '3da2e536604c8' 随机生成 ,没有其他意义
		String boundary = "------------7da2e536604c8";
		HttpURLConnection uploadConn = null;
		try {
			URL uploadUrl = new URL(uploadMediaUrl);
			uploadConn = (HttpURLConnection)uploadUrl.openConnection();
			uploadConn.setDoOutput(true);
			uploadConn.setDoInput(true);
			uploadConn.setRequestMethod("POST");
			uploadConn.setRequestProperty("User-Agent",
					"Mozilla/5.0 (Windows; U; Windows NT 6.1; zh-CN; rv:1.9.2.6)");
			uploadConn.setRequestProperty("Charsert", UTF8);
			// 设置请求头Content-Type
			uploadConn.setRequestProperty("Content-Type", "multipart/form-data;boundary="
					+ boundary);
			uploadConn.setRequestProperty("Connection", "Keep-Alive");

			OutputStream outputStream = null;
			InputStream meidaConnIsm = null;
			BufferedInputStream bis = null;
			HttpURLConnection meidaConn = null;
			try {
				// 获取媒体文件上传的输出流（往微信服务器写数据）
				outputStream = uploadConn.getOutputStream();

				URL mediaUrl = new URL(mediaFileUrl);
				meidaConn = (HttpURLConnection)mediaUrl.openConnection();
				meidaConn.setDoOutput(true);
				meidaConn.setRequestMethod("GET");

				// 从请求头中获取内容类型
				String contentType = meidaConn.getHeaderField("Content-Type");
				// 根据内容类型判断文件扩展名
				String fileExt = FileUtil.getFileExt(contentType);
				// 请求体开始
				outputStream.write(("--" + boundary + "\r\n").getBytes());
				outputStream.write(String.format(
						"Content-Disposition: form-data; name=\"media\"; filename=\"file1%s\"\r\n",
						fileExt).getBytes());
				outputStream.write(String.format("Content-Type: %s\r\n\r\n", contentType)
						.getBytes());

				// 获取媒体文件的输入流（读取文件）
				meidaConnIsm = meidaConn.getInputStream();
				bis = new BufferedInputStream(meidaConnIsm);
				byte[] buf = new byte[8096];
				int size = 0;
				while ((size = bis.read(buf)) != -1) {
					// 将媒体文件写到输出流（往微信服务器写数据）
					outputStream.write(buf, 0, size);
				}
				// 请求体结束
				outputStream.write(("\r\n--" + boundary + "--\r\n").getBytes());
			} catch (Exception ex) {
				logger.error(ex.getMessage(), ex);
				throw ex;
			} finally {
				// modify by ranphy 内存问题
				if (outputStream != null) {
					outputStream.close();
				}
				if (bis != null) {
					bis.close();
				}
				if (meidaConnIsm != null) {
					meidaConnIsm.close();
				}
				if (meidaConn != null) {
					meidaConn.disconnect();
				}
			}

			StringBuilder buffer = new StringBuilder();
			try (InputStream inputStream = uploadConn.getInputStream();
			     InputStreamReader inputStreamReader = new InputStreamReader(inputStream, UTF8);
			     BufferedReader bufferedReader = new BufferedReader(inputStreamReader)
			){
				// 获取媒体文件上传的输入流（从微信服务器读数据）
				String str;
				while ((str = bufferedReader.readLine()) != null) {
					buffer.append(str);
				}
			} catch (Exception ex) {
				logger.error(ex.getMessage(), ex);
				throw ex;
			}

			result = buffer.toString();
		} catch (Exception e) {
			logger.error("上传媒体文件失败：{}", e);
		} finally {
			if (uploadConn != null) {
				uploadConn.disconnect();
			}
		}

		return result;
	}*/

	/*public static String sendGetSSLRequestImg(String reqURL, String yourPath) {

		long responseLength = 0; // 响应长度
		String responseContent = null; // 响应内容
		X509TrustManager xtm = new X509TrustManager() {
			@Override
			public void checkClientTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				// do
			}
			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				//do
			}
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return  new X509Certificate[1];
			}
		};
		HttpClient httpClient = null;
		try {
			SSLContext ctx = SSLContext.getInstance("TLS");
			ctx.init(null, new TrustManager[] { xtm }, null);
			httpClient=HttpClientBuilder.create().setSSLSocketFactory(new SSLConnectionSocketFactory(ctx,
					SSLConnectionSocketFactory.getDefaultHostnameVerifier())).build();
			HttpGet httpGet = new HttpGet(reqURL); // 创建org.apache.http.client.methods.HttpGet
			HttpResponse response = httpClient.execute(httpGet); // 执行GET请求

			HttpEntity entity = response.getEntity(); // 获取响应实体
			if (null != entity) {
				responseLength = entity.getContentLength();
				String imgFilePath = StringHelperTools.getUUID() + ".jpg";
				String filePath = yourPath + imgFilePath;
				File file = new File(filePath);
				if (file.exists()) {
					file.createNewFile();
				}
				try(FileOutputStream fileOutputStream = new FileOutputStream(file)){
					InputStream inputStream = entity.getContent();

					byte[] buffer = new byte[1024];
					int len = 0;
					while ((len = inputStream.read(buffer)) != -1) {
						fileOutputStream.write(buffer, 0, len);
					}
					fileOutputStream.flush();
					inputStream.close();

					responseContent = filePath;
					EntityUtils.consume(entity); // Consume response content
				}
			}
			logger.info("请求地址: " + httpGet.getURI());
			logger.info("响应状态: " + response.getStatusLine());
			logger.info("响应长度: " + responseLength);
		} catch (Exception e) {
			logger.error("与[" + reqURL + "]通信过程中发生异常,堆栈信息为", e);
		} finally {
			if(httpClient!=null){
				httpClient.getConnectionManager().shutdown(); // 关闭连接,释放资源
			}
		}
		return responseContent;

	}*/

	/**
	 * 发送HTTPS_GET请求 该方法会自动关闭连接,释放资源
	 *
	 * @param reqURL 请求地址(含参数)
	 * @param decodeCharset 解码字符集,解析响应数据时用之,其为null时默认采用UTF-8解码
	 * @return 远程主机响应正文
	 */
	public static String sendGetSSLRequest(String reqURL, String decodeCharset) {
		long responseLength = 0; // 响应长度
		String responseContent = null; // 响应内容
		HttpClient httpClient =null;
		X509TrustManager xtm = new X509TrustManager() {
			@Override
			public void checkClientTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				//DO
			}
			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType)
					throws CertificateException {
				//DO
			}
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[1];
			}
		};

		try {
			// 创建默认的httpClient实例=
			//httpClient=new DefaultHttpClient();
			SSLContext ctx = SSLContext.getInstance("TLS");
			ctx.init(null, new TrustManager[] { xtm }, null);
//			SSLSocketFactory socketFactory = new SSLSocketFactory(ctx);
//			httpClient.getConnectionManager().getSchemeRegistry()
//					.register(new Scheme("https", 443, socketFactory));
			httpClient=HttpClientBuilder.create().setSSLSocketFactory(new SSLConnectionSocketFactory(ctx,
					SSLConnectionSocketFactory.getDefaultHostnameVerifier())).build();

			HttpGet httpGet = new HttpGet(reqURL); // 创建org.apache.http.client.methods.HttpGet
			HttpResponse response = httpClient.execute(httpGet); // 执行GET请求
			HttpEntity entity = response.getEntity(); // 获取响应实体
			if (null != entity) {
				responseLength = entity.getContentLength();
				responseContent = EntityUtils.toString(entity, decodeCharset == null ? UTF8
						: decodeCharset);
				EntityUtils.consume(entity); // Consume response content
			}
		} catch (Exception e) {
			logger.error("与[" + reqURL + "]通信过程中发生异常,堆栈信息为", e);
		} finally {
			if(httpClient!=null){
				httpClient.getConnectionManager().shutdown(); // 关闭连接,释放资源
			}
		}
		return responseContent;
	}

	/**
	 * 发送HTTP_POST请求 若发送的<code>params</code>中含有中文,记得按照双方约定的字符集将中文 <code>URLEncoder.encode(string,encodeCharset)</code>
	 * 本方法默认的连接超时时间为30秒,默认的读取超时时间为30秒
	 *
	 * @param reqURL 请求地址
	 * @param params 发送到远程主机的正文数据,其数据类型为<code>java.util.Map<String, String></code>
	 * @return 远程主机响应正文`HTTP状态码,如<code>"SUCCESS`200"</code><br>
	 *         若通信过程中发生异常则返回"Failed`HTTP状态码",如<code>"Failed`500"</code>
	 */
	public static String sendPostRequestByJava(String reqURL, Map<String, String> params) {
		StringBuilder sendData = new StringBuilder();
		for (Map.Entry<String, String> entry : params.entrySet()) {
			sendData.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
		}
		if (sendData.length() > 0) {
			sendData.setLength(sendData.length() - 1); // 删除最后一个&符号
		}
		return sendPostRequestByJava(reqURL, sendData.toString());
	}

	/**
	 * 发送HTTP_POST请求 若发送的<code>sendData</code>中含有中文,记得按照双方约定的字符集将中文 <code>URLEncoder.encode(string,encodeCharset)</code>
	 * 本方法默认的连接超时时间为30秒,默认的读取超时时间为30秒
	 *
	 * @param reqURL 请求地址
	 * @param sendData 发送到远程主机的正文数据
	 * @return 远程主机响应正文`HTTP状态码,如<code>"SUCCESS`200"</code><br>
	 *         若通信过程中发生异常则返回"Failed`HTTP状态码",如<code>"Failed`500"</code>
	 */
	public static String sendPostRequestByJava(String reqURL, String sendData) {
		HttpURLConnection httpURLConnection = null;
		OutputStream out = null; // 写
		InputStream in = null; // 读
		int httpStatusCode = 0; // 远程主机响应的HTTP状态码
		try {
			URL sendUrl = new URL(reqURL);
			httpURLConnection = (HttpURLConnection)sendUrl.openConnection();
			httpURLConnection.setRequestMethod("POST");
			httpURLConnection.setDoOutput(true); // 指示应用程序要将数据写入URL连接,其值默认为false
			httpURLConnection.setUseCaches(false);
			httpURLConnection.setConnectTimeout(30000); // 30秒连接超时
			httpURLConnection.setReadTimeout(30000); // 30秒读取超时

			out = httpURLConnection.getOutputStream();
			out.write(sendData.getBytes());

			// 清空缓冲区,发送数据
			out.flush();

			// 获取HTTP状态码
			httpStatusCode = httpURLConnection.getResponseCode();

			in = httpURLConnection.getInputStream();
			byte[] byteDatas = new byte[in.available()];
			in.read(byteDatas);
			return new String(byteDatas) + "`" + httpStatusCode;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return "Failed`" + httpStatusCode;
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (Exception e) {
					logger.error("关闭输出流时发生异常,堆栈信息如下", e);
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
					logger.error("关闭输入流时发生异常,堆栈信息如下", e);
				}
			}
			if (httpURLConnection != null) {
				httpURLConnection.disconnect();
				httpURLConnection = null;
			}
		}
	}

	/**
	 * 发送代理的get请求
	 *
	 * @param request
	 * @param response
	 * @param url
	 * @throws IOException
	 */
	public static void sendGetSSLRequestForProxy(HttpServletRequest request,
	                                             HttpServletResponse response, String url) throws  IOException {
		HttpURLConnection connection = null;
		//		InputStream istream = null;
		OutputStream ostream = null;
		InputStream connectionIstream = null;
		//		OutputStream connectionOstream = null;
		try {
			String requestMethod = request.getMethod();
			URL targetURL = new URL(url);
			connection = (HttpURLConnection)targetURL.openConnection();
			connection.setRequestMethod(requestMethod);
			transferHTTPRequestHeaders(connection, request);
			if (requestMethod.equals("GET")) {
				connectionIstream = connection.getInputStream();
			}
			response.setContentType(connection.getContentType());
			ostream = response.getOutputStream();
			copy(connectionIstream, ostream);
		} catch (Exception e) {
			response.setStatus(500);
			e.printStackTrace();
		} finally {
			//			if (istream != null) {
			//				istream.close();
			//			}
			if (ostream != null) {
				ostream.close();
			}
			if (connectionIstream != null) {
				connectionIstream.close();
			}
			//			if (connectionOstream != null) {
			//				connectionOstream.close();
			//			}
		}

	}

	/**
	 * 复制请求的数据流
	 *
	 * @param istream
	 * @param ostream
	 * @throws Exception
	 */
	private static void copy(InputStream istream, OutputStream ostream) throws IOException {
		int bufferSize = 4 * 4 * 1024;// same buffer size as in Jetty utils//
		// (2*8192)
		byte[] buffer = new byte[bufferSize];
		int read;
		while ((read = istream.read(buffer)) != -1) {
			ostream.write(buffer, 0, read);
		}
	}

	/**
	 * 复制请求头信息
	 *
	 * @param connection
	 * @param request
	 */
	private static void transferHTTPRequestHeaders(HttpURLConnection connection,
	                                               HttpServletRequest request) {
		if (request.getHeader("Accept") != null) {
			connection.setRequestProperty("Accept", request.getHeader("Accept"));
		}
		if (request.getHeader("Accept-Charset") != null) {
			connection.setRequestProperty("Accept-Charset", request.getHeader("Accept-Charset"));
		}
		if (request.getHeader("Authorization") != null) {
			connection.setRequestProperty("Authorization", request.getHeader("Authorization"));
		}
		if (request.getHeader("X-Forwarded-For") != null) {
			connection.setRequestProperty("X-Forwarded-For", request.getHeader("X-Forwarded-For"));
		} else {
			connection.setRequestProperty("X-Forwarded-For", request.getRemoteAddr());
		}
	}

	/**
	 * 获取一个URL的输入流
	 *
	 * @param urlStr
	 * @return
	 * @throws Exception
	 */
	public static InputStream getUrlInputStream(String urlStr) throws IOException {

		URL url = new URL(urlStr);
		URLConnection conn = url.openConnection();
		return conn.getInputStream();
	}

	/**
	 * 保存输入流为一个文件
	 *
	 * @author fanhy
	 * @since 2015年11月11日
	 * @param inputStream
	 * @param file
	 * @throws Exception
	 */
	public static void saveInputStreamForFile(InputStream inputStream, File file) throws IOException {
		if (!file.exists()) {
			file.createNewFile();
		}
		try (OutputStream outputStream = new BufferedOutputStream(new FileOutputStream(file))){
			byte[] b = new byte[1024];
			int count = inputStream.read(b);
			while (count != -1) {

				outputStream.write(b, 0, count);
				count = inputStream.read(b);
			}
			outputStream.flush();
		} catch (Exception ex) {
			// modify by ranphy 内存问题
			logger.error(ex.getMessage(), ex);
		}
	}

	/**
	 * 获取web项目根HttpUrl
	 *
	 * @param request
	 * @return
	 */
	public static String getWebRootUrl(HttpServletRequest request) {

		// 获取项目路径
		String WebRootUrl = request.getScheme() + "://" + request.getServerName();
		int port = request.getServerPort();
		String portInfo = "";
		if (port != 80) portInfo += ":" + port;
		WebRootUrl += portInfo + request.getContextPath();
		return WebRootUrl;
	}

	/**
	 * 判断浏览器
	 *
	 * @param request
	 * @return
	 */
	public static String getBrowser(HttpServletRequest request) {
		String UserAgent = request.getHeader("USER-AGENT").toLowerCase();
		if (UserAgent != null) {
			if (UserAgent.indexOf("msie") >= 0) {
				return "IE";
			}

			if (UserAgent.indexOf("firefox") >= 0) {
				return "FF";
			}

			if (UserAgent.indexOf("safari") >= 0) {
				return "SF";
			}

		}
		return null;
	}

	/**
	 * 获取web项目根HttpUrl,不带项目名称
	 *
	 * @param request
	 * @return
	 */
	public static String getWebRootUrlNotProjectName(HttpServletRequest request) {

		// 获取项目路径
		String WebRootUrl = request.getScheme() + "://" + request.getServerName();
		int port = request.getServerPort();
		String portInfo = "";
		if (port != 80) portInfo += ":" + port;
		WebRootUrl += portInfo;
		return WebRootUrl;
	}

	/**
	 * 获取一个request的完整URL
	 *
	 * @param request
	 * @return
	 */
	public static String getRequestUrl(HttpServletRequest request, String sperator) {

		StringBuilder reqUrl = new StringBuilder();
		reqUrl.append(request.getServletPath());
		reqUrl.append("$1=1");
		Enumeration<String> paramNameArray = request.getParameterNames();
		String paramName = null;
		while (paramNameArray.hasMoreElements()) {

			reqUrl.append(sperator);
			paramName = paramNameArray.nextElement();
			reqUrl.append(paramName);
			reqUrl.append("=");
			reqUrl.append(request.getParameter(paramName));
		}

		return reqUrl.toString();
	}

	/**
	 * 获取当前ip
	 *
	 * @author fanhy
	 * @since 2015年11月11日
	 * @param request
	 * @return
	 */
	public static String getRequestIp(HttpServletRequest request) {

		// 获取请求主机IP地址,如果通过代理进来，则透过防火墙获取真实IP地址
		String ip = request.getHeader("X-Forwarded-For");

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("HTTP_CLIENT_IP");
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader("HTTP_X_FORWARDED_FOR");
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
		} else if (ip.length() > 15) {
			String[] ips = ip.split(",");
			for (int index = 0; index < ips.length; index++) {
				String strIp = ips[index];
				if (!("unknown".equalsIgnoreCase(strIp))) {
					ip = strIp;
					break;
				}
			}
		}
		return ip;
	}

	/**
	 * 发送证书
	 *
	 */
	/*public static String sendPost(String reqURL, String sendData, String certFile,
	                              String encodeCharset) {

		CloseableHttpClient httpClient = null;
		FileInputStream instream=null;
		try {

			WechatConfig configVo = WeChatConfigUtil.getWechatConfig();
			KeyStore keyStore = KeyStore.getInstance("PKCS12");
			instream = new FileInputStream(certFile);
			keyStore.load(instream, configVo.getMch_id().toCharArray());
			SSLContext sslcontext = SSLContexts.custom()
					.loadKeyMaterial(keyStore, configVo.getMch_id().toCharArray()).build();
			// 只允许使用TLSv1协议
			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext,
					new String[] { "TLSv1" }, null,
					SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
			httpClient = HttpClients.custom().setSSLSocketFactory(sslsf).build();

			HttpPost httpPost = new HttpPost(reqURL);
			httpPost.setEntity(new StringEntity(sendData, encodeCharset == null ? UTF8
					: encodeCharset));
			httpPost.addHeader("content-type", "application/json");
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			if (null != entity) {

				byte[] byteArray = EntityUtils.toByteArray(entity);
				String responseContent = new String(byteArray, UTF8);
				EntityUtils.consume(entity);
				return responseContent;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(httpClient!=null){
					httpClient.close();
				}
				if(instream!=null){
					instream.close();
				}
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			} finally {
				httpClient = null;
			}
		}

		return "-1";
	}*/

	private static class TrustAnyTrustManager implements X509TrustManager {

		@Override
		public void checkClientTrusted(X509Certificate[] chain, String authType)
				throws CertificateException {
			//DO
		}
		@Override
		public void checkServerTrusted(X509Certificate[] chain, String authType)
				throws CertificateException {
			//DO
		}
		@Override
		public X509Certificate[] getAcceptedIssuers() {
			return new X509Certificate[1];
		}
	}

	private static class TrustAnyHostnameVerifier implements HostnameVerifier {
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	}

}
