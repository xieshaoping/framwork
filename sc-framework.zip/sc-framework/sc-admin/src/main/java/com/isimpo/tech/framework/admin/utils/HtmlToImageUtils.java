package com.isimpo.tech.framework.admin.utils;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Calendar;
import java.util.UUID;
import javax.imageio.ImageIO;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicEditorPaneUI;

/**
 * html转图片工具类
 * @author wangxinhai
 */
public class HtmlToImageUtils {

    @Value("${htmlToJpg.url}")
    String uploadPath;
    /**
     * 上传路径
     */
    private String path;

    /**
     * html转换为ｊｐｅｇ文件
     *
     * @param bgColor
     *            图片的背景色
     * @param html
     *            html的文本信息
     * @param width
     *            显示图片的Ｔｅｘｔ容器的宽度
     * @param height
     *            显示图片的Ｔｅｘｔ容器的高度
     * @param eb
     *            設置容器的边框
     * @return
     * @throws Exception
     */
    @SuppressWarnings("restriction")
    public String html2jpeg(Color bgColor, String html, int width, int height, EmptyBorder eb) throws Exception {
        Calendar rightNow = Calendar.getInstance();
        Integer year = rightNow.get(Calendar.YEAR);
        Integer month = rightNow.get(Calendar.MONTH) + 1;
        Integer day = rightNow.get(Calendar.DAY_OF_MONTH);
        String xdPath = year.toString() + File.separator + month.toString() + File.separator + day.toString();
        String picturePath = "";
        picturePath = "D:/upload" + "\\" + xdPath+ File.separator + "picture" +File.separator  + UUID.randomUUID().toString() + ".jpg";;
        JTextPane tp = new JTextPane();
        tp.setSize(width, height);
        if (eb == null) {
            eb = new EmptyBorder(0, 50, 0, 50);
        }
        if (bgColor != null) {
            tp.setBackground(bgColor);
        }
        if (width <= 0) {
            width = DEFAULT_IMAGE_WIDTH;
        }
        if (height <= 0) {
            height = DEFAULT_IMAGE_HEIGHT;
        }
        tp.setBorder(eb);
        tp.setContentType("text/html");
        tp.setText(html);

        int pageIndex = 1;
        boolean bcontinue = true;
        String resUrl = "";
        byte[] bytes = null;
        while (bcontinue) {
            BufferedImage image = new BufferedImage(width,
                    height, BufferedImage.TYPE_INT_RGB);
            Graphics g = image.getGraphics();
            g.setClip(0, 0, width, height);
            bcontinue = paintPage(g, height, pageIndex, tp);
            g.dispose();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(image, "jpg", baos);

            baos.flush();
            bytes = baos.toByteArray();
            baos.close();
            FileUtils.writeByteArrayToFile(new File(picturePath), bytes);
            //
            pageIndex++;
        }
        return picturePath;
    }

    public static int DEFAULT_IMAGE_WIDTH = 1200;
    public static int DEFAULT_IMAGE_HEIGHT = 700;
    public static boolean paintPage(Graphics g, int hPage, int pageIndex, JTextPane panel) {
        Graphics2D g2 = (Graphics2D) g;
        Dimension d = ((BasicEditorPaneUI) panel.getUI()).getPreferredSize(panel);
        double panelHeight = d.height;
        double pageHeight = hPage;
        int totalNumPages = (int) Math.ceil(panelHeight / pageHeight);
        g2.translate(0f, -(pageIndex - 1) * pageHeight);
        panel.paint(g2);
        boolean ret = true;

        if (pageIndex >= totalNumPages) {
            ret = false;
            return ret;
        }
        return ret;
    }

    public static void main(String[] args){
        try {
            new HtmlToImageUtils().html2jpeg(Color.white, "",
                    1300, 1200, new EmptyBorder(0, 0,
                            0, 0));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
