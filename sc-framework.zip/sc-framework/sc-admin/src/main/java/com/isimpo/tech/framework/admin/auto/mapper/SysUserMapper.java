package com.isimpo.tech.framework.admin.auto.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.isimpo.tech.framework.admin.auto.entity.SysUser;
import com.isimpo.tech.framework.admin.auto.entity.SysUserRole;
import com.isimpo.tech.framework.common.util.Query;

import tk.mybatis.mapper.common.Mapper;

public interface SysUserMapper extends Mapper<SysUser> {

    /**
     * 查询用户列表
     *
     * @param query 查询参数
     * @return List<SysUser> 用户列表
     */
    List<SysUser> findList(Query query);


    /**
     *根据登录名查询是否存在用户
     *
     * @param loginName 登录名
     * @return int >0 存在
     */
    int checkLoginName(String loginName);

    /**
     * 物理删除此用户所有的用户角色
     *
     * @param id 用户id
     */
    void deleteRoleByUserId(String id);


    /**
     * 保存用户角色信息
     *
     * @param userRoles 用户角色信息
     */
    void saveUserRole(List<SysUserRole> userRoles);


    /**
     * 根据用户id查询每个用户的角色id集合
     *
     * @param id  用户id
     * @return  List<String>  角色id集合
     */
    List<String> getRoleListByUserId(Object id);
    /**
     * 检查用户密码是否正确
     *
     * @param userName    用户名
     * @param password 旧密码
     * @return 记录数
     */
    int checkPassword(@Param("userName") String userName, @Param("password") String password);
    /**
     * 根据用户名获取用户信息
     *
     * @param user 用户名
     * @return SysUser 用户信息
     */

    SysUser getUserByUsername(SysUser user);


    String findTeacherId(SysUser newUser);

    int checkPhone(SysUser newUser);

    SysUser selectUserById(String id);
}