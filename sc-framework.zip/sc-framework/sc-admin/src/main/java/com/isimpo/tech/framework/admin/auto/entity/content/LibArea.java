package com.isimpo.tech.framework.admin.auto.entity.content;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Transient;
import java.util.List;

public class LibArea {
    /**
     * 主键
     */
    @Id
    private String id;

    private String value;

    private String label;

    /**
     * 上级id
     */
    private String parentId;

    private String type;


    @Transient
    private List<LibArea> children;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<LibArea> getChildren() {
        return children;
    }

    public void setChildren(List<LibArea> children) {
        this.children = children;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}