/*
 * Copyright (c) 2016年, SIMPO Technology. All Rights Reserved.
 * SIMPO Technology. CONFIDENTIAL
 */
package com.isimpo.tech.framework.admin.contorller.sys;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isimpo.tech.framework.admin.auto.entity.SysRole;
import com.isimpo.tech.framework.admin.service.sys.SysRoleService;
import com.isimpo.tech.framework.common.constant.CommonConstants;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;


/**
 * 角色管理controller
 *
 * @author huangzj
 * @version 1.0
 * @since 2017/12/22
 */
@RestController
@RequestMapping("/sys/role")
public class SysRoleController extends BaseController<SysRoleService, SysRole> {

    @GetMapping("/page")
    @Override
    public AjaxResponse list(@RequestParam Map<String, Object> params) {
        Map<String, String> orderByMap = new HashMap<>();
        orderByMap.put("addTime", CommonConstants.ORDER_BY_DESC);
        params.put(CommonConstants.ORDER_BY_PARAM, orderByMap);
        return super.list(params);
    }

    /**
     * 根据角色名称和角色id判断角色是否重复
     *
     * @param name 角色名称
     * @param id 角色id
     * @return AjaxResponse
     */
    @GetMapping("/checkName")
    public AjaxResponse checkName(@RequestParam  String name,@RequestParam String id) {
        return AjaxResponse.of(baseService.checkName(name,id));
    }
}
