package com.isimpo.tech.framework.admin.contorller.content.libPlace;

import com.isimpo.tech.framework.admin.auto.entity.content.LibItem;
import com.isimpo.tech.framework.admin.auto.entity.content.LibSupp;
import com.isimpo.tech.framework.admin.service.content.libPlace.LibItemService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import org.springframework.web.bind.annotation.*;


/**
 * 行程事项
 * @author wangxinhai
 * @version V1.0
 * @since 2019/2/18
 */
@RestController
@RequestMapping("/content/libItem")
public class LibItemController extends BaseController<LibItemService, LibItem> {


    /**
     * 增加
     * @param entity
     * @return
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResponse add(@RequestBody LibItem entity) {
        baseService.insertSelective(entity);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    @Override
    @DeleteMapping("/{id}")
    @ResponseBody
    public AjaxResponse remove(@PathVariable String id) {
        baseService.deleteById(id);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 行程补充添加
     * @param traSupp
     * @return
     */
    @ResponseBody
    @PostMapping("/addLibSupp")
    public AjaxResponse addTraSupp(@RequestBody LibSupp traSupp){
        return baseService.addTraSupp(traSupp);
    }

    /**
     * 行程补充修改
     * @param traSupp
     * @return
     */
    @ResponseBody
    @PostMapping("/updateLibSupp")
    public AjaxResponse updateTraSupp(@RequestBody LibSupp traSupp){
        return baseService.updateTraSupp(traSupp);
    }

    /**
     * 行程补充删除
     * @param id
     * @return
     */
    @ResponseBody
    @GetMapping("/delLibSupp")
    public AjaxResponse delTraSupp(String id){
        return baseService.delTraSupp(id);
    }

    /**
     * 行程补充详情
     * @param id
     * @return
     */
    @GetMapping("/getLibSupp")
    public AjaxResponse getTraSupp(String id){
        return AjaxResponse.of(baseService.getLibSupp(id));
    }
}
