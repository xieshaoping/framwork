package com.isimpo.tech.framework.admin.contorller.content.libPlace;

import com.isimpo.tech.framework.admin.auto.entity.content.LibPlace;
import com.isimpo.tech.framework.admin.service.content.libPlace.LibPlaceService;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.controller.BaseController;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.util.Query;
import org.aspectj.weaver.loadtime.Aj;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.Map;

/**
 * 地区信息库Controller
 * @Witer wxh
 * @Date 2019/6/26
 */
@RestController
@ResponseBody
@RequestMapping("/content/libPlace")
public class LibPlaceController extends BaseController<LibPlaceService, LibPlace> {

    /**
     * 获取区域
     * @param map
     * @return
     */
    @PostMapping("/getPlaceList")
    public AjaxResponse getMemberList(@RequestBody Map map) {
        Query query = new Query(map);
        return AjaxResponse.of(baseService.selectByQuery(query));
    }

    /**
     * 校验地点名称是否重复
     * @param name
     * @return
     */
    @GetMapping("/checkName")
    @ResponseBody
    public AjaxResponse checkName(String name) {
        return baseService.checkName(name);
    }

    /**
     * 查询区域
     * @return
     */
    @GetMapping("findAreaList")
    @ResponseBody
    public AjaxResponse findAreaList() {
        return AjaxResponse.of(baseService.findAreaList());
    }

    /**
     * 获取地点事项补充列表
     * @param id
     * @return
     */
    @GetMapping("/findLibPlaceItemSuppList")
    public AjaxResponse findLibPlaceItemSuppList(String id) {
        return AjaxResponse.of(baseService.findLibPlaceItemSuppList(id));
    }

    /**
     * 增加
     * @param entity
     * @return
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResponse add(@RequestBody LibPlace entity) {
        baseService.insertSelective(entity);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }

    /**
     * 逻辑删除
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    @ResponseBody
    @Override
    public AjaxResponse remove(@PathVariable String id) {
        baseService.deleteById(id);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }


    /**
     * 信息库选择地点
     * @param libPlace
     * @return
     */
    @PostMapping("/placeListChoo")
    public AjaxResponse placeListChoo(@RequestBody LibPlace libPlace) throws ParseException {
        baseService.placeListChoo(libPlace);
        return AjaxResponse.of(ResponseCode.SUCCESS);
    }


}
