package com.isimpo.tech.framework.admin.service.content.cocoCard;

import com.isimpo.tech.framework.admin.auto.entity.content.cocoCard.CocoCard;
import com.isimpo.tech.framework.admin.auto.mapper.content.cocoCard.CocoCardMapper;
import com.isimpo.tech.framework.admin.utils.SensitiveWordUtils;
import com.isimpo.tech.framework.common.constant.ResponseCode;
import com.isimpo.tech.framework.common.response.AjaxResponse;
import com.isimpo.tech.framework.common.service.BaseService;
import com.isimpo.tech.framework.common.util.EntityUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CocoCardService extends BaseService<CocoCardMapper, CocoCard> {

    /**
     * 获取可乐名片详细信息
     *
     * @return
     */
    public CocoCard getCocoCard() {
        return mapper.getCocoCard();
    }

    /**
     * 修改可乐名片信息
     *
     * @param cocoCard
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public AjaxResponse updateCocoCard(CocoCard cocoCard) {
        // 敏感词过滤
        cocoCard.setIntroduction(SensitiveWordUtils.filterStr(cocoCard.getIntroduction()));
        int result = 0;
        if (StringUtils.isNotEmpty(cocoCard.getId())) {
            result = mapper.updateCocoCard(cocoCard);
        } else {
            EntityUtils.setCreatAndUpdatInfo(cocoCard);
            result = mapper.insertCocoCard(cocoCard);
        }
        if (result > 0) {
            return AjaxResponse.of(ResponseCode.SUCCESS);
        }
        return AjaxResponse.of(ResponseCode.FAIL);
    }

}
