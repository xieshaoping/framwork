package com.isimpo.tech.framework.admin.contorller.content.strategy;

import com.isimpo.tech.framework.admin.auto.entity.content.strategy.StrategyVo;
import com.isimpo.tech.framework.admin.service.content.strategy.StrategyService;
import com.isimpo.tech.framework.common.controller.BaseController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhuyilong
 * @since 2019/2/25
 */
@RestController
@RequestMapping("/strategy")
public class StrategyController extends BaseController<StrategyService, StrategyVo> {

}
